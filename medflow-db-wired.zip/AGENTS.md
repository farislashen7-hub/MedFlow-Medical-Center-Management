This is a Vite + React 19 + TypeScript web app (Capacitor wraps it for Android). It is NOT an Expo project.

## Data rules

- Supabase is the only source of truth. Do not add seed or mock data; read/write through `src/store.tsx` and `src/lib/remote-data.ts`.
- Schema changes go in a new file under `supabase/migrations/`; add RLS for every new table and add it to the realtime publication.
- Secrets (`SUPABASE_SERVICE_ROLE_KEY`, `N8N_WEBHOOK_SECRET`, `PASSWORD_RESET_SECRET`) are server-only: never prefix with `VITE_`.
- n8n is reached only through `/api/n8n` (same-origin); default webhook paths are in `api/_lib/n8n.js`.

## Commands

```bash
npm run typecheck && npm run build
```
