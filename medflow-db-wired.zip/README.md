# Medflow — مركز ميدفلو الطبي

A production-ready, Arabic-first (RTL) medical-center web application built with **React 19**, **TypeScript**, **Vite 7**, **Tailwind CSS v4**, **React Router v7**, **Framer Motion**, **Lucide**, **html2canvas**, and **Supabase**. It includes public landing pages, a four-step booking flow, role-based patient/doctor/admin workspaces, WhatsApp automation through n8n, and Vercel serverless functions.

> **Supabase is the single source of truth.** Doctors, specialties, schedules, offers, reviews, appointments, prescriptions and center info are all read from (and written to) the database. There is no seed data and no offline mode: without `VITE_SUPABASE_*` the app shows a configuration error.

## Features

- Pixel-tuned RTL medical-center landing page with the supplied brand/ink design tokens, IBM Plex Sans Arabic and Tajawal typography, doctor cards, offers, reviews, dark process band, and conversion CTA.
- Public routes: `/`, `/specialties`, `/doctors`, `/reviews`, `/contact`, and `/staff`.
- Authentication: `/login`, `/register`, `/forgot-password`, with protected role routes.
- Four-step appointment wizard: specialty → doctor → date/time → patient details.
- Patient portal: appointments, prescriptions, follow-up, reviews, and editable profile; prescription PDF/print and invoice printing.
- Doctor portal: today/upcoming schedules, patient files, appointment management, attendance, analytics, reviews, prescription-to-image WhatsApp flow, and **عندي ظرف** emergency cancellation.
- Admin portal: overview, activity log, doctor/schedule/attendance management, appointments, WhatsApp conversations, reports, campaigns, reviews, and center settings.
- Data loaded from Supabase on start (session first, so RLS decides what each role sees) and kept live through realtime on 13 tables.
- Strict writes for bookings, prescriptions and reviews (UI shows the error if the DB rejects it); retry queue only for low-stakes rows (activity log, attendance, leaves).
- Same-origin Vercel APIs for n8n notifications, atomic booking cancellation, and secure password reset.

## Tech

- React 19 + React DOM 19
- TypeScript 5 (strict)
- Vite 7
- Tailwind CSS v4 (`@theme` tokens and Vite plugin)
- React Router DOM v7
- Framer Motion
- Lucide React
- html2canvas + jsPDF
- Supabase JS
- Vercel SPA rewrites and Node.js serverless functions

## Local development

```bash
npm install
cp .env.example .env.local   # required: VITE_SUPABASE_URL + VITE_SUPABASE_PUBLISHABLE_KEY
npm run dev
```

Production check:

```bash
npm run typecheck
npm run build
npm run preview
```

### Accounts

Accounts live in Supabase Auth. Create users in **Dashboard → Authentication → Users** (or via `/register`), then promote them in SQL:

```sql
update medflow.profiles set role = 'admin'  where email = 'you@example.com';
update medflow.profiles set role = 'doctor', doctor_id = 'd1' where email = 'doctor@example.com';
```

## Environment

Copy `.env.example` and configure:

```dotenv
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_your_key
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
N8N_WEBHOOK_BASE=https://n8n.example.com/webhook
N8N_WEBHOOK_SECRET=replace_with_a_long_random_secret
PASSWORD_RESET_SECRET=replace_with_another_long_random_secret
DEFAULT_GULF_CC=966
```

Only the `VITE_` values are exposed to the browser. Service-role, n8n, and reset secrets are server-only and must never use a `VITE_` prefix.

### Supabase migration

Run `supabase/migrations/202611150001_medflow_schema.sql` once. Everything lives in the `medflow` schema (safe to share a project with other apps); then add `medflow` under Project Settings → API → Exposed schemas. It creates:

- `appointments`, `patients`, and `profiles`
- `doctor_schedules`, `doctor_attendance`, and `doctor_leaves`
- `offer_campaigns` and deduplicated `offer_recipients`
- `rate_limits` plus the `rate_hit(key, limit_count, window_seconds)` RPC
- `appointment_cancellations` and its status-change trigger
- server-only `password_resets`
- RLS policies, staff helpers, and realtime publication entries

The third migration adds `center_settings`, `is_admin()`, the public `booked_slots()` RPC (taken times without patient data), one schedule row per doctor, realtime for every synced table, and replaces the open `using (true)` policies with role-based ones: staff see everything, patients only their own appointments/prescriptions, the public only doctors/specialties/offers/schedules/reviews/center info.

The partial unique index on `doctor_id + appointment_date + appointment_time` prevents double-booking while allowing a cancelled slot to be reused. A unique-constraint error (`23505`) is surfaced to the booking UI as `slot_taken`.

## WhatsApp / n8n flow

```text
Browser → POST /api/n8n → n8n Webhook (x-webhook-secret) → Evolution API → WhatsApp
```

The browser never receives the n8n secret or Evolution credentials. `notifyN8n` sends `{ event, payload, ts }` and uses these paths:

| Event | Default path |
|---|---|
| `appointment.created`, `appointment.reminder` | `app-booking` |
| `appointment.cancelled` | `app-cancel-booking` |
| `appointment.rebooked` | `app-Rebooking` |
| `prescription.issued` | `app-Treatment` |
| `doctor.unavailable` | `app-not-available` |
| `offer.broadcast` | `app-offer` |
| `report.send` | `app-report` |
| `review.submitted` | `app-review` |
| rating ≤ 2 review | `review.negative` |
| `patient.password_reset` | `app-password-reset` |

Every path can be overridden with its `N8N_PATH_*` environment variable. An importable starter workflow (path `app-booking`) is provided at [`n8n/medflow-whatsapp.json`](n8n/medflow-whatsapp.json). Select a **Header Auth** credential (Name `x-webhook-secret`, same value as `N8N_WEBHOOK_SECRET`), fill `YOUR_EVOLUTION_HOST`, `YOUR_INSTANCE`, `YOUR_EVOLUTION_APIKEY`, and duplicate the workflow for each path. In n8n the request body is under `$json.body` (`$json.body.event`, `$json.body.payload.phone_wa`). Always end with a **Respond to Webhook** node, or the API reports a 502 after 12 s.

Failure isolation is intentional: booking succeeds locally even if n8n is unavailable. The API returns `503` for an unconfigured n8n service and `502` for an upstream failure; the client toast reports the notification state without rolling back the booking.

## Server APIs

### `POST /api/n8n`

- POST only, same-origin only
- Event allowlist and 4.2 MB body cap
- 120 requests / 10 minutes / IP
- Responses: `200`, `400`, `403`, `413`, `422`, `429`, `502`, `503`

```bash
curl -i http://localhost:5173/api/n8n \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://localhost:5173' \
  -d '{"event":"appointment.created","payload":{"appointment_id":"apt_test","phone":"966501234567"}}'
```

### `POST /api/cancel-booking`

- Same-origin, 20 requests / 10 minutes / IP
- Requires the phone number to match the booking
- Rejects completed or past bookings with `409`
- Uses an atomic `.neq('status', 'cancelled')` update
- Records cancellation and notifies n8n

```bash
curl -i http://localhost:5173/api/cancel-booking \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://localhost:5173' \
  -d '{"appointment_id":"apt_101","phone":"0501234567","cancelled_by":"patient"}'
```

### `POST /api/password-reset`

Actions:

```json
{ "action": "request", "phone": "0501234567" }
```

```json
{ "action": "verify", "phone": "0501234567", "code": "123456", "password": "new-strong-password" }
```

The code is a random 6-digit value, expires after 10 minutes, allows 5 attempts, enforces a 60-second cooldown and 3 requests / 15 minutes / phone. Only an HMAC digest is stored. Verification uses `timingSafeEqual`, updates the Supabase Auth password, and returns a fresh session for automatic sign-in.

```bash
curl -i http://localhost:5173/api/password-reset \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://localhost:5173' \
  -d '{"action":"request","phone":"0501234567"}'
```

## Phone normalization

`src/lib/phone.ts` and `api/_lib/phone.js` implement identical rules:

- Egypt: `01[0125]xxxxxxxx`
- Saudi Arabia: 9 digits beginning with `5`
- UAE: prefixes `50`, `52`, `54`, `55`, `56`, `58`
- Kuwait, Qatar, Bahrain, Oman: 8 digits
- Default country code: `966` (`DEFAULT_GULF_CC`)

## Deployment

The repository includes [`vercel.json`](vercel.json), which:

1. Builds the Vite SPA into `dist`.
2. Rewrites non-`/api` routes to `/index.html` for client-side routing.
3. Deploys `api/**/*.js` as Node.js 20 serverless functions.

```bash
npm run build
npx vercel --prod
```

Add the server and browser environment variables in the Vercel project settings. Never expose `SUPABASE_SERVICE_ROLE_KEY`, `N8N_WEBHOOK_SECRET`, or `PASSWORD_RESET_SECRET` to the browser.
