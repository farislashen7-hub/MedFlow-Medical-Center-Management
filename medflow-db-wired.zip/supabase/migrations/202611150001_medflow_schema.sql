-- Medflow lives in its own schema `medflow`, so it can share one Supabase project
-- with other apps without touching their `public` tables. Run this file once.
-- After running: Dashboard > Project Settings > API > Exposed schemas > add `medflow`.

create schema if not exists medflow;
grant usage on schema medflow to anon, authenticated, service_role;
create extension if not exists pgcrypto;

-- Medflow Supabase schema (run in the Supabase SQL editor)

create table if not exists medflow.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'patient' check (role in ('admin','doctor','patient')),
  doctor_id text,
  phone text,
  email text,
  created_at timestamptz not null default now()
);

create or replace function medflow.medflow_handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = medflow
as $$
begin
  insert into medflow.profiles (id, full_name, role, phone, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', ''), 'patient', new.raw_user_meta_data->>'phone', new.email)
  on conflict (id) do update set full_name = excluded.full_name, phone = excluded.phone;
  return new;
end;
$$;

drop trigger if exists medflow_on_auth_user_created on auth.users;
create trigger medflow_on_auth_user_created
after insert on auth.users
for each row execute function medflow.medflow_handle_new_user();

create table if not exists medflow.patients (
  id text primary key,
  full_name text not null,
  email text,
  phone text not null,
  created_at timestamptz not null default now()
);

create table if not exists medflow.appointments (
  id text primary key,
  patient_id text not null,
  patient_name text not null,
  phone text not null,
  doctor_id text not null,
  specialty_id text not null,
  appointment_date date not null,
  appointment_time time not null,
  status text not null default 'confirmed' check (status in ('confirmed','pending','completed','cancelled')),
  notes text,
  cancelled_by text check (cancelled_by in ('patient','staff','doctor')),
  cancelled_at timestamptz,
  created_at timestamptz not null default now()
);

create unique index if not exists appointments_doctor_slot_unique
  on medflow.appointments (doctor_id, appointment_date, appointment_time)
  where status <> 'cancelled';

create table if not exists medflow.doctor_schedules (
  id uuid primary key default gen_random_uuid(),
  doctor_id text not null,
  day_of_week text not null,
  starts_at time not null,
  ends_at time not null,
  slots jsonb not null default '[]'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists medflow.doctor_attendance (
  doctor_id text not null,
  attendance_date date not null,
  status text not null check (status in ('present','absent','leave')),
  note text,
  created_at timestamptz not null default now(),
  primary key (doctor_id, attendance_date)
);

create table if not exists medflow.doctor_leaves (
  id text primary key,
  doctor_id text not null,
  start_date date not null,
  end_date date not null,
  reason text not null,
  created_at timestamptz not null default now()
);

create table if not exists medflow.offer_campaigns (
  id text primary key,
  offer_id text not null,
  title text not null,
  recipient_count integer not null default 0,
  status text not null default 'staged',
  created_at timestamptz not null default now()
);

create table if not exists medflow.offer_recipients (
  id bigint generated always as identity primary key,
  campaign_id text not null references medflow.offer_campaigns(id) on delete cascade,
  phone text not null,
  status text not null default 'staged',
  sent_at timestamptz,
  unique (campaign_id, phone)
);

create table if not exists medflow.rate_limits (
  key text primary key,
  hits integer not null default 0,
  window_started_at timestamptz not null default now()
);

create or replace function medflow.rate_hit(key text, limit_count integer, window_seconds integer)
returns boolean
language plpgsql
security definer
set search_path = medflow
as $$
declare
  current_window timestamptz;
  current_hits integer;
begin
  select window_started_at, hits into current_window, current_hits
    from medflow.rate_limits where medflow.rate_limits.key = rate_hit.key
    for update;

  if current_window is null or current_window < now() - make_interval(secs => window_seconds) then
    insert into medflow.rate_limits(key, hits, window_started_at)
      values (rate_hit.key, 1, now())
      on conflict (key) do update set hits = 1, window_started_at = now();
    return true;
  end if;

  if current_hits >= limit_count then
    return false;
  end if;

  update medflow.rate_limits set hits = hits + 1 where medflow.rate_limits.key = rate_hit.key;
  return true;
end;
$$;

revoke all on function medflow.rate_hit(text, integer, integer) from public, anon, authenticated;
grant execute on function medflow.rate_hit(text, integer, integer) to service_role;

create table if not exists medflow.appointment_cancellations (
  id bigint generated always as identity primary key,
  appointment_id text not null,
  phone text not null,
  cancelled_by text not null check (cancelled_by in ('patient','staff','doctor')),
  cancelled_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);

create or replace function medflow.log_appointment_cancellation()
returns trigger
language plpgsql
security definer
set search_path = medflow
as $$
begin
  if new.status = 'cancelled' and (old.status is distinct from 'cancelled') then
    insert into medflow.appointment_cancellations(appointment_id, phone, cancelled_by)
      values (new.id, new.phone, coalesce(new.cancelled_by, 'staff'));
  end if;
  return new;
end;
$$;

drop trigger if exists appointments_cancellation_trigger on medflow.appointments;
create trigger appointments_cancellation_trigger
after update of status on medflow.appointments
for each row execute function medflow.log_appointment_cancellation();

-- Server-only reset records. The service role bypasses RLS; no client role is granted access.
create table if not exists medflow.password_resets (
  phone text primary key,
  code_hash text not null,
  attempts integer not null default 0,
  used boolean not null default false,
  requested_at timestamptz not null default now(),
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);
revoke all on medflow.password_resets from anon, authenticated;

-- RLS helpers and policies
create or replace function medflow.is_staff()
returns boolean
language sql
stable
security definer
set search_path = medflow
as $$
  select exists (
    select 1 from medflow.profiles
    where id = auth.uid() and role in ('admin','doctor')
  );
$$;

alter table medflow.profiles enable row level security;
alter table medflow.patients enable row level security;
alter table medflow.appointments enable row level security;
alter table medflow.doctor_schedules enable row level security;
alter table medflow.doctor_attendance enable row level security;
alter table medflow.doctor_leaves enable row level security;
alter table medflow.offer_campaigns enable row level security;
alter table medflow.offer_recipients enable row level security;
alter table medflow.appointment_cancellations enable row level security;

drop policy if exists "profiles own or staff" on medflow.profiles;
create policy "profiles own or staff" on medflow.profiles for select using (id = auth.uid() or medflow.is_staff());
drop policy if exists "staff manage profiles" on medflow.profiles;
create policy "staff manage profiles" on medflow.profiles for all using (medflow.is_staff()) with check (medflow.is_staff());

drop policy if exists "patients anon insert" on medflow.patients;
create policy "patients anon insert" on medflow.patients for insert with check (true);
drop policy if exists "patients staff read" on medflow.patients;
create policy "patients staff read" on medflow.patients for select using (medflow.is_staff());

drop policy if exists "appointments anon insert" on medflow.appointments;
create policy "appointments anon insert" on medflow.appointments for insert with check (true);
drop policy if exists "appointments staff read" on medflow.appointments;
create policy "appointments staff read" on medflow.appointments for select using (medflow.is_staff());
drop policy if exists "appointments staff update" on medflow.appointments;
create policy "appointments staff update" on medflow.appointments for update using (medflow.is_staff()) with check (medflow.is_staff());

drop policy if exists "schedules public read" on medflow.doctor_schedules;
create policy "schedules public read" on medflow.doctor_schedules for select using (true);
drop policy if exists "schedules staff write" on medflow.doctor_schedules;
create policy "schedules staff write" on medflow.doctor_schedules for all using (medflow.is_staff()) with check (medflow.is_staff());

drop policy if exists "attendance staff read" on medflow.doctor_attendance;
create policy "attendance staff read" on medflow.doctor_attendance for select using (medflow.is_staff());
drop policy if exists "attendance staff write" on medflow.doctor_attendance;
create policy "attendance staff write" on medflow.doctor_attendance for all using (medflow.is_staff()) with check (medflow.is_staff());

drop policy if exists "leaves staff read" on medflow.doctor_leaves;
create policy "leaves staff read" on medflow.doctor_leaves for select using (medflow.is_staff());
drop policy if exists "leaves staff write" on medflow.doctor_leaves;
create policy "leaves staff write" on medflow.doctor_leaves for all using (medflow.is_staff()) with check (medflow.is_staff());

drop policy if exists "campaigns staff" on medflow.offer_campaigns;
create policy "campaigns staff" on medflow.offer_campaigns for all using (medflow.is_staff()) with check (medflow.is_staff());
drop policy if exists "recipients staff" on medflow.offer_recipients;
create policy "recipients staff" on medflow.offer_recipients for all using (medflow.is_staff()) with check (medflow.is_staff());
drop policy if exists "cancellations staff" on medflow.appointment_cancellations;
create policy "cancellations staff" on medflow.appointment_cancellations for select using (medflow.is_staff());

-- Realtime
alter publication supabase_realtime add table medflow.appointments;
alter publication supabase_realtime add table medflow.doctor_schedules;
alter publication supabase_realtime add table medflow.doctor_attendance;
alter publication supabase_realtime add table medflow.doctor_leaves;

-- Live application data and public read/write policies for Medflow.
create table if not exists medflow.prescriptions (
  id text primary key,
  appointment_id text,
  patient_id text,
  doctor_id text not null,
  date date not null default current_date,
  diagnosis text not null,
  medications text not null,
  instructions text,
  sent_to_whatsapp boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists medflow.reviews (
  id text primary key,
  patient_id text,
  patient_name text not null,
  doctor_id text not null,
  rating integer not null check (rating between 1 and 5),
  text text not null,
  date date not null default current_date,
  verified boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists medflow.offers (
  id text primary key,
  title text not null,
  description text,
  old_price numeric(10,2) not null default 0,
  price numeric(10,2) not null default 0,
  badge text,
  theme text not null default 'brand' check (theme in ('brand','amber','sky')),
  expires date,
  created_at timestamptz not null default now()
);

create table if not exists medflow.activities (
  id text primary key,
  type text not null default 'system' check (type in ('booking','review','prescription','offer','system')),
  text text not null,
  at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists medflow.conversations (
  id text primary key,
  phone text not null,
  name text not null,
  last_message text,
  at timestamptz not null default now(),
  unread integer not null default 0,
  status text not null default 'active' check (status in ('active','pending')),
  created_at timestamptz not null default now()
);

create table if not exists medflow.specialties (
  id text primary key,
  name text not null,
  description text,
  icon text,
  tint text,
  count integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists medflow.doctors (
  id text primary key,
  name text not null,
  specialty_id text,
  title text,
  experience integer not null default 0,
  rating numeric(2,1) not null default 0,
  reviews integer not null default 0,
  image text,
  location text,
  phone text,
  bio text,
  working_hours text,
  created_at timestamptz not null default now()
);

alter table medflow.prescriptions enable row level security;
alter table medflow.reviews enable row level security;
alter table medflow.offers enable row level security;
alter table medflow.activities enable row level security;
alter table medflow.conversations enable row level security;
alter table medflow.specialties enable row level security;
alter table medflow.doctors enable row level security;

drop policy if exists "live prescriptions read" on medflow.prescriptions;
create policy "live prescriptions read" on medflow.prescriptions for select using (true);
drop policy if exists "live prescriptions write" on medflow.prescriptions;
create policy "live prescriptions write" on medflow.prescriptions for all using (true) with check (true);

drop policy if exists "live reviews read" on medflow.reviews;
create policy "live reviews read" on medflow.reviews for select using (true);
drop policy if exists "live reviews write" on medflow.reviews;
create policy "live reviews write" on medflow.reviews for all using (true) with check (true);

drop policy if exists "live offers read" on medflow.offers;
create policy "live offers read" on medflow.offers for select using (true);
drop policy if exists "live offers write" on medflow.offers;
create policy "live offers write" on medflow.offers for all using (true) with check (true);

drop policy if exists "live activities read" on medflow.activities;
create policy "live activities read" on medflow.activities for select using (true);
drop policy if exists "live activities write" on medflow.activities;
create policy "live activities write" on medflow.activities for all using (true) with check (true);

drop policy if exists "live conversations read" on medflow.conversations;
create policy "live conversations read" on medflow.conversations for select using (true);
drop policy if exists "live conversations write" on medflow.conversations;
create policy "live conversations write" on medflow.conversations for all using (true) with check (true);

drop policy if exists "live specialties read" on medflow.specialties;
create policy "live specialties read" on medflow.specialties for select using (true);
drop policy if exists "live doctors read" on medflow.doctors;
create policy "live doctors read" on medflow.doctors for select using (true);

-- Existing application tables are readable by the live app and remain writable for sync.
drop policy if exists "live appointments read" on medflow.appointments;
create policy "live appointments read" on medflow.appointments for select using (true);
drop policy if exists "live appointments update" on medflow.appointments;
create policy "live appointments update" on medflow.appointments for update using (true) with check (true);
drop policy if exists "live patients read" on medflow.patients;
create policy "live patients read" on medflow.patients for select using (true);
drop policy if exists "live profiles read" on medflow.profiles;
create policy "live profiles read" on medflow.profiles for select using (true);
drop policy if exists "live schedules read" on medflow.doctor_schedules;
create policy "live schedules read" on medflow.doctor_schedules for select using (true);
drop policy if exists "live attendance read" on medflow.doctor_attendance;
create policy "live attendance read" on medflow.doctor_attendance for select using (true);
drop policy if exists "live leaves read" on medflow.doctor_leaves;
create policy "live leaves read" on medflow.doctor_leaves for select using (true);
drop policy if exists "live campaigns read" on medflow.offer_campaigns;
create policy "live campaigns read" on medflow.offer_campaigns for select using (true);
drop policy if exists "live recipients read" on medflow.offer_recipients;
create policy "live recipients read" on medflow.offer_recipients for select using (true);

grant select, insert, update, delete on medflow.prescriptions, medflow.reviews, medflow.offers, medflow.activities, medflow.conversations, medflow.specialties, medflow.doctors to anon, authenticated;
grant select, insert, update, delete on medflow.appointments, medflow.patients, medflow.profiles, medflow.doctor_schedules, medflow.doctor_attendance, medflow.doctor_leaves, medflow.offer_campaigns, medflow.offer_recipients to anon, authenticated;

insert into medflow.specialties (id, name, description, icon, tint, count) values
  ('cardiology', 'طب القلب', 'تشخيص وعلاج أمراض القلب والأوعية الدموية', 'HeartPulse', 'rose', 12),
  ('pediatrics', 'طب الأطفال', 'رعاية متكاملة لصحتك وصحة أطفالك', 'Baby', 'sky', 9),
  ('dermatology', 'الجلدية', 'حلول متخصصة للبشرة والشعر والأظافر', 'Sparkles', 'violet', 8),
  ('dentistry', 'طب الأسنان', 'أسنان بابتسامة وابتسامة تليق بك', 'Smile', 'amber', 7),
  ('gynecology', 'النساء والولادة', 'رعاية طبية آمنة ومطمئنة لكل مرحلة', 'ShieldPlus', 'brand', 10)
on conflict (id) do update set name = excluded.name, description = excluded.description, count = excluded.count;

insert into medflow.doctors (id, name, specialty_id, title, experience, rating, reviews, image, location, phone, bio, working_hours) values
  ('d1', 'د. سارة العتيبي', 'cardiology', 'استشارية أمراض القلب', 14, 4.9, 126, '/images/doc-1.jpg', 'الرياض – العليا', '966501234567', 'استشارية أمراض القلب والأوعية الدموية، حاصلة على شهادة البورد الأمريكي في أمراض القلب.', 'الأحد – الخميس، 9:00 ص – 5:00 م'),
  ('d2', 'د. أحمد الحربي', 'pediatrics', 'استشاري طب الأطفال', 11, 4.8, 98, '/images/doc-2.jpg', 'الرياض – النخيل', '966502234567', 'اهتمام خاص برعاية حديثي الولادة والمتابعة النموية والغذائية والصحية.', 'الاثنين – السبت، 10:00 ص – 6:00 م'),
  ('d3', 'د. لمى القحطاني', 'dermatology', 'استشارية الأمراض الجلدية', 9, 4.9, 143, '/images/doc-3.jpg', 'جدة – الروضة', '966503234567', 'خبرة في علاج حب الشباب والتهابات الجلد ومراقبة العلاجات الحديثة.', 'الأحد – الأربعاء، 3:00 م – 9:00 م'),
  ('d4', 'د. خالد المطيري', 'dentistry', 'استشاري طب وجراحة الأسنان', 12, 4.7, 87, '/images/doc-4.jpg', 'الرياض – العليا', '966504234567', 'متخصص في تجميل الأسنان وزراعة الأسنان بتقنية حديثة وآمنة.', 'السبت – الأربعاء، 9:00 ص – 7:00 م'),
  ('d5', 'د. نورة السالم', 'gynecology', 'استشارية النساء والتوليد', 15, 4.9, 164, '/images/doc-5.jpg', 'الرياض – حي الياسمين', '966505234567', 'متابعة متكاملة للحمل وصحة المرأة مع دعم سردي واضح في كل زيارة.', 'الأحد – الخميس، 8:00 ص – 4:00 م'),
  ('d6', 'د. عمر الزهراني', 'cardiology', 'استشاري أمراض القلب والأوعية الدموية', 10, 4.8, 75, '/images/doc-6.jpg', 'جدة – حي الشاطئ', '966506234567', 'تشخيص دوائي وقسطري لأمراض القلب مع خطط علاج وقائية.', 'الاثنين – الجمعة، 1:00 م – 7:00 م'),
  ('d7', 'د. ريم الدوسري', 'pediatrics', 'استشارية صحة الطفل', 8, 4.8, 92, '/images/doc-7.jpg', 'الخبر – العقربية', '966507234567', 'استشارات طبية دقيقة لنمو الطفل وحمايته من الأمراض الشائعة.', 'الأحد – الخميس، 9:00 ص – 3:00 م'),
  ('d8', 'د. فهد العنزي', 'dentistry', 'طبيب أسنان – تجميل', 7, 4.7, 64, '/images/doc-8.jpg', 'الدمام – الفيصلية', '966508234567', 'تصميم ابتسامة رقمي وعلاج تجميلي مريح باستخدام أحدث التقنيات.', 'السبت – الأربعاء، 4:00 م – 10:00 م')
on conflict (id) do update set name = excluded.name, title = excluded.title, rating = excluded.rating, reviews = excluded.reviews, working_hours = excluded.working_hours;

-- Medflow: Supabase becomes the single source of truth (run after 001 + 002).
-- Idempotent. Review the "RLS" section before running on a live project.

-- ---------------------------------------------------------------- helpers
create or replace function medflow.is_admin()
returns boolean language sql stable security definer set search_path = medflow as $$
  select exists (select 1 from medflow.profiles where id = auth.uid() and role = 'admin');
$$;

-- ---------------------------------------------------------------- center settings (single row)
create table if not exists medflow.center_settings (
  id text primary key default 'main',
  name text not null,
  short_name text,
  phone text,
  whatsapp text,
  email text,
  address text,
  hours text,
  currency text default 'ر.س',
  updated_at timestamptz not null default now()
);

insert into medflow.center_settings (id, name, short_name, phone, whatsapp, email, address, hours, currency) values
  ('main', 'مركز ميدفلو الطبي', 'ميدفلو', '+966 11 245 8890', '966112458890', 'hello@medflow.sa',
   'طريق الملك فهد، حي العليا، الرياض', 'يومياً، 8 صباحاً – 10 مساءً', 'ر.س')
on conflict (id) do nothing;

-- ---------------------------------------------------------------- schedules: one row per doctor, free-text label
alter table medflow.doctor_schedules add column if not exists hours_label text;
alter table medflow.doctor_schedules alter column starts_at set default '09:00';
alter table medflow.doctor_schedules alter column ends_at set default '17:00';
alter table medflow.doctor_schedules alter column day_of_week set default '';
-- Fails loudly if a doctor already has several rows: merge them by hand first.
create unique index if not exists doctor_schedules_doctor_unique on medflow.doctor_schedules (doctor_id);

insert into medflow.doctor_schedules (doctor_id, day_of_week, hours_label, slots)
select d.id,
       split_part(d.working_hours, '،', 1),
       d.working_hours,
       '["09:00","09:30","10:00","10:30","11:00","11:30","12:00","16:00","16:30","17:00","17:30","18:00"]'::jsonb
from medflow.doctors d
on conflict (doctor_id) do nothing;

-- ---------------------------------------------------------------- offers seed (only when empty)
insert into medflow.offers (id, title, description, old_price, price, badge, theme, expires)
select * from (values
  ('o1', 'الفحص الشامل للقلب', 'تخطيط قلب وتحليل دهون ومتابعة مع استشاري القلب.', 450, 299, 'خصم ٣٤٪', 'brand', current_date + 12),
  ('o2', 'جلسة تجميل البشرة', 'جلسة عناية متكاملة مع تقرير توصيات مخصص.', 320, 199, 'عرض محدود', 'amber', current_date + 8),
  ('o3', 'استشارة أطفال', 'استشارة نمو وتغذية ومتابعة صحة الطفل.', 250, 175, 'الأكثر طلباً', 'sky', current_date + 15)
) as v(id, title, description, old_price, price, badge, theme, expires)
where not exists (select 1 from medflow.offers);

-- ---------------------------------------------------------------- booked slots (public, no patient data)
create or replace function medflow.booked_slots(p_doctor text, p_from date, p_to date)
returns table (doctor_id text, appointment_date date, appointment_time text)
language sql stable security definer set search_path = medflow as $$
  select a.doctor_id, a.appointment_date, to_char(a.appointment_time, 'HH24:MI')
  from medflow.appointments a
  where a.doctor_id = p_doctor
    and a.appointment_date between p_from and p_to
    and a.status <> 'cancelled';
$$;
grant execute on function medflow.booked_slots(text, date, date) to anon, authenticated;

-- ---------------------------------------------------------------- RLS (replaces the open "live ..." policies)
alter table medflow.center_settings enable row level security;

-- profiles / patients: no public read
drop policy if exists "live profiles read" on medflow.profiles;
drop policy if exists "live patients read" on medflow.patients;
drop policy if exists "patients own update" on medflow.patients;
create policy "patients own update" on medflow.patients for update
  using (id = auth.uid()::text) with check (id = auth.uid()::text);

-- a user may edit own name/phone, never role or doctor_id
drop policy if exists "profiles own update" on medflow.profiles;
create policy "profiles own update" on medflow.profiles for update
  using (id = auth.uid())
  with check (
    id = auth.uid()
    and role = (select p.role from medflow.profiles p where p.id = auth.uid())
    and doctor_id is not distinct from (select p.doctor_id from medflow.profiles p where p.id = auth.uid())
  );

-- appointments: staff all, patient own; guests insert only
drop policy if exists "live appointments read" on medflow.appointments;
drop policy if exists "live appointments update" on medflow.appointments;
drop policy if exists "appointments own read" on medflow.appointments;
create policy "appointments own read" on medflow.appointments for select using (patient_id = auth.uid()::text);

-- prescriptions
drop policy if exists "live prescriptions read" on medflow.prescriptions;
drop policy if exists "live prescriptions write" on medflow.prescriptions;
drop policy if exists "prescriptions own read" on medflow.prescriptions;
drop policy if exists "prescriptions staff all" on medflow.prescriptions;
create policy "prescriptions own read" on medflow.prescriptions for select using (patient_id = auth.uid()::text or medflow.is_staff());
create policy "prescriptions staff all" on medflow.prescriptions for all using (medflow.is_staff()) with check (medflow.is_staff());

-- reviews: public read, signed-in insert, staff moderate
drop policy if exists "live reviews write" on medflow.reviews;
drop policy if exists "reviews signed insert" on medflow.reviews;
drop policy if exists "reviews staff manage" on medflow.reviews;
create policy "reviews signed insert" on medflow.reviews for insert with check (auth.uid() is not null);
create policy "reviews staff manage" on medflow.reviews for update using (medflow.is_staff()) with check (medflow.is_staff());
drop policy if exists "reviews staff delete" on medflow.reviews;
create policy "reviews staff delete" on medflow.reviews for delete using (medflow.is_staff());

-- offers / doctors / specialties / center: public read, admin write
drop policy if exists "live offers write" on medflow.offers;
drop policy if exists "offers admin write" on medflow.offers;
create policy "offers admin write" on medflow.offers for all using (medflow.is_admin()) with check (medflow.is_admin());

drop policy if exists "doctors admin write" on medflow.doctors;
create policy "doctors admin write" on medflow.doctors for all using (medflow.is_admin()) with check (medflow.is_admin());
drop policy if exists "specialties admin write" on medflow.specialties;
create policy "specialties admin write" on medflow.specialties for all using (medflow.is_admin()) with check (medflow.is_admin());

drop policy if exists "center public read" on medflow.center_settings;
create policy "center public read" on medflow.center_settings for select using (true);
drop policy if exists "center admin write" on medflow.center_settings;
create policy "center admin write" on medflow.center_settings for all using (medflow.is_admin()) with check (medflow.is_admin());

-- activities + conversations: staff only (n8n writes with the service role)
drop policy if exists "live activities read" on medflow.activities;
drop policy if exists "live activities write" on medflow.activities;
drop policy if exists "activities staff read" on medflow.activities;
drop policy if exists "activities signed insert" on medflow.activities;
create policy "activities staff read" on medflow.activities for select using (medflow.is_staff());
create policy "activities signed insert" on medflow.activities for insert with check (auth.uid() is not null);

drop policy if exists "live conversations read" on medflow.conversations;
drop policy if exists "live conversations write" on medflow.conversations;
drop policy if exists "conversations staff all" on medflow.conversations;
create policy "conversations staff all" on medflow.conversations for all using (medflow.is_staff()) with check (medflow.is_staff());

-- attendance / leaves / schedules / campaigns: drop the open read policies (staff policies from 001 remain)
drop policy if exists "live attendance read" on medflow.doctor_attendance;
drop policy if exists "live leaves read" on medflow.doctor_leaves;
drop policy if exists "live campaigns read" on medflow.offer_campaigns;
drop policy if exists "live recipients read" on medflow.offer_recipients;

grant select, insert, update, delete on medflow.center_settings to anon, authenticated;

-- ---------------------------------------------------------------- realtime for every synced table
do $$
declare t text;
begin
  foreach t in array array['prescriptions','reviews','offers','activities','conversations','doctors','specialties','center_settings','profiles']
  loop
    if not exists (
      select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'medflow' and tablename = t
    ) then
      execute format('alter publication supabase_realtime add table medflow.%I', t);
    end if;
  end loop;
end $$;

-- ---------------------------------------------------------------- first admin / doctor (edit the emails, run once)
-- 1) create the user in Supabase Auth (Dashboard > Authentication > Users), then:
-- update medflow.profiles set role = 'admin'  where email = 'you@example.com';
-- update medflow.profiles set role = 'doctor', doctor_id = 'd1' where email = 'doctor@example.com';

-- ---------------------------------------------------------------- grants
grant all on all tables in schema medflow to service_role;
grant all on all sequences in schema medflow to service_role;
grant execute on all functions in schema medflow to service_role;
alter default privileges in schema medflow grant all on tables to service_role;
alter default privileges in schema medflow grant all on sequences to service_role;
grant select, insert, update, delete on all tables in schema medflow to authenticated;
grant select, insert on medflow.patients, medflow.appointments to anon;
grant select on medflow.doctors, medflow.specialties, medflow.offers, medflow.reviews, medflow.doctor_schedules, medflow.center_settings to anon;
-- sensitive tables stay unreadable for anon
revoke all on medflow.password_resets, medflow.rate_limits from anon, authenticated;
