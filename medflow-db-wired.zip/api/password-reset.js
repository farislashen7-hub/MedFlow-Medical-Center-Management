import { toNode } from './_lib/http.js';
import { createHmac, randomInt, timingSafeEqual } from 'node:crypto';
import { notifyN8n } from './_lib/n8n.js';
import { isSameOrigin, rateHit, requestIp } from './_lib/rate-limit.js';
import { normalizePhone } from './_lib/phone.js';
import { getAnonClient, getServiceClient } from './_lib/supabase.js';

const CODE_TTL_MS = 10 * 60 * 1000;
const COOLDOWN_MS = 60 * 1000;
const MAX_ATTEMPTS = 5;
const localResets = new Map();

function response(status, body) {
  return { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, body: JSON.stringify(body) };
}

function hmac(code, phone, secret) {
  return createHmac('sha256', secret).update(`${phone}:${code}`).digest('hex');
}

function safeEqual(hex, expected) {
  const left = Buffer.from(hex, 'hex');
  const right = Buffer.from(expected, 'hex');
  return left.length === right.length && timingSafeEqual(left, right);
}

async function readRecord(phone) {
  const supabase = getServiceClient();
  if (!supabase) return localResets.get(phone) || null;
  const { data } = await supabase.from('password_resets').select('*').eq('phone', phone).order('created_at', { ascending: false }).limit(1).maybeSingle();
  return data || null;
}

async function writeRecord(record) {
  const supabase = getServiceClient();
  if (!supabase) {
    localResets.set(record.phone, record);
    return;
  }
  await supabase.from('password_resets').upsert(record, { onConflict: 'phone' });
}

async function handler(request) {
  if (request.method !== 'POST') return response(405, { message: 'Method not allowed' });
  if (!isSameOrigin(request)) return response(403, { message: 'Origin not allowed' });
  if (process.env.NODE_ENV === 'production' && !process.env.PASSWORD_RESET_SECRET) return response(503, { message: 'Password reset is not configured' });

  let body;
  try { body = typeof request.body === 'string' ? JSON.parse(request.body || '{}') : request.body || {}; }
  catch { return response(400, { message: 'Invalid JSON' }); }
  const action = body.action === 'verify' ? 'verify' : body.action === 'request' ? 'request' : null;
  if (!action) return response(400, { message: 'action must be request or verify' });

  const phoneResult = normalizePhone(String(body.phone || ''));
  if (!phoneResult.valid) return response(422, { message: 'Invalid phone number' });
  const phone = phoneResult.normalized;
  const ip = requestIp(request);

  if (action === 'request') {
    if (!(await rateHit(`reset-phone:${phone}`, 3, 900))) return response(429, { message: 'Too many reset requests for this phone' });
    const existing = await readRecord(phone);
    if (existing && existing.requested_at && Date.now() - new Date(existing.requested_at).getTime() < COOLDOWN_MS) {
      return response(429, { message: 'Please wait before requesting another code' });
    }
    const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
    const secret = process.env.PASSWORD_RESET_SECRET || (process.env.NODE_ENV === 'production' ? '' : 'medflow-local-development-secret');
    const record = {
      phone,
      code_hash: hmac(code, phone, secret),
      attempts: 0,
      used: false,
      requested_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + CODE_TTL_MS).toISOString(),
    };
    await writeRecord(record);
    const sent = await notifyN8n('patient.password_reset', { phone, code, expires_in_minutes: 10 });
    return response(200, { ok: true, expires_in: 600, notification_queued: sent.ok, ...(process.env.NODE_ENV !== 'production' && !process.env.SUPABASE_URL ? { dev_code: code } : {}) });
  }

  if (!(await rateHit(`reset-verify:${ip}`, 20, 600))) return response(429, { message: 'Too many verification attempts' });
  const code = String(body.code || '').replace(/\D/g, '');
  const password = String(body.password || '');
  if (!/^\d{6}$/.test(code)) return response(422, { message: 'Code must contain 6 digits' });
  if (password.length < 8) return response(422, { message: 'Password must be at least 8 characters' });

  const record = await readRecord(phone);
  if (!record) return response(400, { message: 'No reset request found' });
  if (record.used) return response(409, { message: 'Code has already been used' });
  if (new Date(record.expires_at).getTime() < Date.now()) return response(410, { message: 'Code has expired' });
  if (Number(record.attempts) >= MAX_ATTEMPTS) return response(429, { message: 'Too many incorrect attempts' });

  const secret = process.env.PASSWORD_RESET_SECRET || (process.env.NODE_ENV === 'production' ? '' : 'medflow-local-development-secret');
  const valid = safeEqual(record.code_hash, hmac(code, phone, secret));
  if (!valid) {
    await writeRecord({ ...record, attempts: Number(record.attempts || 0) + 1 });
    return response(422, { message: 'Invalid verification code' });
  }

  const supabase = getServiceClient();
  if (supabase) {
    const phoneCandidates = Array.from(new Set([phone, String(body.phone || ''), `+${phone}`]));
    const { data: profile } = await supabase.from('profiles').select('id').in('phone', phoneCandidates).maybeSingle();
    if (!profile) return response(404, { message: 'No account is linked to this phone' });
    const { data: updatedUser, error: updateError } = await supabase.auth.admin.updateUserById(profile.id, { password });
    if (updateError || !updatedUser.user) return response(503, { message: 'Could not update password' });

    const anon = getAnonClient();
    let session = null;
    if (anon && updatedUser.user.email) {
      const { data: authData } = await anon.auth.signInWithPassword({ email: updatedUser.user.email, password });
      session = authData.session ? { access_token: authData.session.access_token, refresh_token: authData.session.refresh_token } : null;
    }
    await writeRecord({ ...record, used: true, used_at: new Date().toISOString() });
    return response(200, { ok: true, session });
  }

  await writeRecord({ ...record, used: true, used_at: new Date().toISOString() });
  return response(200, { ok: true, local_fallback: true });
}

export default toNode(handler);
