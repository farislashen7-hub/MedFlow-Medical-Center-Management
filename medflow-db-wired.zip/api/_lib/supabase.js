import { createClient } from '@supabase/supabase-js';

let serviceClient = null;
const opts = { auth: { persistSession: false, autoRefreshToken: false }, db: { schema: 'medflow' } };

function env(name) {
  const v = process.env[name]?.trim();
  return v && v !== name ? v : ''; // ignore placeholder values like SUPABASE_SERVICE_ROLE_KEY=SUPABASE_SERVICE_ROLE_KEY
}

function supabaseUrl() {
  return env('SUPABASE_URL') || env('VITE_SUPABASE_URL');
}

// Server client: service-role key only. Never falls back to the public key (RLS would silently block writes).
export function getServiceClient() {
  const url = supabaseUrl();
  const key = env('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !key) return null;
  if (!serviceClient) serviceClient = createClient(url, key, opts);
  return serviceClient;
}

export function getAnonClient() {
  const url = supabaseUrl();
  const key = env('SUPABASE_PUBLISHABLE_KEY') || env('SUPABASE_ANON_KEY') || env('VITE_SUPABASE_PUBLISHABLE_KEY');
  if (!url || !key) return null;
  return createClient(url, key, opts);
}
