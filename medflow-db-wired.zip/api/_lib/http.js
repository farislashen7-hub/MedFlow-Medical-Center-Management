import { isAllowedAppOrigin } from './rate-limit.js';

// Adapts `(request) => {status, headers, body}` handlers to Vercel's Node (req, res) signature, with CORS for the mobile app.
export function toNode(handler) {
  return async function (req, res) {
    const origin = req.headers.origin;
    if (origin && isAllowedAppOrigin(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Requested-With');
      res.setHeader('Access-Control-Max-Age', '86400');
    }
    if (req.method === 'OPTIONS') return res.status(204).end();
    try {
      const out = await handler(req);
      for (const [k, v] of Object.entries(out.headers || {})) res.setHeader(k, v);
      res.status(out.status).send(out.body);
    } catch (error) {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.status(500).send(JSON.stringify({ message: 'Internal error' }));
    }
  };
}
