import { shapePayload } from './shape.js';
const DEFAULT_PATHS = {
  'appointment.created': 'app-booking',
  'appointment.reminder': 'app-booking',
  'appointment.cancelled': 'app-cancel-booking',
  'appointment.rebooked': 'app-Rebooking',
  'prescription.issued': 'app-Treatment',
  'doctor.unavailable': 'app-not-available',
  'offer.broadcast': 'app-offer',
  'report.send': 'app-report',
  'review.submitted': 'app-review',
  'review.negative': 'review.negative',
  'patient.password_reset': 'app-password-reset',
};

// Events the browser may submit (review.negative is derived server-side from the rating).
export const ALLOWED_EVENTS = Object.freeze(Object.keys(DEFAULT_PATHS).filter((e) => e !== 'review.negative'));

// Each event lists env names in priority order (legacy / mixed-case names kept for compatibility).
const ENV_OVERRIDES = {
  'appointment.created': ['N8N_PATH_BOOKING'],
  'appointment.reminder': ['N8N_PATH_BOOKING'],
  'appointment.cancelled': ['N8N_PATH_CANCEL_BOOKING', 'N8N_PATH_cancelbooking', 'N8N_PATH_CANCELBOOKING'],
  'appointment.rebooked': ['N8N_PATH_REBOOKING'],
  'prescription.issued': ['N8N_PATH_TREATMENT'],
  'doctor.unavailable': ['N8N_PATH_NOT_AVAILABLE', 'N8N_PATH_Not_available'],
  'offer.broadcast': ['N8N_PATH_OFFER'],
  'report.send': ['N8N_PATH_REPORT'],
  'review.negative': ['N8N_PATH_REVIEW_NEGATIVE'],
  'review.submitted': ['N8N_PATH_REVIEW'],
  'patient.password_reset': ['N8N_PATH_PASSWORD_RESET'],
};

function firstEnv(names) {
  for (const name of names) {
    const value = process.env[name]?.trim();
    if (value) return value;
  }
  return '';
}

export function getN8nPath(event, payload = {}) {
  return firstEnv(ENV_OVERRIDES[event] || []) || DEFAULT_PATHS[event];
}

export async function notifyN8n(event, payload = {}) {
  const base = (process.env.N8N_WEBHOOK_BASE || '').trim().replace(/\/$/, '');
  const secret = (process.env.N8N_WEBHOOK_SECRET || '').trim();
  if (!base || !secret) return { ok: false, status: 503, message: 'n8n is not configured' };

  const shaped = shapePayload(event, payload);
  const path = getN8nPath(shaped.event, shaped.payload).replace(/^\//, '');
  const url = `${base}/${path}`;
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-webhook-secret': secret,
        'ngrok-skip-browser-warning': 'true',
      },
      body: JSON.stringify({ event: shaped.event, payload: shaped.payload, ts: new Date().toISOString() }),
      signal: AbortSignal.timeout(12_000),
    });
    const text = await response.text();
    let data;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }
    return { ok: response.ok, status: response.status, data };
  } catch (error) {
    return { ok: false, status: 502, message: error instanceof Error ? error.message : 'n8n request failed' };
  }
}
