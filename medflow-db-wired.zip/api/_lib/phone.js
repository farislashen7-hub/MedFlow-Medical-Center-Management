export const DEFAULT_GULF_CC = '966';

const rules = [
  { country: 'EG', cc: '20', test: (value) => /^01[0125]\d{8}$/.test(value) },
  { country: 'SA', cc: '966', test: (value) => /^5\d{8}$/.test(value) },
  { country: 'AE', cc: '971', test: (value) => /^5[024568]\d{7}$/.test(value) },
  { country: 'KW', cc: '965', test: (value) => /^\d{8}$/.test(value) },
  { country: 'QA', cc: '974', test: (value) => /^\d{8}$/.test(value) },
  { country: 'BH', cc: '973', test: (value) => /^\d{8}$/.test(value) },
  { country: 'OM', cc: '968', test: (value) => /^\d{8}$/.test(value) },
];

export function normalizePhone(input, defaultCountry = process.env.DEFAULT_GULF_CC || DEFAULT_GULF_CC) {
  const raw = String(input ?? '').trim();
  const digits = raw.replace(/\D/g, '');
  const local = digits.startsWith('00') ? digits.slice(2) : digits;
  for (const rule of rules) {
    for (const prefix of [rule.cc, `0${rule.cc}`]) {
      if (local.startsWith(prefix)) {
        const national = local.slice(prefix.length);
        if (rule.test(national)) return { valid: true, normalized: `${rule.cc}${national}`, country: rule.country };
      }
    }
  }
  for (const rule of rules) {
    if (rule.test(local)) return { valid: true, normalized: `${rule.cc}${local}`, country: rule.country };
  }
  const fallback = rules.find((rule) => rule.country === defaultCountry);
  if (fallback && fallback.test(local)) return { valid: true, normalized: `${fallback.cc}${local}`, country: fallback.country };
  return { valid: false, normalized: local, country: null };
}

export function samePhone(first, second) {
  const a = normalizePhone(first);
  const b = normalizePhone(second);
  return a.valid && b.valid && a.normalized === b.normalized;
}
