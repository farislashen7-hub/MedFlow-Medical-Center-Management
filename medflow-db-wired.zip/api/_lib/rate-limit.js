import { getServiceClient } from './supabase.js';

const memoryWindows = new Map();

export async function rateHit(key, limit, windowSeconds) {
  const supabase = getServiceClient();
  if (supabase) {
    const { data, error } = await supabase.rpc('rate_hit', { key, limit_count: limit, window_seconds: windowSeconds });
    if (!error) return Boolean(data);
  }

  const now = Date.now();
  const current = memoryWindows.get(key);
  if (!current || now - current.startedAt >= windowSeconds * 1000) {
    memoryWindows.set(key, { startedAt: now, count: 1 });
    if (memoryWindows.size > 5_000) {
      for (const [itemKey, item] of memoryWindows) {
        if (now - item.startedAt >= windowSeconds * 1000) memoryWindows.delete(itemKey);
      }
    }
    return true;
  }
  current.count += 1;
  return current.count <= limit;
}

export function requestIp(request) {
  const forwarded = request.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') return forwarded.split(',')[0].trim();
  return request.headers['x-real-ip'] || request.socket?.remoteAddress || 'unknown';
}

const APP_ORIGINS = ['https://localhost', 'http://localhost', 'capacitor://localhost'];

export function isAllowedAppOrigin(origin) {
  const extra = (process.env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean);
  return APP_ORIGINS.includes(origin) || extra.includes(origin);
}

export function isSameOrigin(request) {
  const origin = request.headers.origin;
  if (!origin) return true;
  if (isAllowedAppOrigin(origin)) return true; // Android/iOS app (Capacitor WebView)
  try {
    const originHost = new URL(origin).host;
    const forwardedHost = request.headers['x-forwarded-host'];
    const host = (typeof forwardedHost === 'string' ? forwardedHost : request.headers.host) || '';
    return originHost === host;
  } catch {
    return false;
  }
}
