import { normalizePhone } from './phone.js';

// WhatsApp number (digits, country code, no +). Egyptian/Saudi local forms handled explicitly.
export function toWaNumber(input) {
  let d = String(input ?? '').replace(/\D/g, '');
  if (d.startsWith('00')) d = d.slice(2);
  if (/^01[0125]\d{8}$/.test(d)) return `20${d.slice(1)}`;
  if (/^201[0125]\d{8}$/.test(d)) return d;
  if (/^05\d{8}$/.test(d)) return `966${d.slice(1)}`;
  const n = normalizePhone(d);
  if (n.valid) return n.normalized;
  return /^\d{8,15}$/.test(d) ? d : '';
}

const str = (v) => (v == null ? '' : String(v));

// Maps the app's payloads to the shape the n8n workflows validate (phone_wa, name, date, ...).
export function shapePayload(event, p = {}) {
  switch (event) {
    case 'appointment.created':
    case 'appointment.reminder':
    case 'appointment.cancelled':
    case 'appointment.rebooked':
      return {
        event,
        payload: {
          ...p,
          id: str(p.id || p.appointment_id),
          name: str(p.name || p.patientName || p.patient_name),
          phone_wa: toWaNumber(p.phone),
          date: str(p.date || p.appointment_date).slice(0, 10),
          time: str(p.time || p.appointment_time).slice(0, 5),
          doctor_name: str(p.doctor_name),
          specialty_name: str(p.specialty_name),
          cancelled_by: str(p.cancelled_by || p.cancelledBy),
        },
      };
    case 'prescription.issued': {
      const url = str(p.image_data_url);
      const m = /^data:([^;,]+)?(?:;[^,]*)?,(.*)$/s.exec(url);
      const { image_data_url, ...rest } = p;
      return {
        event,
        payload: {
          ...rest,
          phone_wa: toWaNumber(p.phone),
          code: str(p.prescription_id || p.code),
          image_base64: m ? m[2] : '',
          mimetype: m?.[1] || 'image/jpeg',
          filename: 'prescription.jpg',
        },
      };
    }
    case 'doctor.unavailable':
      return {
        event,
        payload: {
          ...p,
          since: str(p.date),
          until: str(p.date),
          affected: (Array.isArray(p.affected) ? p.affected : []).map((a) => ({ ...a, phone_wa: toWaNumber(a.phone) })),
        },
      };
    case 'review.submitted': {
      const rating = Number(p.rating);
      const negative = rating <= 2;
      return {
        event: negative ? 'review.negative' : event,
        payload: {
          ...p,
          patient_name: str(p.patient_name || p.patientName),
          comment: str(p.comment || p.text),
          doctor_name: str(p.doctor_name),
          ...(negative ? { sentiment: 'negative' } : {}),
        },
      };
    }
    case 'patient.password_reset':
      return {
        event,
        payload: {
          phone_wa: toWaNumber(p.phone),
          code: str(p.code),
          expires_minutes: Number(p.expires_in_minutes) || 10,
        },
      };
    default:
      return { event, payload: p };
  }
}
