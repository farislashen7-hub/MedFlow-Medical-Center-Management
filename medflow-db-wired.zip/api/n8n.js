import { toNode } from './_lib/http.js';
import { ALLOWED_EVENTS, notifyN8n } from './_lib/n8n.js';
import { isSameOrigin, rateHit, requestIp } from './_lib/rate-limit.js';

const MAX_BODY_BYTES = 4.2 * 1024 * 1024;

function response(status, body) {
  return {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    },
    body: JSON.stringify(body),
  };
}

async function handler(request) {
  if (request.method !== 'POST') return response(405, { message: 'Method not allowed' });
  if (!isSameOrigin(request)) return response(403, { message: 'Origin not allowed' });

  const contentLength = Number(request.headers['content-length'] || 0);
  if (contentLength > MAX_BODY_BYTES) return response(413, { message: 'Payload exceeds 4.2MB' });

  let body = request.body;
  if (typeof body === 'string') {
    if (Buffer.byteLength(body, 'utf8') > MAX_BODY_BYTES) return response(413, { message: 'Payload exceeds 4.2MB' });
    try { body = JSON.parse(body); } catch { return response(400, { message: 'Invalid JSON' }); }
  }
  if (!body || typeof body !== 'object' || Array.isArray(body)) return response(400, { message: 'Invalid request body' });
  if (Buffer.byteLength(JSON.stringify(body), 'utf8') > MAX_BODY_BYTES) return response(413, { message: 'Payload exceeds 4.2MB' });

  const event = String(body.event || '');
  const payload = body.payload && typeof body.payload === 'object' && !Array.isArray(body.payload) ? body.payload : {};
  if (!ALLOWED_EVENTS.includes(event)) return response(400, { message: 'Unsupported event' });
  if (!Object.keys(payload).length) return response(422, { message: 'Payload is required' });

  const ip = requestIp(request);
  const allowed = await rateHit(`n8n:${ip}`, 120, 600);
  if (!allowed) return response(429, { message: 'Too many requests' });

  const result = await notifyN8n(event, payload);
  if (!result.ok) {
    const status = result.status === 503 ? 503 : 502;
    return response(status, { message: result.message || 'Notification service unavailable' });
  }
  return response(200, { ok: true, event });
}

export default toNode(handler);
