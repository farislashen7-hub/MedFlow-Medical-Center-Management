import { toNode } from './_lib/http.js';
import { notifyN8n } from './_lib/n8n.js';
import { isSameOrigin, rateHit, requestIp } from './_lib/rate-limit.js';
import { normalizePhone, samePhone } from './_lib/phone.js';
import { getServiceClient } from './_lib/supabase.js';

function response(status, body) {
  return { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, body: JSON.stringify(body) };
}

async function handler(request) {
  if (request.method !== 'POST') return response(405, { message: 'Method not allowed' });
  if (!isSameOrigin(request)) return response(403, { message: 'Origin not allowed' });

  const ip = requestIp(request);
  if (!(await rateHit(`cancel:${ip}`, 20, 600))) return response(429, { message: 'Too many cancellation requests' });

  let body;
  try { body = typeof request.body === 'string' ? JSON.parse(request.body || '{}') : request.body || {}; }
  catch { return response(400, { message: 'Invalid JSON' }); }
  const appointmentId = String(body.appointment_id || '').trim();
  const phone = String(body.phone || '').trim();
  const cancelledBy = ['staff', 'doctor'].includes(body.cancelled_by) ? body.cancelled_by : 'patient';
  const extra = {
    doctor_name: String(body.doctor_name || '').slice(0, 120),
    specialty_name: String(body.specialty_name || '').slice(0, 120),
  };
  if (!appointmentId || !phone) return response(400, { message: 'appointment_id and phone are required' });
  if (!normalizePhone(phone).valid) return response(422, { message: 'Invalid phone number' });

  const supabase = getServiceClient();
  if (!supabase) {
    await notifyN8n('appointment.cancelled', { id: appointmentId, appointment_id: appointmentId, phone, patient_name: String(body.patient_name || '').slice(0, 120), date: String(body.date || ''), time: String(body.time || ''), ...extra, cancelled_by: cancelledBy, local_fallback: true });
    return response(202, { ok: true, local_fallback: true });
  }

  const { data: appointment, error: lookupError } = await supabase
    .from('appointments')
    .select('id, phone, patient_name, appointment_date, appointment_time, status')
    .eq('id', appointmentId)
    .maybeSingle();
  if (lookupError) return response(503, { message: 'Database temporarily unavailable' });
  if (!appointment) return response(404, { message: 'Appointment not found' });
  if (!samePhone(appointment.phone, phone)) return response(403, { message: 'Phone does not match booking' });
  if (appointment.status === 'completed') return response(409, { message: 'Completed appointments cannot be cancelled' });

  const bookingTime = new Date(`${appointment.appointment_date}T${appointment.appointment_time || '00:00'}:00`);
  if (bookingTime.getTime() < Date.now()) return response(409, { message: 'Past appointments cannot be cancelled' });

  const { data: updated, error: updateError } = await supabase
    .from('appointments')
    .update({ status: 'cancelled', cancelled_by: cancelledBy, cancelled_at: new Date().toISOString() })
    .eq('id', appointmentId)
    .neq('status', 'cancelled')
    .select('id')
    .maybeSingle();
  if (updateError) return response(503, { message: 'Cancellation failed' });
  if (!updated) return response(409, { message: 'Appointment was already cancelled' });

  await notifyN8n('appointment.cancelled', { id: appointmentId, appointment_id: appointmentId, phone: appointment.phone, patient_name: appointment.patient_name, date: appointment.appointment_date, time: String(appointment.appointment_time || '').slice(0, 5), ...extra, cancelled_by: cancelledBy });
  return response(200, { ok: true });
}

export default toNode(handler);
