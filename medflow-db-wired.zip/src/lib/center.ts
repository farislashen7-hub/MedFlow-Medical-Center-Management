import type { Center } from '../types';

// Shown only until the `center_settings` row loads from Supabase. Not a data source.
export const emptyCenter: Center = {
  name: 'مركز ميدفلو الطبي',
  shortName: 'ميدفلو',
  phone: '',
  whatsapp: '',
  email: '',
  address: '',
  hours: '',
  currency: 'ر.س',
};
