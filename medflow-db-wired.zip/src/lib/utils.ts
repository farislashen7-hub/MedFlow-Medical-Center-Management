export function cn(...values: Array<string | false | null | undefined>) {
  return values.filter(Boolean).join(' ');
}

export function uid(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function formatDate(date: string, options?: { weekday?: 'long' | 'short' | 'narrow'; day?: 'numeric' | '2-digit'; month?: 'long' | 'short' | 'numeric' | '2-digit'; year?: 'numeric' | '2-digit' }) {
  return new Intl.DateTimeFormat('ar-SA-u-ca-gregory', options ?? { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(`${date}T12:00:00`));
}

export function formatDateTime(date: string, time: string) {
  return `${formatDate(date, { day: 'numeric', month: 'short' })} • ${time}`;
}

export function money(value: number) {
  return `${new Intl.NumberFormat('ar-SA', { maximumFractionDigits: 0 }).format(value)} ر.س`;
}

export function initials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join('');
}

export function isFuture(date: string, time = '23:59') {
  return new Date(`${date}T${time}:00`).getTime() > Date.now();
}

export function sameLocalDate(date: Date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function addDays(date: Date, amount: number) {
  const next = new Date(date);
  next.setDate(next.getDate() + amount);
  return sameLocalDate(next);
}

export async function downloadTextFile(filename: string, content: string, type = 'text/plain;charset=utf-8') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}
