// Web: same origin (empty base). Android APK (Capacitor): set VITE_API_BASE=https://<your-site>.vercel.app
const base = (import.meta.env.VITE_API_BASE || '').trim().replace(/\/$/, '');
export const apiUrl = (path: string) => `${base}${path}`;
