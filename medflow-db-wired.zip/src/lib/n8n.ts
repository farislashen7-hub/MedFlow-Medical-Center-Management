import { apiUrl } from './api';
export type N8nEvent =
  | 'appointment.created'
  | 'appointment.reminder'
  | 'appointment.cancelled'
  | 'appointment.rebooked'
  | 'prescription.issued'
  | 'doctor.unavailable'
  | 'offer.broadcast'
  | 'report.send'
  | 'review.submitted'
  | 'patient.password_reset';

export interface NotifyResult {
  ok: boolean;
  status: number;
  message?: string;
}

export async function notifyN8n(event: N8nEvent, payload: Record<string, unknown>): Promise<NotifyResult> {
  try {
    const response = await fetch(apiUrl('/api/n8n'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'MedflowWeb' },
      body: JSON.stringify({ event, payload }),
    });
    const data = await response.json().catch(() => ({}));
    return { ok: response.ok, status: response.status, message: data?.message };
  } catch {
    return { ok: false, status: 0, message: 'تعذر الاتصال بخدمة التنبيه' };
  }
}
