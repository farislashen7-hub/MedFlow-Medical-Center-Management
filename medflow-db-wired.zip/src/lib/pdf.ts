import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

export async function saveElementAsPdf(element: HTMLElement, filename: string) {
  const canvas = await html2canvas(element, { scale: 2, backgroundColor: '#ffffff', useCORS: true, logging: false });
  const image = canvas.toDataURL('image/jpeg', 0.96);
  const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const margin = 10;
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const ratio = Math.min((pageWidth - margin * 2) / canvas.width, (pageHeight - margin * 2) / canvas.height);
  const width = canvas.width * ratio;
  const height = canvas.height * ratio;
  pdf.addImage(image, 'JPEG', (pageWidth - width) / 2, margin, width, height);
  pdf.save(filename);
}

export function printElement(element: HTMLElement) {
  const printWindow = window.open('', '_blank', 'width=900,height=700');
  if (!printWindow) return false;
  printWindow.document.write(`<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>طباعة</title><style>body{font-family:Tahoma,Arial,sans-serif;padding:30px;color:#172227}*{box-sizing:border-box}.no-print{display:none!important}@media print{body{padding:0}}</style></head><body>${element.outerHTML}</body></html>`);
  printWindow.document.close();
  printWindow.focus();
  window.setTimeout(() => printWindow.print(), 250);
  return true;
}
