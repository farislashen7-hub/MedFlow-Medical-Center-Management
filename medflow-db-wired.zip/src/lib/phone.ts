export type GulfCountry = 'SA' | 'AE' | 'KW' | 'QA' | 'BH' | 'OM' | 'EG' | '966';

export interface PhoneResult {
  valid: boolean;
  normalized: string;
  country: GulfCountry | null;
  message?: string;
}

const rules: Array<{ country: GulfCountry; cc: string; test: (value: string) => boolean }> = [
  { country: 'EG', cc: '20', test: (v) => /^01[0125]\d{8}$/.test(v) },
  { country: 'SA', cc: '966', test: (v) => /^5\d{8}$/.test(v) },
  { country: 'AE', cc: '971', test: (v) => /^5[024568]\d{7}$/.test(v) },
  { country: 'KW', cc: '965', test: (v) => /^(\d{8})$/.test(v) },
  { country: 'QA', cc: '974', test: (v) => /^(\d{8})$/.test(v) },
  { country: 'BH', cc: '973', test: (v) => /^(\d{8})$/.test(v) },
  { country: 'OM', cc: '968', test: (v) => /^(\d{8})$/.test(v) },
];

export function normalizePhone(input: string, defaultCountry: GulfCountry = '966'): PhoneResult {
  const raw = String(input ?? '').trim();
  const digits = raw.replace(/\D/g, '');
  const local = digits.startsWith('00') ? digits.slice(2) : digits;

  for (const rule of rules) {
    const prefixes = [rule.cc, `0${rule.cc}`];
    for (const prefix of prefixes) {
      if (local.startsWith(prefix)) {
        const national = local.slice(prefix.length);
        if (rule.test(national)) return { valid: true, normalized: `${rule.cc}${national}`, country: rule.country };
      }
    }
  }

  if (rules.some((rule) => rule.test(local))) {
    const rule = rules.find((candidate) => candidate.test(local))!;
    return { valid: true, normalized: `${rule.cc}${local}`, country: rule.country };
  }

  const fallback = rules.find((rule) => rule.country === defaultCountry)!;
  if (fallback.test(local)) return { valid: true, normalized: `${fallback.cc}${local}`, country: fallback.country };
  return { valid: false, normalized: local, country: null, message: 'رقم الجوال غير صحيح. مثال: 0501234567' };
}

export function isValidPhone(input: string, defaultCountry: GulfCountry = '966') {
  return normalizePhone(input, defaultCountry).valid;
}

export function whatsappUrl(input: string, message = '', defaultCountry: GulfCountry = '966') {
  const result = normalizePhone(input, defaultCountry);
  const phone = result.valid ? result.normalized : String(input).replace(/\D/g, '');
  return `https://wa.me/${phone}${message ? `?text=${encodeURIComponent(message)}` : ''}`;
}
