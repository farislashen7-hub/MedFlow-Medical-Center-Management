import type { SupabaseClient } from '@supabase/supabase-js';
import type { Activity, Appointment, AppointmentStatus, Attendance, Center, Conversation, Doctor, Leave, Offer, Prescription, Review, Schedule, Specialty, User } from '../types';

type Row = Record<string, unknown>;

export interface RemoteData {
  doctors: Doctor[];
  specialties: Specialty[];
  center: Center | null;
  appointments: Appointment[];
  prescriptions: Prescription[];
  reviews: Review[];
  offers: Offer[];
  attendance: Attendance[];
  schedules: Schedule[];
  leaves: Leave[];
  activities: Activity[];
  conversations: Conversation[];
  users: User[];
}

const text = (row: Row, key: string, fallback = '') => String(row[key] ?? fallback);
const number = (row: Row, key: string, fallback = 0) => Number(row[key] ?? fallback);
const array = (row: Row, key: string) => Array.isArray(row[key]) ? (row[key] as unknown[]).map(String) : [];

export function mapDoctor(row: Row): Doctor {
  return {
    id: text(row, 'id'),
    name: text(row, 'name'),
    specialtyId: text(row, 'specialty_id'),
    title: text(row, 'title'),
    experience: number(row, 'experience'),
    rating: number(row, 'rating'),
    reviews: number(row, 'reviews'),
    image: text(row, 'image', '/images/logo.png'),
    location: text(row, 'location'),
    phone: text(row, 'phone'),
    bio: text(row, 'bio'),
    workingHours: text(row, 'working_hours'),
  };
}

export function mapSpecialty(row: Row): Specialty {
  return {
    id: text(row, 'id'),
    name: text(row, 'name'),
    description: text(row, 'description'),
    icon: text(row, 'icon', 'Stethoscope'),
    tint: text(row, 'tint', 'brand'),
    count: number(row, 'count'),
  };
}

export function mapCenter(row: Row): Center {
  return {
    name: text(row, 'name'),
    shortName: text(row, 'short_name', text(row, 'name')),
    phone: text(row, 'phone'),
    whatsapp: text(row, 'whatsapp'),
    email: text(row, 'email'),
    address: text(row, 'address'),
    hours: text(row, 'hours'),
    currency: text(row, 'currency', 'ر.س'),
  };
}

export function mapAppointment(row: Row): Appointment {
  return {
    id: text(row, 'id'),
    patientId: text(row, 'patient_id'),
    patientName: text(row, 'patient_name', 'مريض'),
    phone: text(row, 'phone'),
    doctorId: text(row, 'doctor_id'),
    specialtyId: text(row, 'specialty_id'),
    date: text(row, 'appointment_date', text(row, 'date')).slice(0, 10),
    time: text(row, 'appointment_time', text(row, 'time')).slice(0, 5),
    status: (text(row, 'status', 'confirmed') as AppointmentStatus),
    notes: row.notes ? String(row.notes) : undefined,
    createdAt: text(row, 'created_at', new Date().toISOString()),
    cancelledBy: row.cancelled_by ? (String(row.cancelled_by) as 'patient' | 'staff' | 'doctor') : undefined,
  };
}

export function mapPrescription(row: Row): Prescription {
  return {
    id: text(row, 'id'),
    appointmentId: text(row, 'appointment_id'),
    patientId: text(row, 'patient_id'),
    doctorId: text(row, 'doctor_id'),
    date: text(row, 'date').slice(0, 10),
    diagnosis: text(row, 'diagnosis'),
    medications: text(row, 'medications'),
    instructions: text(row, 'instructions'),
    sentToWhatsApp: Boolean(row.sent_to_whatsapp),
  };
}

export function mapReview(row: Row): Review {
  return {
    id: text(row, 'id'),
    patientName: text(row, 'patient_name', text(row, 'full_name', 'مريض')),
    doctorId: text(row, 'doctor_id'),
    rating: number(row, 'rating', 5),
    text: text(row, 'text', text(row, 'review_text')),
    date: text(row, 'date').slice(0, 10),
    verified: row.verified !== false,
  };
}

export function mapOffer(row: Row): Offer {
  return {
    id: text(row, 'id'),
    title: text(row, 'title'),
    description: text(row, 'description'),
    oldPrice: number(row, 'old_price'),
    price: number(row, 'price'),
    badge: text(row, 'badge', 'عرض خاص'),
    theme: (text(row, 'theme', 'brand') as Offer['theme']),
    expires: text(row, 'expires').slice(0, 10),
  };
}

export function mapAttendance(row: Row): Attendance {
  return {
    doctorId: text(row, 'doctor_id'),
    date: text(row, 'attendance_date', text(row, 'date')).slice(0, 10),
    status: (text(row, 'status', 'present') as Attendance['status']),
    note: row.note ? String(row.note) : undefined,
  };
}

export function mapSchedule(row: Row): Schedule {
  const startsAt = text(row, 'starts_at');
  const endsAt = text(row, 'ends_at');
  return {
    doctorId: text(row, 'doctor_id'),
    days: text(row, 'day_of_week', text(row, 'days')),
    hours: text(row, 'hours_label') || (startsAt || endsAt ? `${startsAt.slice(0, 5)} – ${endsAt.slice(0, 5)}` : text(row, 'hours')),
    slots: array(row, 'slots'),
  };
}

export function mapLeave(row: Row): Leave {
  return {
    id: text(row, 'id'),
    doctorId: text(row, 'doctor_id'),
    startDate: text(row, 'start_date').slice(0, 10),
    endDate: text(row, 'end_date').slice(0, 10),
    reason: text(row, 'reason'),
  };
}

export function mapActivity(row: Row): Activity {
  return {
    id: text(row, 'id'),
    type: (text(row, 'type', 'system') as Activity['type']),
    text: text(row, 'text'),
    at: text(row, 'at', text(row, 'created_at', new Date().toISOString())),
  };
}

export function mapConversation(row: Row): Conversation {
  return {
    id: text(row, 'id'),
    phone: text(row, 'phone'),
    name: text(row, 'name', 'مريض'),
    lastMessage: text(row, 'last_message'),
    at: text(row, 'at', text(row, 'created_at', new Date().toISOString())),
    unread: number(row, 'unread'),
    status: (text(row, 'status', 'active') as Conversation['status']),
  };
}

export function mapUser(row: Row): User {
  const role = text(row, 'role', 'patient');
  return {
    id: text(row, 'id'),
    name: text(row, 'full_name', text(row, 'name', 'مستخدم ميدفلو')),
    email: text(row, 'email'),
    phone: text(row, 'phone'),
    role: (role === 'admin' || role === 'doctor' || role === 'patient' ? role : 'patient'),
    doctorId: row.doctor_id ? String(row.doctor_id) : undefined,
  };
}

const rows = (result: PromiseSettledResult<{ data: unknown }>) => result.status === 'fulfilled' && Array.isArray(result.value.data) ? result.value.data as Row[] : [];

export interface BookedSlot { doctorId: string; date: string; time: string }

export async function fetchBookedSlots(client: SupabaseClient, doctorId: string, from: string, to: string): Promise<BookedSlot[]> {
  const { data, error } = await client.rpc('booked_slots', { p_doctor: doctorId, p_from: from, p_to: to });
  if (error || !Array.isArray(data)) return [];
  return (data as Row[]).map((row) => ({ doctorId: text(row, 'doctor_id'), date: text(row, 'appointment_date').slice(0, 10), time: text(row, 'appointment_time').slice(0, 5) }));
}

export async function fetchRemoteData(client: SupabaseClient): Promise<RemoteData> {
  const results = await Promise.allSettled([
    client.from('appointments').select('*').order('created_at', { ascending: false }),
    client.from('prescriptions').select('*'),
    client.from('reviews').select('*'),
    client.from('offers').select('*'),
    client.from('doctor_attendance').select('*'),
    client.from('doctor_schedules').select('*'),
    client.from('doctor_leaves').select('*'),
    client.from('activities').select('*'),
    client.from('conversations').select('*'),
    client.from('profiles').select('*'),
    client.from('doctors').select('*').order('id'),
    client.from('specialties').select('*').order('id'),
    client.from('center_settings').select('*').eq('id', 'main').maybeSingle(),
  ]);
  const centerResult = results[12];
  const centerRow = centerResult.status === 'fulfilled' && centerResult.value.data && !Array.isArray(centerResult.value.data) ? centerResult.value.data as Row : null;
  return {
    doctors: rows(results[10] as PromiseSettledResult<{ data: unknown }>).map(mapDoctor).filter((item) => item.id),
    specialties: rows(results[11] as PromiseSettledResult<{ data: unknown }>).map(mapSpecialty).filter((item) => item.id),
    center: centerRow ? mapCenter(centerRow) : null,
    appointments: rows(results[0]).map(mapAppointment).filter((item) => item.id),
    prescriptions: rows(results[1]).map(mapPrescription).filter((item) => item.id),
    reviews: rows(results[2]).map(mapReview).filter((item) => item.id),
    offers: rows(results[3]).map(mapOffer).filter((item) => item.id),
    attendance: rows(results[4]).map(mapAttendance).filter((item) => item.doctorId),
    schedules: rows(results[5]).map(mapSchedule).filter((item) => item.doctorId),
    leaves: rows(results[6]).map(mapLeave).filter((item) => item.id),
    activities: rows(results[7]).map(mapActivity).filter((item) => item.id),
    conversations: rows(results[8]).map(mapConversation).filter((item) => item.id),
    users: rows(results[9]).map(mapUser).filter((item) => item.id),
  };
}
