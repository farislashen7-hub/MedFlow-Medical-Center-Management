import type { Doctor, Specialty } from '../types';

// Filled by the store after every Supabase load; lets non-React code resolve names.
let doctorList: Doctor[] = [];
let specialtyList: Specialty[] = [];

export const setCatalog = (doctors: Doctor[], specialties: Specialty[]) => {
  doctorList = doctors;
  specialtyList = specialties;
};

export const doctorName = (id?: string) => doctorList.find((d) => d.id === id)?.name ?? '';
export const specialtyName = (id?: string) => specialtyList.find((s) => s.id === id)?.name ?? '';
