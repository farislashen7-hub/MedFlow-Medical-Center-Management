import { apiUrl } from './lib/api';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Activity, Appointment, AppointmentStatus, Attendance, Center, Conversation, Doctor, Leave, Offer, Prescription, Review, Role, Schedule, Specialty, User } from './types';
import { emptyCenter } from './lib/center';
import { isSupabaseConfigured, supabase } from './lib/supabase';
import { notifyN8n } from './lib/n8n';
import { doctorName, setCatalog, specialtyName } from './lib/names';
import { uid } from './lib/utils';
import { fetchBookedSlots, fetchRemoteData, mapActivity, mapAppointment, mapAttendance, mapCenter, mapConversation, mapDoctor, mapLeave, mapOffer, mapPrescription, mapReview, mapSchedule, mapSpecialty, mapUser, type BookedSlot } from './lib/remote-data';

interface PersistedState {
  currentUser: User | null;
  users: User[];
  doctors: Doctor[];
  specialties: Specialty[];
  center: Center;
  appointments: Appointment[];
  prescriptions: Prescription[];
  reviews: Review[];
  offers: Offer[];
  attendance: Attendance[];
  schedules: Schedule[];
  leaves: Leave[];
  activities: Activity[];
  conversations: Conversation[];
}

interface NewAppointment {
  patientId: string;
  patientName: string;
  phone: string;
  doctorId: string;
  specialtyId: string;
  date: string;
  time: string;
  notes?: string;
}

interface StoreValue extends PersistedState {
  hydrated: boolean;
  bookedSlots: BookedSlot[];
  loadBookedSlots: (doctorId: string) => Promise<void>;
  reload: () => Promise<void>;
  saveDoctor: (payload: Partial<Doctor> & Pick<Doctor, 'name' | 'title' | 'specialtyId'>) => Promise<void>;
  saveSchedule: (doctorId: string, hours: string) => Promise<void>;
  saveCenter: (payload: Center) => Promise<void>;
  toast: { id: number; message: string; tone: 'success' | 'error' | 'info' } | null;
  login: (email: string, password: string) => Promise<User>;
  restoreSession: () => Promise<User | null>;
  register: (payload: { name: string; email: string; phone: string; password: string }) => Promise<User>;
  logout: () => Promise<void>;
  addAppointment: (payload: NewAppointment) => Promise<Appointment>;
  updateAppointment: (id: string, status: AppointmentStatus) => void;
  cancelAppointment: (id: string, by: 'patient' | 'staff' | 'doctor') => Promise<void>;
  addPrescription: (payload: Omit<Prescription, 'id' | 'date' | 'sentToWhatsApp'>) => Promise<Prescription>;
  markPrescriptionSent: (id: string) => void;
  addReview: (payload: Omit<Review, 'id' | 'date' | 'verified'>) => Promise<Review>;
  setAttendance: (payload: Omit<Attendance, 'date'>) => void;
  addLeave: (payload: Omit<Leave, 'id'>) => void;
  broadcastOffer: (offerId: string) => Promise<number>;
  updatePatient: (payload: Pick<User, 'name' | 'email' | 'phone'>) => void;
  showToast: (message: string, tone?: 'success' | 'error' | 'info') => void;
  dismissToast: () => void;
}

const QUEUE_KEY = 'medflow_sync_queue_v1';

// Supabase is the only source of truth: nothing but this empty shell exists before the first load.
const initialState: PersistedState = {
  currentUser: null,
  users: [],
  doctors: [],
  specialties: [],
  center: emptyCenter,
  appointments: [],
  prescriptions: [],
  reviews: [],
  offers: [],
  attendance: [],
  schedules: [],
  leaves: [],
  activities: [],
  conversations: [],
};

const DB_OFF = 'قاعدة البيانات غير مُعدّة. أضف VITE_SUPABASE_URL و VITE_SUPABASE_PUBLISHABLE_KEY.';

function queueSync(table: string, row: Record<string, unknown>) {
  try {
    const current = JSON.parse(window.localStorage.getItem(QUEUE_KEY) ?? '[]') as Array<{ table: string; row: Record<string, unknown> }>;
    current.push({ table, row });
    window.localStorage.setItem(QUEUE_KEY, JSON.stringify(current.slice(-100)));
  } catch {
    // Storage is unavailable; the local state remains authoritative.
  }
}

async function syncRow(table: string, row: Record<string, unknown>) {
  if (!supabase) return false;
  const { error } = await supabase.from(table).upsert(row as never);
  if (error) {
    queueSync(table, row);
    return false;
  }
  return true;
}

const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistedState>(initialState);
  const [hydrated, setHydrated] = useState(false);
  const [bookedSlots, setBookedSlots] = useState<BookedSlot[]>([]);
  const [toast, setToast] = useState<StoreValue['toast']>(null);

  // Drop the old offline-mode cache so stale seed data can never leak back in.
  useEffect(() => {
    try { window.localStorage.removeItem('medflow_state_v1'); } catch { /* storage unavailable */ }
  }, []);

  useEffect(() => { setCatalog(state.doctors, state.specialties); }, [state.doctors, state.specialties]);

  const showToast = useCallback((message: string, tone: 'success' | 'error' | 'info' = 'success') => {
    setToast({ id: Date.now(), message, tone });
  }, []);

  const dismissToast = useCallback(() => setToast(null), []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const retryQueue = useCallback(async () => {
    if (!supabase) return;
    try {
      const queue = JSON.parse(window.localStorage.getItem(QUEUE_KEY) ?? '[]') as Array<{ table: string; row: Record<string, unknown> }>;
      if (!queue.length) return;
      const remaining: typeof queue = [];
      for (const item of queue) {
        const { error } = await supabase.from(item.table).upsert(item.row as never);
        if (error) remaining.push(item);
      }
      window.localStorage.setItem(QUEUE_KEY, JSON.stringify(remaining));
    } catch {
      // Retry on the next application start.
    }
  }, []);

  // Full reload from Supabase. RLS decides what the current session may see.
  const reload = useCallback(async () => {
    const client = supabase;
    if (!client) return;
    const remote = await fetchRemoteData(client);
    setState((current) => ({
      ...current,
      doctors: remote.doctors,
      specialties: remote.specialties,
      center: remote.center ?? current.center,
      appointments: remote.appointments,
      prescriptions: remote.prescriptions,
      reviews: remote.reviews,
      offers: remote.offers,
      attendance: remote.attendance,
      schedules: remote.schedules,
      leaves: remote.leaves,
      activities: remote.activities,
      conversations: remote.conversations,
      users: remote.users,
    }));
  }, []);

  const loadSession = useCallback(async () => {
    const client = supabase;
    if (!client) return null;
    const { data } = await client.auth.getSession();
    const authUser = data.session?.user;
    if (!authUser) return null;
    const { data: profile } = await client.from('profiles').select('id, full_name, role, doctor_id, phone').eq('id', authUser.id).maybeSingle();
    const user: User = {
      id: authUser.id,
      name: String(profile?.full_name ?? authUser.user_metadata?.full_name ?? authUser.email?.split('@')[0] ?? 'مستخدم ميدفلو'),
      email: authUser.email ?? '',
      phone: String(profile?.phone ?? ''),
      role: (profile?.role as Role | undefined) ?? 'patient',
      doctorId: profile?.doctor_id ? String(profile.doctor_id) : undefined,
    };
    setState((current) => ({ ...current, currentUser: user }));
    return user;
  }, []);

  // Boot: restore session first (so RLS-gated tables load), then load everything.
  useEffect(() => {
    let active = true;
    if (!supabase) {
      setHydrated(true);
      showToast(DB_OFF, 'error');
      return;
    }
    void (async () => {
      try {
        await loadSession();
        await reload();
        void retryQueue();
      } catch {
        showToast('تعذر الاتصال بقاعدة البيانات', 'error');
      } finally {
        if (active) setHydrated(true);
      }
    })();
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN' || event === 'SIGNED_OUT') {
        if (event === 'SIGNED_OUT') setState((current) => ({ ...current, currentUser: null }));
        window.setTimeout(() => { void reload(); }, 0); // never call supabase inside the auth callback
      }
    });
    return () => { active = false; sub.subscription.unsubscribe(); };
  }, [loadSession, reload, retryQueue, showToast]);

  useEffect(() => {
    const client = supabase;
    if (!client) return;
    type ChangePayload = { eventType: string; new: unknown; old: unknown };
    const upsertById = <T extends { id: string }>(items: T[], item: T) => items.some((current) => current.id === item.id)
      ? items.map((current) => current.id === item.id ? item : current)
      : [item, ...items];
    const dropById = <T extends { id: string }>(items: T[], id: string) => items.filter((item) => item.id !== id);

    const applyRecord = (table: string, payload: ChangePayload) => {
      if (payload.eventType === 'DELETE') {
        const old = payload.old as Record<string, unknown>;
        const id = String(old?.id ?? '');
        if (!id) return;
        setState((current) => ({
          ...current,
          appointments: table === 'appointments' ? dropById(current.appointments, id) : current.appointments,
          prescriptions: table === 'prescriptions' ? dropById(current.prescriptions, id) : current.prescriptions,
          reviews: table === 'reviews' ? dropById(current.reviews, id) : current.reviews,
          offers: table === 'offers' ? dropById(current.offers, id) : current.offers,
          leaves: table === 'doctor_leaves' ? dropById(current.leaves, id) : current.leaves,
          activities: table === 'activities' ? dropById(current.activities, id) : current.activities,
          conversations: table === 'conversations' ? dropById(current.conversations, id) : current.conversations,
          doctors: table === 'doctors' ? dropById(current.doctors, id) : current.doctors,
          specialties: table === 'specialties' ? dropById(current.specialties, id) : current.specialties,
        }));
        return;
      }
      const row = payload.new as Record<string, unknown>;
      if (table === 'center_settings') {
        if (row) setState((current) => ({ ...current, center: mapCenter(row) }));
        return;
      }
      if (table === 'doctor_attendance' || table === 'doctor_schedules') {
        if (!row?.doctor_id) return;
      } else if (!row?.id) return;
      setState((current) => {
        if (table === 'appointments') return { ...current, appointments: upsertById(current.appointments, mapAppointment(row)) };
        if (table === 'prescriptions') return { ...current, prescriptions: upsertById(current.prescriptions, mapPrescription(row)) };
        if (table === 'reviews') return { ...current, reviews: upsertById(current.reviews, mapReview(row)) };
        if (table === 'offers') return { ...current, offers: upsertById(current.offers, mapOffer(row)) };
        if (table === 'doctor_leaves') return { ...current, leaves: upsertById(current.leaves, mapLeave(row)) };
        if (table === 'activities') return { ...current, activities: upsertById(current.activities, mapActivity(row)) };
        if (table === 'conversations') return { ...current, conversations: upsertById(current.conversations, mapConversation(row)) };
        if (table === 'doctors') return { ...current, doctors: upsertById(current.doctors, mapDoctor(row)) };
        if (table === 'specialties') return { ...current, specialties: upsertById(current.specialties, mapSpecialty(row)) };
        if (table === 'profiles') {
          const user = mapUser(row);
          return { ...current, users: [...current.users.filter((item) => item.id !== user.id), user] };
        }
        if (table === 'doctor_attendance') {
          const attendance = mapAttendance(row);
          return { ...current, attendance: [attendance, ...current.attendance.filter((item) => !(item.doctorId === attendance.doctorId && item.date === attendance.date))] };
        }
        if (table === 'doctor_schedules') {
          const schedule = mapSchedule(row);
          return { ...current, schedules: [schedule, ...current.schedules.filter((item) => item.doctorId !== schedule.doctorId)] };
        }
        return current;
      });
    };

    const tables = ['appointments', 'prescriptions', 'reviews', 'offers', 'doctor_attendance', 'doctor_schedules', 'doctor_leaves', 'activities', 'conversations', 'profiles', 'doctors', 'specialties', 'center_settings'];
    let channel = client.channel('medflow-realtime');
    for (const table of tables) {
      channel = channel.on('postgres_changes', { event: '*', schema: 'medflow', table }, (payload) => applyRecord(table, payload as unknown as ChangePayload));
    }
    channel.subscribe();
    return () => { void client.removeChannel(channel); };
  }, []);

  const loadBookedSlots = useCallback(async (doctorId: string) => {
    if (!supabase || !doctorId) return;
    const from = new Date();
    const to = new Date(Date.now() + 45 * 86_400_000);
    const iso = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    const slots = await fetchBookedSlots(supabase, doctorId, iso(from), iso(to));
    setBookedSlots((current) => [...current.filter((item) => item.doctorId !== doctorId), ...slots]);
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    if (!supabase) throw new Error(DB_OFF);
    const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (error || !data.user) throw new Error('تعذر تسجيل الدخول. تحقق من البريد وكلمة المرور.');
    const user = await loadSession();
    if (!user) throw new Error('تعذر تحميل بيانات الحساب.');
    return user;
  }, [loadSession]);

  const restoreSession = useCallback(async () => {
    const user = await loadSession();
    if (user) await reload();
    return user;
  }, [loadSession, reload]);

  const register = useCallback(async (payload: { name: string; email: string; phone: string; password: string }) => {
    if (!supabase) throw new Error(DB_OFF);
    const { data, error } = await supabase.auth.signUp({
      email: payload.email,
      password: payload.password,
      options: { data: { full_name: payload.name, phone: payload.phone } },
    });
    if (error || !data.user) throw new Error('تعذر إنشاء الحساب. قد يكون البريد مسجلاً مسبقاً.');
    // profiles row is created by the on_auth_user_created trigger from the metadata above.
    await syncRow('patients', { id: data.user.id, full_name: payload.name, email: payload.email, phone: payload.phone, created_at: new Date().toISOString() });
    const user: User = { id: data.user.id, name: payload.name, email: payload.email, phone: payload.phone, role: 'patient' };
    setState((current) => ({ ...current, currentUser: user }));
    return user;
  }, []);

  const logout = useCallback(async () => {
    if (supabase) await supabase.auth.signOut();
    setState((current) => ({ ...current, currentUser: null }));
  }, []);

  const addAppointment = useCallback(async (payload: NewAppointment) => {
    if (!supabase) throw new Error(DB_OFF);
    const taken = state.appointments.some((item) => item.doctorId === payload.doctorId && item.date === payload.date && item.time === payload.time && item.status !== 'cancelled')
      || bookedSlots.some((item) => item.doctorId === payload.doctorId && item.date === payload.date && item.time === payload.time);
    if (taken) throw new Error('slot_taken');
    const appointment: Appointment = { ...payload, id: uid('apt'), status: 'confirmed', createdAt: new Date().toISOString() };
    const { error } = await supabase.from('appointments').insert({
      id: appointment.id,
      patient_id: appointment.patientId,
      patient_name: appointment.patientName,
      phone: appointment.phone,
      doctor_id: appointment.doctorId,
      specialty_id: appointment.specialtyId,
      appointment_date: appointment.date,
      appointment_time: appointment.time,
      status: appointment.status,
      notes: appointment.notes ?? null,
      created_at: appointment.createdAt,
    } as never);
    if (error) throw new Error(error.code === '23505' ? 'slot_taken' : 'save_failed'); // DB unique index is the final arbiter
    const activity = { id: uid('ac'), type: 'booking' as const, text: `حجز موعد جديد: ${payload.patientName}`, at: new Date().toISOString() };
    setState((current) => ({
      ...current,
      appointments: current.appointments.some((item) => item.id === appointment.id) ? current.appointments : [appointment, ...current.appointments],
      activities: [activity, ...current.activities],
    }));
    setBookedSlots((current) => [...current, { doctorId: payload.doctorId, date: payload.date, time: payload.time }]);
    void syncRow('activities', { id: activity.id, type: activity.type, text: activity.text, at: activity.at });
    void notifyN8n('appointment.created', { ...appointment, doctor_name: doctorName(appointment.doctorId), specialty_name: specialtyName(appointment.specialtyId) } as unknown as Record<string, unknown>);
    return appointment;
  }, [state.appointments, bookedSlots]);

  const updateAppointment = useCallback((id: string, status: AppointmentStatus) => {
    const client = supabase;
    if (!client) { showToast(DB_OFF, 'error'); return; }
    const previous = state.appointments.find((item) => item.id === id)?.status;
    setState((current) => ({ ...current, appointments: current.appointments.map((item) => (item.id === id ? { ...item, status } : item)) }));
    void client.from('appointments').update({ status }).eq('id', id).then(({ error }) => {
      if (!error) return;
      showToast('تعذر حفظ الحالة', 'error');
      if (previous) setState((current) => ({ ...current, appointments: current.appointments.map((item) => (item.id === id ? { ...item, status: previous } : item)) }));
    });
  }, [state.appointments, showToast]);

  // Server (service role) performs the DB update + WhatsApp; local state follows only after it succeeds.
  const cancelAppointment = useCallback(async (id: string, by: 'patient' | 'staff' | 'doctor') => {
    const appointment = state.appointments.find((item) => item.id === id);
    if (!appointment) return;
    const names = { doctor_name: doctorName(appointment.doctorId), specialty_name: specialtyName(appointment.specialtyId) };
    try {
      const res = await fetch(apiUrl('/api/cancel-booking'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'MedflowWeb' },
        body: JSON.stringify({ appointment_id: id, phone: appointment.phone, cancelled_by: by, patient_name: appointment.patientName, date: appointment.date, time: appointment.time, ...names }),
      });
      const data = await res.json().catch(() => ({})) as { message?: string; local_fallback?: boolean };
      if (!res.ok) throw new Error(data.message || 'تعذر إلغاء الموعد');
      if (data.local_fallback && supabase) {
        // Server has no service-role key: staff can still cancel through RLS, then notify n8n themselves.
        const { error } = await supabase.from('appointments').update({ status: 'cancelled', cancelled_by: by, cancelled_at: new Date().toISOString() }).eq('id', id);
        if (error) throw new Error('تعذر حفظ الإلغاء في قاعدة البيانات');
      }
    } catch (caught) {
      showToast(caught instanceof Error ? caught.message : 'تعذر إلغاء الموعد', 'error');
      return;
    }
    const activity = { id: uid('ac'), type: 'system' as const, text: `إلغاء موعد ${appointment.patientName}`, at: new Date().toISOString() };
    setState((current) => ({
      ...current,
      appointments: current.appointments.map((item) => (item.id === id ? { ...item, status: 'cancelled', cancelledBy: by } : item)),
      activities: [activity, ...current.activities],
    }));
    setBookedSlots((current) => current.filter((item) => !(item.doctorId === appointment.doctorId && item.date === appointment.date && item.time === appointment.time)));
    void syncRow('activities', { id: activity.id, type: activity.type, text: activity.text, at: activity.at });
  }, [state.appointments, showToast]);

  const addPrescription = useCallback(async (payload: Omit<Prescription, 'id' | 'date' | 'sentToWhatsApp'>) => {
    if (!supabase) throw new Error(DB_OFF);
    const prescription: Prescription = { ...payload, id: uid('rx'), date: new Date().toISOString().slice(0, 10), sentToWhatsApp: false };
    const { error } = await supabase.from('prescriptions').insert({ id: prescription.id, appointment_id: prescription.appointmentId, patient_id: prescription.patientId, doctor_id: prescription.doctorId, date: prescription.date, diagnosis: prescription.diagnosis, medications: prescription.medications, instructions: prescription.instructions, sent_to_whatsapp: false } as never);
    if (error) throw new Error('تعذر حفظ الوصفة في قاعدة البيانات');
    setState((current) => ({ ...current, prescriptions: current.prescriptions.some((item) => item.id === prescription.id) ? current.prescriptions : [prescription, ...current.prescriptions] }));
    return prescription;
  }, []);

  const markPrescriptionSent = useCallback((id: string) => {
    setState((current) => ({ ...current, prescriptions: current.prescriptions.map((item) => (item.id === id ? { ...item, sentToWhatsApp: true } : item)) }));
    if (supabase) void supabase.from('prescriptions').update({ sent_to_whatsapp: true }).eq('id', id);
  }, []);

  const addReview = useCallback(async (payload: Omit<Review, 'id' | 'date' | 'verified'>) => {
    if (!supabase) throw new Error(DB_OFF);
    const review: Review = { ...payload, id: uid('review'), date: new Date().toISOString().slice(0, 10), verified: true };
    const { error } = await supabase.from('reviews').insert({ id: review.id, patient_name: review.patientName, doctor_id: review.doctorId, rating: review.rating, text: review.text, date: review.date, verified: review.verified } as never);
    if (error) throw new Error('تعذر حفظ التقييم في قاعدة البيانات');
    setState((current) => ({ ...current, reviews: current.reviews.some((item) => item.id === review.id) ? current.reviews : [review, ...current.reviews] }));
    void notifyN8n('review.submitted', { ...review, doctor_name: doctorName(review.doctorId) } as unknown as Record<string, unknown>);
    return review;
  }, []);

  const setAttendance = useCallback((payload: Omit<Attendance, 'date'>) => {
    const attendance: Attendance = { ...payload, date: new Date().toISOString().slice(0, 10) };
    setState((current) => ({ ...current, attendance: [attendance, ...current.attendance.filter((item) => !(item.doctorId === attendance.doctorId && item.date === attendance.date))] }));
    void syncRow('doctor_attendance', { doctor_id: attendance.doctorId, attendance_date: attendance.date, status: attendance.status, note: attendance.note ?? null });
  }, []);

  const addLeave = useCallback((payload: Omit<Leave, 'id'>) => {
    const leave: Leave = { ...payload, id: uid('leave') };
    setState((current) => ({ ...current, leaves: [leave, ...current.leaves] }));
    void syncRow('doctor_leaves', { id: leave.id, doctor_id: leave.doctorId, start_date: leave.startDate, end_date: leave.endDate, reason: leave.reason });
  }, []);

  const broadcastOffer = useCallback(async (offerId: string) => {
    const client = supabase;
    const offer = state.offers.find((item) => item.id === offerId);
    if (!client || !offer) return 0;
    const numbers = Array.from(new Set(state.conversations.map((item) => item.phone).filter(Boolean))).slice(0, 500);
    const campaignId = uid('campaign');
    const { error } = await client.from('offer_campaigns').insert({ id: campaignId, offer_id: offerId, title: offer.title, recipient_count: numbers.length, status: 'staged' } as never);
    if (error) { showToast('تعذر إنشاء الحملة', 'error'); return 0; }
    if (numbers.length) {
      const { error: recipientsError } = await client.from('offer_recipients').upsert(numbers.map((phone) => ({ campaign_id: campaignId, phone, status: 'staged' })) as never, { onConflict: 'campaign_id,phone', ignoreDuplicates: true });
      if (recipientsError) { showToast('تعذر تجهيز المستلمين', 'error'); return 0; }
    }
    const result = await notifyN8n('offer.broadcast', { campaign_id: campaignId });
    showToast(result.ok ? `تم تجهيز ${numbers.length} رقماً وإرسال الحملة` : `تم تجهيز ${numbers.length} رقماً لكن تعذر تشغيل n8n`, result.ok ? 'success' : 'error');
    return numbers.length;
  }, [state.conversations, state.offers, showToast]);

  const updatePatient = useCallback((payload: Pick<User, 'name' | 'email' | 'phone'>) => {
    const user = state.currentUser;
    setState((current) => ({ ...current, currentUser: current.currentUser ? { ...current.currentUser, ...payload } : null }));
    if (user && supabase) {
      void syncRow('patients', { id: user.id, full_name: payload.name, email: payload.email, phone: payload.phone });
      // role / doctor_id are never sent: RLS only lets a user edit own name + phone.
      void supabase.from('profiles').update({ full_name: payload.name, phone: payload.phone }).eq('id', user.id).then(({ error }) => {
        if (error) showToast('تعذر حفظ البيانات', 'error');
      });
    }
  }, [state.currentUser, showToast]);

  const saveDoctor = useCallback(async (payload: Partial<Doctor> & Pick<Doctor, 'name' | 'title' | 'specialtyId'>) => {
    if (!supabase) throw new Error(DB_OFF);
    const existing = state.doctors.find((item) => item.id === payload.id);
    const doctor: Doctor = {
      id: payload.id || uid('doctor'),
      name: payload.name,
      title: payload.title,
      specialtyId: payload.specialtyId,
      experience: payload.experience ?? existing?.experience ?? 0,
      rating: payload.rating ?? existing?.rating ?? 0,
      reviews: payload.reviews ?? existing?.reviews ?? 0,
      image: payload.image ?? existing?.image ?? '/images/logo.png',
      location: payload.location ?? existing?.location ?? '',
      phone: payload.phone ?? existing?.phone ?? '',
      bio: payload.bio ?? existing?.bio ?? '',
      workingHours: payload.workingHours ?? existing?.workingHours ?? '',
    };
    const { error } = await supabase.from('doctors').upsert({ id: doctor.id, name: doctor.name, specialty_id: doctor.specialtyId, title: doctor.title, experience: doctor.experience, rating: doctor.rating, reviews: doctor.reviews, image: doctor.image, location: doctor.location, phone: doctor.phone, bio: doctor.bio, working_hours: doctor.workingHours } as never);
    if (error) throw new Error('تعذر حفظ الطبيب. هذه العملية للمدير فقط.');
    setState((current) => ({ ...current, doctors: current.doctors.some((item) => item.id === doctor.id) ? current.doctors.map((item) => item.id === doctor.id ? doctor : item) : [...current.doctors, doctor] }));
  }, [state.doctors]);

  const saveSchedule = useCallback(async (doctorId: string, hours: string) => {
    if (!supabase) throw new Error(DB_OFF);
    const current = state.schedules.find((item) => item.doctorId === doctorId);
    const { error } = await supabase.from('doctor_schedules').upsert({ doctor_id: doctorId, day_of_week: hours.split('،')[0].trim(), hours_label: hours.trim(), slots: current?.slots ?? [] } as never, { onConflict: 'doctor_id' });
    if (error) throw new Error('تعذر حفظ الجدول');
    setState((cur) => ({ ...cur, schedules: [{ doctorId, days: hours.split('،')[0].trim(), hours: hours.trim(), slots: current?.slots ?? [] }, ...cur.schedules.filter((item) => item.doctorId !== doctorId)] }));
  }, [state.schedules]);

  const saveCenter = useCallback(async (payload: Center) => {
    if (!supabase) throw new Error(DB_OFF);
    const { error } = await supabase.from('center_settings').upsert({ id: 'main', name: payload.name, short_name: payload.shortName, phone: payload.phone, whatsapp: payload.whatsapp, email: payload.email, address: payload.address, hours: payload.hours, currency: payload.currency, updated_at: new Date().toISOString() } as never);
    if (error) throw new Error('تعذر حفظ بيانات المركز. هذه العملية للمدير فقط.');
    setState((current) => ({ ...current, center: payload }));
  }, []);

  const value = useMemo<StoreValue>(() => ({
    ...state,
    hydrated,
    bookedSlots,
    loadBookedSlots,
    reload,
    saveDoctor,
    saveSchedule,
    saveCenter,
    toast,
    login,
    restoreSession,
    register,
    logout,
    addAppointment,
    updateAppointment,
    cancelAppointment,
    addPrescription,
    markPrescriptionSent,
    addReview,
    setAttendance,
    addLeave,
    broadcastOffer,
    updatePatient,
    showToast,
    dismissToast,
  }), [state, hydrated, bookedSlots, loadBookedSlots, reload, saveDoctor, saveSchedule, saveCenter, toast, login, restoreSession, register, logout, addAppointment, updateAppointment, cancelAppointment, addPrescription, markPrescriptionSent, addReview, setAttendance, addLeave, broadcastOffer, updatePatient, showToast, dismissToast]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used within StoreProvider');
  return context;
}
