import { useMemo, useRef, useState } from 'react';
import { Activity, CalendarCheck, CalendarClock, ClipboardList, Download, FileHeart, FileText, HeartPulse, MessageSquareText, Printer, Star, UserRound } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { Badge, Button, Card, EmptyState, Field, Modal, StatCard } from '../components/ui';
import { DashboardShell, DataRow, StatusBadge } from './Shared';
import { formatDate, formatDateTime } from '../lib/utils';
import { printElement, saveElementAsPdf } from '../lib/pdf';
import { cn } from '../lib/utils';

const patientTabs = [
  { id: 'appointments', label: 'مواعيدي', icon: <CalendarCheck size={15} /> },
  { id: 'prescriptions', label: 'الوصفات الطبية', icon: <FileText size={15} /> },
  { id: 'followup', label: 'المتابعة', icon: <Activity size={15} /> },
  { id: 'reviews', label: 'تقييماتي', icon: <Star size={15} /> },
  { id: 'profile', label: 'بياناتي', icon: <UserRound size={15} /> },
];

export function PatientDashboard() {
  const { currentUser, appointments, prescriptions, reviews, cancelAppointment, updatePatient, showToast, doctors } = useStore();
  const [tab, setTab] = useState('appointments');
  const [cancelId, setCancelId] = useState<string | null>(null);
  const [profile, setProfile] = useState({ name: currentUser?.name ?? '', email: currentUser?.email ?? '', phone: currentUser?.phone ?? '' });
  const [selectedPrescriptionId, setSelectedPrescriptionId] = useState<string | undefined>();
  const [invoiceAppointmentId, setInvoiceAppointmentId] = useState<string | undefined>();
  const printableRef = useRef<HTMLDivElement>(null);
  const invoiceRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);
  const patientAppointments = appointments.filter((appointment) => appointment.patientId === currentUser?.id || appointment.patientName === currentUser?.name);
  const patientPrescriptions = prescriptions.filter((prescription) => prescription.patientId === currentUser?.id || prescriptions.some((item) => item.id === prescription.id && patientAppointments.some((appointment) => appointment.id === item.appointmentId)));
  const patientReviews = reviews.filter((review) => patientAppointments.some((appointment) => appointment.patientName === review.patientName));
  const nextAppointment = patientAppointments.filter((item) => item.status === 'confirmed').sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))[0];
  const activePrescription = patientPrescriptions.find((item) => item.id === selectedPrescriptionId) ?? patientPrescriptions[0];
  const activeInvoice = patientAppointments.find((item) => item.id === invoiceAppointmentId) ?? patientAppointments[0];

  const tabCounts = useMemo(() => ({
    appointments: patientAppointments.length,
    prescriptions: patientPrescriptions.length,
    reviews: patientReviews.length,
  }), [patientAppointments.length, patientPrescriptions.length, patientReviews.length]);

  const saveProfile = () => {
    updatePatient(profile);
    showToast('تم تحديث بياناتك بنجاح');
  };

  const handlePrescriptionOutput = (id: string, format: 'print' | 'pdf') => {
    setSelectedPrescriptionId(id);
    window.setTimeout(() => {
      if (!printableRef.current) return;
      if (format === 'print') printElement(printableRef.current);
      else void saveElementAsPdf(printableRef.current, `prescription-${id}.pdf`);
    }, 60);
  };

  const handleInvoiceOutput = (id: string, format: 'print' | 'pdf') => {
    setInvoiceAppointmentId(id);
    window.setTimeout(() => {
      if (!invoiceRef.current) return;
      if (format === 'print') printElement(invoiceRef.current);
      else void saveElementAsPdf(invoiceRef.current, `invoice-${id}.pdf`);
    }, 60);
  };

  return (
    <DashboardShell
      title={`مرحباً، ${currentUser?.name?.split(' ')[0] ?? 'ضيفنا'}`}
      subtitle="تابع مواعيدك وملفك الطبي من بوابة المريض."
      icon={<HeartPulse size={23} />}
      tabs={patientTabs.map((item) => ({ ...item, count: tabCounts[item.id as keyof typeof tabCounts] }))}
      active={tab}
      onChange={setTab}
      actions={<Link to="/book" className="btn btn-primary btn-md"><CalendarCheck size={17} /> حجز موعد</Link>}
    >
      {tab === 'appointments' && (
        <div className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-3">
            <StatCard icon={<CalendarCheck size={20} />} label="إجمالي المواعيد" value={patientAppointments.length} />
            <StatCard icon={<CalendarClock size={20} />} label="المواعيد القادمة" value={patientAppointments.filter((item) => item.status === 'confirmed').length} tone="blue" />
            <StatCard icon={<FileHeart size={20} />} label="الوصفات الطبية" value={patientPrescriptions.length} tone="violet" />
          </div>
          {nextAppointment && <div className="flex flex-col items-start justify-between gap-4 rounded-2xl border border-brand-200 bg-gradient-to-l from-brand-50 to-white p-5 sm:flex-row sm:items-center"><div><p className="text-[11px] font-bold text-brand-600">موعدك القادم</p><h3 className="mt-1 font-display text-lg font-extrabold text-ink-900">{formatDate(nextAppointment.date)} · {nextAppointment.time}</h3><p className="mt-1 text-xs text-ink-500">مع {doctors.find((doctor) => doctor.id === nextAppointment.doctorId)?.name}</p></div><Badge>تأكيد فوري</Badge></div>}
          <div className="overflow-hidden rounded-2xl border border-ink-100 bg-white">
            {patientAppointments.length ? patientAppointments.map((appointment) => {
              const doctor = doctors.find((item) => item.id === appointment.doctorId);
              return <DataRow key={appointment.id} className="sm:grid-cols-[1.4fr_1fr_auto]"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-brand-50 text-brand-700"><CalendarClock size={18} /></span><div><p className="text-sm font-bold text-ink-900">{doctor?.name}</p><p className="mt-0.5 text-[11.5px] text-ink-500">{formatDateTime(appointment.date, appointment.time)}</p></div></div><div className="text-right"><StatusBadge status={appointment.status} /><p className="mt-1 text-[11px] text-ink-400">{appointment.notes || appointment.phone}</p></div><div className="flex justify-end gap-2">{appointment.status === 'confirmed' && <><Button size="sm" variant="secondary" onClick={() => setCancelId(appointment.id)}>إلغاء</Button><Button size="sm" variant="ghost" onClick={() => handleInvoiceOutput(appointment.id, 'print')}>طباعة الفاتورة</Button><Button size="sm" variant="ghost" onClick={() => handleInvoiceOutput(appointment.id, 'pdf')}><Download size={14} /> PDF</Button></>}</div></DataRow>;
            }) : <EmptyState icon={<CalendarClock size={22} />} title="لا توجد مواعيد" description="ابدأ بحجز موعدك الأول من الزر بالأعلى." action={<Link to="/book" className="btn btn-primary btn-sm">حجز موعد</Link>} />}
          </div>
        </div>
      )}

      {tab === 'prescriptions' && (
        <div className="grid gap-4 lg:grid-cols-2">
          {patientPrescriptions.length ? patientPrescriptions.map((prescription) => {
            const doctor = doctors.find((item) => item.id === prescription.doctorId);
            return <Card key={prescription.id}><div className="flex items-start justify-between"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-violet-50 text-violet-700"><FileText size={18} /></span><div><p className="text-sm font-bold text-ink-900">{prescription.diagnosis}</p><p className="mt-0.5 text-[11px] text-ink-400">{doctor?.name} · {prescription.date}</p></div></div>{prescription.sentToWhatsApp && <Badge tone="green">أُرسلت على واتساب</Badge>}</div><div className="mt-4 rounded-xl bg-ink-50 p-3"><p className="text-xs font-bold text-ink-700">الأدوية</p><p className="mt-1 text-sm leading-6 text-ink-600">{prescription.medications}</p><p className="mt-2 text-xs leading-6 text-ink-500">{prescription.instructions}</p></div><div className="mt-4 flex gap-2"><Button size="sm" variant="secondary" onClick={() => handlePrescriptionOutput(prescription.id, 'print')}><Printer size={15} /> طباعة</Button><Button size="sm" variant="ghost" onClick={() => handlePrescriptionOutput(prescription.id, 'pdf')}><Download size={15} /> PDF</Button></div></Card>;
          }) : <div className="lg:col-span-2"><EmptyState icon={<FileText size={22} />} title="لا توجد وصفات بعد" description="ستظهر الوصفات التي يصدرها الطبيب هنا." /></div>}
          <div ref={printableRef} className="hidden rounded-2xl border border-ink-100 bg-white p-8"><img src="/images/logo-full.png" alt="ميدفلو" className="mb-5 h-12" /><h2 className="font-display text-xl font-extrabold">وصفة طبية</h2>{activePrescription && <div className="mt-4 text-sm leading-7"><p><b>المريض:</b> {currentUser?.name}</p><p><b>التشخيص:</b> {activePrescription.diagnosis}</p><p><b>الأدوية:</b> {activePrescription.medications}</p><p><b>التعليمات:</b> {activePrescription.instructions}</p></div>}</div>
        </div>
      )}

      {tab === 'followup' && (
        <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
          <Card><h2 className="font-display text-lg font-extrabold text-ink-900">مسار المتابعة</h2><div className="mt-6 space-y-0">{[
            { title: 'تم استلام الوصفة', text: 'أرسلنا الوصفة إلى واتساب.', done: true },
            { title: 'موعد مراجعة القراءة', text: 'ننصح بإعادة القراءة خلال 4 أسابيع.', done: false },
            { title: 'التحليل المخبري', text: 'أرسل نتائج التحليل عبر بوابة المريض.', done: false },
          ].map((item, index) => <div key={item.title} className="relative flex gap-4 pb-7 last:pb-0"><div className="flex flex-col items-center"><span className={cn('grid size-8 place-items-center rounded-full text-xs font-bold', item.done ? 'bg-brand-600 text-white' : 'border border-ink-200 bg-white text-ink-400')}>{item.done ? '✓' : index + 1}</span>{index < 2 && <span className="mt-1 h-full w-px bg-ink-200" />}</div><div><p className="text-sm font-bold text-ink-800">{item.title}</p><p className="mt-1 text-xs leading-6 text-ink-500">{item.text}</p></div></div>)}</div></Card>
          <Card className="h-fit"><h3 className="font-display text-lg font-extrabold text-ink-900">نصائح المتابعة</h3><ul className="mt-4 space-y-3 text-sm leading-6 text-ink-600"><li className="rounded-xl bg-brand-50 p-3">سجل قراءتك والضغط بانتظام.</li><li className="rounded-xl bg-sky-50 p-3">لا توقف الدواء قبل موعد المراجعة.</li><li className="rounded-xl bg-amber-50 p-3">احتفظ بنتائج التحليل في ملفك.</li></ul></Card>
        </div>
      )}

      {tab === 'reviews' && (
        <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
          <Card><h2 className="font-display text-lg font-extrabold text-ink-900">تقييماتي السابقة</h2>{patientReviews.length ? <div className="mt-4 space-y-3">{patientReviews.map((review) => <div key={review.id} className="rounded-xl border border-ink-100 p-4"><div className="flex justify-between"><div className="flex gap-0.5">{Array.from({ length: 5 }).map((_, index) => <Star key={index} size={13} className={index < review.rating ? 'fill-amber-400 text-amber-400' : 'text-ink-200'} />)}</div><span className="text-[10px] text-ink-400">{review.date}</span></div><p className="mt-2 text-sm leading-6 text-ink-600">{review.text}</p></div>)}</div> : <EmptyState icon={<Star size={20} />} title="لم تكتب تقييماً بعد" />}</Card>
          <Card className="h-fit bg-brand-50"><MessageSquareText size={24} className="text-brand-700" /><h3 className="mt-3 font-display text-lg font-extrabold text-brand-950">شارك تجربتك</h3><p className="mt-2 text-sm leading-6 text-brand-700">تقييمك يساعد المرضى الآخرين على اختيار الطبيب المناسب.</p><Link to="/reviews" className="btn btn-primary btn-md mt-5 w-full">اكتب تقييماً</Link></Card>
        </div>
      )}

      {tab === 'profile' && (
        <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
          <Card><h2 className="font-display text-lg font-extrabold text-ink-900">البيانات الشخصية</h2><div className="mt-5 grid gap-4 sm:grid-cols-2"><Field label="الاسم الكامل" value={profile.name} onChange={(event) => setProfile({ ...profile, name: event.target.value })} /><Field label="رقم الجوال" value={profile.phone} onChange={(event) => setProfile({ ...profile, phone: event.target.value })} /><div className="sm:col-span-2"><Field label="البريد الإلكتروني" type="email" value={profile.email} onChange={(event) => setProfile({ ...profile, email: event.target.value })} /></div></div><Button className="mt-5" onClick={saveProfile}>حفظ التغييرات</Button></Card>
          <Card className="h-fit"><div className="flex items-center gap-3"><span className="grid size-12 place-items-center rounded-full bg-brand-50 text-lg font-extrabold text-brand-700">{currentUser?.name?.slice(0, 1)}</span><div><p className="font-bold text-ink-900">{currentUser?.name}</p><p className="text-xs text-ink-400">عضو منذ 2026</p></div></div><div className="mt-5 border-t border-ink-100 pt-4"><p className="flex items-center gap-2 text-xs text-ink-500"><ClipboardList size={15} /> رقم العضوية: {currentUser?.id.slice(0, 10)}</p><div className="mt-4 flex gap-2"><Button size="sm" variant="secondary" onClick={() => profileRef.current && printElement(profileRef.current)}><Printer size={14} /> طباعة الملف</Button><Button size="sm" variant="ghost" onClick={() => profileRef.current && void saveElementAsPdf(profileRef.current, 'patient-file.pdf')}><Download size={14} /> PDF</Button></div></div></Card>
        </div>
      )}

      <div ref={invoiceRef} className="hidden rounded-2xl border border-ink-100 bg-white p-8">
        <div className="flex items-start justify-between border-b border-ink-100 pb-4"><div><img src="/images/logo-full.png" alt="ميدفلو" className="h-12" /><p className="mt-1 text-xs font-bold text-brand-700">مركز ميدفلو الطبي</p></div><div className="text-left text-[10px] text-ink-500">فاتورة موعد<br />{activeInvoice?.date}</div></div>
        {activeInvoice && <div className="mt-5 text-sm leading-7"><p><b>المريض:</b> {currentUser?.name}</p><p><b>رقم الجوال:</b> {activeInvoice.phone}</p><p><b>التاريخ والوقت:</b> {formatDateTime(activeInvoice.date, activeInvoice.time)}</p><p><b>الطبيب:</b> {doctors.find((doctor) => doctor.id === activeInvoice.doctorId)?.name}</p><div className="mt-4 rounded-xl bg-ink-50 p-3">قيمة الاستشارة: 200 ر.س — الحالة: {activeInvoice.status === 'confirmed' ? 'مؤكد' : activeInvoice.status === 'completed' ? 'مكتمل' : 'ملغي'}</div></div>}
      </div>
      <div ref={profileRef} className="hidden rounded-2xl border border-ink-100 bg-white p-8"><img src="/images/logo-full.png" alt="ميدفلو" className="mb-5 h-12" /><h2 className="font-display text-xl font-extrabold">الملف الطبي</h2><div className="mt-4 grid gap-2 text-sm leading-7"><p><b>الاسم:</b> {profile.name}</p><p><b>الجوال:</b> {profile.phone}</p><p><b>البريد:</b> {profile.email}</p><p><b>المواعيد:</b> {patientAppointments.length}</p><p><b>الوصفات:</b> {patientPrescriptions.length}</p></div></div>

      <Modal open={Boolean(cancelId)} onClose={() => setCancelId(null)} title="تأكيد إلغاء الموعد" footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setCancelId(null)}>تراجع</Button><Button variant="danger" className="flex-1" onClick={async () => { if (cancelId) { await cancelAppointment(cancelId, 'patient'); showToast('تم إلغاء الموعد وإشعار العيادة'); } setCancelId(null); }}>تأكيد الإلغاء</Button></div>}>
        <p className="text-sm leading-7 text-ink-600">هل تريد إلغاء هذا الموعد؟ سيتم إشعار العيادة والمرضى تلقائياً، ويمكنك حجز موعد آخر في أي وقت.</p>
      </Modal>
    </DashboardShell>
  );
}
