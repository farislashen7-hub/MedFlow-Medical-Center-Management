import { useEffect, useMemo, useState } from 'react';
import { Activity, BarChart3, BellRing, CalendarCheck, CalendarDays, CheckCircle2, ClipboardList, FileBarChart, Gift, LayoutDashboard, MessageCircle, MessagesSquare, Send, Settings2, Star, Stethoscope, UserRound, UsersRound } from 'lucide-react';
import { useStore } from '../store';
import { Badge, Button, Card, EmptyState, Field, Modal, StatCard, TextArea } from '../components/ui';
import { DashboardShell, DataRow, StatusBadge } from './Shared';
import { BarChart, DonutChart, LineChart } from '../components/charts';
import { formatDateTime, money, sameLocalDate, uid } from '../lib/utils';
import { notifyN8n } from '../lib/n8n';

const adminTabs = [
  { id: 'overview', label: 'نظرة عامة', icon: <LayoutDashboard size={15} /> },
  { id: 'activities', label: 'الأنشطة', icon: <Activity size={15} /> },
  { id: 'doctors', label: 'الأطباء', icon: <Stethoscope size={15} /> },
  { id: 'schedules', label: 'جداول الأطباء', icon: <CalendarDays size={15} /> },
  { id: 'attendance', label: 'حضور وغياب الأطباء', icon: <CheckCircle2 size={15} /> },
  { id: 'appointments', label: 'المواعيد', icon: <CalendarCheck size={15} /> },
  { id: 'whatsapp', label: 'محادثات واتساب', icon: <MessagesSquare size={15} /> },
  { id: 'reports', label: 'التقارير والإحصائيات', icon: <FileBarChart size={15} /> },
  { id: 'offers', label: 'العروض والآراء', icon: <Gift size={15} /> },
  { id: 'reviews', label: 'آراء العملاء', icon: <Star size={15} /> },
  { id: 'center', label: 'بيانات المركز', icon: <Settings2 size={15} /> },
];

export function AdminDashboard() {
  const { appointments, reviews, activities, conversations, attendance, leaves, updateAppointment, broadcastOffer, showToast, center, doctors, offers, schedules, specialties, saveDoctor: persistDoctor, saveSchedule: persistSchedule, saveCenter } = useStore();
  const [tab, setTab] = useState('overview');
  const [report, setReport] = useState({ title: 'تقرير الأداء الشهري', details: '' });
  const [sending, setSending] = useState(false);
  const [reply, setReply] = useState('');
  const [activeConversation, setActiveConversation] = useState<string | null>(null);
  const [doctorModal, setDoctorModal] = useState(false);
  const [doctorForm, setDoctorForm] = useState({ id: '', name: '', title: '', specialtyId: '', rating: 4.8 });
  const [centerForm, setCenterForm] = useState(center);
  useEffect(() => { setCenterForm(center); }, [center]);
  const [scheduleModal, setScheduleModal] = useState<string | null>(null);
  const [scheduleHours, setScheduleHours] = useState('');
  const today = sameLocalDate(new Date());

  const counts = useMemo(() => ({ activities: activities.length, doctors: doctors.length, appointments: appointments.length, whatsapp: conversations.reduce((sum, item) => sum + item.unread, 0), offers: offers.length, reviews: reviews.length }), [activities.length, appointments.length, conversations, offers.length, reviews.length]);

  const sendReport = async () => {
    setSending(true);
    const result = await notifyN8n('report.send', { title: report.title, details: report.details, report_date: today });
    setSending(false);
    showToast(result.ok ? 'تم إرسال التقرير للجهات المسؤولة' : 'تم حفظ التقرير محلياً وتعذر الإرسال', result.ok ? 'success' : 'error');
  };

  const openDoctorEditor = (doctorId?: string) => {
    const doctor = doctors.find((item) => item.id === doctorId);
    setDoctorForm(doctor ? { id: doctor.id, name: doctor.name, title: doctor.title, specialtyId: doctor.specialtyId, rating: doctor.rating } : { id: '', name: '', title: '', specialtyId: specialties[0]?.id ?? '', rating: 4.8 });
    setDoctorModal(true);
  };

  const saveDoctor = async () => {
    if (!doctorForm.name.trim() || !doctorForm.title.trim() || !doctorForm.specialtyId) { showToast('أدخل اسم الطبيب والمسمى الوظيفي والتخصص', 'error'); return; }
    try {
      await persistDoctor({ id: doctorForm.id || undefined, name: doctorForm.name.trim(), title: doctorForm.title.trim(), specialtyId: doctorForm.specialtyId, rating: doctorForm.rating });
      setDoctorModal(false);
      showToast('تم حفظ بيانات الطبيب');
    } catch (caught) {
      showToast(caught instanceof Error ? caught.message : 'تعذر حفظ الطبيب', 'error');
    }
  };

  const openScheduleEditor = (doctorId: string) => {
    const schedule = schedules.find((item) => item.doctorId === doctorId);
    setScheduleHours(schedule?.hours ?? '');
    setScheduleModal(doctorId);
  };

  const saveSchedule = async () => {
    if (!scheduleModal || !scheduleHours.trim()) return;
    try {
      await persistSchedule(scheduleModal, scheduleHours);
      setScheduleModal(null);
      showToast('تم تحديث جدول الطبيب');
    } catch (caught) {
      showToast(caught instanceof Error ? caught.message : 'تعذر حفظ الجدول', 'error');
    }
  };

  const saveCenterForm = async () => {
    try {
      await saveCenter(centerForm);
      showToast('تم حفظ بيانات المركز');
    } catch (caught) {
      showToast(caught instanceof Error ? caught.message : 'تعذر حفظ بيانات المركز', 'error');
    }
  };

  return (
    <DashboardShell
      title="لوحة إدارة مركز ميدفلو"
      subtitle="متابعة شاملة للعيادة والأطباء والمواعيد والتواصل."
      icon={<LayoutDashboard size={23} />}
      tabs={adminTabs.map((item) => ({ ...item, count: counts[item.id as keyof typeof counts] }))}
      active={tab}
      onChange={setTab}
      actions={<Button variant="secondary" size="md" onClick={() => setTab('reports')}><FileBarChart size={16} /> إنشاء تقرير</Button>}
    >
      {tab === 'overview' && (
        <div className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4"><StatCard icon={<CalendarCheck size={20} />} label="مواعيد اليوم" value={appointments.filter((item) => item.date === today).length} hint="بزيادة 12% عن أمس" /><StatCard icon={<UsersRound size={20} />} label="مرضى نشطون" value="8,942" tone="blue" hint="إجمالي هذا الشهر" /><StatCard icon={<Stethoscope size={20} />} label="الأطباء المتاحون" value={doctors.length} tone="violet" hint="جميعهم في المواعيد" /><StatCard icon={<MessageCircle size={20} />} label="رسائل واتساب" value={counts.whatsapp} tone="amber" hint="تحتاج إلى متابعة" /></div>
          <div className="grid gap-5 lg:grid-cols-[1.35fr_.65fr]"><Card><div className="flex items-center justify-between"><div><h2 className="font-display text-lg font-extrabold text-ink-900">حركة المواعيد</h2><p className="mt-1 text-xs text-ink-400">آخر 7 أيام</p></div><Badge tone="green">+18.4%</Badge></div><LineChart data={[34, 42, 39, 55, 48, 67, 61]} labels={['سبت', 'أحد', 'اثن', 'ثلا', 'أرب', 'خمي', 'جمع']} /></Card><Card><h2 className="font-display text-lg font-extrabold text-ink-900">توزيع التخصصات</h2><div className="mt-4 flex justify-center"><DonutChart value={78} label="حجز ناجح" /></div><div className="mt-3 grid grid-cols-2 gap-2 text-[11px] text-ink-500">{specialties.slice(0, 4).map((item) => <span key={item.id} className="flex items-center gap-1.5"><span className="size-2 rounded-full bg-brand-400" /> {item.name}</span>)}</div></Card></div>
          <div className="grid gap-5 lg:grid-cols-2"><Card><div className="flex items-center justify-between"><h2 className="font-display text-lg font-extrabold text-ink-900">أحدث الأنشطة</h2><button onClick={() => setTab('activities')} className="text-xs font-bold text-brand-700">عرض الكل</button></div><div className="mt-4 space-y-3">{activities.slice(0, 5).map((activity) => <div key={activity.id} className="flex items-center gap-3 rounded-xl bg-ink-50 p-3"><span className="grid size-8 place-items-center rounded-lg bg-white text-brand-600"><Activity size={15} /></span><p className="flex-1 text-xs font-semibold text-ink-700">{activity.text}</p><span className="text-[10px] text-ink-400">{new Date(activity.at).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}</span></div>)}</div></Card><Card><h2 className="font-display text-lg font-extrabold text-ink-900">المواعيد حسب اليوم</h2><BarChart data={[38, 54, 47, 66, 59, 72, 61]} labels={['س', 'ح', 'ن', 'ث', 'ر', 'خ', 'ج']} /></Card></div>
        </div>
      )}

      {tab === 'activities' && (
        <Card className="!p-0"><div className="border-b border-ink-100 px-5 py-4"><h2 className="font-display text-lg font-extrabold text-ink-900">سجل الأنشطة</h2></div>{activities.map((activity) => <DataRow key={activity.id} className="sm:grid-cols-[1fr_1fr_auto]"><div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-xl bg-brand-50 text-brand-700"><Activity size={16} /></span><p className="text-sm font-semibold text-ink-700">{activity.text}</p></div><Badge tone="slate">{activity.type === 'booking' ? 'حجز' : activity.type === 'prescription' ? 'وصفة' : activity.type === 'review' ? 'تقييم' : activity.type === 'offer' ? 'عرض' : 'النظام'}</Badge><span className="text-[11px] text-ink-400">{new Date(activity.at).toLocaleString('ar-SA')}</span></DataRow>)}</Card>
      )}

      {tab === 'doctors' && (
        <Card className="!p-0"><div className="flex items-center justify-between border-b border-ink-100 px-5 py-4"><h2 className="font-display text-lg font-extrabold text-ink-900">إدارة الأطباء</h2><Button size="sm" variant="secondary" onClick={() => openDoctorEditor()}>إضافة طبيب</Button></div>{doctors.map((doctor) => <DataRow key={doctor.id} className="sm:grid-cols-[1.4fr_1fr_1fr_auto]"><div className="flex items-center gap-3"><img src={doctor.image} alt={doctor.name} className="size-10 rounded-xl object-cover object-top" /><div><p className="text-sm font-bold text-ink-900">{doctor.name}</p><p className="text-[11px] text-ink-400">{doctor.title}</p></div></div><p className="text-xs text-ink-600">{specialties.find((item) => item.id === doctor.specialtyId)?.name}</p><Badge tone={doctor.rating >= 4.8 ? 'green' : 'amber'}>تقييم {doctor.rating}</Badge><Button size="sm" variant="ghost" onClick={() => openDoctorEditor(doctor.id)}>تعديل</Button></DataRow>)}</Card>
      )}

      {tab === 'schedules' && (
        <div className="grid gap-4 md:grid-cols-2">{doctors.map((doctor) => { const schedule = schedules.find((item) => item.doctorId === doctor.id) ?? { doctorId: doctor.id, days: '', hours: doctor.workingHours, slots: [] as string[] }; ; return <Card key={schedule.doctorId}><div className="flex items-center justify-between"><div className="flex items-center gap-3"><img src={doctor.image} alt={doctor.name} className="size-11 rounded-xl object-cover object-top" /><div><p className="text-sm font-bold text-ink-900">{doctor.name}</p><p className="text-[11px] text-ink-400">{doctor.location}</p></div></div><Button size="sm" variant="secondary" onClick={() => openScheduleEditor(schedule.doctorId)}>تعديل</Button></div><p className="mt-4 rounded-xl bg-ink-50 p-3 text-xs leading-6 text-ink-600">{schedule.hours}</p><div className="mt-3 flex flex-wrap gap-1.5">{schedule.slots.slice(0, 6).map((slot) => <span key={slot} className="rounded-lg bg-brand-50 px-2 py-1 text-[10px] font-bold text-brand-700">{slot}</span>)}</div></Card>; })}</div>
      )}

      {tab === 'attendance' && (
        <Card className="!p-0"><div className="border-b border-ink-100 px-5 py-4"><h2 className="font-display text-lg font-extrabold text-ink-900">حضور وغياب الأطباء اليوم</h2></div>{doctors.map((doctor) => { const record = attendance.find((item) => item.doctorId === doctor.id && item.date === today); return <DataRow key={doctor.id} className="sm:grid-cols-[1.4fr_1fr_1fr]"><div className="flex items-center gap-3"><img src={doctor.image} alt={doctor.name} className="size-9 rounded-lg object-cover object-top" /><p className="text-sm font-bold text-ink-900">{doctor.name}</p></div><StatusBadge status={record?.status ?? 'absent'} /><p className="text-xs text-ink-500">{leaves.some((leave) => leave.doctorId === doctor.id && leave.startDate <= today && leave.endDate >= today) ? 'إجازة معتمدة' : record?.note ?? 'لم يسجل بعد'}</p></DataRow>; })}</Card>
      )}

      {tab === 'appointments' && (
        <Card className="!p-0"><div className="border-b border-ink-100 px-5 py-4"><h2 className="font-display text-lg font-extrabold text-ink-900">جميع المواعيد</h2></div>{appointments.map((appointment) => { const doctor = doctors.find((item) => item.id === appointment.doctorId); return <DataRow key={appointment.id} className="sm:grid-cols-[1fr_1fr_1fr_auto]"><div><p className="text-sm font-bold text-ink-900">{appointment.patientName}</p><p className="text-[11px] text-ink-400">{appointment.phone}</p></div><div><p className="text-xs font-bold text-brand-700">{formatDateTime(appointment.date, appointment.time)}</p><p className="text-[11px] text-ink-400">{doctor?.name}</p></div><StatusBadge status={appointment.status} /><div className="flex gap-1">{appointment.status === 'confirmed' && <Button size="sm" variant="ghost" onClick={() => updateAppointment(appointment.id, 'completed')}>إكمال</Button>}{appointment.status !== 'cancelled' && <Button size="sm" variant="ghost" onClick={() => updateAppointment(appointment.id, 'cancelled')}>إلغاء</Button>}</div></DataRow>; })}</Card>
      )}

      {tab === 'whatsapp' && (
        <div className="grid gap-5 lg:grid-cols-[380px_1fr]"><Card className="!p-0"><div className="border-b border-ink-100 px-5 py-4"><h2 className="font-display text-lg font-extrabold text-ink-900">المحادثات</h2></div>{conversations.map((conversation) => <button key={conversation.id} onClick={() => { setActiveConversation(conversation.id); setReply(''); }} className={`flex w-full items-center gap-3 border-b border-ink-100 p-4 text-right transition hover:bg-ink-50 ${activeConversation === conversation.id ? 'bg-brand-50' : ''}`}><span className="grid size-10 place-items-center rounded-full bg-brand-50 text-brand-700"><UserRound size={17} /></span><span className="min-w-0 flex-1"><b className="block truncate text-sm text-ink-900">{conversation.name}</b><small className="mt-0.5 block truncate text-[11px] text-ink-400">{conversation.lastMessage}</small></span>{conversation.unread > 0 && <span className="grid size-5 place-items-center rounded-full bg-brand-600 text-[10px] font-bold text-white">{conversation.unread}</span>}</button>)}</Card><Card>{activeConversation ? <><div className="flex items-center gap-3 border-b border-ink-100 pb-4"><span className="grid size-10 place-items-center rounded-full bg-brand-50 text-brand-700"><UserRound size={17} /></span><div><p className="text-sm font-bold text-ink-900">{conversations.find((item) => item.id === activeConversation)?.name}</p><p className="text-[11px] text-ink-400">متصل عبر واتساب</p></div></div><div className="my-5 rounded-2xl bg-ink-50 p-4 text-sm leading-7 text-ink-600">{conversations.find((item) => item.id === activeConversation)?.lastMessage}</div><div className="flex gap-2"><input className="field" value={reply} onChange={(event) => setReply(event.target.value)} placeholder="اكتب رداً..." /><Button onClick={() => { if (reply.trim()) { void notifyN8n('appointment.reminder', { phone: conversations.find((item) => item.id === activeConversation)?.phone, message: reply }); setReply(''); showToast('تم إرسال الرد'); } }}><Send size={17} /></Button></div></> : <EmptyState icon={<MessagesSquare size={22} />} title="اختر محادثة" description="اختر محادثة من القائمة لعرضها والرد عليها." />}</Card></div>
      )}

      {tab === 'reports' && (
        <div className="grid gap-5 lg:grid-cols-[1fr_360px]"><Card><h2 className="font-display text-lg font-extrabold text-ink-900">أداء العيادة هذا الأسبوع</h2><LineChart data={[38, 46, 42, 58, 51, 64, 60]} labels={['سبت', 'أحد', 'اثن', 'ثلا', 'أرب', 'خمي', 'جمع']} /><div className="mt-5 grid gap-3 sm:grid-cols-3"><StatCard icon={<BarChart3 size={19} />} label="نسبة الحضور" value="93%" tone="green" /><StatCard icon={<CalendarCheck size={19} />} label="الإلغاءات" value="4.2%" tone="rose" /><StatCard icon={<Gift size={19} />} label="حملات العروض" value="7" tone="amber" /></div></Card><Card><h3 className="font-display text-lg font-extrabold text-ink-900">إرسال تقرير</h3><div className="mt-5 space-y-4"><Field label="عنوان التقرير" value={report.title} onChange={(event) => setReport({ ...report, title: event.target.value })} /><TextArea label="التفاصيل" value={report.details} onChange={(event) => setReport({ ...report, details: event.target.value })} placeholder="اذخل أهم المؤشرات والملاحظات..." /><Button onClick={() => void sendReport()} disabled={sending} className="w-full"><Send size={16} /> {sending ? 'جارٍ الإرسال...' : 'إرسال التقرير'}</Button></div></Card></div>
      )}

      {tab === 'offers' && (
        <div className="grid gap-4 md:grid-cols-3">{offers.map((offer) => <Card key={offer.id}><Badge tone="amber">{offer.badge}</Badge><h3 className="mt-4 font-display text-lg font-extrabold text-ink-900">{offer.title}</h3><p className="mt-2 min-h-12 text-sm leading-6 text-ink-500">{offer.description}</p><div className="mt-4 flex items-end gap-2"><b className="text-2xl font-extrabold text-brand-700">{money(offer.price)}</b><span className="text-xs text-ink-400 line-through">{money(offer.oldPrice)}</span></div><Button className="mt-5 w-full" onClick={() => void broadcastOffer(offer.id).then((count) => showToast(`تمت تجهئة ${count} رقماً للحملة`))}><BellRing size={16} /> بث الحملة</Button></Card>)}</div>
      )}

      {tab === 'reviews' && (
        <Card className="!p-0"><div className="border-b border-ink-100 px-5 py-4"><h2 className="font-display text-lg font-extrabold text-ink-900">مراجعة آراء العملاء</h2></div>{reviews.map((review) => <DataRow key={review.id} className="sm:grid-cols-[1fr_1.4fr_auto]"><div><p className="text-sm font-bold text-ink-900">{review.patientName}</p><p className="text-[11px] text-ink-400">{doctors.find((item) => item.id === review.doctorId)?.name}</p></div><p className="text-xs leading-6 text-ink-600">{review.text}</p><div className="flex items-center gap-2"><div className="flex gap-0.5">{Array.from({ length: 5 }).map((_, index) => <Star key={index} size={12} className={index < review.rating ? 'fill-amber-400 text-amber-400' : 'text-ink-200'} />)}</div><Badge tone="green">منشور</Badge></div></DataRow>)}</Card>
      )}

      {tab === 'center' && (
        <div className="grid gap-5 lg:grid-cols-[1fr_340px]"><Card><h2 className="font-display text-lg font-extrabold text-ink-900">بيانات المركز</h2><div className="mt-5 grid gap-4 sm:grid-cols-2"><Field label="اسم المركز" value={centerForm.name} onChange={(event) => setCenterForm({ ...centerForm, name: event.target.value })} /><Field label="رقم التواصل" value={centerForm.phone} onChange={(event) => setCenterForm({ ...centerForm, phone: event.target.value })} /><Field label="واتساب (أرقام فقط)" value={centerForm.whatsapp} onChange={(event) => setCenterForm({ ...centerForm, whatsapp: event.target.value })} /><Field label="البريد الإلكتروني" value={centerForm.email} onChange={(event) => setCenterForm({ ...centerForm, email: event.target.value })} /><Field label="العنوان" value={centerForm.address} onChange={(event) => setCenterForm({ ...centerForm, address: event.target.value })} /><Field label="ساعات العمل" value={centerForm.hours} onChange={(event) => setCenterForm({ ...centerForm, hours: event.target.value })} /></div><Button className="mt-5" onClick={() => void saveCenterForm()}>حفظ البيانات</Button></Card><Card className="h-fit"><div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-xl bg-brand-50 text-brand-700"><ClipboardList size={20} /></span><div><p className="text-sm font-bold text-ink-900">حالة النظام</p><p className="text-[11px] text-ink-400">جميع الخدمات تعمل</p></div></div><div className="mt-5 space-y-3 border-t border-ink-100 pt-4 text-xs text-ink-600"><p className="flex items-center justify-between"><span>بوابة الحجز</span><Badge tone="green">متصل</Badge></p><p className="flex items-center justify-between"><span>واتساب / n8n</span><Badge tone="green">متصل</Badge></p><p className="flex items-center justify-between"><span>قاعدة البيانات</span><Badge tone="slate">وضع محلي</Badge></p></div></Card></div>
      )}
      <Modal open={doctorModal} onClose={() => setDoctorModal(false)} title={doctorForm.id ? 'تعديل بيانات الطبيب' : 'إضافة طبيب جديد'} footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setDoctorModal(false)}>إلغاء</Button><Button className="flex-1" onClick={saveDoctor}>حفظ الطبيب</Button></div>}>
        <div className="grid gap-4 sm:grid-cols-2"><Field label="اسم الطبيب" required value={doctorForm.name} onChange={(event) => setDoctorForm({ ...doctorForm, name: event.target.value })} /><Field label="المسمى الوظيفي" required value={doctorForm.title} onChange={(event) => setDoctorForm({ ...doctorForm, title: event.target.value })} /><div><label className="label">التخصص</label><select className="field mt-1.5" value={doctorForm.specialtyId} onChange={(event) => setDoctorForm({ ...doctorForm, specialtyId: event.target.value })}>{specialties.map((specialty) => <option key={specialty.id} value={specialty.id}>{specialty.name}</option>)}</select></div><Field label="التقييم" type="number" min={1} max={5} step={0.1} value={doctorForm.rating} onChange={(event) => setDoctorForm({ ...doctorForm, rating: Number(event.target.value) })} /></div>
      </Modal>
      <Modal open={Boolean(scheduleModal)} onClose={() => setScheduleModal(null)} title="تعديل جدول العمل" footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setScheduleModal(null)}>إلغاء</Button><Button className="flex-1" onClick={saveSchedule}>حفظ الجدول</Button></div>}>
        <Field label="أيام وساعات العمل" value={scheduleHours} onChange={(event) => setScheduleHours(event.target.value)} placeholder="الأحد – الخميس، 9:00 ص – 5:00 م" />
      </Modal>
    </DashboardShell>
  );
}
