import html2canvas from 'html2canvas';
import { useMemo, useRef, useState } from 'react';
import { AlertTriangle, BarChart3, CalendarCheck, CalendarClock, CalendarDays, CheckCircle2, ClipboardCheck, Clock3, FileText, MessageSquareText, Send, Stethoscope, UserRound, UsersRound } from 'lucide-react';
import { useStore } from '../store';
import { Badge, Button, Card, EmptyState, Field, Modal, StatCard, TextArea } from '../components/ui';
import { DashboardShell, DataRow, StatusBadge } from './Shared';
import { BarChart, DonutChart, LineChart } from '../components/charts';
import { formatDate, formatDateTime, sameLocalDate } from '../lib/utils';
import { notifyN8n } from '../lib/n8n';
import { whatsappUrl } from '../lib/phone';
import { saveElementAsPdf } from '../lib/pdf';

const doctorTabs = [
  { id: 'today', label: 'جدول اليوم', icon: <CalendarDays size={15} /> },
  { id: 'upcoming', label: 'المواعيد القادمة', icon: <CalendarClock size={15} /> },
  { id: 'files', label: 'ملفات المرضى', icon: <UsersRound size={15} /> },
  { id: 'manage', label: 'إدارة المواعيد', icon: <ClipboardCheck size={15} /> },
  { id: 'attendance', label: 'حضوري وغيابي', icon: <CheckCircle2 size={15} /> },
  { id: 'stats', label: 'إحصائياتي', icon: <BarChart3 size={15} /> },
  { id: 'reviews', label: 'تقييمات المرضى', icon: <MessageSquareText size={15} /> },
];

export function DoctorDashboard() {
  const { currentUser, appointments, prescriptions, reviews, updateAppointment, cancelAppointment, addPrescription, markPrescriptionSent, setAttendance, showToast, doctors } = useStore();
  const [tab, setTab] = useState('today');
  const [emergency, setEmergency] = useState(false);
  const [prescriptionApt, setPrescriptionApt] = useState<string | null>(null);
  const [prescription, setPrescription] = useState({ diagnosis: '', medications: '', instructions: '' });
  const [sending, setSending] = useState(false);
  const prescriptionRef = useRef<HTMLDivElement>(null);
  const doctorId = currentUser?.doctorId ?? '';
  const doctor = doctors.find((item) => item.id === doctorId) ?? { id: '', name: currentUser?.name ?? '', specialtyId: '', title: '', experience: 0, rating: 0, reviews: 0, image: '/images/logo.png', location: '', phone: '', bio: '', workingHours: '' };
  const today = sameLocalDate(new Date());
  const doctorAppointments = appointments.filter((appointment) => appointment.doctorId === doctorId);
  const todayAppointments = doctorAppointments.filter((appointment) => appointment.date === today);
  const upcoming = doctorAppointments.filter((appointment) => appointment.date > today && appointment.status !== 'cancelled').sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
  const patientFiles = Array.from(new Map(doctorAppointments.map((appointment) => [appointment.patientId, appointment])).values());
  const doctorReviews = reviews.filter((review) => review.doctorId === doctorId);
  const selectedAppointment = appointments.find((appointment) => appointment.id === prescriptionApt);

  const tabCounts = useMemo(() => ({ today: todayAppointments.length, upcoming: upcoming.length, files: patientFiles.length, reviews: doctorReviews.length }), [todayAppointments.length, upcoming.length, patientFiles.length, doctorReviews.length]);

  const handleEmergency = async () => {
    const affected = todayAppointments.filter((appointment) => appointment.status === 'confirmed' || appointment.status === 'pending');
    for (const appointment of affected) await cancelAppointment(appointment.id, 'doctor');
    await notifyN8n('doctor.unavailable', { doctor_id: doctorId, doctor_name: doctor.name, date: today, affected_appointments: affected.map((item) => item.id), affected: affected.map((item) => ({ patient_name: item.patientName, phone: item.phone, date: item.date, time: item.time })), reason: 'طارئ', cancelled: true });
    setEmergency(false);
    showToast(`تم إلغاء ${affected.length} موعد وإشعار المرضى`, 'info');
  };

  const issuePrescription = async () => {
    if (!selectedAppointment || !prescription.diagnosis || !prescription.medications) { showToast('أدخل التشخيص والأدوية', 'error'); return; }
    setSending(true);
    let created: Awaited<ReturnType<typeof addPrescription>>;
    try {
      created = await addPrescription({ appointmentId: selectedAppointment.id, patientId: selectedAppointment.patientId, doctorId, diagnosis: prescription.diagnosis, medications: prescription.medications, instructions: prescription.instructions });
    } catch (caught) {
      setSending(false);
      showToast(caught instanceof Error ? caught.message : 'تعذر حفظ الوصفة', 'error');
      return;
    }
    let imageData = '';
    try {
      if (prescriptionRef.current) {
        const canvas = await html2canvas(prescriptionRef.current, { scale: 1.5, backgroundColor: '#ffffff', useCORS: true, logging: false });
        imageData = canvas.toDataURL('image/jpeg', 0.82);
      }
      const result = await notifyN8n('prescription.issued', { appointment_id: selectedAppointment.id, patient_name: selectedAppointment.patientName, phone: selectedAppointment.phone, doctor_name: doctor.name, prescription_id: created.id, image_data_url: imageData, ...prescription });
      markPrescriptionSent(created.id);
      window.open(whatsappUrl(selectedAppointment.phone, `السلام عليكم ${selectedAppointment.patientName}، أرسلنا لكم وصفة الطبيب ${doctor.name}.`), '_blank', 'noopener,noreferrer');
      showToast(result.ok ? 'تم إرسال الوصفة عبر واتساب' : 'تم حفظ الوصفة وفتح واتساب لإرسالها');
    } catch {
      showToast('تم حفظ الوصفة، وتعذر إرسال الصورة تلقائياً', 'error');
    } finally {
      setSending(false); setPrescriptionApt(null); setPrescription({ diagnosis: '', medications: '', instructions: '' });
    }
  };

  return (
    <DashboardShell
      title={`مرحباً، ${doctor.name}`}
      subtitle="إدارة جدولك، ملفات المرضى، والوصفات الطبية."
      icon={<Stethoscope size={23} />}
      tabs={doctorTabs.map((item) => ({ ...item, count: tabCounts[item.id as keyof typeof tabCounts] }))}
      active={tab}
      onChange={setTab}
      actions={<Button variant="danger" size="md" onClick={() => setEmergency(true)}><AlertTriangle size={16} /> عندي ظرف</Button>}
    >
      {tab === 'today' && (
        <div className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-3"><StatCard icon={<CalendarCheck size={20} />} label="مواعيد اليوم" value={todayAppointments.length} /><StatCard icon={<CheckCircle2 size={20} />} label="مكتملة" value={todayAppointments.filter((item) => item.status === 'completed').length} tone="green" /><StatCard icon={<Clock3 size={20} />} label="متبقية" value={todayAppointments.filter((item) => item.status === 'confirmed' || item.status === 'pending').length} tone="amber" /></div>
          <div className="overflow-hidden rounded-2xl border border-ink-100 bg-white">
            {todayAppointments.length ? todayAppointments.map((appointment) => <DataRow key={appointment.id} className="sm:grid-cols-[90px_1.3fr_1fr_auto]"><div className="font-display text-lg font-extrabold text-brand-700">{appointment.time}</div><div><p className="text-sm font-bold text-ink-900">{appointment.patientName}</p><p className="mt-0.5 text-[11px] text-ink-400">{appointment.phone}</p></div><div><StatusBadge status={appointment.status} />{appointment.notes && <p className="mt-1 text-[11px] text-ink-500">{appointment.notes}</p>}</div><div className="flex justify-end gap-2">{appointment.status !== 'completed' && appointment.status !== 'cancelled' && <Button size="sm" variant="secondary" onClick={() => { setPrescriptionApt(appointment.id); setPrescription({ diagnosis: appointment.notes ?? '', medications: '', instructions: '' }); }}>وصفة</Button>}<Button size="sm" variant="ghost" onClick={() => updateAppointment(appointment.id, 'completed')}>إكمال</Button></div></DataRow>) : <EmptyState icon={<CalendarDays size={22} />} title="لا توجد مواعيد اليوم" description="استمتع بيوم هادئ، أو راجع المواعيد القادمة." />}
          </div>
        </div>
      )}

      {tab === 'upcoming' && (
        <Card className="!p-0"><div className="border-b border-ink-100 px-5 py-4"><h2 className="font-display text-lg font-extrabold text-ink-900">المواعيد القادمة</h2></div>{upcoming.length ? upcoming.map((appointment) => <DataRow key={appointment.id} className="sm:grid-cols-[1fr_1fr_auto]"><div><p className="text-sm font-bold text-ink-900">{appointment.patientName}</p><p className="mt-0.5 text-xs text-ink-500">{appointment.phone}</p></div><div><p className="text-sm font-bold text-brand-700">{formatDateTime(appointment.date, appointment.time)}</p><p className="mt-0.5 text-[11px] text-ink-400">{appointment.notes || 'زيارة عادية'}</p></div><StatusBadge status={appointment.status} /></DataRow>) : <EmptyState icon={<CalendarClock size={22} />} title="لا توجد مواعيد قادمة" />}</Card>
      )}

      {tab === 'files' && (
        <Card className="!p-0"><div className="border-b border-ink-100 px-5 py-4"><h2 className="font-display text-lg font-extrabold text-ink-900">ملفات المرضى</h2><p className="mt-1 text-xs text-ink-400">اضغط على المريض لعرض سجل زياراته.</p></div>{patientFiles.map((appointment) => <DataRow key={appointment.patientId} className="sm:grid-cols-[1fr_1fr_auto]"><div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-full bg-brand-50 text-xs font-bold text-brand-700">{appointment.patientName.slice(0, 1)}</span><div><p className="text-sm font-bold text-ink-900">{appointment.patientName}</p><p className="text-[11px] text-ink-400">{appointment.phone}</p></div></div><div className="text-xs text-ink-500">{doctorAppointments.filter((item) => item.patientId === appointment.patientId).length} زيارات سابقة</div><Button size="sm" variant="secondary" onClick={() => setTab('manage')}>فتح الملف</Button></DataRow>)}</Card>
      )}

      {tab === 'manage' && (
        <Card className="!p-0"><div className="border-b border-ink-100 px-5 py-4"><h2 className="font-display text-lg font-extrabold text-ink-900">إدارة المواعيد</h2></div>{doctorAppointments.map((appointment) => <DataRow key={appointment.id} className="sm:grid-cols-[1fr_1fr_1fr_auto]"><div><p className="text-sm font-bold text-ink-900">{appointment.patientName}</p><p className="text-[11px] text-ink-400">{appointment.phone}</p></div><p className="text-xs font-semibold text-ink-600">{formatDateTime(appointment.date, appointment.time)}</p><StatusBadge status={appointment.status} /><div className="flex gap-1">{appointment.status === 'confirmed' && <Button size="sm" variant="ghost" onClick={() => updateAppointment(appointment.id, 'completed')}>إكمال</Button>}{appointment.status !== 'cancelled' && <Button size="sm" variant="ghost" onClick={() => updateAppointment(appointment.id, 'cancelled')}>إلغاء</Button>}</div></DataRow>)}</Card>
      )}

      {tab === 'attendance' && (
        <div className="grid gap-5 lg:grid-cols-[1fr_360px]"><Card><h2 className="font-display text-lg font-extrabold text-ink-900">تسجيل حضور اليوم</h2><p className="mt-1 text-sm text-ink-500">حدّث حالتك ليظهر فريق الإدارة.</p><div className="mt-6 grid gap-3 sm:grid-cols-3">{(['present', 'absent', 'leave'] as const).map((status) => <button key={status} onClick={() => { setAttendance({ doctorId, status }); showToast('تم تحديث حالة الحضور'); }} className={`rounded-2xl border p-5 text-center transition ${status === 'present' ? 'hover:border-emerald-300 hover:bg-emerald-50' : status === 'absent' ? 'hover:border-rose-300 hover:bg-rose-50' : 'hover:border-amber-300 hover:bg-amber-50'}`}><span className="mx-auto grid size-11 place-items-center rounded-xl bg-ink-50 text-ink-500">{status === 'present' ? <CheckCircle2 size={21} /> : status === 'absent' ? <AlertTriangle size={21} /> : <Clock3 size={21} />}</span><b className="mt-3 block text-sm text-ink-800">{status === 'present' ? 'حاضر' : status === 'absent' ? 'غائب' : 'إجازة'}</b></button>)}</div></Card><Card className="h-fit"><h3 className="font-display text-lg font-extrabold text-ink-900">سجل الإجازات</h3><p className="mt-3 text-sm leading-7 text-ink-500">تُرسل طلبات الإجازة تلقائياً إلى الإدارة، وتُغلق المواعيد المتأثرة مع إشعار المرضى.</p></Card></div>
      )}

      {tab === 'stats' && (
        <div className="space-y-5"><div className="grid gap-4 sm:grid-cols-3"><StatCard icon={<UsersRound size={20} />} label="المرضى هذا الشهر" value={126} tone="blue" /><StatCard icon={<CalendarCheck size={20} />} label="نسبة الحضور" value="94%" tone="green" /><StatCard icon={<FileText size={20} />} label="وصفات صادرة" value={prescriptions.filter((item) => item.doctorId === doctorId).length + 48} tone="violet" /></div><div className="grid gap-5 lg:grid-cols-[1.4fr_.6fr]"><Card><h3 className="font-display text-lg font-extrabold text-ink-900">المواعيد الأسبوعية</h3><LineChart data={[12, 18, 15, 24, 21, 28, 19]} labels={['سبت', 'أحد', 'اثن', 'ثلا', 'أرب', 'خمي', 'جمع']} /></Card><Card><h3 className="font-display text-lg font-extrabold text-ink-900">رضا المرضى</h3><div className="mt-4"><DonutChart value={96} label="رضا" /></div></Card></div></div>
      )}

      {tab === 'reviews' && (
        <div className="grid gap-4 md:grid-cols-2">{doctorReviews.length ? doctorReviews.map((review) => <Card key={review.id}><div className="flex items-center justify-between"><div className="flex gap-0.5">{Array.from({ length: 5 }).map((_, index) => <span key={index} className={index < review.rating ? 'text-amber-400' : 'text-ink-200'}>★</span>)}</div><span className="text-[11px] text-ink-400">{review.date}</span></div><p className="mt-4 text-sm leading-7 text-ink-600">“{review.text}”</p><p className="mt-4 text-xs font-bold text-ink-800">{review.patientName}</p></Card>) : <EmptyState icon={<MessageSquareText size={22} />} title="لا توجد تقييمات بعد" />}</div>
      )}

      <Modal open={emergency} onClose={() => setEmergency(false)} title="تأكيد ظرف طارئ" footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setEmergency(false)}>تراجع</Button><Button variant="danger" className="flex-1" onClick={() => void handleEmergency()}>إلغاء المواعيد وإشعار المرضى</Button></div>}>
        <div className="rounded-xl border border-rose-200 bg-rose-50 p-4"><div className="flex items-center gap-2 font-bold text-rose-700"><AlertTriangle size={18} /> سيتم إلغاء {todayAppointments.filter((item) => item.status !== 'cancelled' && item.status !== 'completed').length} مواعيد اليوم.</div><p className="mt-2 text-sm leading-7 text-rose-600">سيصل تنبيه فوري لكل مريض عبر واتساب، ويمكن للمريض إعادة حجز موعد آخر.</p></div>
      </Modal>

      <Modal open={Boolean(prescriptionApt)} onClose={() => setPrescriptionApt(null)} title="إصدار وصفة طبية" size="lg" footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => prescriptionRef.current && void saveElementAsPdf(prescriptionRef.current, `prescription-${prescriptionApt}.pdf`)}>تنزيل PDF</Button><Button className="flex-1" disabled={sending} onClick={() => void issuePrescription()}><Send size={16} /> {sending ? 'جارٍ الإرسال...' : 'إرسال عبر واتساب'}</Button></div>}>
        <div className="grid gap-4 sm:grid-cols-2"><Field label="التشخيص" value={prescription.diagnosis} onChange={(event) => setPrescription({ ...prescription, diagnosis: event.target.value })} placeholder="مثال: ارتفاع ضغط الدم" /><Field label="الأدوية والجرعات" value={prescription.medications} onChange={(event) => setPrescription({ ...prescription, medications: event.target.value })} placeholder="الدواء — الجرعة — التكرار" /><div className="sm:col-span-2"><TextArea label="التعليمات" value={prescription.instructions} onChange={(event) => setPrescription({ ...prescription, instructions: event.target.value })} placeholder="إرشادات المريض قبل استخدام الدواء" /></div></div>
        <div ref={prescriptionRef} className="mt-6 rounded-2xl border border-ink-200 bg-white p-7 shadow-sm"><div className="flex items-start justify-between border-b border-ink-100 pb-4"><div><img src="/images/logo-full.png" alt="ميدفلو" className="h-11" /><p className="mt-1 text-xs font-bold text-brand-700">مركز ميدفلو الطبي</p></div><div className="text-left text-[10px] text-ink-500">رقم الوصفة: {prescriptionApt}<br />التاريخ: {today}</div></div><div className="mt-5 text-sm leading-7"><p><b>المريض:</b> {selectedAppointment?.patientName}</p><p><b>الطبيب:</b> {doctor.name} — {doctor.title}</p><div className="mt-4 rounded-xl bg-ink-50 p-3"><b>التشخيص:</b> {prescription.diagnosis || '—'}<br /><b>الأدوية:</b> {prescription.medications || '—'}<br /><b>التعليمات:</b> {prescription.instructions || '—'}</div></div><div className="mt-8 border-t border-ink-100 pt-3 text-[10px] text-ink-400">هذه الوصفة صادرة إلكترونياً ولا تحتاج إلى ختم أو توقيع.</div></div>
      </Modal>
    </DashboardShell>
  );
}
