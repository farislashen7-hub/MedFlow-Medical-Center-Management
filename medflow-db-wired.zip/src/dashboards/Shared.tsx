import type { ReactNode } from 'react';
import type { TabItem } from '../components/ui';
import { Tabs } from '../components/ui';
import { useStore } from '../store';
import { cn } from '../lib/utils';

export function DashboardShell({ title, subtitle, icon, tabs, active, onChange, children, actions }: { title: string; subtitle: string; icon: ReactNode; tabs: TabItem[]; active: string; onChange: (id: string) => void; children: ReactNode; actions?: ReactNode }) {
  const { currentUser } = useStore();
  return (
    <main className="container-medflow py-8 sm:py-10">
      <div className="mb-7 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
        <div className="flex items-center gap-3">
          <div className="grid size-12 place-items-center rounded-2xl bg-brand-600 text-white shadow-[0_10px_24px_-12px_rgba(15,130,113,0.8)]">{icon}</div>
          <div>
            <div className="flex items-center gap-2"><h1 className="font-display text-2xl font-extrabold text-ink-950 sm:text-3xl">{title}</h1><span className="hidden rounded-full bg-brand-50 px-2.5 py-1 text-[10.5px] font-bold text-brand-700 sm:inline">{currentUser?.role === 'admin' ? 'مدير النظام' : currentUser?.role === 'doctor' ? 'بوابة الطبيب' : 'بوابة المريض'}</span></div>
            <p className="mt-1 text-sm text-ink-500">{subtitle}</p>
          </div>
        </div>
        {actions}
      </div>
      <Tabs items={tabs} active={active} onChange={onChange} className="mb-6" />
      <div className="min-h-[420px]">{children}</div>
    </main>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; tone: 'brand' | 'green' | 'amber' | 'rose' | 'slate' }> = {
    confirmed: { label: 'مؤكد', tone: 'brand' },
    completed: { label: 'مكتمل', tone: 'green' },
    pending: { label: 'بانتظار التأكيد', tone: 'amber' },
    cancelled: { label: 'ملغي', tone: 'rose' },
    present: { label: 'حاضر', tone: 'green' },
    absent: { label: 'غائب', tone: 'rose' },
    leave: { label: 'إجازة', tone: 'amber' },
  };
  const item = map[status] ?? { label: status, tone: 'slate' as const };
  return <span className={cn('inline-flex rounded-full px-2.5 py-1 text-[11px] font-bold ring-1 ring-inset', item.tone === 'brand' ? 'bg-brand-50 text-brand-700 ring-brand-200' : item.tone === 'green' ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' : item.tone === 'amber' ? 'bg-amber-50 text-amber-700 ring-amber-200' : item.tone === 'rose' ? 'bg-rose-50 text-rose-700 ring-rose-200' : 'bg-slate-50 text-slate-700 ring-slate-200')}>{item.label}</span>;
}

export function DataRow({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn('grid items-center gap-3 border-b border-ink-100 px-4 py-3.5 last:border-0 sm:px-5', className)}>{children}</div>;
}
