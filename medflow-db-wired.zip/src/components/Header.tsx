import { AnimatePresence, motion } from 'framer-motion';
import { LogOut, Menu, UserRound, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { cn } from '../lib/utils';

const navItems = [
  { to: '/', label: 'الرئيسية' },
  { to: '/specialties', label: 'التخصصات' },
  { to: '/doctors', label: 'الأطباء' },
  { to: '/book', label: 'حجز موعد' },
  { to: '/reviews', label: 'آراء العملاء' },
  { to: '/contact', label: 'تواصل معنا' },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { currentUser, logout } = useStore();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setOpen(false), [location.pathname]);

  const dashboard = currentUser?.role === 'admin' ? '/admin' : currentUser?.role === 'doctor' ? '/doctor' : '/patient';

  return (
    <header className={cn('sticky top-0 z-40 h-16 transition-all duration-300', scrolled ? 'border-b border-ink-100 bg-white/90 backdrop-blur-xl' : 'bg-white/60 backdrop-blur-md')}>
      <div className="container-medflow flex h-full items-center justify-between gap-5">
        <Link to="/" className="flex shrink-0 items-center gap-2.5" aria-label="ميدفلو - الصفحة الرئيسية">
          <img src="/images/logo.png" alt="شعار مركز ميدفلو" className="size-10 rounded-xl object-contain" />
          <div className="hidden sm:block">
            <p className="font-display text-[17px] font-extrabold leading-none text-ink-950">ميدفلو</p>
            <p className="mt-1 text-[9px] font-semibold tracking-wide text-brand-700">مركز طبي متكامل</p>
          </div>
        </Link>

        <nav className="hidden items-center gap-0.5 lg:flex" aria-label="التنقل الرئيسي">
          {navItems.map((item) => {
            const active = item.to === '/' ? location.pathname === '/' : location.pathname.startsWith(item.to);
            return (
              <NavLink key={item.to} to={item.to} className={cn('relative rounded-lg px-3.5 py-2 text-[13.5px] font-semibold transition', active ? 'text-brand-700' : 'text-ink-600 hover:bg-ink-50 hover:text-ink-900')}>
                {item.label}
                {active && <motion.span layoutId="header-active-link" className="absolute inset-x-3 bottom-0.5 h-0.5 rounded-full bg-brand-500" transition={{ type: 'spring', stiffness: 420, damping: 34 }} />}
              </NavLink>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          {currentUser ? (
            <>
              <Link to={dashboard} className="hidden items-center gap-2 rounded-xl border border-ink-200 bg-white py-1.5 pl-2 pr-3 transition hover:border-brand-300 sm:flex">
                <span className="grid size-8 place-items-center rounded-lg bg-brand-50 text-brand-700"><UserRound size={16} /></span>
                <span className="text-right leading-tight">
                  <span className="block max-w-28 truncate text-[12.5px] font-bold text-ink-800">{currentUser.name}</span>
                  <span className="block text-[10px] font-medium text-ink-400">{currentUser.role === 'admin' ? 'مدير النظام' : currentUser.role === 'doctor' ? 'طبيب' : 'مريض'}</span>
                </span>
              </Link>
              <button onClick={async () => { await logout(); navigate('/'); }} className="grid size-9 place-items-center rounded-lg text-ink-400 transition hover:bg-rose-50 hover:text-rose-600" title="تسجيل الخروج" aria-label="تسجيل الخروج"><LogOut size={17} /></button>
            </>
          ) : (
            <div className="hidden items-center gap-2 sm:flex">
              <Link to="/login" className="btn btn-ghost btn-sm">تسجيل الدخول</Link>
              <Link to="/register" className="btn btn-primary btn-sm">إنشاء حساب</Link>
            </div>
          )}
          <button onClick={() => setOpen((value) => !value)} className="grid size-10 place-items-center rounded-xl border border-ink-200 bg-white text-ink-700 lg:hidden" aria-label="فتح القائمة" aria-expanded={open}>
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25, ease: 'easeOut' }} className="overflow-hidden border-t border-ink-100 bg-white/95 backdrop-blur-xl lg:hidden">
            <nav className="container-medflow flex flex-col gap-1 py-4">
              {navItems.map((item) => (
                <NavLink key={item.to} to={item.to} className={({ isActive }) => cn('rounded-xl px-4 py-3 text-sm font-semibold transition', isActive ? 'bg-brand-50 text-brand-700' : 'text-ink-600 hover:bg-ink-50')}>
                  {item.label}
                </NavLink>
              ))}
              {!currentUser && (
                <div className="mt-2 grid grid-cols-2 gap-2 border-t border-ink-100 pt-4">
                  <Link to="/login" className="btn btn-secondary btn-md">تسجيل الدخول</Link>
                  <Link to="/register" className="btn btn-primary btn-md">إنشاء حساب</Link>
                </div>
              )}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
