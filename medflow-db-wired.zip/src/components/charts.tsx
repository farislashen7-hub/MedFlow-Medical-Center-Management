import { cn } from '../lib/utils';

export function LineChart({ data, labels, height = 180, className }: { data: number[]; labels: string[]; height?: number; className?: string }) {
  const width = 520;
  const padding = 24;
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = Math.max(max - min, 1);
  const points = data.map((value, index) => {
    const x = padding + (index * (width - padding * 2)) / Math.max(data.length - 1, 1);
    const y = height - padding - ((value - min) / range) * (height - padding * 2);
    return { x, y };
  });
  const path = points.map((point, index) => `${index ? 'L' : 'M'} ${point.x} ${point.y}`).join(' ');
  const area = `${path} L ${points.at(-1)?.x ?? padding} ${height - padding} L ${padding} ${height - padding} Z`;

  return (
    <div className={cn('w-full', className)}>
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full overflow-visible" role="img" aria-label="رسم بياني">
        <defs><linearGradient id="line-area" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#1aa38c" stopOpacity="0.24" /><stop offset="100%" stopColor="#1aa38c" stopOpacity="0" /></linearGradient></defs>
        {[0, 1, 2, 3].map((line) => <line key={line} x1={padding} y1={padding + line * ((height - padding * 2) / 3)} x2={width - padding} y2={padding + line * ((height - padding * 2) / 3)} stroke="#eaeeef" strokeWidth="1" />)}
        <path d={area} fill="url(#line-area)" />
        <path d={path} fill="none" stroke="#0f8271" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        {points.map((point, index) => <circle key={index} cx={point.x} cy={point.y} r="4" fill="white" stroke="#0f8271" strokeWidth="2.5" />)}
        {labels.map((label, index) => <text key={label} x={points[index]?.x ?? 0} y={height - 4} textAnchor="middle" fontSize="11" fill="#8496a0">{label}</text>)}
      </svg>
    </div>
  );
}

export function DonutChart({ value, label, color = '#0f8271', size = 150 }: { value: number; label: string; color?: string; size?: number }) {
  const radius = 55;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.min(Math.max(value, 0), 100) / 100) * circumference;
  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} viewBox="0 0 140 140" role="img" aria-label={label}>
        <circle cx="70" cy="70" r={radius} fill="none" stroke="#eaeeef" strokeWidth="13" />
        <circle cx="70" cy="70" r={radius} fill="none" stroke={color} strokeWidth="13" strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={offset} transform="rotate(-90 70 70)" />
        <text x="70" y="66" textAnchor="middle" fontSize="23" fontWeight="800" fill="#172227">{value}%</text>
        <text x="70" y="86" textAnchor="middle" fontSize="10" fill="#8496a0">{label}</text>
      </svg>
    </div>
  );
}

export function BarChart({ data, labels }: { data: number[]; labels: string[] }) {
  const max = Math.max(...data, 1);
  return (
    <div className="flex h-48 items-end justify-between gap-3 pt-5" dir="ltr">
      {data.map((value, index) => (
        <div key={labels[index]} className="flex h-full flex-1 flex-col items-center justify-end gap-2">
          <span className="text-[10px] font-bold text-ink-500">{value}</span>
          <div className="w-full max-w-10 rounded-t-lg bg-brand-100 transition hover:bg-brand-200" style={{ height: `${Math.max((value / max) * 125, 5)}px` }} />
          <span className="text-[10px] text-ink-400">{labels[index]}</span>
        </div>
      ))}
    </div>
  );
}
