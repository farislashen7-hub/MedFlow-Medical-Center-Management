import { motion } from 'framer-motion';
import { Clock3, MapPin, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Doctor, Specialty } from '../types';
import { Badge, Card } from './ui';

export function DoctorCard({ doctor, specialty, index = 0 }: { doctor: Doctor; specialty?: Specialty; index?: number }) {
  return (
    <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-40px' }} whileHover={{ y: -4 }} transition={{ duration: 0.3, delay: Math.min(index * 0.05, 0.2) }}>
      <Card className="!p-0 overflow-hidden transition-shadow hover:shadow-[0_18px_45px_-24px_rgba(16,40,45,0.3)]">
        <div className="relative h-44 overflow-hidden bg-ink-100">
          <img src={doctor.image} alt={doctor.name} className="h-full w-full object-cover object-top transition duration-500 hover:scale-[1.03]" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950/55 via-transparent to-transparent" />
          <Badge className="absolute right-3 top-3 border-0 bg-white/95 shadow-sm">{specialty?.name ?? 'طبيب مركز'}</Badge>
          <div className="absolute bottom-3 left-3 flex items-center gap-1 rounded-lg bg-white/95 px-2.5 py-1.5 text-[11.5px] font-bold text-ink-800 shadow-sm">
            <Star size={13} className="fill-amber-400 text-amber-400" /> {doctor.rating.toFixed(1)} <span className="font-normal text-ink-400">({doctor.reviews})</span>
          </div>
        </div>
        <div className="p-5">
          <h3 className="font-display text-[17px] font-extrabold text-ink-900">{doctor.name}</h3>
          <p className="mt-1 text-[12.5px] font-semibold text-brand-700">{doctor.title}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-lg bg-ink-50 px-2.5 py-1.5 text-[11px] font-medium text-ink-600"><MapPin size={12} /> {doctor.location}</span>
            <span className="inline-flex items-center gap-1.5 rounded-lg bg-ink-50 px-2.5 py-1.5 text-[11px] font-medium text-ink-600"><Clock3 size={12} /> خبرة {doctor.experience} سنوات</span>
          </div>
          <Link to={`/book?doctor=${doctor.id}`} className="btn btn-secondary btn-sm mt-5 w-full">احجز مع الطبيب</Link>
        </div>
      </Card>
    </motion.div>
  );
}
