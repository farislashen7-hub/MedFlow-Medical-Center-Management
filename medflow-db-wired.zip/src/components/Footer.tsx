import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { Clock3, Mail, MapPin, MessageCircle, Phone, ShieldCheck, UserRound } from 'lucide-react';

export function Footer() {
  const { center } = useStore();
  return (
    <footer className="mt-20 bg-ink-950 py-14 text-ink-300">
      <div className="container-medflow grid gap-10 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <Link to="/" className="mb-4 flex items-center gap-3">
            <img src="/images/logo-full.png" alt="ميدفلو" className="h-11 w-auto rounded-xl bg-white p-1.5" />
            <div><p className="font-display text-lg font-extrabold text-white">ميدفلو</p><p className="text-[10px] text-brand-300">رعايتك تبدأ من موعد أسهل</p></div>
          </Link>
          <p className="max-w-sm text-sm leading-7 text-ink-400">منصة عيادات متكاملة تجمع بين حجز المواعيد، متابعة الملف الطبي، والتواصل المباشر على واتساب.</p>
          <div className="mt-5 flex flex-wrap gap-2">
            <a href={`https://wa.me/${center.whatsapp}`} target="_blank" rel="noreferrer" className="btn btn-whatsapp btn-sm"><MessageCircle size={16} /> واتساب</a>
            <Link to="/book" className="btn btn-sm border border-ink-700 bg-transparent text-white hover:border-brand-400 hover:text-brand-300">حجز موعد</Link>
          </div>
        </div>
        <div>
          <h3 className="mb-4 font-bold text-white">روابط سريعة</h3>
          <div className="flex flex-col gap-3 text-sm">
            <Link to="/specialties" className="transition hover:text-brand-300">التخصصات الطبية</Link>
            <Link to="/doctors" className="transition hover:text-brand-300">تصفح الأطباء</Link>
            <Link to="/book" className="transition hover:text-brand-300">حجز موعد</Link>
            <Link to="/reviews" className="transition hover:text-brand-300">آراء العملاء</Link>
            <Link to="/contact" className="transition hover:text-brand-300">تواصل معنا</Link>
          </div>
        </div>
        <div>
          <h3 className="mb-4 font-bold text-white">بوابات الدخول</h3>
          <div className="flex flex-col gap-3 text-sm">
            <Link to="/patient" className="transition hover:text-brand-300"><UserRound size={15} className="ml-2 inline" /> بوابة المريض</Link>
            <Link to="/doctor" className="transition hover:text-brand-300"><ShieldCheck size={15} className="ml-2 inline" /> بوابة الطبيب</Link>
            <Link to="/admin" className="transition hover:text-brand-300"><ShieldCheck size={15} className="ml-2 inline" /> لوحة الإدارة</Link>
            <Link to="/staff" className="transition hover:text-brand-300">دخول فريق العمل</Link>
          </div>
        </div>
        <div>
          <h3 className="mb-4 font-bold text-white">بيانات المركز</h3>
          <div className="space-y-3 text-sm text-ink-400">
            <p className="flex items-start gap-2"><MapPin size={17} className="mt-0.5 shrink-0 text-brand-400" /><span>{center.address}<br />الرياض، المملكة العربية السعودية</span></p>
            <a href={`tel:${center.phone}`} className="flex items-center gap-2 transition hover:text-brand-300"><Phone size={16} className="text-brand-400" /> {center.phone}</a>
            <a href={`mailto:${center.email}`} className="flex items-center gap-2 transition hover:text-brand-300"><Mail size={16} className="text-brand-400" /> {center.email}</a>
            <p className="flex items-center gap-2"><Clock3 size={16} className="text-brand-400" /> {center.hours}</p>
          </div>
        </div>
      </div>
      <div className="container-medflow mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-ink-500 sm:flex-row">
        <p>© {new Date().getFullYear()} مركز ميدفلو الطبي. جميع الحقوق محفوظة.</p>
        <p>الخصوصية · الشروط والأحكام · سياسة الإلغاء</p>
      </div>
    </footer>
  );
}
