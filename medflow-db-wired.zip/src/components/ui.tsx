import { AnimatePresence, motion } from 'framer-motion';
import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';
import { useEffect, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes } from 'react';
import { cn } from '../lib/utils';

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'dark' | 'whatsapp';
export type ButtonSize = 'sm' | 'md' | 'lg';

export function buttonClass(variant: ButtonVariant = 'primary', size: ButtonSize = 'md', className?: string) {
  return cn('btn', `btn-${variant}`, `btn-${size}`, className);
}

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
}

export function Button({ variant = 'primary', size = 'md', className, type = 'button', ...props }: ButtonProps) {
  return <button type={type} className={buttonClass(variant, size, className)} {...props} />;
}

export function Card({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('card', className)} {...props}>{children}</div>;
}

type BadgeTone = 'brand' | 'green' | 'amber' | 'rose' | 'sky' | 'violet' | 'slate' | 'dark';
const badgeTones: Record<BadgeTone, string> = {
  brand: 'bg-brand-50 text-brand-700 ring-brand-200',
  green: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  amber: 'bg-amber-50 text-amber-700 ring-amber-200',
  rose: 'bg-rose-50 text-rose-700 ring-rose-200',
  sky: 'bg-sky-50 text-sky-700 ring-sky-200',
  violet: 'bg-violet-50 text-violet-700 ring-violet-200',
  slate: 'bg-slate-50 text-slate-700 ring-slate-200',
  dark: 'bg-ink-900 text-white ring-ink-900',
};

export function Badge({ tone = 'brand', className, children }: { tone?: BadgeTone; className?: string; children: ReactNode }) {
  return <span className={cn('inline-flex items-center rounded-full px-2.5 py-1 text-[11.5px] font-semibold ring-1 ring-inset', badgeTones[tone], className)}>{children}</span>;
}

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  hint?: string;
  required?: boolean;
  icon?: ReactNode;
  suffix?: ReactNode;
}

export function Field({ label, error, hint, required, icon, suffix, className, id, ...props }: FieldProps) {
  const inputId = id ?? props.name;
  return (
    <div className="space-y-1.5">
      <label htmlFor={inputId} className="label">
        {label} {required && <span className="text-rose-500">*</span>}
      </label>
      <div className="relative">
        {icon && <span className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-ink-400">{icon}</span>}
        <input id={inputId} className={cn('field', Boolean(icon) && 'pr-11', Boolean(suffix) && 'pl-11', Boolean(error) && 'border-rose-300 focus:border-rose-400 focus:ring-rose-100', className)} {...props} />
        {suffix && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400">{suffix}</span>}
      </div>
      {error ? <p className="text-xs text-rose-600">{error}</p> : hint ? <p className="text-xs text-ink-400">{hint}</p> : null}
    </div>
  );
}

interface TextAreaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  error?: string;
  required?: boolean;
}

export function TextArea({ label, error, required, id, ...props }: TextAreaProps) {
  const inputId = id ?? props.name;
  return (
    <div className="space-y-1.5">
      <label htmlFor={inputId} className="label">{label} {required && <span className="text-rose-500">*</span>}</label>
      <textarea id={inputId} className={cn('field min-h-28 resize-y', error && 'border-rose-300')} {...props} />
      {error && <p className="text-xs text-rose-600">{error}</p>}
    </div>
  );
}

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg';
}

export function Modal({ open, onClose, title, children, footer, size = 'md' }: ModalProps) {
  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (event: KeyboardEvent) => event.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener('keydown', onKey);
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-50 flex items-end justify-center bg-ink-950/55 backdrop-blur-sm sm:items-center sm:p-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={title}
            className={cn('flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl sm:rounded-3xl', size === 'sm' ? 'sm:max-w-md' : size === 'lg' ? 'sm:max-w-3xl' : 'sm:max-w-xl')}
            initial={{ opacity: 0, y: 40, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 360, damping: 30 }}
          >
            <div className="flex items-center justify-between border-b border-ink-100 px-5 py-4">
              <h3 className="text-lg font-bold text-ink-900">{title}</h3>
              <button onClick={onClose} className="rounded-lg p-2 text-ink-400 transition hover:bg-ink-50 hover:text-ink-800" aria-label="إغلاق"><X size={19} /></button>
            </div>
            <div className="scrollbar-thin overflow-y-auto px-5 py-5">{children}</div>
            {footer && <div className="border-t border-ink-100 bg-ink-50/60 px-5 py-4">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export interface TabItem {
  id: string;
  label: string;
  icon?: ReactNode;
  count?: number;
}

export function Tabs({ items, active, onChange, className }: { items: TabItem[]; active: string; onChange: (id: string) => void; className?: string }) {
  return (
    <div className={cn('scrollbar-thin flex overflow-x-auto rounded-2xl border border-ink-100 bg-white p-1.5', className)}>
      {items.map((tab) => {
        const selected = active === tab.id;
        return (
          <button key={tab.id} onClick={() => onChange(tab.id)} className={cn('relative flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2.5 text-[13px] font-semibold transition', selected ? 'text-white' : 'text-ink-500 hover:bg-ink-50 hover:text-ink-800')}>
            {selected && <motion.span layoutId="active-dashboard-tab" className="absolute inset-0 rounded-xl bg-brand-600 shadow-sm" transition={{ type: 'spring', stiffness: 430, damping: 34 }} />}
            <span className="relative z-10 flex items-center gap-2">{tab.icon}<span>{tab.label}</span>{typeof tab.count === 'number' && <span className={cn('rounded-full px-1.5 py-0.5 text-[10.5px] font-bold', selected ? 'bg-white/20 text-white' : 'bg-ink-100 text-ink-600')}>{tab.count}</span>}</span>
          </button>
        );
      })}
    </div>
  );
}

export function StatCard({ icon, label, value, hint, tone = 'brand' }: { icon: ReactNode; label: string; value: string | number; hint?: string; tone?: 'brand' | 'blue' | 'amber' | 'rose' | 'violet' | 'green' }) {
  const tones = {
    brand: 'bg-brand-50 text-brand-700',
    blue: 'bg-sky-50 text-sky-700',
    amber: 'bg-amber-50 text-amber-700',
    rose: 'bg-rose-50 text-rose-700',
    violet: 'bg-violet-50 text-violet-700',
    green: 'bg-emerald-50 text-emerald-700',
  };
  return (
    <Card className="flex items-start gap-3.5 p-4 sm:p-5">
      <div className={cn('grid size-11 shrink-0 place-items-center rounded-xl', tones[tone])}>{icon}</div>
      <div className="min-w-0">
        <p className="text-[12.5px] text-ink-500">{label}</p>
        <p className="mt-0.5 text-2xl font-extrabold tracking-tight text-ink-900">{value}</p>
        {hint && <p className="mt-1 text-[11px] text-ink-400">{hint}</p>}
      </div>
    </Card>
  );
}

export function SectionTitle({ icon, title, subtitle, action }: { icon: ReactNode; title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4">
      <div className="flex items-center gap-3">
        <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-700">{icon}</div>
        <div>
          <h2 className="text-lg font-bold text-ink-900 sm:text-xl">{title}</h2>
          {subtitle && <p className="mt-0.5 text-sm text-ink-500">{subtitle}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

export function PageHeading({ eyebrow, title, description }: { eyebrow?: string; title: string; description?: string }) {
  return (
    <div className="mb-8 text-center">
      {eyebrow && <p className="mb-2 text-[12px] font-bold tracking-widest text-brand-600">{eyebrow}</p>}
      <h1 className="font-display text-3xl font-extrabold text-ink-950 sm:text-4xl">{title}</h1>
      {description && <p className="mx-auto mt-3 max-w-2xl text-sm leading-7 text-ink-500 sm:text-base">{description}</p>}
    </div>
  );
}

export function EmptyState({ icon, title, description, action }: { icon: ReactNode; title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-ink-200 bg-ink-50/60 px-6 py-12 text-center">
      <div className="mb-3 grid size-12 place-items-center rounded-2xl bg-white text-ink-400 shadow-sm">{icon}</div>
      <h3 className="font-bold text-ink-800">{title}</h3>
      {description && <p className="mt-1 max-w-sm text-sm text-ink-500">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Toast({ toast, onClose }: { toast: { id: number; message: string; tone: 'success' | 'error' | 'info' } | null; onClose: () => void }) {
  const Icon = toast?.tone === 'success' ? CheckCircle2 : toast?.tone === 'error' ? AlertCircle : Info;
  return (
    <AnimatePresence>
      {toast && (
        <motion.div initial={{ opacity: 0, y: -18, x: 20 }} animate={{ opacity: 1, y: 0, x: 0 }} exit={{ opacity: 0, y: -12 }} className="fixed left-4 top-20 z-[80] flex max-w-sm items-center gap-3 rounded-xl border border-ink-100 bg-white px-4 py-3 text-sm font-semibold text-ink-800 shadow-xl">
          <Icon size={19} className={toast.tone === 'success' ? 'text-brand-600' : toast.tone === 'error' ? 'text-rose-600' : 'text-sky-600'} />
          <span>{toast.message}</span>
          <button onClick={onClose} className="mr-1 text-ink-400"><X size={16} /></button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
