import { motion } from 'framer-motion';
import { ArrowLeft, Baby, HeartPulse, ShieldPlus, Smile, Sparkles, Stethoscope } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Card, PageHeading } from '../components/ui';
import { useStore } from '../store';

const icons = { HeartPulse, Baby, Sparkles, Smile, ShieldPlus };

export function SpecialtiesPage() {
  const { specialties } = useStore();
  return (
    <main className="container-medflow py-12 sm:py-16">
      <PageHeading eyebrow="تخصصات طبية" title="رعاية متخصصة لكل احتياجاتك" description="اختر التخصص المناسب، وسنساعدك في الوصول إلى الطبيب الأنسب لصحتك." />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {specialties.map((specialty, index) => {
          const Icon = icons[specialty.icon as keyof typeof icons] ?? Stethoscope;
          return (
            <motion.div key={specialty.id} id={specialty.id} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.05 }}>
              <Card className="h-full scroll-mt-24">
                <div className="flex items-start justify-between gap-4">
                  <div className="grid size-12 place-items-center rounded-xl bg-brand-50 text-brand-700"><Icon size={23} /></div>
                  <span className="rounded-full bg-ink-50 px-2.5 py-1 text-[11px] font-bold text-ink-500">{specialty.count} طبيباً</span>
                </div>
                <h2 className="mt-5 font-display text-xl font-extrabold text-ink-900">{specialty.name}</h2>
                <p className="mt-2 text-sm leading-7 text-ink-500">{specialty.description}</p>
                <ul className="mt-5 space-y-2 border-t border-ink-100 pt-4 text-[13px] text-ink-600">
                  <li className="flex items-center gap-2"><span className="size-1.5 rounded-full bg-brand-500" /> استشارات ومتابعة متخصصة</li>
                  <li className="flex items-center gap-2"><span className="size-1.5 rounded-full bg-brand-500" /> فحوصات وخطط علاج واضحة</li>
                </ul>
                <Link to={`/book?specialty=${specialty.id}`} className="btn btn-secondary btn-md mt-6 w-full">احجز هذا التخصص <ArrowLeft size={17} /></Link>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </main>
  );
}
