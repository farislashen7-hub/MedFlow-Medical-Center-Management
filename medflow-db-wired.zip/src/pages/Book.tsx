import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, CalendarDays, Check, CheckCircle2, Clock3, MapPin, Stethoscope, UserRound } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useStore } from '../store';
import { Badge, Button, Card, Field, Modal, TextArea } from '../components/ui';
import { addDays, cn, sameLocalDate } from '../lib/utils';
import { normalizePhone } from '../lib/phone';

const steps = ['التخصص', 'الطبيب', 'الموعد', 'بياناتك'];

export function BookPage() {
  const { currentUser, appointments, bookedSlots, loadBookedSlots, doctors, schedules, specialties, addAppointment, showToast } = useStore();
  const [searchParams] = useSearchParams();
  const [step, setStep] = useState(0);
  const [specialtyId, setSpecialtyId] = useState(searchParams.get('specialty') ?? '');
  const [doctorId, setDoctorId] = useState(searchParams.get('doctor') ?? '');
  const [date, setDate] = useState(addDays(new Date(), 1));
  const [time, setTime] = useState('');
  const [details, setDetails] = useState({ name: '', phone: '', email: '', notes: '' });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    setDetails({ name: currentUser?.name ?? '', phone: currentUser?.phone ?? '', email: currentUser?.email ?? '', notes: '' });
  }, [currentUser]);

  const availableDoctors = useMemo(() => doctors.filter((doctor) => !specialtyId || doctor.specialtyId === specialtyId), [doctors, specialtyId]);
  const selectedDoctor = doctors.find((doctor) => doctor.id === doctorId);
  const selectedSpecialty = specialties.find((item) => item.id === specialtyId);
  const dates = useMemo(() => Array.from({ length: 8 }, (_, index) => addDays(new Date(), index + 1)), []);
  const slots = useMemo(() => {
    const schedule = schedules.find((item) => item.doctorId === doctorId)?.slots ?? [];
    return schedule.filter((slot) => !appointments.some((appointment) => appointment.doctorId === doctorId && appointment.date === date && appointment.time === slot && appointment.status !== 'cancelled')
      && !bookedSlots.some((item) => item.doctorId === doctorId && item.date === date && item.time === slot));
  }, [appointments, bookedSlots, schedules, date, doctorId]);

  useEffect(() => { if (doctorId) void loadBookedSlots(doctorId); }, [doctorId, loadBookedSlots]);

  const canContinue = step === 0 ? Boolean(specialtyId) : step === 1 ? Boolean(doctorId) : step === 2 ? Boolean(date && time) : true;

  const submit = async () => {
    if (!currentUser || !selectedDoctor || !selectedSpecialty) return;
    if (!details.name.trim() || !normalizePhone(details.phone).valid) { showToast('تحقق من الاسم ورقم الجوال', 'error'); return; }
    setSubmitting(true);
    try {
      const appointment = await addAppointment({ patientId: currentUser.id, patientName: details.name.trim(), phone: details.phone, doctorId: selectedDoctor.id, specialtyId: selectedSpecialty.id, date, time, notes: details.notes });
      setSuccess(true);
      void appointment;
    } catch (error) {
      showToast(error instanceof Error && error.message === 'slot_taken' ? 'هذا الموعد تم حجزه للتو. اختر وقتاً آخر.' : 'تعذر إكمال الحجز، حاول مجدداً.', 'error');
      setStep(2);
      setTime('');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="container-medflow py-10 sm:py-14">
      <div className="mb-8 text-center">
        <p className="text-[12px] font-bold tracking-widest text-brand-600">حجز إلكتروني سريع</p>
        <h1 className="mt-2 font-display text-3xl font-extrabold text-ink-950 sm:text-4xl">احجز موعدك في 4 خطوات</h1>
        <p className="mt-2 text-sm text-ink-500">اختياراتك محفوظة تلقائياً حتى تكمل على الموعد.</p>
      </div>

      <div className="mx-auto mb-8 max-w-3xl">
        <div className="flex items-center">
          {steps.map((label, index) => (
            <div key={label} className={cn('flex items-center', index < steps.length - 1 && 'flex-1')}>
              <div className="flex flex-col items-center gap-1.5">
                <span className={cn('grid size-9 place-items-center rounded-full border-2 text-xs font-extrabold transition', index < step ? 'border-brand-600 bg-brand-600 text-white' : index === step ? 'animate-pulse-ring border-brand-600 bg-white text-brand-700' : 'border-ink-200 bg-white text-ink-400')}>{index < step ? <Check size={16} /> : index + 1}</span>
                <span className={cn('hidden whitespace-nowrap text-[11px] font-bold sm:block', index === step ? 'text-brand-700' : 'text-ink-400')}>{label}</span>
              </div>
              {index < steps.length - 1 && <div className={cn('mx-2 mb-5 h-0.5 flex-1 rounded-full sm:mb-6', index < step ? 'bg-brand-500' : 'bg-ink-100')} />}
            </div>
          ))}
        </div>
      </div>

      <Card className="mx-auto max-w-4xl !p-5 sm:!p-7">
        <AnimatePresence mode="wait">
          <motion.div key={step} initial={{ opacity: 0, x: 25 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -25 }} transition={{ duration: 0.25 }}>
            {step === 0 && (
              <div>
                <h2 className="font-display text-xl font-extrabold text-ink-900">اختر التخصص الطبي</h2><p className="mt-1 text-sm text-ink-500">سيظهر لك الأطباء المتاحون في التخصص المختار.</p>
                <div className="mt-6 grid gap-3 sm:grid-cols-2">
                  {specialties.map((specialty) => (
                    <button key={specialty.id} onClick={() => { setSpecialtyId(specialty.id); setDoctorId(''); }} className={cn('flex items-start gap-3 rounded-2xl border p-4 text-right transition', specialtyId === specialty.id ? 'border-brand-400 bg-brand-50 ring-4 ring-brand-100' : 'border-ink-200 hover:border-brand-300 hover:bg-brand-50/40')}>
                      <span className={cn('grid size-10 shrink-0 place-items-center rounded-xl', specialtyId === specialty.id ? 'bg-brand-600 text-white' : 'bg-ink-50 text-ink-500')}><Stethoscope size={18} /></span>
                      <span><b className="block text-sm text-ink-900">{specialty.name}</b><small className="mt-1 block text-[11.5px] leading-5 text-ink-500">{specialty.description}</small></span>
                      {specialtyId === specialty.id && <CheckCircle2 size={17} className="mr-auto shrink-0 text-brand-600" />}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 1 && (
              <div>
                <h2 className="font-display text-xl font-extrabold text-ink-900">اختر الطبيب</h2><p className="mt-1 text-sm text-ink-500">{selectedSpecialty?.name} · {availableDoctors.length} طبيباً متاحاً</p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  {availableDoctors.map((doctor) => (
                    <button key={doctor.id} onClick={() => { setDoctorId(doctor.id); setTime(''); }} className={cn('overflow-hidden rounded-2xl border text-right transition', doctorId === doctor.id ? 'border-brand-400 bg-brand-50 ring-4 ring-brand-100' : 'border-ink-200 hover:border-brand-300')}>
                      <div className="flex items-center gap-4 p-4"><img src={doctor.image} alt={doctor.name} className="size-16 rounded-xl object-cover object-top" /><div className="min-w-0"><b className="block font-display text-[15px] font-extrabold text-ink-900">{doctor.name}</b><span className="mt-1 block text-xs font-semibold text-brand-700">{doctor.title}</span><span className="mt-2 flex items-center gap-1 text-[11px] text-ink-500"><MapPin size={12} /> {doctor.location}</span></div></div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 2 && (
              <div>
                <h2 className="font-display text-xl font-extrabold text-ink-900">اختر التاريخ والوقت</h2><p className="mt-1 text-sm text-ink-500">المواعيد المتاحة مع {selectedDoctor?.name}</p>
                <div className="scrollbar-thin mt-6 flex gap-2 overflow-x-auto pb-2">
                  {dates.map((item) => {
                    const parsed = new Date(`${item}T12:00:00`);
                    const day = new Intl.DateTimeFormat('ar-SA-u-ca-gregory', { weekday: 'short' }).format(parsed);
                    const number = new Intl.DateTimeFormat('ar-SA-u-ca-gregory', { day: 'numeric' }).format(parsed);
                    const month = new Intl.DateTimeFormat('ar-SA-u-ca-gregory', { month: 'short' }).format(parsed);
                    return <button key={item} onClick={() => { setDate(item); setTime(''); }} className={cn('min-w-[82px] rounded-xl border px-3 py-3 text-center transition', date === item ? 'border-brand-500 bg-brand-600 text-white' : 'border-ink-200 bg-white text-ink-600 hover:border-brand-300')}><span className="block text-[10.5px] font-semibold opacity-75">{day}</span><b className="my-1 block text-xl font-extrabold">{number}</b><span className="block text-[10px] opacity-75">{month}</span></button>;
                  })}
                </div>
                <div className="mt-6 rounded-2xl bg-ink-50 p-4"><div className="mb-4 flex items-center gap-2 text-sm font-bold text-ink-800"><Clock3 size={17} className="text-brand-600" /> الأوقات المتاحة</div><div className="grid grid-cols-3 gap-2 sm:grid-cols-5">{slots.map((slot) => <button key={slot} onClick={() => setTime(slot)} className={cn('rounded-lg border px-2 py-2.5 text-xs font-bold transition', time === slot ? 'border-brand-600 bg-brand-600 text-white' : 'border-ink-200 bg-white text-ink-700 hover:border-brand-400')}>{slot}</button>)}{!slots.length && <p className="col-span-full py-6 text-center text-sm text-ink-400">لا توجد أوقات متاحة في هذا اليوم، اختر تاريخاً آخر.</p>}</div></div>
              </div>
            )}

            {step === 3 && (
              <div>
                <h2 className="font-display text-xl font-extrabold text-ink-900">أدخل بياناتك</h2><p className="mt-1 text-sm text-ink-500">ستستخدم هذه البيانات لإرسال تأكيد الموعد.</p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <Field label="الاسم الكامل" name="name" required value={details.name} onChange={(event) => setDetails({ ...details, name: event.target.value })} icon={<UserRound size={17} />} />
                  <Field label="رقم الجوال" name="phone" type="tel" inputMode="tel" required value={details.phone} onChange={(event) => setDetails({ ...details, phone: event.target.value })} placeholder="05xxxxxxxx" />
                  <div className="sm:col-span-2"><Field label="البريد الإلكتروني" name="email" type="email" inputMode="email" value={details.email} onChange={(event) => setDetails({ ...details, email: event.target.value })} placeholder="name@example.com" /></div>
                  <div className="sm:col-span-2"><TextArea label="ملاحظات للطبيب (اختياري)" name="notes" value={details.notes} onChange={(event) => setDetails({ ...details, notes: event.target.value })} placeholder="اذكر سبب الزيارة أو أي ملاحظة مهمة..." /></div>
                </div>
                <div className="mt-5 rounded-2xl border border-brand-100 bg-brand-50 p-4"><p className="text-sm font-bold text-brand-900">ملخص الموعد</p><div className="mt-3 grid gap-2 text-xs text-brand-700 sm:grid-cols-2"><span>التخصص: {selectedSpecialty?.name}</span><span>الطبيب: {selectedDoctor?.name}</span><span>التاريخ: {date}</span><span>الوقت: {time}</span></div></div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        <div className="mt-7 flex items-center justify-between border-t border-ink-100 pt-5">
          <Button variant="secondary" disabled={step === 0} onClick={() => setStep((value) => Math.max(0, value - 1))}><ArrowRight size={17} /> السابق</Button>
          {step < 3 ? <Button disabled={!canContinue} onClick={() => setStep((value) => Math.min(3, value + 1))}>التالي <ArrowLeft size={17} /></Button> : <Button disabled={submitting} onClick={() => void submit()}>{submitting ? 'جارٍ الحجز...' : 'تأكيد الحجز'} <CheckCircle2 size={17} /></Button>}
        </div>
      </Card>

      <Modal open={success} onClose={() => setSuccess(false)} title="تم تأكيد موعدك" footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setSuccess(false)}>إغلاق</Button><Link to="/patient" className="btn btn-primary btn-md flex-1">فتح بوابة المريض</Link></div>}>
        <div className="text-center"><span className="mx-auto grid size-16 place-items-center rounded-full bg-brand-50 text-brand-600"><CheckCircle2 size={32} /></span><h3 className="mt-4 font-display text-2xl font-extrabold text-ink-900">موعدك محفوظ بنجاح</h3><p className="mt-2 text-sm leading-7 text-ink-500">أرسلنا تفاصيل الموعد إلى واتساب. يمكنك مراجعته أو إلغائه من بوابة المريض.</p><div className="mt-5 rounded-2xl bg-ink-50 p-4 text-right text-sm"><div className="flex items-center gap-2 font-bold text-ink-900"><CalendarDays size={17} className="text-brand-600" /> {date} · {time}</div><p className="mt-2 text-ink-600">{selectedDoctor?.name} — {selectedSpecialty?.name}</p></div></div>
      </Modal>
    </main>
  );
}
