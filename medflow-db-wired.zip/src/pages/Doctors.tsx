import { useMemo, useState } from 'react';
import { Search, SlidersHorizontal, Stethoscope } from 'lucide-react';
import { DoctorCard } from '../components/DoctorCard';
import { EmptyState, PageHeading } from '../components/ui';
import { useStore } from '../store';

export function DoctorsPage() {
  const { doctors, specialties } = useStore();
  const [query, setQuery] = useState('');
  const [specialty, setSpecialty] = useState('all');
  const filtered = useMemo(() => doctors.filter((doctor) => {
    const matchesQuery = `${doctor.name} ${doctor.title}`.includes(query);
    return matchesQuery && (specialty === 'all' || doctor.specialtyId === specialty);
  }), [doctors, query, specialty]);

  return (
    <main className="container-medflow py-12 sm:py-16">
      <PageHeading eyebrow="فريق العيادة" title="أطباء معتمدون" description="اختر الطبيب المناسب حسب التخصص، واطّلع على تقييمات المرضى وخبرته الطبية." />
      <div className="mb-8 grid gap-3 rounded-2xl border border-ink-100 bg-white p-3 shadow-sm md:grid-cols-[1fr_auto]">
        <div className="relative"><Search size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-400" /><input className="field pr-11" placeholder="ابحث باسم الطبيب أو التخصص..." value={query} onChange={(event) => setQuery(event.target.value)} /></div>
        <div className="scrollbar-thin flex gap-2 overflow-x-auto">
          <button onClick={() => setSpecialty('all')} className={`btn btn-sm shrink-0 ${specialty === 'all' ? 'btn-primary' : 'btn-secondary'}`}>الكل</button>
          {specialties.map((item) => <button key={item.id} onClick={() => setSpecialty(item.id)} className={`btn btn-sm shrink-0 ${specialty === item.id ? 'btn-primary' : 'btn-secondary'}`}>{item.name}</button>)}
        </div>
      </div>
      {filtered.length ? (
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{filtered.map((doctor, index) => <DoctorCard key={doctor.id} doctor={doctor} specialty={specialties.find((item) => item.id === doctor.specialtyId)} index={index} />)}</div>
      ) : <EmptyState icon={<Stethoscope size={22} />} title="لا توجد نتائج مطابقة" description="جرّب تغيير كلمة البحث أو التخصص المختار." />}
    </main>
  );
}
