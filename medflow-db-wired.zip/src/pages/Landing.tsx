import { motion } from 'framer-motion';
import { ArrowLeft, Baby, BadgeCheck, CalendarCheck, CalendarDays, CheckCircle2, Clock3, HeartPulse, MessageCircle, ShieldPlus, Smile, Sparkles, Star, Stethoscope, UsersRound } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { DoctorCard } from '../components/DoctorCard';
import { Badge, Card, SectionTitle } from '../components/ui';
import { cn } from '../lib/utils';

const specialtyIcons: Record<string, typeof HeartPulse> = { HeartPulse, Baby, Sparkles, Smile, ShieldPlus };

export function LandingPage() {
  const { reviews, center, doctors, offers, specialties } = useStore();
  const visibleReviews = reviews.slice(0, 3);

  return (
    <main>
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -top-24 right-[-100px] size-[420px] rounded-full bg-brand-200/40 blur-3xl" />
        <div className="pointer-events-none absolute bottom-10 left-[-90px] size-[360px] rounded-full bg-sky-200/30 blur-3xl" />
        <div className="container-medflow relative grid items-center gap-12 py-12 lg:grid-cols-2 lg:py-20">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.55, ease: 'easeOut' }}>
            <Badge className="gap-1.5 border border-brand-200 py-1.5 text-[12px] font-bold">
              <Sparkles size={14} className="text-brand-600" /> {center.name}
            </Badge>
            <h1 className="mt-6 font-display text-[34px] font-extrabold leading-[1.25] text-ink-950 sm:text-5xl lg:text-[52px]">
              رعايتك تبدأ من <span className="relative inline-block text-brand-600"><span className="relative z-10">موعد أسهل</span><span className="absolute inset-x-0 bottom-1 z-0 h-[7px] rounded-full bg-brand-200/60" /></span>
              <br /> وتجربة عيادة أسرع
            </h1>
            <p className="mt-6 max-w-xl text-[15px] leading-8 text-ink-600">
              احجز موعدك مع أفضل الأطباء حسب التخصص، تابع نتائجك وملفك الطبي، واحصل على وصفتك الطبية وكل تحديثات العيادة مباشرة على واتساب — من مكان واحد.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row lg:flex-wrap">
              <Link to="/book" className="btn btn-primary btn-lg"><CalendarCheck size={19} /> احجز موعدك الآن</Link>
              <Link to="/doctors" className="btn btn-secondary btn-lg">تصفّح الأطباء <ArrowLeft size={18} /></Link>
              <a href={`https://wa.me/${center.whatsapp}?text=${encodeURIComponent('مرحباً، أود الاستفسار عن خدمات مركز ميدفلو')}`} target="_blank" rel="noreferrer" className="btn btn-whatsapp btn-lg"><MessageCircle size={19} /> استفسر عبر واتساب</a>
            </div>
            <div className="mt-9 flex flex-wrap items-center gap-x-7 gap-y-3 text-[12.5px] font-semibold text-ink-500">
              <span className="flex items-center gap-2"><CalendarCheck size={17} className="text-brand-600" /> <b className="text-ink-800">+١٢,٤٠٠</b> موعد منجز</span>
              <span className="flex items-center gap-2"><UsersRound size={17} className="text-brand-600" /> <b className="text-ink-800">+٨,٩٠٠</b> مسجل في المنصة</span>
              <span className="flex items-center gap-2"><Star size={17} className="fill-brand-500 text-brand-500" /> تقييم <b className="text-ink-800">4.8</b> من 5</span>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.55, delay: 0.12, ease: 'easeOut' }} className="relative">
            <div className="relative h-[340px] overflow-visible rounded-[28px] border border-ink-100 bg-ink-100 shadow-[0_30px_70px_-30px_rgba(16,40,45,0.35)] sm:h-[430px]">
              <img src="/images/hero.jpg" alt="فريق أطباء مركز ميدفلو" className="h-full w-full rounded-[28px] object-cover" />
              <div className="absolute inset-0 rounded-[28px] bg-gradient-to-t from-ink-950/20 to-transparent" />
            </div>
            <div className="animate-floaty absolute -bottom-5 left-2 flex items-center gap-3 rounded-2xl border border-ink-100 bg-white/95 p-3.5 shadow-xl backdrop-blur sm:-left-5 sm:bottom-8 sm:p-4">
              <div className="grid size-11 place-items-center rounded-xl bg-brand-50 text-brand-700"><CalendarDays size={21} /></div>
              <div><p className="text-[10.5px] font-semibold text-ink-400">موعدك القادم</p><p className="mt-0.5 text-sm font-bold text-ink-900">الأحد، 10:30 صباحاً</p></div>
            </div>
            <div className="absolute -right-2 top-5 rounded-2xl border border-ink-100 bg-white/95 p-3.5 shadow-xl backdrop-blur sm:-right-5 sm:top-8">
              <p className="text-[10.5px] font-semibold text-ink-400">رضا المرضى</p><p className="mt-0.5 text-xl font-extrabold text-ink-900">98%</p>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="container-medflow py-14 sm:py-18">
        <SectionTitle icon={<Stethoscope size={20} />} title="تخصصات نساعدك فيها" subtitle="اختر التخصص المناسب وابدأ رعايتك مع فريق متخصص" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {specialties.map((specialty, index) => {
            const Icon = specialtyIcons[specialty.icon] ?? Stethoscope;
            const tint = { rose: 'bg-rose-50 text-rose-600', sky: 'bg-sky-50 text-sky-600', violet: 'bg-violet-50 text-violet-600', amber: 'bg-amber-50 text-amber-600', brand: 'bg-brand-50 text-brand-700' }[specialty.tint];
            return (
              <motion.div key={specialty.id} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.05 }}>
                <Link to={`/specialties#${specialty.id}`} className="block">
                  <Card className="group h-full transition duration-300 hover:-translate-y-1 hover:border-brand-200 hover:shadow-lg">
                    <div className={cn('grid size-11 place-items-center rounded-xl transition group-hover:scale-105', tint)}><Icon size={21} /></div>
                    <h3 className="mt-4 font-display text-base font-extrabold text-ink-900">{specialty.name}</h3>
                    <p className="mt-2 text-[13px] leading-6 text-ink-500">{specialty.description}</p>
                    <div className="mt-4 flex items-center justify-between text-[11.5px] font-semibold text-ink-400"><span>{specialty.count} طبيباً متخصصاً</span><ArrowLeft size={15} className="text-brand-600 transition group-hover:-translate-x-1" /></div>
                  </Card>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </section>

      <section className="container-medflow py-6">
        <div className="rounded-[28px] bg-ink-950 px-6 py-14 text-white sm:px-10">
          <div className="text-center">
            <p className="text-[12px] font-bold tracking-widest text-brand-300">ثلاث خطوات فقط</p>
            <h2 className="mt-3 font-display text-3xl font-extrabold">كيف تحجز موعدك؟</h2>
          </div>
          <div className="mt-10 grid gap-7 md:grid-cols-3">
            {[
              { n: '١', title: 'اختر التخصص والطبيب', text: 'حدد الخدمة والطبيب المناسب، واطّلع على أوقات العمل والتقييمات.' },
              { n: '٢', title: 'حدد اليوم والموعد', text: 'اختر التاريخ والوقت المناسبين وأدخل بياناتك في خطوة واحدة.' },
              { n: '٣', title: 'استلم تأكيدك', text: 'يصلك التأكيد والتفاصيل والتذكير مباشرة على واتساب.' },
            ].map((step) => (
              <div key={step.n} className="relative rounded-2xl border border-white/10 bg-white/[0.04] p-6">
                <span className="grid size-11 place-items-center rounded-xl bg-brand-500 font-display text-lg font-extrabold text-white shadow-[0_0_0_8px_rgba(26,163,140,0.12)]">{step.n}</span>
                <h3 className="mt-5 font-display text-lg font-extrabold">{step.title}</h3>
                <p className="mt-2 text-sm leading-7 text-ink-400">{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container-medflow py-16">
        <SectionTitle icon={<Sparkles size={20} />} title="عروض خاصة" subtitle="أسعار مميزة لفترة محدودة على مجموعة من الخدمات" />
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {offers.map((offer, index) => {
            const theme = offer.theme === 'brand' ? 'from-brand-700 to-brand-500' : offer.theme === 'amber' ? 'from-amber-600 to-amber-400' : 'from-sky-700 to-sky-500';
            return (
              <motion.div key={offer.id} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.07 }}>
                <div className={cn('relative h-full overflow-hidden rounded-2xl bg-gradient-to-br p-6 text-white shadow-lg', theme)}>
                  <div className="absolute -left-8 -top-8 size-32 rounded-full bg-white/10" />
                  <Badge className="border-0 bg-white/90 text-ink-800">{offer.badge}</Badge>
                  <h3 className="mt-5 font-display text-xl font-extrabold">{offer.title}</h3>
                  <p className="mt-2 min-h-12 text-sm leading-6 text-white/80">{offer.description}</p>
                  <div className="mt-5 flex items-end gap-2"><span className="text-3xl font-extrabold">{offer.price}</span><span className="pb-1 text-sm">ر.س</span><span className="pb-1 text-sm text-white/60 line-through">{offer.oldPrice} ر.س</span></div>
                  <Link to="/book" className="btn btn-md mt-6 w-full border-0 bg-white text-ink-900 hover:bg-ink-50">احجز العرض</Link>
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="container-medflow">
          <SectionTitle icon={<MessageCircle size={20} />} title="آراء العملاء" subtitle="ماذا يقول مرضانا" />
          <div className="grid gap-4 md:grid-cols-3">
            {visibleReviews.map((review, index) => (
              <motion.div key={review.id} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.06 }}>
                <Card className="h-full">
                  <div className="flex items-center justify-between"><div className="flex gap-0.5">{Array.from({ length: 5 }).map((_, star) => <Star key={star} size={15} className={cn(star < review.rating ? 'fill-amber-400 text-amber-400' : 'fill-ink-100 text-ink-100')} />)}</div><Badge tone="green"><BadgeCheck size={12} className="ml-1" /> زيارة موثقة</Badge></div>
                  <p className="mt-4 text-sm leading-7 text-ink-600">“{review.text}”</p>
                  <div className="mt-5 flex items-center gap-3 border-t border-ink-100 pt-4"><span className="grid size-9 place-items-center rounded-full bg-brand-50 text-xs font-bold text-brand-700">{review.patientName.slice(0, 1)}</span><div><p className="text-[13px] font-bold text-ink-800">{review.patientName}</p><p className="text-[10.5px] text-ink-400">زيارة العيادة</p></div></div>
                </Card>
              </motion.div>
            ))}
          </div>
          <div className="mt-7 text-center"><Link to="/reviews" className="btn btn-secondary btn-md">عرض جميع الآراء <ArrowLeft size={17} /></Link></div>
        </div>
      </section>

      <section className="container-medflow py-16">
        <SectionTitle icon={<Stethoscope size={20} />} title="فريق العيادة" subtitle="أطباء معتمدون" action={<Link to="/doctors" className="hidden text-sm font-bold text-brand-700 hover:text-brand-800 sm:block">عرض الكل ←</Link>} />
        <div className="grid gap-5 md:grid-cols-3">
          {doctors.slice(0, 3).map((doctor, index) => <DoctorCard key={doctor.id} doctor={doctor} specialty={specialties.find((item) => item.id === doctor.specialtyId)} index={index} />)}
        </div>
      </section>

      <section className="container-medflow pb-4 pt-8">
        <div className="flex flex-col items-center justify-between gap-6 rounded-[28px] bg-gradient-to-l from-brand-700 to-brand-500 px-7 py-12 text-white sm:px-12 lg:flex-row">
          <div><h2 className="font-display text-3xl font-extrabold">جاهز لحجز موعدك؟</h2><p className="mt-2 text-sm leading-7 text-brand-50">اختر التخصص والطبيب المناسب، ودعنا نتكفّل بالبقية.</p></div>
          <Link to="/book" className="btn btn-lg border-0 bg-white text-brand-700 shadow-lg hover:bg-brand-50"><CheckCircle2 size={19} /> احجز موعدك الآن</Link>
        </div>
      </section>
    </main>
  );
}
