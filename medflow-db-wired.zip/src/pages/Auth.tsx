import { apiUrl } from '../lib/api';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, Eye, EyeOff, KeyRound, LockKeyhole, Mail, Phone, ShieldCheck, UserRound } from 'lucide-react';
import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { Button, Card, Field } from '../components/ui';
import { normalizePhone } from '../lib/phone';
import { supabase } from '../lib/supabase';

const roleHome = { admin: '/admin', doctor: '/doctor', patient: '/patient' } as const;

function AuthShell({ children, sideTitle, sideText }: { children: React.ReactNode; sideTitle: string; sideText: string }) {
  return (
    <main className="grid min-h-screen bg-white lg:grid-cols-[1fr_1.05fr]">
      <section className="flex items-center justify-center px-5 py-10 sm:px-12 lg:px-16">
        <div className="w-full max-w-md">{children}</div>
      </section>
      <aside className="relative hidden overflow-hidden lg:block">
        <img src="/images/login-side.jpg" alt="فريق مركز ميدفلو" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950/90 via-ink-950/25 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-12 text-white">
          <p className="mb-4 inline-flex rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-bold backdrop-blur">ملفك الطبي في مكان واحد</p>
          <h2 className="font-display text-3xl font-extrabold leading-tight">{sideTitle}</h2>
          <p className="mt-3 max-w-md text-sm leading-7 text-white/75">{sideText}</p>
        </div>
      </aside>
    </main>
  );
}

function Brand() {
  return <Link to="/" className="mb-9 inline-flex items-center gap-2.5"><img src="/images/logo.png" alt="ميدفلو" className="size-11 rounded-xl" /><div><p className="font-display text-lg font-extrabold text-ink-950">ميدفلو</p><p className="text-[10px] font-semibold text-brand-700">مركز طبي متكامل</p></div></Link>;
}

export function LoginPage() {
  const { login, showToast } = useStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      const user = await login(email, password);
      const from = (location.state as { from?: string } | null)?.from;
      navigate(from || roleHome[user.role], { replace: true });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'تعذر تسجيل الدخول');
    } finally { setLoading(false); }
  };


  return (
    <AuthShell sideTitle="رعايتك продолжа من حيث توقفت" sideText="تابع مواعيدك، اطّلع على وصفاتك، وتواصل مع فريق العيادة في أي وقت.">
      <Brand />
      <h1 className="font-display text-3xl font-extrabold text-ink-950">بوابة المريض</h1>
      <p className="mt-2 text-sm leading-7 text-ink-500">سجّل الدخول للوصول إلى مواعيدك وملفك الطبي.</p>
      <form onSubmit={submit} className="mt-7 space-y-4">
        {error && <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold text-rose-700">{error}</div>}
        <Field label="البريد الإلكتروني" name="email" type="email" inputMode="email" required autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} icon={<Mail size={17} />} placeholder="name@example.com" />
        <Field label="كلمة المرور" name="password" type={showPassword ? 'text' : 'password'} required autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} icon={<LockKeyhole size={17} />} suffix={<button type="button" onClick={() => setShowPassword((value) => !value)} className="p-1" aria-label={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button>} />
        <div className="flex items-center justify-between text-[12.5px]"><label className="flex items-center gap-2 text-ink-500"><input type="checkbox" className="size-4 rounded border-ink-200 accent-brand-600" /> تذكرني</label><Link to="/forgot-password" className="font-bold text-brand-700 hover:text-brand-800">نسيت كلمة المرور؟</Link></div>
        <Button type="submit" size="lg" className="w-full" disabled={loading}>{loading ? 'جارٍ تسجيل الدخول...' : 'تسجيل الدخول'}</Button>
      </form>
      <div className="grid gap-2 sm:grid-cols-3">
      </div>
      <p className="mt-7 text-center text-sm text-ink-500">ليس لديك حساب؟ <Link to="/register" className="font-bold text-brand-700 hover:text-brand-800">أنشئ حساباً جديداً</Link></p>
    </AuthShell>
  );
}

export function RegisterPage() {
  const { register, showToast } = useStore();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirm: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (form.password !== form.confirm) { setError('كلمتا المرور غير متطابقتين'); return; }
    if (!normalizePhone(form.phone).valid) { setError('رقم الجوال غير صحيح'); return; }
    setLoading(true);
    try { await register(form); showToast('تم إنشاء حسابك بنجاح'); navigate('/patient'); }
    catch (caught) { setError(caught instanceof Error ? caught.message : 'تعذر إنشاء الحساب'); }
    finally { setLoading(false); }
  };

  return (
    <AuthShell sideTitle="ابدأ رعايتك الرقمية" sideText="حساب واحد يجمع المواعيد والوصفات والتقييمات ومتابعة نتائجك الطبية.">
      <Brand />
      <h1 className="font-display text-3xl font-extrabold text-ink-950">إنشاء حساب جديد</h1>
      <p className="mt-2 text-sm leading-7 text-ink-500">انضم إلى ميدفلو وابدأ حجز موعدك في دقائق.</p>
      <form onSubmit={submit} className="mt-7 space-y-4">
        {error && <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold text-rose-700">{error}</div>}
        <Field label="الاسم الكامل" name="name" required value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} icon={<UserRound size={17} />} placeholder="الاسم كما يظهر في الهوية" />
        <Field label="رقم الجوال" name="phone" type="tel" inputMode="tel" required value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} icon={<Phone size={17} />} placeholder="05xxxxxxxx" />
        <Field label="البريد الإلكتروني" name="email" type="email" inputMode="email" required value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} icon={<Mail size={17} />} placeholder="name@example.com" />
        <Field label="كلمة المرور" name="password" type={showPassword ? 'text' : 'password'} required minLength={6} value={form.password} onChange={(event) => setForm({ ...form, password: event.target.value })} icon={<LockKeyhole size={17} />} suffix={<button type="button" onClick={() => setShowPassword((value) => !value)} className="p-1">{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button>} />
        <Field label="تأكيد كلمة المرور" name="confirm" type={showPassword ? 'text' : 'password'} required minLength={6} value={form.confirm} onChange={(event) => setForm({ ...form, confirm: event.target.value })} icon={<ShieldCheck size={17} />} />
        <Button type="submit" size="lg" className="w-full" disabled={loading}>{loading ? 'جارٍ إنشاء الحساب...' : 'إنشاء الحساب'}</Button>
      </form>
      <p className="mt-7 text-center text-sm text-ink-500">لديك حساب بالفعل؟ <Link to="/login" className="font-bold text-brand-700">تسجيل الدخول</Link></p>
    </AuthShell>
  );
}

export function ForgotPasswordPage() {
  const { showToast, restoreSession } = useStore();
  const navigate = useNavigate();
  const [step, setStep] = useState<'phone' | 'code'>('phone');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const request = async (event: React.FormEvent) => {
    event.preventDefault(); setLoading(true); setError('');
    try {
      const response = await fetch(apiUrl('/api/password-reset'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'request', phone }) });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.message ?? 'تعذر إرسال الرمز');
      setStep('code'); showToast(data.dev_code ? `رمز التحقق التجريبي: ${data.dev_code}` : 'تم إرسال رمز التحقق عبر واتساب');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'تعذر إرسال الرمز. حاول مجدداً.');
    } finally { setLoading(false); }
  };

  const verify = async (event: React.FormEvent) => {
    event.preventDefault(); setLoading(true); setError('');
    try {
      const response = await fetch(apiUrl('/api/password-reset'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'verify', phone, code, password: newPassword }) });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.message ?? 'الرمز غير صحيح');
      if (data.session?.access_token && data.session?.refresh_token && supabase) {
        await supabase.auth.setSession({ access_token: data.session.access_token, refresh_token: data.session.refresh_token });
        await restoreSession();
        showToast('تم تحديث كلمة المرور وتسجيل الدخول بنجاح');
        navigate('/patient');
      } else {
        showToast('تم تحديث كلمة المرور، يمكنك تسجيل الدخول الآن');
        navigate('/login');
      }
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'تعذر التحقق'); }
    finally { setLoading(false); }
  };

  return (
    <AuthShell sideTitle="استعادة الحساب بأمان" sideText="نرسل رمزاً مؤقتاً إلى جوالك، ولا نشارك بياناتك مع أي جهة.">
      <Brand />
      <div className="mb-6 flex items-center gap-3"><div className="grid size-11 place-items-center rounded-xl bg-brand-50 text-brand-700"><KeyRound size={21} /></div><div><h1 className="font-display text-3xl font-extrabold text-ink-950">استعادة كلمة المرور</h1><p className="mt-1 text-sm text-ink-500">خطوة واحدة لاستعادة الوصول</p></div></div>
      <AnimatePresence mode="wait">
        {step === 'phone' ? (
          <motion.form key="phone" onSubmit={request} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
            {error && <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold text-rose-700">{error}</div>}
            <Field label="رقم الجوال المسجل" name="phone" type="tel" inputMode="tel" required value={phone} onChange={(event) => setPhone(event.target.value)} icon={<Phone size={17} />} placeholder="05xxxxxxxx" />
            <Button type="submit" size="lg" className="w-full" disabled={loading}>{loading ? 'جارٍ الإرسال...' : 'إرسال رمز التحقق'}</Button>
          </motion.form>
        ) : (
          <motion.form key="code" onSubmit={verify} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
            {error && <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold text-rose-700">{error}</div>}
            <Field label="رمز التحقق المكوّن من 6 أرقام" name="code" inputMode="numeric" pattern="[0-9]{6}" maxLength={6} required value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, ''))} icon={<KeyRound size={17} />} placeholder="000000" />
            <Field label="كلمة المرور الجديدة" name="password" type="password" minLength={6} required value={newPassword} onChange={(event) => setNewPassword(event.target.value)} icon={<LockKeyhole size={17} />} />
            <Button type="submit" size="lg" className="w-full" disabled={loading}>{loading ? 'جارٍ التحقق...' : 'تحديث كلمة المرور'}</Button>
            <button type="button" onClick={() => setStep('phone')} className="flex w-full items-center justify-center gap-1 text-sm font-bold text-brand-700"><ArrowLeft size={16} /> تغيير رقم الجوال</button>
          </motion.form>
        )}
      </AnimatePresence>
    </AuthShell>
  );
}
