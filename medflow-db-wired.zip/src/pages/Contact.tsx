import { useState } from 'react';
import { Clock3, Mail, MapPin, MessageCircle, Phone, Send } from 'lucide-react';
import { useStore } from '../store';
import { Button, Card, Field, PageHeading, TextArea } from '../components/ui';

export function ContactPage() {
  const { showToast, center } = useStore();
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [sent, setSent] = useState(false);
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!form.name || !form.phone || !form.message) { showToast('يرجى تعبئة جميع الحقول المطلوبة', 'error'); return; }
    setSent(true);
    showToast('تم استلام رسالتك، وسنرد عليك قريباً');
  };

  return (
    <main className="container-medflow py-12 sm:py-16">
      <PageHeading eyebrow="تواصل معنا" title="نسعد بخدمتك" description="فريقنا جاهز للإجابة عن استفساراتك ومساعدتك في اختيار الخدمة المناسبة." />
      <div className="grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
        <div className="space-y-4">
          <Card className="bg-ink-950 text-white">
            <h2 className="font-display text-xl font-extrabold">مركز ميدفلو الطبي</h2>
            <p className="mt-2 text-sm leading-7 text-ink-400">نحن هنا لخدمتك بكل وضوح وشفافية، من أول اتصال وحتى موعدك.</p>
            <div className="mt-6 space-y-4 text-sm">
              <p className="flex items-start gap-3"><MapPin size={18} className="mt-0.5 shrink-0 text-brand-400" /><span>{center.address}<br />الرياض، المملكة العربية السعودية</span></p>
              <a href={`tel:${center.phone}`} className="flex items-center gap-3 text-ink-300 transition hover:text-brand-300"><Phone size={18} className="text-brand-400" /> {center.phone}</a>
              <a href={`mailto:${center.email}`} className="flex items-center gap-3 text-ink-300 transition hover:text-brand-300"><Mail size={18} className="text-brand-400" /> {center.email}</a>
              <p className="flex items-center gap-3 text-ink-300"><Clock3 size={18} className="text-brand-400" /> {center.hours}</p>
            </div>
            <a href={`https://wa.me/${center.whatsapp}`} target="_blank" rel="noreferrer" className="btn btn-whatsapp btn-md mt-7 w-full"><MessageCircle size={18} /> تواصل عبر واتساب</a>
          </Card>
          <Card className="border-brand-100 bg-brand-50/60"><p className="text-sm font-bold text-brand-900">هل لديك موعد قادم؟</p><p className="mt-1 text-xs leading-6 text-brand-700">يمكنك تغيير موعدك أو التواصل مع خدمة المرضى من بوابة المريض.</p></Card>
        </div>
        <Card>
          <h2 className="font-display text-xl font-extrabold text-ink-900">أرسل لنا رسالة</h2>
          <p className="mt-1 text-sm text-ink-500">نرد عادة خلال أقل من 24 ساعة عمل.</p>
          {sent ? (
            <div className="mt-10 rounded-2xl border border-brand-200 bg-brand-50 p-8 text-center"><Send size={28} className="mx-auto text-brand-600" /><h3 className="mt-3 font-bold text-brand-900">وصلتنا رسالتك</h3><p className="mt-1 text-sm text-brand-700">شكراً لتواصلك. سيقوم فريقنا بالرد قريباً.</p><Button variant="secondary" className="mt-5" onClick={() => { setSent(false); setForm({ name: '', email: '', phone: '', message: '' }); }}>إرسال رسالة أخرى</Button></div>
          ) : (
            <form onSubmit={submit} className="mt-6 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2"><Field label="الاسم الكامل" name="name" required value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="مثال: أحمد محمد" /><Field label="رقم الجوال" name="phone" type="tel" inputMode="tel" required value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} placeholder="05xxxxxxxx" /></div>
              <Field label="البريد الإلكتروني" name="email" type="email" inputMode="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} placeholder="name@example.com" />
              <TextArea label="رسالتك" name="message" required value={form.message} onChange={(event) => setForm({ ...form, message: event.target.value })} placeholder="كيف يمكننا مساعدتك؟" />
              <Button type="submit" className="w-full"><Send size={17} /> إرسال الرسالة</Button>
            </form>
          )}
        </Card>
      </div>
    </main>
  );
}
