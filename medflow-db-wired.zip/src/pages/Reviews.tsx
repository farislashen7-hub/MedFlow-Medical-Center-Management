import { useMemo, useState } from 'react';
import { BadgeCheck, MessageCircle, Star } from 'lucide-react';
import { useStore } from '../store';
import { Badge, Button, Card, EmptyState, Field, PageHeading, TextArea } from '../components/ui';
import { cn } from '../lib/utils';

export function ReviewsPage() {
  const { reviews, addReview, currentUser, showToast, doctors, specialties } = useStore();
  const [rating, setRating] = useState(5);
  const [text, setText] = useState('');
  const [doctorId, setDoctorId] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const average = useMemo(() => (reviews.reduce((sum, review) => sum + review.rating, 0) / Math.max(reviews.length, 1)).toFixed(1), [reviews]);

  const submit = async () => {
    if (text.trim().length < 10) { showToast('اكتب رأيك في 10 أحرف على الأقل', 'error'); return; }
    const targetDoctor = doctorId || doctors[0]?.id;
    if (!targetDoctor) { showToast('لا يوجد أطباء لتقييمهم حالياً', 'error'); return; }
    setSubmitting(true);
    try {
      await addReview({ patientName: currentUser?.name ?? 'ضيف المنصة', doctorId: targetDoctor, rating, text: text.trim() });
      setText('');
      showToast('شكراً لك! تم نشر تقييمك');
    } catch (caught) {
      showToast(caught instanceof Error ? caught.message : 'تعذر نشر التقييم', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="container-medflow py-12 sm:py-16">
      <PageHeading eyebrow="آراء العملاء" title="ماذا يقول مرضانا" description="تجارب حقيقية من مرضى زاروا مركز ميدفلو، وقيّم تجربتك أنت أيضاً." />
      <div className="mb-10 grid gap-4 sm:grid-cols-3">
        <Card className="text-center"><p className="text-sm text-ink-500">متوسط التقييم</p><p className="mt-1 text-4xl font-extrabold text-ink-950">{average}</p><div className="mt-2 flex justify-center gap-1">{Array.from({ length: 5 }).map((_, index) => <Star key={index} size={16} className="fill-amber-400 text-amber-400" />)}</div></Card>
        <Card className="text-center"><p className="text-sm text-ink-500">تقييمات موثقة</p><p className="mt-1 text-4xl font-extrabold text-ink-950">+{reviews.length * 37}</p><p className="mt-2 text-xs text-ink-400">زيارة موثقة من مركز ميدفلو</p></Card>
        <Card className="text-center"><p className="text-sm text-ink-500">نسبة الرضا</p><p className="mt-1 text-4xl font-extrabold text-brand-700">98%</p><p className="mt-2 text-xs text-ink-400">يوصوننا بنا مرضى آخرون</p></Card>
      </div>
      <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
        <div className="space-y-4">
          {reviews.map((review) => {
            const doctor = doctors.find((item) => item.id === review.doctorId);
            return (
              <Card key={review.id}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-full bg-brand-50 font-bold text-brand-700">{review.patientName.slice(0, 1)}</span><div><p className="text-sm font-bold text-ink-900">{review.patientName}</p><p className="mt-0.5 text-[11.5px] text-ink-400">{doctor?.name} · {specialties.find((item) => item.id === doctor?.specialtyId)?.name}</p></div></div>
                  <div className="flex items-center gap-2"><Badge tone="green"><BadgeCheck size={12} className="ml-1" /> موثّق</Badge><div className="flex gap-0.5">{Array.from({ length: 5 }).map((_, index) => <Star key={index} size={14} className={cn(index < review.rating ? 'fill-amber-400 text-amber-400' : 'fill-ink-100 text-ink-100')} />)}</div></div>
                </div>
                <p className="mt-4 text-sm leading-7 text-ink-600">“{review.text}”</p>
              </Card>
            );
          })}
          {!reviews.length && <EmptyState icon={<MessageCircle size={22} />} title="لا توجد آراء بعد" />}
        </div>
        <Card className="h-fit lg:sticky lg:top-24">
          <h2 className="font-display text-xl font-extrabold text-ink-900">شاركنا رأيك</h2>
          <p className="mt-1 text-sm text-ink-500"> رأيك يساعدنا على تقديم خدمة أفضل.</p>
          <div className="mt-5 space-y-4">
            <div><label className="label">اختر الطبيب</label><select className="field mt-1.5" value={doctorId || doctors[0]?.id || ''} onChange={(event) => setDoctorId(event.target.value)}>{doctors.map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.name}</option>)}</select></div>
            <div><label className="label">تقييمك</label><div className="mt-2 flex gap-1" dir="ltr">{Array.from({ length: 5 }).map((_, index) => <button key={index} onClick={() => setRating(index + 1)} aria-label={`${index + 1} نجوم`}><Star size={27} className={cn(index < rating ? 'fill-amber-400 text-amber-400' : 'text-ink-200')} /></button>)}</div></div>
            <TextArea label="رأيك في الزيارة" value={text} onChange={(event) => setText(event.target.value)} placeholder="اكتب تجربتك مع العيادة والطبيب..." required />
            <Button onClick={() => void submit()} disabled={submitting} className="w-full">{submitting ? 'جارٍ الإرسال...' : 'إرسال التقييم'}</Button>
          </div>
        </Card>
      </div>
    </main>
  );
}
