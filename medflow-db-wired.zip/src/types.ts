export type Role = 'admin' | 'doctor' | 'patient';
export type AppointmentStatus = 'confirmed' | 'pending' | 'completed' | 'cancelled';

export interface Specialty {
  id: string;
  name: string;
  description: string;
  icon: string;
  tint: string;
  count: number;
}

export interface Doctor {
  id: string;
  name: string;
  specialtyId: string;
  title: string;
  experience: number;
  rating: number;
  reviews: number;
  image: string;
  location: string;
  phone: string;
  bio: string;
  workingHours: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: Role;
  doctorId?: string;
  avatar?: string;
  /** Used only by the offline demo credential store. */
  password?: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  phone: string;
  doctorId: string;
  specialtyId: string;
  date: string;
  time: string;
  status: AppointmentStatus;
  notes?: string;
  createdAt: string;
  cancelledBy?: 'patient' | 'staff' | 'doctor';
}

export interface Prescription {
  id: string;
  appointmentId: string;
  patientId: string;
  doctorId: string;
  date: string;
  diagnosis: string;
  medications: string;
  instructions: string;
  sentToWhatsApp?: boolean;
}

export interface Review {
  id: string;
  patientName: string;
  doctorId: string;
  rating: number;
  text: string;
  date: string;
  verified: boolean;
}

export interface Offer {
  id: string;
  title: string;
  description: string;
  oldPrice: number;
  price: number;
  badge: string;
  theme: 'brand' | 'amber' | 'sky';
  expires: string;
}

export interface Attendance {
  doctorId: string;
  date: string;
  status: 'present' | 'absent' | 'leave';
  note?: string;
}

export interface Schedule {
  doctorId: string;
  days: string;
  hours: string;
  slots: string[];
}

export interface Leave {
  id: string;
  doctorId: string;
  startDate: string;
  endDate: string;
  reason: string;
}

export interface Activity {
  id: string;
  type: 'booking' | 'review' | 'prescription' | 'offer' | 'system';
  text: string;
  at: string;
}

export interface Conversation {
  id: string;
  phone: string;
  name: string;
  lastMessage: string;
  at: string;
  unread: number;
  status: 'active' | 'pending';
}

export interface Center {
  name: string;
  shortName: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  hours: string;
  currency: string;
}
