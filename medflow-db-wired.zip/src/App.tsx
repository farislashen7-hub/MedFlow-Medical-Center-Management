import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Toast } from './components/ui';
import { useStore } from './store';
import type { Role } from './types';
import { LandingPage } from './pages/Landing';
import { SpecialtiesPage } from './pages/Specialties';
import { DoctorsPage } from './pages/Doctors';
import { ReviewsPage } from './pages/Reviews';
import { ContactPage } from './pages/Contact';
import { LoginPage, RegisterPage, ForgotPasswordPage } from './pages/Auth';
import { BookPage } from './pages/Book';
import { PatientDashboard } from './dashboards/Patient';
import { DoctorDashboard } from './dashboards/Doctor';
import { AdminDashboard } from './dashboards/Admin';

function PublicLayout() {
  return <><Header /><Outlet /><Footer /></>;
}

function ProtectedRoute({ roles }: { roles?: Role[] }) {
  const { currentUser, hydrated } = useStore();
  const location = useLocation();
  if (!hydrated) return <div className="grid min-h-screen place-items-center bg-ink-50"><div className="size-9 animate-spin rounded-full border-2 border-brand-200 border-t-brand-600" /></div>;
  if (!currentUser) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  if (roles && !roles.includes(currentUser.role)) return <Navigate to={currentUser.role === 'admin' ? '/admin' : currentUser.role === 'doctor' ? '/doctor' : '/patient'} replace />;
  return <Outlet />;
}

function BlockRole({ role }: { role: Role }) {
  const { currentUser } = useStore();
  if (currentUser?.role === role) return <Navigate to={role === 'doctor' ? '/doctor' : '/patient'} replace />;
  return <Outlet />;
}

function StaffPage() {
  const { currentUser } = useStore();
  const target = currentUser?.role === 'admin' ? '/admin' : currentUser?.role === 'doctor' ? '/doctor' : '/login';
  return (
    <main className="container-medflow grid min-h-[70vh] place-items-center py-12">
      <div className="w-full max-w-lg rounded-3xl border border-ink-100 bg-white p-8 text-center shadow-xl">
        <img src="/images/logo.png" alt="ميدفلو" className="mx-auto size-16 rounded-2xl" />
        <h1 className="mt-5 font-display text-3xl font-extrabold text-ink-950">بوابة فريق العمل</h1>
        <p className="mt-3 text-sm leading-7 text-ink-500">سجّل الدخول بحساب الطبيب أو الإدارة للوصول إلى الأدوات المخصصة لفريقك.</p>
        <a href={target} className="btn btn-primary btn-lg mt-7 w-full">الانتقال إلى تسجيل الدخول</a>
      </div>
    </main>
  );
}

function NotFound() {
  return <main className="container-medflow grid min-h-[65vh] place-items-center py-16 text-center"><div><p className="font-display text-7xl font-extrabold text-brand-100">404</p><h1 className="mt-2 font-display text-3xl font-extrabold text-ink-950">الصفحة غير موجودة</h1><p className="mt-3 text-sm text-ink-500">يبدو أن الرابط الذي طلبته غير صحيح.</p><a href="/" className="btn btn-primary btn-md mt-7">العودة للرئيسية</a></div></main>;
}

function AppRoutes() {
  const { toast, dismissToast } = useStore();
  return (
    <>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route index element={<LandingPage />} />
          <Route path="specialties" element={<SpecialtiesPage />} />
          <Route path="doctors" element={<DoctorsPage />} />
          <Route path="reviews" element={<ReviewsPage />} />
          <Route path="contact" element={<ContactPage />} />
          <Route path="staff" element={<StaffPage />} />
          <Route element={<ProtectedRoute />}>
            <Route element={<BlockRole role="doctor" />}>
              <Route path="book" element={<BookPage />} />
            </Route>
          </Route>
          <Route element={<ProtectedRoute roles={['patient']} />}>
            <Route path="patient" element={<PatientDashboard />} />
          </Route>
          <Route element={<ProtectedRoute roles={['doctor']} />}>
            <Route path="doctor" element={<DoctorDashboard />} />
          </Route>
          <Route element={<ProtectedRoute roles={['admin']} />}>
            <Route path="admin" element={<AdminDashboard />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Route>
        <Route path="login" element={<LoginPage />} />
        <Route path="register" element={<RegisterPage />} />
        <Route path="forgot-password" element={<ForgotPasswordPage />} />
      </Routes>
      <Toast toast={toast} onClose={dismissToast} />
    </>
  );
}

export default function App() {
  return <AppRoutes />;
}
