param(
  [switch]$New,       # force a brand-new project (timestamped name) - only when you really want one
  [switch]$SyncEnv    # push VITE_* vars from .env.production / .env / .env.local to the project, then deploy
)

# ---- THE project (fixed). Every deploy updates this one, even if the folder was re-extracted from a zip ----
$ProjectName = 'medflow-20261108-011507'
$ProjectId   = 'prj_08ahJLyI13YRIQfiNROmajFmU7Fc'
$OrgId       = 'team_oTeGVj8pPnoSNHsRxeNn4RIv'

Set-Location $PSScriptRoot

function Step($text) { Write-Host "`n==> $text" -ForegroundColor Cyan }
function Fail($text) { Write-Host "ERROR: $text" -ForegroundColor Red; exit 1 }

# ---------- 1. login ----------
Step 'Checking Vercel login'
cmd /c "vercel whoami >nul 2>nul"
if ($LASTEXITCODE -ne 0) {
  Write-Host 'Not logged in. Starting login...'
  vercel login
  if ($LASTEXITCODE -ne 0) { Fail 'Vercel login failed.' }
}

# ---------- 2. dependencies ----------
if (-not (Test-Path 'node_modules')) {
  Step 'Installing dependencies (first run only)'
  npm install
  if ($LASTEXITCODE -ne 0) { Fail 'npm install failed.' }
}

# ---------- 3. project: ALWAYS the same one (new only with -New) ----------
function Sync-Env {
  $envFile = @('.env.production', '.env', '.env.local') | Where-Object { Test-Path $_ } | Select-Object -First 1
  if (-not $envFile) { Write-Host 'No .env file found - skipping env sync.'; return }
  Step "Syncing env vars from $envFile (production)"
  Get-Content $envFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -eq '' -or $line.StartsWith('#') -or -not $line.Contains('=')) { return }
    $idx = $line.IndexOf('=')
    $key = $line.Substring(0, $idx).Trim()
    $val = $line.Substring($idx + 1).Trim().Trim('"').Trim("'")
    if ($key -eq '' -or $val -eq '') { return }
    Write-Host "  + $key"
    $val | vercel env add $key production --force 2>&1 | Out-Null
  }
}

if ($New) {
  if (Test-Path '.vercel') { Remove-Item '.vercel' -Recurse -Force }
  $newName = 'medflow-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
  Step "Creating NEW Vercel project: $newName"
  vercel link --yes --project $newName
  if ($LASTEXITCODE -ne 0) { Fail 'Could not create/link the new Vercel project.' }
  Sync-Env
} else {
  if (-not (Test-Path '.vercel\project.json')) {
    Step "No .vercel link here - relinking to existing project $ProjectName"
    New-Item -ItemType Directory -Path '.vercel' -Force | Out-Null
    $json = '{"projectId":"' + $ProjectId + '","orgId":"' + $OrgId + '","projectName":"' + $ProjectName + '"}'
    Set-Content -Path '.vercel\project.json' -Value $json -Encoding ASCII
  } else {
    Step 'Reusing existing Vercel project (.vercel link found)'
  }
  if ($SyncEnv) { Sync-Env }
}

# ---------- 5. deploy ----------
Step 'Deploying to production'
$url = vercel deploy --prod --yes | Select-Object -Last 1
if ($LASTEXITCODE -ne 0 -or -not $url) { Fail 'Deploy failed. Check the build log above.' }

# ---------- 6. result ----------
Write-Host "`nLIVE: $url" -ForegroundColor Green
Add-Content -Path 'deployed-urls.txt' -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm'), $url)
try { Set-Clipboard -Value $url; Write-Host '(URL copied to clipboard)' } catch {}
Start-Process $url
