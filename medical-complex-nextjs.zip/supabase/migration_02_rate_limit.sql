-- migration_02_rate_limit.sql (idempotent) — نفس rate_hit بتاع المطعم. يُستدعى من /api/bookings بالـ service role.
create table if not exists public.rate_limits (
  key text primary key,
  hits int not null default 0,
  window_start timestamptz not null default now()
);
alter table public.rate_limits enable row level security;

create or replace function public.rate_hit(p_key text, p_limit int, p_window_secs int)
returns boolean language plpgsql security definer set search_path = public as $$
declare r public.rate_limits;
begin
  if random() < 0.01 then
    delete from public.rate_limits where window_start < now() - interval '1 day';
  end if;
  insert into public.rate_limits as a (key, hits, window_start) values (left(p_key, 200), 1, now())
  on conflict (key) do update set
    hits = case when a.window_start < now() - make_interval(secs => p_window_secs) then 1 else a.hits + 1 end,
    window_start = case when a.window_start < now() - make_interval(secs => p_window_secs) then now() else a.window_start end
  returning * into r;
  return r.hits <= p_limit;
end $$;
revoke all on function public.rate_hit(text, int, int) from public, anon, authenticated;
grant execute on function public.rate_hit(text, int, int) to service_role;
