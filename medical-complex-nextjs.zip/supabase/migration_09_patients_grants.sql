-- migration_09_patients_grants.sql (idempotent)
-- مشكلة: migration_05 عملت RLS بس من غير GRANT، فالزائر (anon) بيتمنع من الـ INSERT (42501 permission denied)
-- والمريض الجديد مبيظهرش في الداتا. هنا بنديه صلاحية INSERT فقط، والإدارة تقرأ.
alter table public.patients add column if not exists email text not null default '';

grant usage on schema public to anon, authenticated;
grant insert on public.patients to anon, authenticated;
grant select on public.patients to authenticated;

alter table public.patients enable row level security;

drop policy if exists "public can register" on public.patients;
create policy "public can register" on public.patients for insert to anon, authenticated
  with check (true);

drop policy if exists "admin read patients" on public.patients;
create policy "admin read patients" on public.patients for select to authenticated
  using (public.my_role() = 'admin');

revoke update, delete, truncate on public.patients from anon;
