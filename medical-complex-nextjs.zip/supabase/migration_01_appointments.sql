-- migration_01_appointments.sql  (idempotent)
-- n8n يكتب بالـ service role (بيتخطى RLS). المتصفح (anon/publishable) مالوش وصول مباشر.

create table if not exists public.appointments (
  id             text primary key,                 -- نفس id الحجز في الفرونت (apt_xxx)
  patient_name   text        not null check (char_length(patient_name) between 2 and 120),
  patient_phone  text        not null check (patient_phone ~ '^\+(20|966|971|965|974|973|968)\d{8,10}$'),
  phone_country  text        not null check (phone_country in ('EG','SA','AE','KW','QA','BH','OM')),
  doctor_id      text        not null,
  specialty_id   text        not null,
  date           date        not null,
  time           text        not null check (time ~ '^\d{1,2}:\d{2}'),
  type           text        not null default 'new',
  reason         text        not null default '' check (char_length(reason) <= 1000),
  status         text        not null default 'confirmed' check (status in ('pending','confirmed','completed','cancelled','no_show')),
  source         text        not null default 'web',
  created_at     timestamptz not null default now()
);

-- منع حجزين لنفس الدكتور في نفس الميعاد (إلا الملغي)
create unique index if not exists appointments_doctor_slot_uq
  on public.appointments (doctor_id, date, time)
  where status <> 'cancelled';

create index if not exists appointments_phone_idx on public.appointments (patient_phone);
create index if not exists appointments_date_idx  on public.appointments (date);

alter table public.appointments enable row level security;
-- مفيش policies للـ anon/authenticated = مقفول. الكتابة/القراءة عبر n8n (service role) فقط.
drop policy if exists "no direct access" on public.appointments;
