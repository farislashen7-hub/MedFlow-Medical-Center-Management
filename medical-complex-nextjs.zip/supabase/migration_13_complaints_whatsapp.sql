-- migration_13_complaints_whatsapp.sql (idempotent) — بعد migration_12_complaints.sql
-- أعمدة لاستقبال الشكاوى من واتساب: مصدر الشكوى + رقم رسالة واتساب (منع التكرار لو n8n أعاد الإرسال).
alter table public.complaints add column if not exists source      text not null default 'whatsapp'
  check (source in ('whatsapp','web','manual'));
alter table public.complaints add column if not exists external_id text;

create unique index if not exists complaints_external_id_key on public.complaints (external_id) where external_id is not null;

-- لو Realtime مش مفعّل على الجدول (migration_12 بيعمله، ده تأمين)
do $$ begin
  if not exists (select 1 from pg_publication_tables
                 where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'complaints') then
    alter publication supabase_realtime add table public.complaints;
  end if;
end $$;
