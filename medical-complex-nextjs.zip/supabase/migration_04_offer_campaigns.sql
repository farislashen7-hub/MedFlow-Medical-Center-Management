-- migration_04_offer_campaigns.sql (idempotent)
-- العرض بيتبعت لـ n8n من غير أرقام. السيرفر (/api/n8n) بيحفظ المستلمين هنا، و n8n بيقراهم بالـ campaign_id.
-- مقفول على anon/authenticated (RLS من غير policies) = service role فقط.

create table if not exists public.offer_campaigns (
  id          uuid primary key default gen_random_uuid(),
  offer_title text        not null default '',
  total       int         not null default 0,
  created_at  timestamptz not null default now()
);

create table if not exists public.offer_recipients (
  id          bigint generated always as identity primary key,
  campaign_id uuid        not null references public.offer_campaigns(id) on delete cascade,
  name        text        not null default '',
  number      text        not null check (number ~ '^\d{8,15}$'),
  status      text        not null default 'pending' check (status in ('pending','sent','failed')),
  sent_at     timestamptz,
  unique (campaign_id, number)
);

create index if not exists offer_recipients_campaign_idx on public.offer_recipients (campaign_id, status);

alter table public.offer_campaigns  enable row level security;
alter table public.offer_recipients enable row level security;
