-- migration_08_password_reset.sql (idempotent)
-- أكواد استعادة كلمة المرور (6 أرقام). الجدول للسيرفر بس (service_role): RLS مفعّل ومفيش policies = مفيش وصول من المتصفح.
-- الكود نفسه مبيتخزنش، بيتخزن HMAC بتاعه. صلاحية الكود 10 دقايق، و5 محاولات غلط بس.
create table if not exists public.password_resets (
  phone_wa   text primary key,
  code_hash  text not null,
  attempts   int  not null default 0,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

alter table public.password_resets enable row level security;
revoke all on public.password_resets from anon, authenticated;
grant select, insert, update, delete on public.password_resets to service_role;
