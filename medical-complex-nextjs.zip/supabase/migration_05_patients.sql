-- migration_05_patients.sql (idempotent)
-- جدول patients موجود في المشروع بأعمدة: full_name, phone (unique), date_of_birth, gender, national_id,
-- blood_type, allergies, chronic_diseases, insurance, address, emergency_contact... (الكود في src/lib/patientsApi.ts بيستخدمها).
-- هنا بنضيف email بس ونقفل الجدول: الزائر يسجّل (INSERT فقط)، والإدارة (profiles.role = 'admin') تقرأ.
-- لو الجدول مش موجود عندك، أنشئه الأول بنفس الأعمدة دي.

alter table public.patients add column if not exists email text not null default '';

alter table public.patients enable row level security;

drop policy if exists "public can register" on public.patients;
create policy "public can register" on public.patients for insert to anon, authenticated
  with check (true);

drop policy if exists "admin read patients" on public.patients;
create policy "admin read patients" on public.patients for select to authenticated
  using (public.my_role() = 'admin');

revoke select, update, delete, truncate on public.patients from anon;
