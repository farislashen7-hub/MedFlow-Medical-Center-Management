-- migration_11_patients_table.sql (idempotent)
-- يضمن إن جدول public.patients موجود بكل الأعمدة اللي /api/register-patient والمتصفح بيكتبوها.
-- التسجيل الجديد بيتكتب من السيرفر (service role)، فمش لازم صلاحيات للزائر. شغّله حتى لو الجدول موجود.
create table if not exists public.patients (
  id               uuid primary key default gen_random_uuid(),
  full_name        text not null,
  phone            text not null,
  created_at       timestamptz not null default now()
);

alter table public.patients add column if not exists email            text not null default '';
alter table public.patients add column if not exists date_of_birth    date;
alter table public.patients add column if not exists gender           text;
alter table public.patients add column if not exists national_id      text;
alter table public.patients add column if not exists blood_type       text;
alter table public.patients add column if not exists allergies        text;
alter table public.patients add column if not exists chronic_diseases text;
alter table public.patients add column if not exists insurance        text;
alter table public.patients add column if not exists address          text;
alter table public.patients add column if not exists emergency_contact text;
alter table public.patients add column if not exists created_at       timestamptz not null default now();

-- الرقم فريد (نفس الرقم مينسجلش مرتين). لو فيه تكرار قديم هيتخطى ومش هيوقف الـ migration.
do $$ begin
  create unique index if not exists patients_phone_key on public.patients (phone);
exception when others then
  raise notice 'تعذر إنشاء unique على phone (فيه أرقام مكررة): %', sqlerrm;
end $$;

alter table public.patients enable row level security;
grant select, insert, update, delete on public.patients to service_role;
