-- migration_07_attendance.sql  (idempotent)
-- حضور/غياب الأطباء + سجل «عندي ظرف». الطبيب يكتب ويقرأ صفوفه هو بس، والإدارة (المالك) تقرأ وتعدّل الكل.
-- لازم تكون شغّلت migration_03 قبله (بيستخدم profiles و my_role() و my_doctor_id()).

create table if not exists public.doctor_attendance (
  id         text primary key,                      -- doctorId_yyyy-mm-dd (نفس الـ id في الفرونت)
  doctor_id  text        not null,
  date       date        not null,
  status     text        not null check (status in ('present','late','absent','leave')),
  check_in   text        not null default '',
  check_out  text        not null default '',
  note       text        not null default '' check (char_length(note) <= 500),
  updated_at timestamptz not null default now(),
  unique (doctor_id, date)
);
create index if not exists doctor_attendance_date_idx on public.doctor_attendance (date);

create table if not exists public.doctor_leaves (
  id         text primary key,
  doctor_id  text        not null,
  reason     text        not null check (char_length(reason) <= 120),
  note       text        not null default '' check (char_length(note) <= 500),
  since      date        not null,
  until      text        not null default '',       -- yyyy-mm-dd أو فاضي = مفتوح لحد ما يرجع
  created_at timestamptz not null default now(),
  ended_at   timestamptz
);
create index if not exists doctor_leaves_doctor_idx on public.doctor_leaves (doctor_id, since);

alter table public.doctor_attendance enable row level security;
alter table public.doctor_leaves     enable row level security;

-- ---- doctor_attendance ----
drop policy if exists "att read" on public.doctor_attendance;
create policy "att read" on public.doctor_attendance for select to authenticated
  using (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

drop policy if exists "att insert" on public.doctor_attendance;
create policy "att insert" on public.doctor_attendance for insert to authenticated
  with check (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

drop policy if exists "att update" on public.doctor_attendance;
create policy "att update" on public.doctor_attendance for update to authenticated
  using      (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()))
  with check (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

-- الحذف للإدارة بس (الطبيب ميقدرش يمسح غيابه)
drop policy if exists "att delete" on public.doctor_attendance;
create policy "att delete" on public.doctor_attendance for delete to authenticated
  using (public.my_role() = 'admin');

-- ---- doctor_leaves ----
drop policy if exists "leave read" on public.doctor_leaves;
create policy "leave read" on public.doctor_leaves for select to authenticated
  using (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

drop policy if exists "leave insert" on public.doctor_leaves;
create policy "leave insert" on public.doctor_leaves for insert to authenticated
  with check (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

drop policy if exists "leave update" on public.doctor_leaves;
create policy "leave update" on public.doctor_leaves for update to authenticated
  using      (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()))
  with check (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

revoke all on public.doctor_attendance, public.doctor_leaves from anon;
grant select, insert, update, delete on public.doctor_attendance to authenticated;
grant select, insert, update on public.doctor_leaves to authenticated;

-- Realtime: الإدارة تشوف الحضور والظروف لحظياً
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'doctor_attendance') then
    alter publication supabase_realtime add table public.doctor_attendance;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'doctor_leaves') then
    alter publication supabase_realtime add table public.doctor_leaves;
  end if;
end $$;
