-- migration_10_cancellations.sql (idempotent)
-- الإلغاء كان بس status='cancelled' جوه appointments. هنا جدول سجل إلغاءات: مين لغى ومتى.
-- بيتملا أوتوماتيك بـ trigger لما أي موعد حالته تتحول لـ cancelled (مريض / دكتور / إدارة). مفيش تعديل في الكود.
create table if not exists public.appointment_cancellations (
  id             bigint generated always as identity primary key,
  appointment_id text        not null references public.appointments(id) on delete cascade,
  patient_name   text        not null,
  patient_phone  text        not null,
  doctor_id      text        not null,
  specialty_id   text        not null,
  appt_date      date        not null,
  appt_time      text        not null,
  cancelled_by   text        not null default 'patient' check (cancelled_by in ('patient','doctor','admin','system')),
  cancelled_at   timestamptz not null default now()
);
create index if not exists appt_cancellations_appt_idx on public.appointment_cancellations (appointment_id);
create index if not exists appt_cancellations_at_idx   on public.appointment_cancellations (cancelled_at desc);

alter table public.appointment_cancellations enable row level security;
revoke all on public.appointment_cancellations from anon, authenticated;
grant select on public.appointment_cancellations to authenticated;
grant all on public.appointment_cancellations to service_role;

drop policy if exists "staff read cancellations" on public.appointment_cancellations;
create policy "staff read cancellations" on public.appointment_cancellations for select to authenticated
  using (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

-- المُلغي: مفيش جلسة (service role من /api/cancel-booking) = المريض، وإلا دور المستخدم في profiles
create or replace function public.log_appointment_cancellation() returns trigger
language plpgsql security definer set search_path = public as $$
declare who text;
begin
  who := case when auth.uid() is null then 'patient' else coalesce(public.my_role(), 'system') end;
  if who not in ('patient','doctor','admin') then who := 'system'; end if;
  insert into public.appointment_cancellations
    (appointment_id, patient_name, patient_phone, doctor_id, specialty_id, appt_date, appt_time, cancelled_by)
  values (new.id, new.patient_name, new.patient_phone, new.doctor_id, new.specialty_id, new.date, new.time, who);
  return new;
end $$;

drop trigger if exists trg_log_cancellation on public.appointments;
create trigger trg_log_cancellation
  after update of status on public.appointments
  for each row
  when (new.status = 'cancelled' and old.status is distinct from 'cancelled')
  execute function public.log_appointment_cancellation();

-- المواعيد الملغية قبل كده (المُلغي مجهول => system)
insert into public.appointment_cancellations
  (appointment_id, patient_name, patient_phone, doctor_id, specialty_id, appt_date, appt_time, cancelled_by, cancelled_at)
select a.id, a.patient_name, a.patient_phone, a.doctor_id, a.specialty_id, a.date, a.time, 'system', a.created_at
from public.appointments a
where a.status = 'cancelled'
  and not exists (select 1 from public.appointment_cancellations c where c.appointment_id = a.id);
