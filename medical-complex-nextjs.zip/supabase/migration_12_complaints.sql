-- migration_12_complaints.sql (idempotent)
-- جدول الشكاوي: شكاوى المرضى (على دكتور / موظف / انتظار / فواتير / نظافة / حجز / أخرى) ومتابعة الإدارة لها.
-- لازم تكون شغّلت migration_03 قبله (بيستخدم my_role() و my_doctor_id()).
-- الكتابة (تسجيل شكوى جديدة): من السيرفر بالـ service role فقط (المريض مالوش جلسة Supabase). الإدارة تقرأ وتعدّل، الدكتور يقرأ الشكاوى المتعلقة بيه بس.
create table if not exists public.complaints (
  id             uuid        primary key default gen_random_uuid(),
  patient_name   text        not null check (char_length(patient_name) between 2 and 120),
  patient_phone  text        not null check (char_length(patient_phone) between 8 and 20),
  patient_id     text,                                   -- id المريض في الفرونت (pat_...) لو متاح
  doctor_id      text,                                   -- لو الشكوى على دكتور (doc_1 ...)
  appointment_id text,                                   -- لو مرتبطة بحجز معيّن
  category       text        not null default 'other'
                 check (category in ('doctor','staff','waiting','billing','facility','booking','other')),
  subject        text        not null check (char_length(subject) between 3 and 150),
  message        text        not null check (char_length(message) between 5 and 2000),
  priority       text        not null default 'normal' check (priority in ('low','normal','high')),
  status         text        not null default 'new'    check (status in ('new','in_review','resolved','rejected')),
  admin_response text,                                   -- رد الإدارة على المريض
  resolved_by    uuid        default null,               -- auth.uid() للأدمن اللي قفلها
  resolved_at    timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create index if not exists complaints_status_idx  on public.complaints (status, created_at desc);
create index if not exists complaints_phone_idx   on public.complaints (patient_phone);
create index if not exists complaints_doctor_idx  on public.complaints (doctor_id) where doctor_id is not null;

-- updated_at تلقائي + resolved_at/resolved_by لما الحالة تتقفل
create or replace function public.complaints_touch() returns trigger
language plpgsql as
$$ begin
  new.updated_at := now();
  if new.status in ('resolved','rejected') and (tg_op = 'INSERT' or old.status is distinct from new.status) then
    new.resolved_at := now();
    new.resolved_by := auth.uid();
  elsif new.status in ('new','in_review') then
    new.resolved_at := null;
    new.resolved_by := null;
  end if;
  return new;
end $$;

drop trigger if exists complaints_touch on public.complaints;
create trigger complaints_touch before insert or update on public.complaints
  for each row execute function public.complaints_touch();

alter table public.complaints enable row level security;
revoke all on public.complaints from anon, authenticated;
grant select, update, delete on public.complaints to authenticated;
grant all on public.complaints to service_role;

drop policy if exists "complaints admin all" on public.complaints;
create policy "complaints admin all" on public.complaints for all to authenticated
  using (public.my_role() = 'admin') with check (public.my_role() = 'admin');

drop policy if exists "complaints doctor read own" on public.complaints;
create policy "complaints doctor read own" on public.complaints for select to authenticated
  using (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id());

-- Realtime: الشكوى الجديدة تظهر فوراً عند الإدارة
do $$ begin
  if not exists (select 1 from pg_publication_tables
                 where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'complaints') then
    alter publication supabase_realtime add table public.complaints;
  end if;
end $$;

-- مثال تسجيل شكوى (من السيرفر / SQL Editor):
-- insert into public.complaints (patient_name, patient_phone, doctor_id, category, subject, message, priority)
-- values ('اسم المريض', '+201012345678', 'doc_1', 'waiting', 'انتظار طويل', 'استنيت أكتر من ساعة بعد معاد الحجز.', 'normal');
