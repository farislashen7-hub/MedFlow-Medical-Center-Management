-- migration_06_doctor_schedules.sql  (idempotent)
-- جدول مواعيد دوام الأطباء (أيام + ساعات). الطبيب بيعدّل جدوله هو بس (RLS)، والإدارة تقدر تعدّل أي جدول.
-- القراءة عامة (anon) لأن صفحة الحجز محتاجة تعرف أيام/ساعات كل طبيب.
-- لازم تكون شغّلت migration_03 قبله (بيستخدم profiles و my_role() و my_doctor_id()).

create table if not exists public.doctor_schedules (
  doctor_id   text primary key,                       -- نفس id الطبيب في الفرونت (doc_1 ...) = profiles.doctor_id
  days        int[]       not null default '{0,1,2,3,4}',   -- 0=الأحد ... 6=السبت
  start_hour  int         not null default 9,
  end_hour    int         not null default 17,
  updated_at  timestamptz not null default now(),
  updated_by  uuid        default auth.uid(),
  constraint doctor_schedules_days_ok  check (cardinality(days) > 0 and days <@ array[0,1,2,3,4,5,6]),
  constraint doctor_schedules_hours_ok check (start_hour between 0 and 23 and end_hour between 1 and 24 and end_hour > start_hour)
);

create or replace function public.doctor_schedules_touch() returns trigger
language plpgsql as
$$ begin new.updated_at := now(); new.updated_by := auth.uid(); return new; end $$;

drop trigger if exists doctor_schedules_touch on public.doctor_schedules;
create trigger doctor_schedules_touch before insert or update on public.doctor_schedules
  for each row execute function public.doctor_schedules_touch();

alter table public.doctor_schedules enable row level security;

drop policy if exists "schedules public read" on public.doctor_schedules;
create policy "schedules public read" on public.doctor_schedules for select to anon, authenticated using (true);

-- الطبيب يكتب صفه هو بس، والإدارة أي صف
drop policy if exists "schedules own insert" on public.doctor_schedules;
create policy "schedules own insert" on public.doctor_schedules for insert to authenticated
  with check (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

drop policy if exists "schedules own update" on public.doctor_schedules;
create policy "schedules own update" on public.doctor_schedules for update to authenticated
  using      (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()))
  with check (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

drop policy if exists "schedules admin delete" on public.doctor_schedules;
create policy "schedules admin delete" on public.doctor_schedules for delete to authenticated
  using (public.my_role() = 'admin');

grant select on public.doctor_schedules to anon, authenticated;
grant insert, update, delete on public.doctor_schedules to authenticated;

-- Realtime: أي تعديل من الطبيب يظهر فوراً عند الإدارة والحجز
do $$ begin
  if not exists (select 1 from pg_publication_tables
                 where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'doctor_schedules') then
    alter publication supabase_realtime add table public.doctor_schedules;
  end if;
end $$;
