-- migration_03_browser_access_realtime.sql (idempotent)
-- يفتح الوصول من المتصفح بشكل محدود: الزائر يحجز (INSERT فقط)، والدكتور/الإدارة (Supabase Auth) يقرؤوا/يحدّثوا + Realtime.

-- 1) profiles: بيربط مستخدم Supabase Auth بدور (admin/doctor) ومعرّف الدكتور المحلي (d1, d2 ...)
create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  role       text not null check (role in ('admin','doctor')),
  doctor_id  text,
  created_at timestamptz not null default now(),
  check (role <> 'doctor' or doctor_id is not null)
);
alter table public.profiles enable row level security;

create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as
$$ select role from public.profiles where id = auth.uid() $$;

create or replace function public.my_doctor_id() returns text
language sql stable security definer set search_path = public as
$$ select doctor_id from public.profiles where id = auth.uid() $$;

drop policy if exists "profile self read" on public.profiles;
create policy "profile self read" on public.profiles for select to authenticated using (id = auth.uid());

-- 2) appointments
drop policy if exists "public can book" on public.appointments;
create policy "public can book" on public.appointments for insert to anon, authenticated
  with check (status = 'confirmed' and source = 'web' and date between current_date - 2 and current_date + 400);

drop policy if exists "staff read" on public.appointments;
create policy "staff read" on public.appointments for select to authenticated
  using (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

drop policy if exists "staff update" on public.appointments;
create policy "staff update" on public.appointments for update to authenticated
  using (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()))
  with check (public.my_role() = 'admin' or (public.my_role() = 'doctor' and doctor_id = public.my_doctor_id()));

grant insert on public.appointments to anon, authenticated;
grant select, update on public.appointments to authenticated;

-- 3) Realtime
do $$ begin
  if not exists (select 1 from pg_publication_tables
                 where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'appointments') then
    alter publication supabase_realtime add table public.appointments;
  end if;
end $$;

-- 4) بعد ما تعمل المستخدمين من Dashboard -> Authentication -> Users (نفس الإيميل/الباسورد المستخدم في الموقع):
-- insert into public.profiles (id, role) values ('<admin-user-uuid>', 'admin');
-- insert into public.profiles (id, role, doctor_id) values ('<doctor-user-uuid>', 'doctor', 'd1');
