@echo off
cd /d "%~dp0"
if not exist "package.json" (
  echo ERROR: wrong folder. package.json not found.
  pause
  exit /b 1
)
if not exist "src\App.tsx" (
  echo ERROR: wrong folder. src\App.tsx not found.
  pause
  exit /b 1
)
rem one-time: install CLI globally (npx re-downloads it every run = slow)
where vercel >nul 2>nul
if errorlevel 1 (
  echo Installing Vercel CLI once...
  call npm i -g vercel
)
rem default  = redeploy to the SAME project (.vercel link, else project "medflow")
rem "DEPLOY.bat env" = also push .env vars to the project first
rem "DEPLOY.bat new" = create a brand-new project (rarely needed)
set "EXTRA="
if /i "%~1"=="new" set "EXTRA=-New"
if /i "%~1"=="env" set "EXTRA=-SyncEnv"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy-new.ps1" %EXTRA%
if errorlevel 1 (
  echo.
  echo Failed. If login needed, run: vercel login
)
pause
