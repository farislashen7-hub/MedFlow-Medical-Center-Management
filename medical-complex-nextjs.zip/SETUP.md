# ربط n8n + Supabase (medflow)

```
Browser ──insert (publishable key + RLS)──► Supabase  (src/lib/bookingApi.ts)
   │                                          ▲ Auth + Realtime للدكتور/الإدارة (src/lib/remoteAppointments.ts)
   └──POST /api/n8n──► Vercel Function (api/n8n.js)
                          │ same-origin + allowlist أحداث + rate limit (rate_hit)
                          │ x-webhook-secret
                          ▼
                     n8n webhook ─► Evolution API ─► واتساب
```
المتصفح مفيهوش secret ولا رابط n8n. لو n8n وقع الحجز يكمل (لا بيتكسر).
`api/bookings.js` و`api/notify.js` = مسارات قديمة (service_role) مش مستخدمة من الواجهة حالياً.

## 1) Supabase (SQL Editor، بالترتيب)
1. `supabase/migration_01_appointments.sql` (جدول + RLS + منع حجزين لنفس الدكتور/الميعاد)
2. `supabase/migration_02_rate_limit.sql` (`rate_hit` للـ rate limit)
3. `supabase/migration_03_browser_access_realtime.sql` (policies للحجز من المتصفح + `profiles` + Realtime)
4. `supabase/migration_04_offer_campaigns.sql` (جداول العروض — لازم لـ `offer.broadcast`)
5. `supabase/migration_05_patients.sql` (جدول `patients`: تسجيل حساب المريض من المتصفح، من غير باسورد)
6. Authentication → Users: مستخدم لكل دكتور/إدارة + صفوف `profiles` (آخر ملف 03). لازم `profiles.doctor_id` = id الطبيب في الموقع (مثلاً `doc_1`).
7. `supabase/migration_06_doctor_schedules.sql` (جدول `doctor_schedules`: الطبيب يحدد أيام/ساعات دوامه من «إدارة المواعيد»، يظهر للإدارة والحجز لحظياً + Realtime)
8. `supabase/migration_07_attendance.sql` (جداول `doctor_attendance` + `doctor_leaves`: حضور/انصراف الطبيب وسجل «عندي ظرف»؛ الطبيب يكتب صفوفه، والمالك يشوف الكل في تبويب «حضور وغياب الأطباء» + Realtime). يحتاج `profiles` زي migration_06.
7b. `supabase/migration_10_cancellations.sql` (جدول سجل الإلغاءات `appointment_cancellations` + trigger أوتوماتيك، يشتغل بعد migration_01 و03)
7a. `supabase/migration_08_password_reset.sql` (جدول `password_resets`: أكواد استعادة كلمة المرور، للسيرفر بس)
7. Settings → API Keys: انسخ **secret key** (`sb_secret_…`) → `SUPABASE_SERVICE_ROLE_KEY`.

## 2) n8n
> ملفات الـ workflow (`n8n/*.json`) مش موجودة في الـ zip ده. هاتها من نسختك الأصلية؛ المعتمد `n8n/medflow-all-webhooks.workflow.json` فقط.
1. Import `n8n/cli-booking.workflow.json` (أو الملف الشامل بدلها).
2. Credential **Header Auth** للـ Webhook: Name = `x-webhook-secret`، Value = قيمة `N8N_WEBHOOK_SECRET` (موجودة في `.env.local`). اربطها بنود `booking`.
3. Credential **Header Auth** لنود `WhatsApp confirm`: Name = `apikey`، Value = مفتاح Evolution. وغيّر الـ URL (`YOUR-EVOLUTION-HOST` / `YOUR_INSTANCE`).
4. Activate. الرابط Production: `https://<n8n-host>/webhook/cli-booking` (مش `/webhook-test/`). المسار case-sensitive.

## 3) Env (محلي `.env.local` + Vercel، وبعدها Redeploy)
| Var | ملاحظة |
|---|---|
| `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY` | للمتصفح (عام) |
| `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` | **سيرفر بس** — ممنوع `VITE_` |
| `N8N_WEBHOOK_BASE` | `https://<n8n-host>/webhook` بدون `/` في الآخر |
| `N8N_WEBHOOK_SECRET` | نفس قيمة Header Auth في n8n |
| `N8N_PATH_BOOKING` | `cli-booking` |
| `DEFAULT_GULF_CC` | `966` — الرقم `05xxxxxxxx` من غير كود دولة يتحسب على الدولة دي |

`deploy-new.ps1 -SyncEnv` يرفع القيم دي لـ Vercel وينشر (`DEPLOY.bat` مش موجود في الـ zip).

## الـ webhooks (كلها POST عبر `/api/notify`)
| الحدث في الموقع | path في n8n | الـ body (`body.payload`) |
|---|---|---|
| إصدار وصفة (الدكتور) | `cli-Treatment` | `image_base64` (JPEG)، `patient_name`، `phone_wa`، `doctor_name`، `code`، `diagnosis` |
| «عندي ظرف» (الدكتور) | `cli-Not available` | `doctor_name`، `reason`، `since`، `until`، `cancelled`، `affected[]` (اسم/تليفون/ميعاد كل مريض متأثر) |
| إرسال عروض (الإدارة) | `cli-offer` | `number`، `text`، `image_base64` (اختياري) — **رسالة لكل مريض** |
| إرسال التقرير للمدير | `cli-report` | `pdf_base64`، `filename`، `summary`، `manager_email`، `manager_phone_wa` |

- كل الـ body شكله `{ event, payload, ts }`. في n8n حوّل الـ base64 لملف بـ **Convert to File** (Move Binary Data) وبعدين ابعته Evolution `sendMedia` / Gmail attachment.
- import الملف `n8n/cli-webhooks.workflow.json` = 4 flows شغالة (Webhook → Code → Evolution): `Treatment` (صورة الوصفة)، `Not available` (رسالة لكل مريض متأثر)، `offer` (نص أو صورة)، `report` (PDF للمدير على واتساب). بعد الـ import: اربط credential `x-webhook-secret` بكل Webhook، وcredential `apikey` بكل نود Evolution، وغيّر `YOUR-EVOLUTION-HOST` و`YOUR_INSTANCE`، وActivate. `cli-booking` في ملفه المنفصل (`cli-booking.workflow.json`) — متستوردش الاتنين على نفس الـ path.
- `cli-Not available` فيه مسافة: السيرفر بيعمل URL-encode لوحده (`cli-Not%20available`). الأسلم تسميه `cli-not-available` وتغيّر `N8N_PATH_NOT_AVAILABLE`.
- محلياً `npm run dev` مفيهوش `/api`: الوصفة/الظرف/العرض بيتخطوا بهدوء، والتقرير بيتنزل PDF.
- بعد الـ pull: `npm install` (أضفنا `html2canvas`).

## أكتر من webhook
- كل webhook = سطر في `ROUTES` داخل `api/_lib/n8n.js` (events + اسم متغير الـ path + الافتراضي).
- نفس العائلة (إنشاء/إلغاء/تذكير) = path واحد + Switch على `body.event` في n8n. شغل مختلف = path وworkflow منفصل.
- الـ secret واحد للكل (Header Auth `x-webhook-secret`). الـ path case-sensitive.
- استدعي `await notifyN8n('event.name', payload)` بعد نجاح الكتابة في DB، مش قبلها.

## 4) اختبار
```bash
curl -i -X POST "https://<site>/api/bookings" -H "Content-Type: application/json" \
  -d '{"appointmentId":"apt_test1","patientName":"Ahmed Ali","patientPhone":"01012345678","doctorId":"d1","specialtyId":"s1","doctorName":"د. سارة","specialtyName":"باطنة","date":"2026-11-20","time":"10:30","type":"new","reason":"test"}'
```
200 اتحفظ · 422 رقم غلط · 409 الميعاد متحجز · 429 طلبات كتير · 503 DB/Env مش جاهز.
أرقام مقبولة: مصر `01[0125]xxxxxxxx` · السعودية 9 أرقام تبدأ 5 · الإمارات 9 تبدأ 50/52/54/55/56/58 · الكويت/قطر/البحرين/عُمان 8 أرقام (`api/_lib/phone.js`).

## ملاحظات
- محلياً `npm run dev` مفيهوش `/api` → الحجز يكمل محلياً بس. للتجربة الكاملة: `vercel dev`.
- منطق الأرقام في ملفين: `src/lib/phone.ts` (الفرونت) و`api/_lib/phone.js` (السيرفر). عدّل الاتنين مع بعض.
- اسم الدكتور والتخصص بيجوا من الفرونت (البيانات محلية) ومحطوطين في رسالة الواتساب بس.

## Deploy (Vercel)
- `.\deploy-new.ps1` = تحديث نفس المشروع `medflow-20261108-011507`.
- `.\deploy-new.ps1 -SyncEnv` = يرفع `.env.production` / `.env` / `.env.local` ثم ينشر (لازم بعد أي تغيير في المتغيرات).
- `.\deploy-new.ps1 -New` = مشروع جديد (نادراً).


## استعادة كلمة مرور المريض (نسيت كلمة المرور)
```
/login ─► «نسيت كلمة المرور؟» ─► /forgot-password
   1) رقم الجوال ─► POST /api/password-reset {action:'request'} ─► n8n `cli-password-reset` ─► واتساب (كود 6 أرقام)
   2) الكود + كلمة مرور جديدة ─► POST /api/password-reset {action:'verify'} ─► تحديث الباسورد + دخول تلقائي
```
- شغّل `migration_08_password_reset.sql`. الجدول للسيرفر بس (RLS من غير policies). الكود بيتخزن HMAC (مفتاح `PASSWORD_RESET_SECRET`، أو `SUPABASE_SERVICE_ROLE_KEY` لو فاضي).
- n8n: الـ workflow الشامل فيه فرع `password reset` (path `cli-password-reset`). اربط credential `x-webhook-secret` بالـ Webhook و`apikey` بنود `Send password reset`، وActivate. المسار قابل للتغيير بـ `N8N_PATH_PASSWORD_RESET`.
- الحماية: صلاحية 10 دقايق، استخدام مرة واحدة، 5 محاولات غلط، كولداون 60 ثانية، حد 3 طلبات/15 دقيقة للرقم و10/10 دقايق للـ IP. رد الإرسال واحد سواء الرقم موجود أو لأ.
- ملاحظة: حسابات المرضى بتتخزن محلياً في المتصفح (db.ts)، فالاستعادة بتحدّث الباسورد على الجهاز اللي فيه ملف المريض. لو المريض على جهاز جديد هيتوجّه لإنشاء ملف.
- محلياً `npm run dev` مفيهوش `/api`: هيظهر «خدمة الإرسال غير متاحة». جرّب بـ `vercel dev`.

## إلغاء الحجز من المريض
```
بوابة المريض ► «إلغاء الموعد» ► نافذة تأكيد ► POST /api/cancel-booking
   السيرفر (service role): يتحقق (الحجز موجود + نفس رقم الجوال + مش مكتمل/قديم)
     ├─► Supabase: appointments.status = 'cancelled'  (الميعاد يتفتح لغيره، والدكتور/الإدارة يشوفوه لحظياً Realtime)
     └─► n8n `cli-cancel-booking` ► واتساب تأكيد الإلغاء للمريض
```
- import `n8n/cli-cancel-booking.workflow.json` (Webhook → Validate → OK? → Build → Verification → Evolution، نفس شكل Rebooking). اربط credential `x-webhook-secret` بالـ Webhook و`apikey` بنود Evolution، وActivate. الـ path الافتراضي `cli-cancel-booking` (يتغير بـ `N8N_PATH_cancelbooking`).
- إلغاء الدكتور/الإدارة بيروح لنفس الـ webhook برسالة مختلفة (`cancelled_by` = `patient` أو `staff`).
- لو `/api/cancel-booking` مش متاح (مثلاً `npm run dev`) أو الحجز مش في Supabase: الإلغاء بيتم محلياً والإشعار بيتبعت من المتصفح كاحتياطي.
- لو كنت ضابط `N8N_PATH_cancelbooking` قبل كده على path الحجز القديم، غيّره أو امسحه.


## تسجيل المرضى الجدد في Supabase
```
أي تسجيل مريض (Register / الحجز لمريض جديد / الإدارة) ► registerPatient ► POST /api/register-patient (service role) ► public.patients
   لو /api مش متاح ► إدخال مباشر بالـ anon (محتاج migration_09)   |   لو فشل الاتنين ► طابور إعادة تلقائي عند فتح الموقع
```
- شغّل `supabase/migration_11_patients_table.sql` (بينشئ الجدول لو مش موجود ويضيف الأعمدة الناقصة).
- محتاج `SUPABASE_SERVICE_ROLE_KEY` و`SUPABASE_URL` في Vercel (نفس اللي بتستخدمه باقي الـ API).
- لو فشل: افتح Vercel ► Functions ► logs وابحث عن `[register-patient]` (بيطبع كود الخطأ).


## الشكاوي (جدول complaints)
- شغّل `supabase/migration_12_complaints.sql` (بعد migration_03). الجدول: المريض، الدكتور/الحجز (اختياري)، التصنيف، العنوان، الرسالة، الأولوية، الحالة (new / in_review / resolved / rejected)، رد الإدارة.
- RLS: الإدارة تقرأ وتعدّل الكل، الدكتور يقرأ الشكاوى اللي عليه بس، والتسجيل من السيرفر (service role). الواجهة (نموذج شكوى + شاشة في لوحة الإدارة) لسه مش متوصلة بالجدول.


## الشكاوى من واتساب ► لوحة الإدارة لحظياً
```
مريض يشتكي على واتساب ► AI Agent (n8n) ► Tool: Log patient complaint ► POST /api/complaints (x-webhook-secret)
   ► public.complaints (service role) ► Supabase Realtime ► تبويب «الشكاوي» عند الإدارة (+ توست + عدّاد الجديد)
```
1. شغّل `migration_12_complaints.sql` ثم `migration_13_complaints_whatsapp.sql`.
2. n8n: import `n8n/tool-log-patient-complaint.workflow.json` (اربط credential `cli-webhook-secret`) وفعّله، وخلّي الـ URL بتاع دومينك.
3. في الـ AI Agent ضيف **Call n8n Workflow Tool** يشاور على الـ workflow ده. وصف الـ Tool المقترح: «سجّل شكوى المريض لما يشتكي من دكتور/موظف/انتظار/فواتير/حجز. ابعت رقم المريض ونص الشكوى». مرّر `patient_phone` من رقم الواتساب (`remoteJid`) و`message` بنص الشكوى، وممكن `category` و`priority` و`doctor_id` و`external_id` (id الرسالة).
4. لازم الإدارة تدخل بحساب Supabase Auth (نفس دخول المواعيد) علشان الشكاوى تظهر (RLS). من غير جلسة بيظهر تنبيه بدل القايمة.
5. مفيش حاجة تتغير في الداتا القديمة. التكرار بيتمنع بـ `external_id`.


## زرار «مسح كل الشات» (تبويب محادثات واتساب)
```
زرار «مسح كل الشات» ► نافذة تأكيد ► POST /api/wipe-chats (Bearer token، أدمن بس) ► n8n `res-wipe-all`
   ► truncate whatsapp.whatsapp_messages + whatsapp_contacts + مسح ملفات الـ Storage ► Respond OK
   + مسح المحادثات من اللوحة محلياً وتسجيل النشاط
```
- import `n8n/res-wipe-all.workflow.json` (فيه نود **Respond OK** اتضافت لأن الـ Webhook مضبوط Respond to Webhook Node ومن غيرها الموقع كان هياخد خطأ). اربط credentials (Header Auth و Postgres و Supabase) وActivate.
- الـ path الافتراضي `res-wipe-all` (يتغير بـ `N8N_PATH_WIPE_ALL`). الدالة `api/wipe-chats.js` maxDuration = 60 ثانية (vercel.json).
- العملية مدمّرة ونهائية. السيرفر بيرفض أي حد مش أدمن (جلسة Supabase + `profiles.role = 'admin'`) وحد أقصى 3 مرات/10 دقايق.
- لو دخلت بحساب محلي (من غير Supabase) المحادثات بتتمسح من اللوحة بس، وهتظهر رسالة إن بيانات واتساب في الداتابيز ماتمسحتش.
- `N8N_PATH_WIPE_ALL` في `.env.example`.
