# الربط حسب وثيقة Vite + Supabase + n8n

> ⚠ **قديم جزئياً:** معمارية n8n المباشر من المتصفح (`VITE_N8N_WEBHOOK_URL`) اتلغت. المعتمد حالياً: **Browser → `/api/n8n` → n8n** (راجع قسم «الحل النهائي» آخر الملف و`SETUP.md`). الجزء الخاص بـ Supabase (migration 03 + Auth + Realtime) لسه صحيح.

```
Browser ──► Supabase (publishable key + RLS + Realtime + Auth)
   └──────► n8n webhook (VITE_N8N_WEBHOOK_URL)  ──► Evolution/WhatsApp
n8n ──► Supabase (service role، جوه n8n بس)
```

## الخطوات
1. SQL Editor: شغّل `supabase/migration_03_browser_access_realtime.sql` (بعد 01 و02).
2. Authentication -> Users: اعمل مستخدم لكل دكتور/إدارة بنفس الإيميل والباسورد المستخدمين في الموقع، وبعدها أضف صفوف `profiles` (آخر الملف).
3. `.env.local` + Vercel: أضف `VITE_N8N_WEBHOOK_URL` (انظر `.env.example`) وأعد النشر. متغيرات السيرفر القديمة مش مطلوبة بعد كده.
4. n8n (لكل Webhook node):
   - **امسح Header Auth** (`x-webhook-secret`) — المتصفح مينفعش يحمل secret.
   - Options -> **Allowed Origins (CORS)** = دومين الموقع فقط.
   - Respond: `Immediately` أو `When Last Node Finishes` برد JSON.
   - أول نود Code: تحقق من الحقول والأرقام (n8n دلوقتي بيستقبل من الإنترنت مباشرة).
5. اختبر: احجز من الموقع -> صف في `appointments` + رسالة واتساب. ادخل كدكتور/إدارة من جهاز تاني واحجز من الزائر -> الموعد يظهر لحظياً.

## اللي اتغيّر
- `src/lib/n8n.ts` (جديد): `triggerN8nWorkflow` + `sendEvent` (نفس شكل `{event,payload,ts}` فالـ workflows القديمة شغالة).
- `src/lib/notify.ts`، `bookingApi.ts`: استدعاء مباشر بدل `/api/*` (المجلد `api/` بقى غير مستخدم).
- `src/lib/remoteAppointments.ts` (جديد) + `db.ts` + `auth.tsx`: Supabase Auth للدكتور/الإدارة، جلب المواعيد + Realtime، ودفع تغيير الحالة لـ Supabase.

## قيود معروفة
- مفيش rate limit على الحجز ولا على n8n (كان في `/api`). الزائر يقدر يبعت حجوزات/webhooks كتير.
- باقي الداتا (دكاترة، مرضى، وصفات، عروض) لسه في localStorage، والمرضى بيدخلوا محلياً.

## إضافات (Rebooking + آراء العملاء)
- **حجز المتابعة** (`type=followup`) بيروح لـ webhook `cli-Rebooking` (حدث `appointment.rebooked`)، والحجز العادي لـ `cli-booking`.
- **تقييم جديد** من بوابة المريض → `cli-review` (حدث `review.submitted`). المتغيرات: `VITE_N8N_PATH_REBOOKING` و`VITE_N8N_PATH_REVIEW` (اختيارية).
- `n8n/cli-extra.workflow.json` (جديد): flows الـ Rebooking والـ review بوضع المتصفح المباشر (من غير Header Auth، مع `allowedOrigins` + نود Guard). غيّر الدومينات جوه Guard و`YOUR-EVOLUTION-HOST` و`YOUR_INSTANCE` ورقم المدير، وActivate.
- لوحة الإدارة: تبويب **«آراء العملاء»** (متوسط التقييم، نسبة الرضا، تقييمات منخفضة، ترتيب الأطباء، اتجاه 6 أشهر، إدارة الردود/الإخفاء).

## ⚠ تعارض لازم تحله
`n8n/cli-webhooks.workflow.json` و`cli-booking.workflow.json` webhooks فيهم **Header Auth**، والمتصفح المباشر مبيبعتش secret → هيرجّع 403. حسب الخطوة 4 فوق امسح Header Auth من كل Webhook (وضيف `allowedOrigins` + تحقق داخلي زي `cli-extra`). كمان `SETUP.md` لسه بيشرح معمارية `/api/notify` القديمة.


## ✅ الحل النهائي: الموقع → /api/n8n → n8n (بالـ secret)
```
Browser ──POST /api/n8n──► Vercel Function (api/n8n.js)  [same-origin + event allowlist + rate limit]
                              └─ x-webhook-secret ──► n8n webhook ──► Guard ──► Evolution/WhatsApp
```
مفيش CORS، ولا secret أو رابط n8n في المتصفح، ولا مشكلة صفحة تحذير ngrok.

1. **n8n:** استورد `n8n/medflow-all-webhooks.workflow.json` فقط (7 webhooks، كلها Header Auth بـ credential `cli-webhook-secret`: Name = `x-webhook-secret`). القديم في `n8n/_old/` و`n8n/_browser/` — متستوردهوش معاه.
   - اربط credential `apikey` (Evolution) بنود `Send ...`، غيّر `YOUR-EVOLUTION-HOST` / `YOUR_INSTANCE`، ورقم المدير في `Build review msg`، وActivate.
2. **Vercel → Environment Variables:**
   - `N8N_WEBHOOK_BASE` = `https://<n8n-host>/webhook` (من غير `/` في الآخر).
   - `N8N_WEBHOOK_SECRET` = نفس قيمة credential الـ Header Auth في n8n.
   - (اختياري للـ rate limit) `SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY` + migration_02.
   - امسح `VITE_N8N_WEBHOOK_URL` (مبقاش مستخدم). **Redeploy.**
3. **اختبار:**
   ```bash
   curl -i -X POST "https://<site>/api/n8n" -H "Content-Type: application/json" \
     -d '{"event":"appointment.created","payload":{"id":"t1","name":"Ahmed","phone_wa":"201012345678","specialty_name":"باطنة","doctor_name":"د. سارة","date":"2026-11-20","time":"10:30"}}'
   ```
   200 = وصل لـ n8n · 503 = `N8N_WEBHOOK_BASE` فاضي · 502 = n8n رفض أو مش واصل (راجع الـ secret والـ URL) · 429 = rate limit.
- محلياً `npm run dev` مفيهوش `/api`: الإرسال بيتخطى بهدوء. للتجربة الكاملة: `vercel dev`.
