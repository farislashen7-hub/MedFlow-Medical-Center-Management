import { adminClient } from './_lib/supabase.js';
import { notifyN8n } from './_lib/n8n.js';
import { parsePhone } from './_lib/phone.js';

// POST /api/notify  { event, payload }
// Browser never sees the n8n URL/secret. Each event has its own strict validator;
// unknown events are rejected. Vercel body limit is ~4.5MB -> images/PDF are capped below it.
const send = (res, status, body) => res.status(status).json(body);
const clip = (v, max) => String(v ?? '').trim().replace(/\s+/g, ' ').slice(0, max);
const text = (v, max) => String(v ?? '').trim().slice(0, max);       // keeps line breaks
const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s);
const MAX_B64 = 3_800_000;

class Bad extends Error { constructor(code) { super(code); this.code = code; } }

function b64(v, allowed, { required = true } = {}) {
  const s = String(v ?? '');
  if (!s) { if (required) throw new Bad('MISSING_FILE'); return ''; }
  if (s.length > MAX_B64) throw new Bad('FILE_TOO_LARGE');
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(s)) throw new Bad('BAD_FILE');
  return s;
}
const mime = (v, allowed) => { if (!allowed.includes(v)) throw new Bad('BAD_MIMETYPE'); return v; };
const phoneOf = (raw) => {
  const p = parsePhone(clip(raw, 30));
  return p.ok ? { phone: p.e164, phone_wa: p.wa, country: p.iso } : { phone: clip(raw, 30), phone_wa: null, country: null };
};

const EVENTS = {
  // الدكتور أصدر وصفة -> صورة الوصفة
  'prescription.issued': (p) => ({
    code: clip(p.code, 32),
    patient_name: clip(p.patientName, 120),
    ...phoneOf(p.patientPhone),
    doctor_name: clip(p.doctorName, 120),
    specialty_name: clip(p.specialtyName, 120),
    diagnosis: clip(p.diagnosis, 500),
    issued_at: clip(p.issuedAt, 40),
    image_base64: b64(p.image),
    mimetype: mime(p.mimetype, ['image/jpeg', 'image/png']),
    filename: `${clip(p.code, 32).replace(/[^\w-]/g, '') || 'rx'}.jpg`,
  }),

  // الدكتور أعلن إنه مش متاح
  'doctor.unavailable': (p) => {
    const affected = (Array.isArray(p.affected) ? p.affected : []).slice(0, 200).map((a) => ({
      patient_name: clip(a?.patientName, 120),
      ...phoneOf(a?.patientPhone),
      date: isDate(clip(a?.date, 10)) ? clip(a.date, 10) : '',
      time: clip(a?.time, 8),
    }));
    return {
      doctor_id: clip(p.doctorId, 64),
      doctor_name: clip(p.doctorName, 120),
      doctor_phone: clip(p.doctorPhone, 30),
      reason: clip(p.reason, 200),
      note: clip(p.note, 500),
      since: isDate(clip(p.since, 10)) ? clip(p.since, 10) : '',
      until: isDate(clip(p.until, 10)) ? clip(p.until, 10) : '',
      cancelled: Math.max(0, Math.min(10_000, Number(p.cancelled) || 0)),
      affected,
    };
  },

  // الإدارة بعتت ملخص التقرير للمدير -> PDF
  'report.send': (p) => ({
    center_name: clip(p.centerName, 120),
    period: clip(p.period, 120),
    manager_name: clip(p.managerName, 120),
    manager_email: /^\S+@\S+\.\S+$/.test(clip(p.managerEmail, 200)) ? clip(p.managerEmail, 200) : '',
    ...(() => { const x = phoneOf(p.managerPhone); return { manager_phone: x.phone, manager_phone_wa: x.phone_wa }; })(),
    summary: text(p.summary, 6000),
    pdf_base64: b64(p.pdf),
    mimetype: 'application/pdf',
    filename: `${clip(p.filename, 100).replace(/[^\w.\-\u0600-\u06FF]/g, '-') || 'report'}`.replace(/(\.pdf)?$/i, '.pdf'),
  }),

  // عرض واحد -> webhook واحد لكل المستلمين (n8n بيلف عليهم)
  'offer.broadcast': (p) => {
    const seen = new Set();
    const recipients = (Array.isArray(p.recipients) ? p.recipients : [])
      .slice(0, 500)
      .map((r) => ({ name: clip(r?.name, 120), number: String(r?.number ?? '').replace(/\D/g, '') }))
      .filter((r) => /^\d{8,15}$/.test(r.number) && !seen.has(r.number) && seen.add(r.number));
    if (recipients.length === 0) throw new Bad('INVALID_PHONE');
    const image = b64(p.image, null, { required: false });
    return {
      offer_title: clip(p.offerTitle, 200),
      text: text(p.text, 4000),
      image_base64: image || null,
      mimetype: image ? mime(p.mimetype, ['image/jpeg', 'image/png', 'image/webp']) : null,
      recipients,
      count: recipients.length,
    };
  },
};

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'METHOD_NOT_ALLOWED' }); }

  // same-origin only
  const origin = req.headers.origin;
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  if (origin) {
    try { if (new URL(origin).host !== host) return send(res, 403, { error: 'FORBIDDEN' }); }
    catch { return send(res, 403, { error: 'FORBIDDEN' }); }
  }

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = null; } }
  if (!body || typeof body !== 'object') return send(res, 400, { error: 'BAD_REQUEST' });

  const build = EVENTS[body.event];
  if (!build) return send(res, 400, { error: 'UNKNOWN_EVENT' });
  const raw = body.payload;
  if (!raw || typeof raw !== 'object') return send(res, 400, { error: 'BAD_REQUEST' });

  let payload;
  try { payload = build(raw); }
  catch (e) {
    if (e instanceof Bad) return send(res, 422, { error: e.code });
    return send(res, 400, { error: 'BAD_REQUEST' });
  }

  // rate limit per IP (fail open if Supabase is not configured/reachable)
  try {
    const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
    const { data: allowed, error } = await adminClient().rpc('rate_hit', { p_key: `notify|${ip}`, p_limit: 40, p_window_secs: 600 });
    if (!error && allowed === false) return send(res, 429, { error: 'RATE_LIMITED' });
  } catch { /* fail open */ }

  const r = await notifyN8n(body.event, payload, { timeoutMs: 20_000 });
  if (r.reason === 'no_url') return send(res, 503, { error: 'SERVICE_UNAVAILABLE' });
  if (!r.ok) return send(res, 502, { error: 'N8N_FAILED', reason: r.reason });
  return send(res, 200, { ok: true });
}
