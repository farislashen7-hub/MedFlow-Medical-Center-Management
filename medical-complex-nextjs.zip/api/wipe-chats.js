import { adminClient } from './_lib/supabase.js';
import { notifyN8n } from './_lib/n8n.js';

// POST /api/wipe-chats — مسح كل محادثات واتساب (جداول whatsapp + ملفات الـ Storage) عن طريق n8n (res-wipe-all).
// عملية مدمّرة: للإدارة بس. لازم Authorization: Bearer <Supabase access token> ويكون profiles.role = 'admin'.
const send = (res, status, body) => res.status(status).json(body);

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'METHOD_NOT_ALLOWED' }); }

  // same-origin only
  const origin = req.headers.origin;
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  if (origin) {
    try { if (new URL(origin).host !== host) return send(res, 403, { error: 'FORBIDDEN' }); }
    catch { return send(res, 403, { error: 'FORBIDDEN' }); }
  }

  const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim();
  if (!token) return send(res, 401, { error: 'UNAUTHORIZED' });

  let db;
  try { db = adminClient(); }
  catch (e) { console.error('[wipe-chats]', e.message); return send(res, 503, { error: 'SERVICE_UNAVAILABLE' }); }

  // المستخدم لازم يكون أدمن (من Supabase Auth + جدول profiles)
  const { data: u, error: uErr } = await db.auth.getUser(token);
  if (uErr || !u?.user) return send(res, 401, { error: 'UNAUTHORIZED' });
  const { data: prof } = await db.from('profiles').select('role').eq('id', u.user.id).maybeSingle();
  if (prof?.role !== 'admin') return send(res, 403, { error: 'FORBIDDEN' });

  // rate limit: 3 مرات / 10 دقايق لكل أدمن (fail open)
  try {
    const { data: allowed, error } = await db.rpc('rate_hit', { p_key: `wipe|${u.user.id}`, p_limit: 3, p_window_secs: 600 });
    if (!error && allowed === false) return send(res, 429, { error: 'RATE_LIMITED' });
  } catch { /* fail open */ }

  const r = await notifyN8n('whatsapp.wipe_all', { requested_by: u.user.email ?? u.user.id }, { timeoutMs: 55_000 });
  if (r.reason === 'no_url') return send(res, 503, { error: 'SERVICE_UNAVAILABLE' });
  if (r.reason === 'skipped') return send(res, 503, { error: 'NOT_CONFIGURED' });
  if (!r.ok) return send(res, 502, { error: 'N8N_FAILED', reason: r.reason });
  console.log('[wipe-chats] wiped by', u.user.email ?? u.user.id);
  return send(res, 200, { ok: true });
}
