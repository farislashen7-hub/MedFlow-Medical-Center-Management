import { adminClient } from './_lib/supabase.js';
import { notifyN8n } from './_lib/n8n.js';
import { parsePhone } from './_lib/phone.js';

// POST /api/cancel-booking  { appointmentId, patientPhone, doctorName?, specialtyName? }
// المريض مالوش جلسة Supabase (RLS بتمنعه من UPDATE)، فالإلغاء بيعدّي من هنا بـ service role.
// التحقق: الحجز موجود + رقم الجوال مطابق لرقم الحجز + مش مكتمل/لم يحضر + مش فات من أكتر من يوم.
// السيرفر هو اللي يبعت إشعار الواتساب (n8n) بالبيانات الفعلية من الداتابيز، فمفيش رسالة مكررة من المتصفح.
const send = (res, status, body) => res.status(status).json(body);
const clip = (v, max) => String(v ?? '').trim().replace(/\s+/g, ' ').slice(0, max);

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'METHOD_NOT_ALLOWED' }); }

  // same-origin only
  const origin = req.headers.origin;
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  if (origin) {
    try { if (new URL(origin).host !== host) return send(res, 403, { error: 'FORBIDDEN' }); }
    catch { return send(res, 403, { error: 'FORBIDDEN' }); }
  }

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = null; } }
  if (!body || typeof body !== 'object') return send(res, 400, { error: 'BAD_REQUEST' });

  const id = clip(body.appointmentId, 64);
  if (!/^[\w-]{3,64}$/.test(id)) return send(res, 400, { error: 'INVALID_ID' });
  const phone = parsePhone(clip(body.patientPhone, 30));
  if (!phone.ok) return send(res, 422, { error: 'INVALID_PHONE', code: phone.error });

  let db;
  try { db = adminClient(); }
  catch (e) { console.error('[cancel]', e.message); return send(res, 503, { error: 'SERVICE_UNAVAILABLE' }); }

  // rate limit per IP (fail open)
  try {
    const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
    const { data: allowed, error } = await db.rpc('rate_hit', { p_key: `cancel|${ip}`, p_limit: 20, p_window_secs: 600 });
    if (!error && allowed === false) return send(res, 429, { error: 'RATE_LIMITED' });
  } catch { /* fail open */ }

  const { data: row, error: readErr } = await db
    .from('appointments')
    .select('id, patient_name, patient_phone, doctor_id, specialty_id, date, time, status')
    .eq('id', id)
    .maybeSingle();
  if (readErr) { console.error('[cancel] read', readErr.message); return send(res, 500, { error: 'STORE_FAILED' }); }
  // مش موجود في Supabase (الحجز اتعمل محلياً بس): المتصفح يكمل لوحده
  if (!row) return send(res, 200, { ok: true, found: false });

  if (row.patient_phone !== phone.e164) return send(res, 403, { error: 'FORBIDDEN' });
  if (row.status === 'cancelled') return send(res, 200, { ok: true, found: true, already: true });
  if (row.status === 'completed' || row.status === 'no_show') return send(res, 409, { error: 'NOT_CANCELLABLE' });
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  if (row.date < yesterday) return send(res, 409, { error: 'PAST_APPOINTMENT' });

  // .neq: لو اتلغى بالتوازي مفيش إشعار مكرر
  const { data: upd, error: updErr } = await db
    .from('appointments')
    .update({ status: 'cancelled' })
    .eq('id', id)
    .neq('status', 'cancelled')
    .select('id');
  if (updErr) { console.error('[cancel] update', updErr.message); return send(res, 500, { error: 'STORE_FAILED' }); }
  if (!upd?.length) return send(res, 200, { ok: true, found: true, already: true });

  const r = await notifyN8n('appointment.cancelled', {
    id: row.id,
    name: row.patient_name,
    phone: phone.e164,
    phone_wa: phone.wa,
    doctor_id: row.doctor_id,
    doctor_name: clip(body.doctorName, 120),
    specialty_id: row.specialty_id,
    specialty_name: clip(body.specialtyName, 120),
    date: row.date,
    time: String(row.time).slice(0, 5),
    status: 'cancelled',
    cancelled_by: 'patient',
  }, { timeoutMs: 15_000 });
  return send(res, 200, { ok: true, found: true, notified: r.ok });
}
