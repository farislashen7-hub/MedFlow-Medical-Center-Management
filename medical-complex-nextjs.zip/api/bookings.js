import { adminClient } from './_lib/supabase.js';
import { notifyN8n } from './_lib/n8n.js';
import { parsePhone } from './_lib/phone.js';

const TYPES = new Set(['new', 'followup', 'urgent']);
const send = (res, status, body) => res.status(status).json(body);
const clip = (v, max) => String(v ?? '').trim().replace(/\s+/g, ' ').slice(0, max);
const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(`${s}T00:00:00Z`));

// POST /api/bookings
// { appointmentId, patientName, patientPhone, doctorId, specialtyId, doctorName, specialtyName, date, time, type, reason }
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'METHOD_NOT_ALLOWED' }); }

  // same-origin only
  const origin = req.headers.origin;
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  if (origin) {
    try { if (new URL(origin).host !== host) return send(res, 403, { error: 'FORBIDDEN' }); }
    catch { return send(res, 403, { error: 'FORBIDDEN' }); }
  }

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = null; } }
  if (!body || typeof body !== 'object') return send(res, 400, { error: 'BAD_REQUEST' });

  // ---- validate (never trust the client) ----
  const id = clip(body.appointmentId, 64);
  const name = clip(body.patientName, 120);
  const doctorId = clip(body.doctorId, 64);
  const specialtyId = clip(body.specialtyId, 64);
  const doctorName = clip(body.doctorName, 120);
  const specialtyName = clip(body.specialtyName, 120);
  const date = clip(body.date, 10);
  const time = clip(body.time, 8);
  const type = TYPES.has(body.type) ? body.type : 'new';
  const reason = clip(body.reason, 1000);
  const phoneRaw = clip(body.patientPhone, 30);

  if (!/^[\w-]{3,64}$/.test(id)) return send(res, 400, { error: 'INVALID_ID' });
  if (name.length < 2) return send(res, 400, { error: 'INVALID_NAME' });
  if (!doctorId || !specialtyId) return send(res, 400, { error: 'INVALID_DOCTOR' });
  if (!isDate(date)) return send(res, 400, { error: 'INVALID_DATE' });
  const today = Date.now();
  const dMs = Date.parse(`${date}T00:00:00Z`);
  if (dMs < today - 2 * 86400000 || dMs > today + 400 * 86400000) return send(res, 400, { error: 'DATE_OUT_OF_RANGE' });
  if (!/^\d{1,2}:\d{2}/.test(time)) return send(res, 400, { error: 'INVALID_TIME' });
  const phone = parsePhone(phoneRaw);
  if (!phone.ok) return send(res, 422, { error: 'INVALID_PHONE', code: phone.error });

  let db;
  try { db = adminClient(); }
  catch (e) { console.error('[bookings]', e.message); return send(res, 503, { error: 'SERVICE_UNAVAILABLE' }); }

  // rate limit per IP (fail open on RPC error)
  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
  try {
    const { data: allowed, error } = await db.rpc('rate_hit', { p_key: `appt|${ip}`, p_limit: 10, p_window_secs: 600 });
    if (!error && allowed === false) return send(res, 429, { error: 'RATE_LIMITED' });
  } catch { /* fail open */ }

  const { error } = await db.from('appointments').insert({
    id, patient_name: name, patient_phone: phone.e164, phone_country: phone.iso,
    doctor_id: doctorId, specialty_id: specialtyId, date, time, type, reason,
    status: 'confirmed', source: 'web',
  });
  if (error) {
    const msg = `${error.message || ''} ${error.details || ''}`;
    if (error.code === '23505') {
      if (/doctor_slot/i.test(msg)) return send(res, 409, { error: 'SLOT_TAKEN' });
      return send(res, 200, { ok: true, id, duplicate: true }); // same id retried
    }
    console.error('[bookings]', error.message);
    if (/appointments|schema cache/i.test(msg)) return send(res, 503, { error: 'DB_NOT_READY' });
    return send(res, 500, { error: 'DB_ERROR' });
  }

  // n8n failure must never break a booking
  const notified = await notifyN8n('appointment.created', {
    id, name, phone: phone.e164, phone_wa: phone.wa, country: phone.iso,
    doctor_id: doctorId, doctor_name: doctorName, specialty_id: specialtyId, specialty_name: specialtyName,
    date, time, type, reason, status: 'confirmed',
  });

  return send(res, 200, { ok: true, id, notified: notified.ok });
}
