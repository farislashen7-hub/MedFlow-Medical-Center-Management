import { createHash, timingSafeEqual } from 'node:crypto';
import { adminClient } from './_lib/supabase.js';
import { parsePhone } from './_lib/phone.js';

// POST /api/complaints  — n8n (شات واتساب) بيبعت أي شكوى هنا فتتسجل في public.complaints وتظهر في لوحة الإدارة لحظياً (Realtime).
// الحماية: Header  x-webhook-secret = N8N_WEBHOOK_SECRET (أو COMPLAINT_WEBHOOK_SECRET). مفيش CORS: ده سيرفر-لسيرفر.
// Body: { patient_name?, patient_phone, message, subject?, category?, priority?, doctor_id?, appointment_id?, external_id? }
const CATEGORIES = ['doctor', 'staff', 'waiting', 'billing', 'facility', 'booking', 'other'];
const PRIORITIES = ['low', 'normal', 'high'];
const send = (res, status, body) => res.status(status).json(body);
const clip = (v, max) => String(v ?? '').trim().replace(/[ \t]+/g, ' ').slice(0, max);
const sha = (s) => createHash('sha256').update(String(s)).digest();
const secretOk = (got) => {
  const want = process.env.COMPLAINT_WEBHOOK_SECRET || process.env.N8N_WEBHOOK_SECRET || '';
  return !!want && !!got && timingSafeEqual(sha(got), sha(want));
};
// واتساب بيبعت الرقم أرقام بس بكود الدولة (201012345678) من غير +
const phoneOf = (raw) => {
  const s = clip(raw, 40).replace(/@.*$/, ''); // 2010...@s.whatsapp.net
  const a = parsePhone(s);
  if (a.ok) return a;
  return /^\d{8,15}$/.test(s) ? parsePhone(`+${s}`) : a;
};

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'METHOD_NOT_ALLOWED' }); }
  if (!secretOk(req.headers['x-webhook-secret'])) return send(res, 401, { error: 'UNAUTHORIZED' });

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = null; } }
  if (!body || typeof body !== 'object') return send(res, 400, { error: 'BAD_REQUEST' });

  const message = clip(body.message, 2000);
  if (message.length < 5) return send(res, 422, { error: 'INVALID_MESSAGE' });
  const phone = phoneOf(body.patient_phone ?? body.phone);
  if (!phone.ok) return send(res, 422, { error: 'INVALID_PHONE', code: phone.error });

  let db;
  try { db = adminClient(); }
  catch (e) { console.error('[complaints]', e.message); return send(res, 503, { error: 'SERVICE_UNAVAILABLE' }); }

  // الاسم: اللي جه من n8n، وإلا من جدول المرضى بالرقم، وإلا «مريض واتساب»
  let name = clip(body.patient_name ?? body.name, 120);
  if (name.length < 2) {
    try {
      const { data } = await db.from('patients').select('full_name').eq('phone', phone.e164).maybeSingle();
      name = clip(data?.full_name, 120);
    } catch { /* ignore */ }
  }
  if (name.length < 2) name = 'مريض واتساب';

  const category = CATEGORIES.includes(body.category) ? body.category : 'other';
  const priority = PRIORITIES.includes(body.priority) ? body.priority : 'normal';
  const subject = clip(body.subject, 150).length >= 3 ? clip(body.subject, 150) : (message.slice(0, 70) + (message.length > 70 ? '…' : ''));
  const id = (v) => (/^[\w-]{2,64}$/.test(String(v ?? '')) ? String(v) : null);

  const { data, error } = await db.from('complaints').insert({
    patient_name: name,
    patient_phone: phone.e164,
    doctor_id: id(body.doctor_id),
    appointment_id: id(body.appointment_id),
    category,
    subject,
    message,
    priority,
    status: 'new',
    source: 'whatsapp',
    external_id: clip(body.external_id, 120) || null,
  }).select('id').single();

  if (error && error.code === '23505') return send(res, 200, { ok: true, duplicate: true }); // نفس رسالة واتساب اتسجلت قبل كده
  if (error) {
    console.error('[complaints]', error.code, error.message);
    return send(res, 500, { error: 'STORE_FAILED', code: error.code, detail: String(error.message).slice(0, 200) });
  }
  return send(res, 200, { ok: true, id: data.id });
}
