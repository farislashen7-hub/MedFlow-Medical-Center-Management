import { adminClient } from './_lib/supabase.js';
import { parsePhone } from './_lib/phone.js';

// POST /api/register-patient  — يسجّل أي مريض جديد في جدول public.patients (service role).
// بيتعمل من السيرفر عشان ميتوقفش على صلاحيات/RLS الزائر (anon). الباسورد مبيتبعتش ولا بيتخزن هنا.
// نفس الرقم اتسجل قبل كده (23505) = نجاح (duplicate:true) مش خطأ.
const send = (res, status, body) => res.status(status).json(body);
const clip = (v, max) => String(v ?? '').trim().replace(/\s+/g, ' ').slice(0, max);
const orNull = (v, max) => { const s = clip(v, max); return s ? s : null; };

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'METHOD_NOT_ALLOWED' }); }

  // same-origin only
  const origin = req.headers.origin;
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  if (origin) {
    try { if (new URL(origin).host !== host) return send(res, 403, { error: 'FORBIDDEN' }); }
    catch { return send(res, 403, { error: 'FORBIDDEN' }); }
  }

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = null; } }
  if (!body || typeof body !== 'object') return send(res, 400, { error: 'BAD_REQUEST' });

  const name = clip(body.name, 120);
  if (name.length < 2) return send(res, 422, { error: 'INVALID_NAME' });
  const phone = parsePhone(clip(body.phone, 30));
  if (!phone.ok) return send(res, 422, { error: 'INVALID_PHONE', code: phone.error });

  let db;
  try { db = adminClient(); }
  catch (e) { console.error('[register-patient]', e.message); return send(res, 503, { error: 'SERVICE_UNAVAILABLE' }); }

  // rate limit per IP (fail open)
  try {
    const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
    const { data: allowed, error } = await db.rpc('rate_hit', { p_key: `reg|${ip}`, p_limit: 20, p_window_secs: 600 });
    if (!error && allowed === false) return send(res, 429, { error: 'RATE_LIMITED' });
  } catch { /* fail open */ }

  const birth = /^\d{4}-\d{2}-\d{2}$/.test(String(body.birthDate ?? '')) ? body.birthDate : null;
  const { error } = await db.from('patients').insert({
    full_name: name,
    phone: phone.e164,
    email: clip(body.email, 160),
    date_of_birth: birth,
    gender: body.gender === 'female' ? 'female' : 'male',
    national_id: orNull(body.nationalId, 30),
    blood_type: orNull(body.bloodType, 10),
    allergies: orNull(body.allergies, 500),
    chronic_diseases: orNull(body.chronic, 500),
    insurance: orNull(body.insurance, 120),
    address: orNull(body.address, 300),
    emergency_contact: orNull(body.emergency, 300),
  });
  if (error && error.code === '23505') return send(res, 200, { ok: true, duplicate: true });
  if (error) {
    console.error('[register-patient]', error.code, error.message);
    return send(res, 500, { error: 'STORE_FAILED', code: error.code, detail: String(error.message).slice(0, 200) });
  }
  return send(res, 200, { ok: true });
}
