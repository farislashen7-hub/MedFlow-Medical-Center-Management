import { createHmac, randomInt, timingSafeEqual } from 'node:crypto';
import { adminClient } from './_lib/supabase.js';
import { notifyN8n } from './_lib/n8n.js';
import { parsePhone } from './_lib/phone.js';

// POST /api/password-reset
//   { action: 'request', phone }          -> يولّد كود 6 أرقام ويبعته واتساب (عبر n8n)
//   { action: 'verify',  phone, code }    -> يتحقق من الكود ويستهلكه (استخدام مرة واحدة)
// الكود بيتخزن HMAC بس. صلاحية 10 دقايق، 5 محاولات غلط، rate limit للـ IP والرقم، وكولداون 60 ثانية بين الإرسالين.
// الرد على request واحد سواء الرقم موجود أو لأ (مفيش تسريب لوجود الحساب).
const TTL_SECS = 600;
const MAX_ATTEMPTS = 5;
const COOLDOWN_SECS = 60;
const send = (res, status, body) => res.status(status).json(body);

const secret = () => process.env.PASSWORD_RESET_SECRET || process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const hash = (wa, code) => createHmac('sha256', secret()).update(`${wa}:${code}`).digest('hex');
const safeEq = (a, b) => {
  const x = Buffer.from(a, 'hex');
  const y = Buffer.from(b, 'hex');
  return x.length === y.length && timingSafeEqual(x, y);
};
const limited = async (db, key, limit, windowSecs) => {
  const { data, error } = await db.rpc('rate_hit', { p_key: key, p_limit: limit, p_window_secs: windowSecs });
  return !error && data === false; // fail open على rate limit بس (التخزين نفسه لازم يشتغل)
};

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'METHOD_NOT_ALLOWED' }); }

  // same-origin only
  const origin = req.headers.origin;
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  if (origin) {
    try { if (new URL(origin).host !== host) return send(res, 403, { error: 'FORBIDDEN' }); }
    catch { return send(res, 403, { error: 'FORBIDDEN' }); }
  }

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = null; } }
  if (!body || typeof body !== 'object') return send(res, 400, { error: 'BAD_REQUEST' });

  const action = body.action;
  if (action !== 'request' && action !== 'verify') return send(res, 400, { error: 'BAD_REQUEST' });
  const phone = parsePhone(String(body.phone ?? '').slice(0, 30));
  if (!phone.ok) return send(res, 422, { error: 'INVALID_PHONE', code: phone.error });
  const wa = phone.wa;

  let db;
  try {
    if (!secret()) throw new Error('no secret');
    db = adminClient();
  } catch (e) { console.error('[pwreset]', e.message); return send(res, 503, { error: 'SERVICE_UNAVAILABLE' }); }

  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';

  /* ---------- request: ابعت كود ---------- */
  if (action === 'request') {
    if (await limited(db, `pwr|ip|${ip}`, 10, 600)) return send(res, 429, { error: 'RATE_LIMITED' });
    if (await limited(db, `pwr|ph|${wa}`, 3, 900)) return send(res, 429, { error: 'RATE_LIMITED' });

    const { data: prev } = await db.from('password_resets').select('created_at').eq('phone_wa', wa).maybeSingle();
    if (prev) {
      const wait = COOLDOWN_SECS - Math.floor((Date.now() - Date.parse(prev.created_at)) / 1000);
      if (wait > 0) return send(res, 429, { error: 'TOO_SOON', retryAfter: wait });
    }

    const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
    const { error: upErr } = await db.from('password_resets').upsert({
      phone_wa: wa,
      code_hash: hash(wa, code),
      attempts: 0,
      expires_at: new Date(Date.now() + TTL_SECS * 1000).toISOString(),
      created_at: new Date().toISOString(),
    });
    if (upErr) { console.error('[pwreset] store', upErr.message); return send(res, 500, { error: 'STORE_FAILED' }); }

    const r = await notifyN8n('patient.password_reset', { phone_wa: wa, code, expires_minutes: TTL_SECS / 60 }, { timeoutMs: 15_000 });
    if (r.reason === 'no_url') return send(res, 503, { error: 'SERVICE_UNAVAILABLE' });
    if (!r.ok) {
      await db.from('password_resets').delete().eq('phone_wa', wa);
      return send(res, 502, { error: 'SEND_FAILED', reason: r.reason });
    }
    return send(res, 200, { ok: true, expiresIn: TTL_SECS, cooldown: COOLDOWN_SECS });
  }

  /* ---------- verify: اتحقق من الكود ---------- */
  if (await limited(db, `pwr|vip|${ip}`, 30, 600)) return send(res, 429, { error: 'RATE_LIMITED' });
  const code = String(body.code ?? '').replace(/\D/g, '');
  if (code.length !== 6) return send(res, 422, { error: 'INVALID_CODE' });

  const { data: row, error } = await db.from('password_resets').select('code_hash, attempts, expires_at').eq('phone_wa', wa).maybeSingle();
  if (error) { console.error('[pwreset] read', error.message); return send(res, 500, { error: 'STORE_FAILED' }); }
  if (!row || Date.parse(row.expires_at) < Date.now()) {
    if (row) await db.from('password_resets').delete().eq('phone_wa', wa);
    return send(res, 400, { error: 'CODE_EXPIRED' });
  }
  if (row.attempts >= MAX_ATTEMPTS) {
    await db.from('password_resets').delete().eq('phone_wa', wa);
    return send(res, 429, { error: 'TOO_MANY_ATTEMPTS' });
  }
  if (!safeEq(row.code_hash, hash(wa, code))) {
    const attempts = row.attempts + 1;
    if (attempts >= MAX_ATTEMPTS) await db.from('password_resets').delete().eq('phone_wa', wa);
    else await db.from('password_resets').update({ attempts }).eq('phone_wa', wa);
    return send(res, 400, { error: 'INVALID_CODE', remaining: Math.max(0, MAX_ATTEMPTS - attempts) });
  }
  await db.from('password_resets').delete().eq('phone_wa', wa); // استخدام مرة واحدة
  return send(res, 200, { ok: true });
}
