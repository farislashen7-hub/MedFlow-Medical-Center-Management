// Server-only. n8n failure must never break a booking. Returns { ok, reason }.
// N8N_WEBHOOK_BASE (e.g. https://host/webhook) -> one path per event family (see ROUTES).
// env: اسم متغير أو أكتر (أول واحد مليان هو اللي بيتاخد). أسماء Vercel case-sensitive.
const envPath = (names, def) => {
  for (const name of [].concat(names)) {
    const v = (process.env[name] || '').trim().replace(/^\/+|\/+$/g, '');
    if (v) return v;
  }
  return def;
};

// كل webhook = سطر هنا. events بتتوزع على نفس الـ path (n8n Switch على body.event).
// path بيتغيّر من env من غير كود. حدث مش موجود هنا = يتخطّى بهدوء.
const ROUTES = [
  { events: ['appointment.created', 'appointment.reminder'], env: 'N8N_PATH_BOOKING', def: 'cli-booking' },
  // الإلغاء: webhook خاص (cli-cancel-booking). N8N_PATH_cancelbooking لو عايز اسم تاني.
  { events: ['appointment.cancelled'],      env: ['N8N_PATH_cancelbooking', 'N8N_PATH_CANCEL_BOOKING'], def: 'cli-cancel-booking' },
  { events: ['appointment.rebooked'],       env: 'N8N_PATH_REBOOKING',     def: 'cli-Rebooking' },
  { events: ['prescription.issued'],        env: 'N8N_PATH_TREATMENT',     def: 'cli-Treatment' },        // صورة الوصفة
  { events: ['doctor.unavailable'],         env: ['N8N_PATH_NOT_AVAILABLE', 'N8N_PATH_Not_available'], def: 'cli-not-available' },
  { events: ['offer.broadcast'],            env: ['N8N_PATH_OFFERS', 'N8N_PATH_OFFER'], def: 'cli-offer' },
  { events: ['report.send'],                env: ['N8N_PATH_REPORT', 'N8N_PATH_sendreport'], def: 'cli-report' }, // PDF ملخص التقرير للمدير
  { events: ['review.submitted'],           env: 'N8N_PATH_REVIEW',        def: 'cli-review' },          // تقييم جديد
  { events: ['patient.signed_up'],          env: 'N8N_PATH_PATIENTS',      def: 'cli-patients' },
  { events: ['whatsapp.wipe_all'],          env: ['N8N_PATH_WIPE_ALL', 'N8N_PATH_WIPE'], def: 'res-wipe-all' }, // مسح كل محادثات واتساب (الداتابيز + الملفات). للإدارة بس عبر /api/wipe-chats
  { events: ['patient.password_reset'],     env: 'N8N_PATH_PASSWORD_RESET', def: 'cli-password-reset' }, // كود استعادة كلمة المرور (6 أرقام) واتساب
];

const NEGATIVE_MAX_RATING = 2; // تقييم <= 2 يروح لـ N8N_PATH_REVIEW_NEGATIVE (لو مضبوط)

function pathFor(event, payload) {
  if (event === 'review.submitted' && Number(payload?.rating) <= NEGATIVE_MAX_RATING) {
    const neg = envPath('N8N_PATH_REVIEW_NEGATIVE', null);
    if (neg) return neg;
  }
  const r = ROUTES.find((x) => x.events.includes(event));
  return r ? envPath(r.env, r.def) : null;
}

export async function notifyN8n(event, payload, { timeoutMs = 8000 } = {}) {
  const base = (process.env.N8N_WEBHOOK_BASE || '').trim().replace(/\/+$/, '');
  if (!base) { console.error('[n8n] N8N_WEBHOOK_BASE is not set'); return { ok: false, reason: 'no_url' }; }
  const p = pathFor(event, payload);
  if (!p) return { ok: true, reason: 'skipped' };
  try {
    const url = `${base}/${p.split('/').map(encodeURIComponent).join('/')}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-webhook-secret': process.env.N8N_WEBHOOK_SECRET || '',
        'ngrok-skip-browser-warning': '1', // ngrok المجاني: يتخطى صفحة التحذير
      },
      body: JSON.stringify({ event, payload, ts: new Date().toISOString() }),
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (!res.ok) console.error('[n8n]', event, 'HTTP', res.status);
    return { ok: res.ok, reason: res.ok ? 'ok' : `http_${res.status}` };
  } catch (e) {
    console.error('[n8n]', event, e.message);
    return { ok: false, reason: 'unreachable' };
  }
}
