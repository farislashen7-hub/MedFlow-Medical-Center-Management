// Server copy of src/lib/phone.ts (Egypt + Gulf). Keep both in sync.
const RULES = [
  { cc: '20',  iso: 'EG', re: /^1[0125]\d{8}$/, trunk: true },
  { cc: '966', iso: 'SA', re: /^5\d{8}$/, trunk: true },
  { cc: '971', iso: 'AE', re: /^5[024568]\d{7}$/, trunk: true },
  { cc: '965', iso: 'KW', re: /^[569]\d{7}$/ },
  { cc: '974', iso: 'QA', re: /^[3567]\d{7}$/ },
  { cc: '973', iso: 'BH', re: /^[36]\d{7}$/ },
  { cc: '968', iso: 'OM', re: /^[79]\d{7}$/ },
];
const DEFAULT_GULF_CC = (process.env.DEFAULT_GULF_CC || '966').replace(/\D/g, '');
const toLatin = (s) => String(s ?? '')
  .replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
  .replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
const build = (r, n) => ({ ok: true, iso: r.iso, e164: `+${r.cc}${n}`, wa: `${r.cc}${n}` });

export function parsePhone(raw) {
  const s = toLatin(raw).trim().replace(/[\s\-().]/g, '');
  if (!s) return { ok: false, error: 'EMPTY' };
  if (!/^\+?\d+$/.test(s.replace(/^00/, '+'))) return { ok: false, error: 'INVALID_CHARS' };
  const intl = s.startsWith('+') || s.startsWith('00');
  const d = s.replace(/^(\+|00)/, '');
  if (intl) {
    const r = RULES.find((x) => d.startsWith(x.cc));
    if (!r) return { ok: false, error: 'COUNTRY_NOT_SUPPORTED' };
    let n = d.slice(r.cc.length);
    if (r.trunk && n.startsWith('0')) n = n.slice(1);
    return r.re.test(n) ? build(r, n) : { ok: false, error: 'BAD_LENGTH_OR_PREFIX', country: r.iso };
  }
  if (d.startsWith('0')) {
    const n = d.slice(1);
    if (RULES[0].re.test(n)) return build(RULES[0], n);
    const g = RULES.find((x) => x.cc === DEFAULT_GULF_CC && x.iso !== 'EG') || RULES[1];
    if (g.re.test(n)) return build(g, n);
    return { ok: false, error: 'BAD_LENGTH_OR_PREFIX' };
  }
  for (const r of RULES) {
    if (d.startsWith(r.cc) && r.re.test(d.slice(r.cc.length))) return build(r, d.slice(r.cc.length));
  }
  if (RULES[0].re.test(d)) return build(RULES[0], d);
  return { ok: false, error: 'BAD_LENGTH_OR_PREFIX' };
}
