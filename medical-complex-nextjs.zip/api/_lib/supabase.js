import { createClient } from '@supabase/supabase-js';

// service_role client: bypasses RLS. Server only (api/*). NEVER import from src/.
export function adminClient() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  if (!key) throw new Error('SUPABASE_SERVICE_ROLE_KEY is not set');
  if (!url) throw new Error('SUPABASE_URL is not set');
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}
