import { notifyN8n } from './_lib/n8n.js';

// POST /api/n8n  { event, payload }   <- المتصفح يكلّم السيرفر بس. السيرفر يبعت لـ n8n بالـ secret.
// مفيش CORS ولا secret ولا رابط n8n في المتصفح. n8n بيعمل تحقق الحقول (Guard) كمان.
const EVENTS = new Set([
  'appointment.created', 'appointment.rebooked', 'appointment.cancelled', 'appointment.reminder',
  'prescription.issued', 'doctor.unavailable', 'offer.broadcast', 'report.send', 'review.submitted',
]);
const MAX_BYTES = 4_200_000; // Vercel body limit ~4.5MB
const send = (res, status, body) => res.status(status).json(body);

// العرض: المتصفح بيبعت المستلمين للسيرفر بس. السيرفر بيحفظهم في Supabase (offer_recipients)
// ويبعت لـ n8n تفاصيل العرض + campaign_id من غير أي رقم. n8n بيجيب الأرقام من الداتابيز.
async function stageOffer(p) {
  const seen = new Set();
  const recipients = (Array.isArray(p.recipients) ? p.recipients : [])
    .slice(0, 500)
    .map((r) => ({ name: String(r?.name ?? '').slice(0, 120), number: String(r?.number ?? '').replace(/\D/g, '') }))
    .filter((r) => /^\d{8,15}$/.test(r.number) && !seen.has(r.number) && !!seen.add(r.number));
  if (recipients.length === 0) return { ok: false, status: 422, error: 'INVALID_PHONE' };
  if (!p.text && !p.image_base64 && !p.offer_title) return { ok: false, status: 422, error: 'EMPTY_OFFER' };

  let db;
  try { ({ adminClient: db } = await import('./_lib/supabase.js')); db = db(); }
  catch { return { ok: false, status: 503, error: 'SERVICE_UNAVAILABLE' }; }

  const { data: camp, error: e1 } = await db
    .from('offer_campaigns')
    .insert({ offer_title: String(p.offer_title ?? '').slice(0, 200), total: recipients.length })
    .select('id')
    .single();
  if (e1 || !camp) { console.error('[offer] campaign', e1?.message); return { ok: false, status: 500, error: 'STAGE_FAILED' }; }

  const { error: e2 } = await db.from('offer_recipients').insert(recipients.map((r) => ({ ...r, campaign_id: camp.id })));
  if (e2) {
    console.error('[offer] recipients', e2.message);
    await db.from('offer_campaigns').delete().eq('id', camp.id);
    return { ok: false, status: 500, error: 'STAGE_FAILED' };
  }

  return {
    ok: true,
    payload: {
      campaign_id: camp.id,
      offer_title: p.offer_title ?? '',
      text: p.text ?? '',
      image_base64: p.image_base64 ?? null,
      mimetype: p.mimetype ?? null,
      count: recipients.length,
    },
  };
}

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(res, 405, { error: 'METHOD_NOT_ALLOWED' }); }

  // same-origin only
  const origin = req.headers.origin;
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  if (origin) {
    try { if (new URL(origin).host !== host) return send(res, 403, { error: 'FORBIDDEN' }); }
    catch { return send(res, 403, { error: 'FORBIDDEN' }); }
  }

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = null; } }
  if (!body || typeof body !== 'object') return send(res, 400, { error: 'BAD_REQUEST' });
  if (!EVENTS.has(body.event)) return send(res, 400, { error: 'UNKNOWN_EVENT' });
  const payload = body.payload;
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return send(res, 400, { error: 'BAD_REQUEST' });
  if (JSON.stringify(payload).length > MAX_BYTES) return send(res, 413, { error: 'PAYLOAD_TOO_LARGE' });

  // rate limit per IP (fail open لو Supabase مش مضبوط)
  try {
    const { adminClient } = await import('./_lib/supabase.js');
    const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
    const { data: allowed, error } = await adminClient().rpc('rate_hit', { p_key: `n8n|${ip}`, p_limit: 120, p_window_secs: 600 });
    if (!error && allowed === false) return send(res, 429, { error: 'RATE_LIMITED' });
  } catch { /* fail open */ }

  let forward = payload;
  if (body.event === 'offer.broadcast') {
    const st = await stageOffer(payload);
    if (!st.ok) return send(res, st.status, { error: st.error });
    forward = st.payload;
  }

  const r = await notifyN8n(body.event, forward, { timeoutMs: 20_000 });
  if (r.reason === 'no_url') return send(res, 503, { error: 'SERVICE_UNAVAILABLE' });
  if (r.reason === 'skipped') return send(res, 200, { ok: true, skipped: true });
  if (!r.ok) return send(res, 502, { error: 'N8N_FAILED', reason: r.reason });
  return send(res, 200, { ok: true });
}
