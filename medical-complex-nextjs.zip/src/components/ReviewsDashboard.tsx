import { useMemo } from 'react'
import { AlertTriangle, MessageSquareQuote, Star, ThumbsUp, Trophy } from 'lucide-react'
import { Badge, Card, SectionTitle, StatCard } from './ui'
import { Stars } from './Stars'
import { LineChart } from './charts'
import { useDB } from '../lib/db'
import { ReviewsManager } from './OffersHub'

const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']

/** تبويب «آراء العملاء» في لوحة الإدارة: مؤشرات التقييم + ترتيب الأطباء + اتجاه التقييم + إدارة التقييمات/الردود */
export function ReviewsDashboard() {
  const db = useDB()
  const all = db.reviews
  const avg = all.length ? all.reduce((s, r) => s + r.rating, 0) / all.length : 0
  const happy = all.length ? Math.round((all.filter((r) => r.rating >= 4).length / all.length) * 100) : 0
  const low = all.filter((r) => r.rating <= 2)
  const unanswered = all.filter((r) => !r.reply.trim()).length

  const byDoctor = useMemo(
    () =>
      db.doctors
        .map((d) => {
          const rs = all.filter((r) => r.doctorId === d.id)
          return { doctor: d, count: rs.length, avg: rs.length ? rs.reduce((s, r) => s + r.rating, 0) / rs.length : 0 }
        })
        .filter((x) => x.count > 0)
        .sort((a, b) => b.avg - a.avg || b.count - a.count),
    [db.doctors, all],
  )

  // متوسط التقييم لآخر 6 أشهر
  const trend = useMemo(() => {
    const out: { label: string; value: number }[] = []
    const now = new Date()
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
      const rs = all.filter((r) => r.createdAt.startsWith(key))
      out.push({ label: MONTHS[d.getMonth()], value: rs.length ? Math.round((rs.reduce((s, r) => s + r.rating, 0) / rs.length) * 10) / 10 : 0 })
    }
    return out
  }, [all])

  return (
    <div className="mt-5 space-y-5">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="متوسط التقييم" value={avg ? avg.toFixed(1) : '—'} hint={`من ${all.length} تقييم`} icon={<Star size={20} />} tone="amber" />
        <StatCard label="نسبة الرضا" value={`${happy}%`} hint="4 نجوم فأكثر" icon={<ThumbsUp size={20} />} tone="green" />
        <StatCard label="تقييمات منخفضة" value={low.length} hint="نجمتين أو أقل" icon={<AlertTriangle size={20} />} tone="rose" />
        <StatCard label="بدون رد" value={unanswered} hint="في انتظار رد المركز" icon={<MessageSquareQuote size={20} />} tone="sky" />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <SectionTitle title="اتجاه التقييم" subtitle="متوسط النجوم لآخر 6 أشهر" icon={<Star size={18} />} />
          <LineChart data={trend} color="#f59e0b" />
        </Card>
        <Card>
          <SectionTitle title="ترتيب الأطباء بالتقييم" subtitle="حسب متوسط تقييمات المرضى" icon={<Trophy size={18} />} />
          {byDoctor.length === 0 ? (
            <p className="py-6 text-center text-[13px] text-ink-400">لا توجد تقييمات بعد.</p>
          ) : (
            <ol className="divide-y divide-ink-50">
              {byDoctor.slice(0, 6).map((x, i) => (
                <li key={x.doctor.id} className="flex items-center gap-3 py-2.5">
                  <span className="flex size-7 shrink-0 items-center justify-center rounded-lg bg-ink-50 text-[12px] font-extrabold text-ink-600">
                    {i + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-bold text-ink-900">{x.doctor.name}</p>
                    <p className="text-[11.5px] text-ink-400">{x.count} تقييم</p>
                  </div>
                  <Stars value={x.avg} size={13} />
                  <Badge tone={x.avg >= 4 ? 'green' : x.avg >= 3 ? 'amber' : 'rose'}>{x.avg.toFixed(1)}</Badge>
                </li>
              ))}
            </ol>
          )}
        </Card>
      </div>

      <ReviewsManager />
    </div>
  )
}
