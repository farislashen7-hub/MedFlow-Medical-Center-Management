import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import {
  CalendarPlus,
  Clock,
  LayoutDashboard,
  LogOut,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  Stethoscope,
  X,
} from 'lucide-react'
import { useAuth } from '../lib/auth'
import { useSettings } from '../lib/db'
import { telHref, waLink } from '../lib/format'
import { Logo } from './Logo'
import { Avatar, Button } from './ui'

const navLinks = [
  { to: '/', label: 'الرئيسية', end: true },
  { to: '/specialties', label: 'التخصصات' },
  { to: '/doctors', label: 'الأطباء' },
  { to: '/book', label: 'حجز موعد' },
  { to: '/reviews', label: 'آراء العملاء' },
  { to: '/contact', label: 'تواصل معنا' },
]

export function Header() {
  const { session, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setOpen(false)
  }, [location.pathname])

  // الطبيب مالوش صلاحية حجز مواعيد — بنخفي رابط الحجز عنه
  const visibleLinks = session?.role === 'doctor' ? navLinks.filter((l) => l.to !== '/book') : navLinks

  const dashboardLink =
    session?.role === 'admin' ? '/admin' : session?.role === 'doctor' ? '/doctor' : '/patient'

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'border-b border-ink-100 bg-white/90 backdrop-blur-xl'
          : 'border-b border-transparent bg-white/60 backdrop-blur-md'
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <Link to="/" className="shrink-0">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {visibleLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              className={({ isActive }) =>
                `relative rounded-lg px-3.5 py-2 text-[13.5px] font-semibold transition ${
                  isActive ? 'text-brand-700' : 'text-ink-600 hover:bg-ink-50 hover:text-ink-900'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  {link.label}
                  {isActive && (
                    <motion.span
                      layoutId="nav-underline"
                      className="absolute inset-x-3 -bottom-0.5 h-0.5 rounded-full bg-brand-500"
                    />
                  )}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          {session ? (
            <div className="hidden items-center gap-2 sm:flex">
              <Link
                to={dashboardLink}
                className="flex items-center gap-2.5 rounded-xl border border-ink-200 py-1.5 pr-1.5 pl-3 transition hover:border-brand-300 hover:bg-brand-50/50"
              >
                <Avatar name={session.name} size={30} />
                <span className="flex flex-col leading-tight">
                  <span className="text-[12.5px] font-bold text-ink-800">{session.name}</span>
                  <span className="text-[10px] font-medium text-ink-400">
                    {session.role === 'admin' ? 'المالك' : session.role === 'doctor' ? 'لوحة الطبيب' : 'بوابة المريض'}
                  </span>
                </span>
              </Link>
              <button
                onClick={() => {
                  logout()
                  navigate('/')
                }}
                title="تسجيل الخروج"
                className="rounded-xl border border-ink-200 p-2.5 text-ink-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
              >
                <LogOut size={17} />
              </button>
            </div>
          ) : (
            <div className="hidden items-center gap-2 sm:flex">
              <Link to="/login">
                <Button variant="secondary" size="sm">
                  تسجيل الدخول
                </Button>
              </Link>
              <Link to="/book">
                <Button size="sm">
                  <CalendarPlus size={16} />
                  احجز موعدك
                </Button>
              </Link>
            </div>
          )}

          <button
            onClick={() => setOpen((v) => !v)}
            aria-label="القائمة"
            className="rounded-xl border border-ink-200 p-2.5 text-ink-700 transition hover:bg-ink-50 lg:hidden"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-ink-100 bg-white lg:hidden"
          >
            <div className="space-y-1 px-4 py-4 sm:px-6">
              {visibleLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.end}
                  className={({ isActive }) =>
                    `block rounded-xl px-4 py-3 text-sm font-semibold transition ${
                      isActive ? 'bg-brand-50 text-brand-700' : 'text-ink-600 hover:bg-ink-50'
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
              <div className="flex flex-col gap-2 pt-2 sm:hidden">
                {session ? (
                  <>
                    <Link to={dashboardLink}>
                      <Button className="w-full">
                        <LayoutDashboard size={17} />
                        لوحة التحكم
                      </Button>
                    </Link>
                    <Button
                      variant="secondary"
                      className="w-full"
                      onClick={() => {
                        logout()
                        navigate('/')
                      }}
                    >
                      <LogOut size={16} />
                      تسجيل الخروج
                    </Button>
                  </>
                ) : (
                  <>
                    <Link to="/login">
                      <Button variant="secondary" className="w-full">
                        تسجيل الدخول
                      </Button>
                    </Link>
                    <Link to="/book">
                      <Button className="w-full">
                        <CalendarPlus size={17} />
                        احجز موعدك
                      </Button>
                    </Link>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}

export function Footer() {
  const center = useSettings()
  const { session } = useAuth()
  return (
    <footer className="mt-20 bg-ink-950 text-ink-300">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Logo light />
            <p className="mt-4 max-w-xs text-sm leading-7 text-ink-400">
              {center.about}
            </p>
            <div className="mt-5 flex gap-2">
              <a
                href={waLink(center.whatsapp || center.phone)}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 rounded-xl bg-[#25D366] px-3.5 py-2 text-[12.5px] font-bold text-ink-950 transition hover:bg-[#1eb958]"
              >
                <MessageCircle size={15} />
                واتساب
              </a>
              <a
                href={telHref(center.phone)}
                className="flex items-center gap-2 rounded-xl border border-ink-700 px-3.5 py-2 text-[12.5px] font-bold text-ink-200 transition hover:border-brand-500 hover:text-white"
              >
                <Phone size={15} />
                <span dir="ltr">{center.phone}</span>
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-bold text-white">روابط سريعة</h4>
            <ul className="mt-4 space-y-2.5 text-[13px]">
              {[
                { to: '/specialties', label: 'التخصصات الطبية' },
                { to: '/doctors', label: 'دليل الأطباء' },
                { to: '/book', label: 'حجز موعد' },
                { to: '/reviews', label: 'آراء العملاء' },
                { to: '/login', label: 'بوابة المريض' },
                { to: '/staff', label: 'دخول الطاقم (طبيب / مالك)' },
              ]
                .filter((l) => !(session?.role === 'doctor' && l.to === '/book'))
                .map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="text-ink-400 transition hover:text-brand-300">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold text-white">بوابات الدخول</h4>
            <ul className="mt-4 space-y-2.5 text-[13px]">
              <li>
                <Link to="/admin" className="text-ink-400 transition hover:text-brand-300">
                  لوحة الإدارة
                </Link>
              </li>
              <li>
                <Link to="/doctor" className="text-ink-400 transition hover:text-brand-300">
                  لوحة الطبيب
                </Link>
              </li>
              <li>
                <Link to="/patient" className="text-ink-400 transition hover:text-brand-300">
                  ملف المريض
                </Link>
              </li>
              <li>
                <Link to="/register" className="text-ink-400 transition hover:text-brand-300">
                  إنشاء حساب جديد
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold text-white">بيانات المركز</h4>
            <ul className="mt-4 space-y-2.5 text-[13px] text-ink-400">
              {(center.city || center.address) && (
                <li className="flex items-start gap-2">
                  <MapPin size={14} className="mt-0.5 shrink-0 text-brand-400" />
                  {[center.city, center.address].filter(Boolean).join(' — ')}
                </li>
              )}
              {center.workHours && (
                <li className="flex items-start gap-2">
                  <Clock size={14} className="mt-0.5 shrink-0 text-brand-400" />
                  {[center.workDays, center.workHours].filter(Boolean).join(' • ')}
                </li>
              )}
              {[
                ['إنستجرام', center.instagram],
                ['فيسبوك', center.facebook],
                ['X', center.x],
                ['الموقع', center.website],
              ].some(([, u]) => u) && (
                <li className="flex flex-wrap gap-x-3 gap-y-1 pt-1">
                  {[
                    ['إنستجرام', center.instagram],
                    ['فيسبوك', center.facebook],
                    ['X', center.x],
                    ['الموقع', center.website],
                  ]
                    .filter(([, u]) => u)
                    .map(([l, u]) => (
                      <a key={l} href={u} target="_blank" rel="noreferrer" className="font-semibold text-brand-300 transition hover:text-white">
                        {l}
                      </a>
                    ))}
                </li>
              )}
              {center.email && (
                <li className="flex items-center gap-2">
                  <Mail size={14} className="shrink-0 text-brand-400" />
                  <span dir="ltr">{center.email}</span>
                </li>
              )}
              <li className="flex items-center gap-2">
                <Stethoscope size={14} className="text-brand-400" />
                استشارة طبية على مدار الساعة
              </li>
              <li className="flex items-center gap-2">
                <CalendarPlus size={14} className="text-brand-400" />
                حجز أو تعديل موعد خلال ثوانٍ
              </li>
              <li className="flex items-center gap-2">
                <MessageCircle size={14} className="text-brand-400" />
                دعم فني عبر واتساب
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-ink-800 pt-6 text-[12px] text-ink-500 sm:flex-row">
          <p>© {new Date().getFullYear()} {center.name} — جميع الحقوق محفوظة{center.licenseNo ? ` • ترخيص رقم ${center.licenseNo}` : ''}</p>
          <p>منصة إدارة العيادات الذكية — الإصدار 2.4</p>
        </div>
      </div>
    </footer>
  )
}

export function PageShell({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <>
      <Header />
      <main className={`mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 ${className}`}>{children}</main>
      <Footer />
    </>
  )
}
