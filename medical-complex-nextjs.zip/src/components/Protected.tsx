import { Navigate, useLocation } from 'react-router-dom'
import type { ReactNode } from 'react'
import { useAuth } from '../lib/auth'
import type { Role } from '../lib/types'

export function Protected({ role, children }: { role: Role; children: ReactNode }) {
  const { session, loading } = useAuth()
  const location = useLocation()

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="size-10 animate-spin rounded-full border-4 border-brand-200 border-t-brand-600" />
      </div>
    )
  }

  if (!session) {
    // الطبيب والمالك بيدخلوا من صفحة الطاقم، المريض من بوابة المريض
    return <Navigate to={role === 'patient' ? '/login' : '/staff'} state={{ from: location.pathname }} replace />
  }

  if (session.role !== role) {
    const target = session.role === 'admin' ? '/admin' : session.role === 'doctor' ? '/doctor' : '/patient'
    return <Navigate to={target} replace />
  }

  return <>{children}</>
}

/** يمنع دور معين (الطبيب) من صفحة — بيتحوّل للوحته. الطبيب مالوش صلاحية حجز مواعيد. */
export function BlockRole({ role, children }: { role: Role; children: ReactNode }) {
  const { session, loading } = useAuth()
  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="size-10 animate-spin rounded-full border-4 border-brand-200 border-t-brand-600" />
      </div>
    )
  }
  if (session?.role === role) return <Navigate to={role === 'doctor' ? '/doctor' : '/admin'} replace />
  return <>{children}</>
}
