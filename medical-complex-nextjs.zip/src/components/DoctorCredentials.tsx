import { useState } from 'react'
import { Check, Copy, Eye, EyeOff, KeyRound, RefreshCw } from 'lucide-react'
import type { Doctor } from '../lib/types'
import { useToast } from './Toast'

/** اسم المستخدم اللي الطبيب بيدخل بيه: البريد لو موجود، وإلا رقم الجوال */
export function doctorUsername(d: Pick<Doctor, 'email' | 'phone'>) {
  return d.email?.trim() || d.phone
}

/** باسورد عشوائي 8 خانات (من غير حروف متشابهة 0/O/1/l) */
export function generatePassword(len = 8) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'
  const buf = new Uint32Array(len)
  crypto.getRandomValues(buf)
  return Array.from(buf, (n) => chars[n % chars.length]).join('')
}

function CopyBtn({ value, label }: { value: string; label: string }) {
  const { push } = useToast()
  const [done, setDone] = useState(false)
  async function copy() {
    try {
      await navigator.clipboard.writeText(value)
      setDone(true)
      push(`تم نسخ ${label}`)
      setTimeout(() => setDone(false), 1500)
    } catch {
      push('تعذر النسخ، انسخ يدوياً', 'error')
    }
  }
  return (
    <button
      type="button"
      onClick={copy}
      aria-label={`نسخ ${label}`}
      className="rounded-lg p-1.5 text-ink-400 transition hover:bg-ink-100 hover:text-ink-700"
    >
      {done ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
    </button>
  )
}

/** بيانات دخول الطبيب (يوزر + باسورد) — بتظهر في كارت الطبيب وفي نافذة ما بعد الإضافة */
export function DoctorCredentials({ doctor, defaultShow = false }: { doctor: Doctor; defaultShow?: boolean }) {
  const [show, setShow] = useState(defaultShow)
  const user = doctorUsername(doctor)

  return (
    <div className="mt-3 rounded-xl border border-brand-100 bg-brand-50/50 px-3 py-2.5">
      <p className="flex items-center gap-1.5 text-[11px] font-bold text-brand-700">
        <KeyRound size={12} />
        بيانات دخول الطبيب
      </p>

      <div className="mt-2 flex items-center justify-between gap-2">
        <span className="shrink-0 text-[11px] text-ink-500">اليوزر</span>
        <span className="min-w-0 flex-1 truncate text-left text-[12.5px] font-bold text-ink-900" dir="ltr">
          {user || '—'}
        </span>
        {user && <CopyBtn value={user} label="اليوزر" />}
      </div>

      <div className="mt-1 flex items-center justify-between gap-2">
        <span className="shrink-0 text-[11px] text-ink-500">الباسورد</span>
        <span className="min-w-0 flex-1 truncate text-left font-mono text-[12.5px] font-bold text-ink-900" dir="ltr">
          {show ? doctor.password : '•'.repeat(Math.min(doctor.password.length, 10))}
        </span>
        <button
          type="button"
          onClick={() => setShow((v) => !v)}
          aria-label={show ? 'إخفاء الباسورد' : 'إظهار الباسورد'}
          className="rounded-lg p-1.5 text-ink-400 transition hover:bg-ink-100 hover:text-ink-700"
        >
          {show ? <EyeOff size={14} /> : <Eye size={14} />}
        </button>
        <CopyBtn value={doctor.password} label="الباسورد" />
      </div>
    </div>
  )
}

export const RegenIcon = RefreshCw
