import { useRef } from 'react'
import type { ClipboardEvent, KeyboardEvent } from 'react'

/** 6 خانات للكود. بيدعم اللصق، الـ Backspace، وإكمال تلقائي من الرسالة (one-time-code). LTR دايماً. */
export function OtpInput({
  value,
  onChange,
  length = 6,
  invalid = false,
  autoFocus = false,
}: {
  value: string
  onChange: (v: string) => void
  length?: number
  invalid?: boolean
  autoFocus?: boolean
}) {
  const refs = useRef<(HTMLInputElement | null)[]>([])
  const digits = Array.from({ length }, (_, i) => value[i] ?? '')

  const focus = (i: number) => refs.current[Math.max(0, Math.min(length - 1, i))]?.focus()
  const clean = (s: string) =>
    s
      .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
      .replace(/\D/g, '')

  function setAt(i: number, raw: string) {
    const d = clean(raw)
    if (!d) return
    const next = (value.slice(0, i) + d).slice(0, length)
    onChange(next + value.slice(next.length))
    focus(Math.min(next.length, length - 1))
  }

  function onKeyDown(i: number, e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace') {
      e.preventDefault()
      if (digits[i]) onChange(value.slice(0, i) + value.slice(i + 1))
      else if (i > 0) {
        onChange(value.slice(0, i - 1) + value.slice(i))
        focus(i - 1)
      }
    } else if (e.key === 'ArrowLeft') focus(i - 1)
    else if (e.key === 'ArrowRight') focus(i + 1)
  }

  function onPaste(e: ClipboardEvent<HTMLInputElement>) {
    e.preventDefault()
    const d = clean(e.clipboardData.getData('text')).slice(0, length)
    if (!d) return
    onChange(d)
    focus(Math.min(d.length, length - 1))
  }

  return (
    <div dir="ltr" className="flex justify-between gap-2" role="group" aria-label="كود التحقق">
      {digits.map((d, i) => (
        <input
          key={i}
          ref={(el) => {
            refs.current[i] = el
          }}
          value={d}
          onChange={(e) => setAt(i, e.target.value)}
          onKeyDown={(e) => onKeyDown(i, e)}
          onPaste={onPaste}
          onFocus={(e) => e.target.select()}
          inputMode="numeric"
          autoComplete={i === 0 ? 'one-time-code' : 'off'}
          autoFocus={autoFocus && i === 0}
          maxLength={length}
          aria-label={`الخانة ${i + 1}`}
          className={`h-14 w-full min-w-0 rounded-xl border bg-white text-center font-display text-xl font-extrabold text-ink-900 outline-none transition focus:ring-4 ${
            invalid
              ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-100'
              : 'border-ink-200 focus:border-brand-400 focus:ring-brand-100'
          }`}
        />
      ))}
    </div>
  )
}
