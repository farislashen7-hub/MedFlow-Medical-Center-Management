import { Activity } from 'lucide-react'
import { useSettings } from '../lib/db'

export function Logo({ compact = false, light = false }: { compact?: boolean; light?: boolean }) {
  const center = useSettings()
  return (
    <span className="flex items-center gap-2.5">
      <span className="relative flex size-9 items-center justify-center overflow-hidden rounded-xl bg-brand-600 text-white shadow-[0_6px_16px_-8px_rgba(15,130,113,0.9)]">
        {center.logo ? (
          <img src={center.logo} alt={center.name} className="size-full object-cover" />
        ) : (
          <Activity size={19} strokeWidth={2.6} />
        )}
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className={`font-display text-[19px] font-extrabold ${light ? 'text-white' : 'text-ink-900'}`}>
            {center.name}
          </span>
          {center.tagline && (
            <span className={`mt-0.5 text-[9.5px] font-semibold tracking-[0.18em] ${light ? 'text-brand-200' : 'text-brand-600'}`}>
              {center.tagline}
            </span>
          )}
        </span>
      )}
    </span>
  )
}
