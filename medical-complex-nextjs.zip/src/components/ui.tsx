import { AnimatePresence, motion } from 'framer-motion'
import { X } from 'lucide-react'
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from 'react'
import { useEffect } from 'react'
import { initials } from '../lib/format'

/* ---------- Card ---------- */
export function Card({
  children,
  className = '',
  padded = true,
}: {
  children: ReactNode
  className?: string
  padded?: boolean
}) {
  return (
    <div
      className={`rounded-2xl border border-ink-100 bg-white shadow-[0_1px_2px_rgba(16,40,45,0.04),0_8px_24px_-16px_rgba(16,40,45,0.18)] ${
        padded ? 'p-5 sm:p-6' : ''
      } ${className}`}
    >
      {children}
    </div>
  )
}

export function SectionTitle({
  title,
  subtitle,
  action,
  icon,
}: {
  title: string
  subtitle?: string
  action?: ReactNode
  icon?: ReactNode
}) {
  return (
    <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
      <div className="flex items-center gap-3">
        {icon && (
          <span className="flex size-10 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
            {icon}
          </span>
        )}
        <div>
          <h2 className="text-lg font-bold text-ink-900 sm:text-xl">{title}</h2>
          {subtitle && <p className="text-sm text-ink-500">{subtitle}</p>}
        </div>
      </div>
      {action}
    </div>
  )
}

/* ---------- Button ---------- */
type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'dark' | 'whatsapp'
type Size = 'sm' | 'md' | 'lg'

const variants: Record<Variant, string> = {
  primary:
    'bg-brand-600 text-white hover:bg-brand-700 focus-visible:ring-brand-400 shadow-[0_8px_20px_-10px_rgba(15,130,113,0.9)]',
  secondary:
    'bg-white text-ink-700 border border-ink-200 hover:border-brand-300 hover:text-brand-700 focus-visible:ring-brand-200',
  ghost: 'bg-transparent text-ink-600 hover:bg-ink-50 hover:text-ink-900',
  danger: 'bg-rose-600 text-white hover:bg-rose-700 focus-visible:ring-rose-300',
  dark: 'bg-ink-900 text-white hover:bg-ink-800 focus-visible:ring-ink-400',
  whatsapp: 'bg-[#25D366] text-ink-950 hover:bg-[#1eb958] focus-visible:ring-[#25D366]',
}

const sizes: Record<Size, string> = {
  sm: 'h-9 px-3.5 text-[13px] gap-1.5 rounded-lg',
  md: 'h-11 px-5 text-sm gap-2 rounded-xl',
  lg: 'h-13 px-7 text-base gap-2.5 rounded-xl',
}

export function Button({
  variant = 'primary',
  size = 'md',
  className = '',
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: Size }) {
  return (
    <button
      className={`inline-flex items-center justify-center font-semibold transition-all duration-150 focus:outline-none focus-visible:ring-4 disabled:cursor-not-allowed disabled:opacity-55 ${variants[variant]} ${sizes[size]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  )
}

/* ---------- Badge ---------- */
const badgeTones: Record<string, string> = {
  brand: 'bg-brand-50 text-brand-700 ring-brand-200',
  green: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  amber: 'bg-amber-50 text-amber-700 ring-amber-200',
  rose: 'bg-rose-50 text-rose-700 ring-rose-200',
  sky: 'bg-sky-50 text-sky-700 ring-sky-200',
  violet: 'bg-violet-50 text-violet-700 ring-violet-200',
  slate: 'bg-ink-50 text-ink-600 ring-ink-200',
  dark: 'bg-ink-900 text-white ring-ink-900',
}

export function Badge({
  children,
  tone = 'slate',
  className = '',
}: {
  children: ReactNode
  tone?: keyof typeof badgeTones
  className?: string
}) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11.5px] font-semibold ring-1 ring-inset ${badgeTones[tone]} ${className}`}
    >
      {children}
    </span>
  )
}

/* ---------- Form fields ---------- */
const fieldBase =
  'w-full rounded-xl border border-ink-200 bg-white px-4 py-3 text-sm text-ink-800 outline-none transition placeholder:text-ink-300 focus:border-brand-400 focus:ring-4 focus:ring-brand-100'

export function Field({
  label,
  hint,
  error,
  required,
  children,
  className = '',
}: {
  label?: string
  hint?: string
  error?: string
  required?: boolean
  children: ReactNode
  className?: string
}) {
  return (
    <label className={`block ${className}`}>
      {label && (
        <span className="mb-1.5 flex items-center gap-1 text-[13px] font-semibold text-ink-700">
          {label}
          {required && <span className="text-rose-500">*</span>}
        </span>
      )}
      {children}
      {error ? (
        <span className="mt-1.5 block text-xs font-medium text-rose-600">{error}</span>
      ) : hint ? (
        <span className="mt-1.5 block text-xs text-ink-400">{hint}</span>
      ) : null}
    </label>
  )
}

export function Input({ className = '', ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={`${fieldBase} ${className}`} {...rest} />
}

export function Textarea({ className = '', ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={`${fieldBase} min-h-24 resize-y ${className}`} {...rest} />
}

export function Select({ className = '', children, ...rest }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select className={`${fieldBase} appearance-none bg-[length:0] ${className}`} {...rest}>
      {children}
    </select>
  )
}

/* ---------- Modal ---------- */
export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  size = 'md',
  footer,
}: {
  open: boolean
  onClose: () => void
  title: string
  subtitle?: string
  children: ReactNode
  size?: 'sm' | 'md' | 'lg' | 'xl'
  footer?: ReactNode
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    if (open) {
      document.addEventListener('keydown', onKey)
      document.body.style.overflow = 'hidden'
    }
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [open, onClose])

  const widths = { sm: 'max-w-md', md: 'max-w-2xl', lg: 'max-w-4xl', xl: 'max-w-6xl' }

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-ink-950/55 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 320, damping: 30 }}
            className={`relative z-10 flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl sm:rounded-3xl ${widths[size]}`}
          >
            <div className="flex items-start justify-between gap-4 border-b border-ink-100 px-5 py-4 sm:px-6">
              <div>
                <h3 className="text-lg font-bold text-ink-900">{title}</h3>
                {subtitle && <p className="mt-0.5 text-sm text-ink-500">{subtitle}</p>}
              </div>
              <button
                onClick={onClose}
                aria-label="إغلاق"
                className="rounded-xl p-2 text-ink-400 transition hover:bg-ink-50 hover:text-ink-700"
              >
                <X size={18} />
              </button>
            </div>
            <div className="scrollbar-thin flex-1 overflow-y-auto px-5 py-5 sm:px-6">{children}</div>
            {footer && (
              <div className="flex flex-wrap items-center justify-end gap-2 border-t border-ink-100 bg-ink-50/60 px-5 py-4 sm:px-6">
                {footer}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  )
}

/* ---------- Tabs ---------- */
export function Tabs({
  items,
  active,
  onChange,
  className = '',
}: {
  items: { id: string; label: string; icon?: ReactNode; count?: number }[]
  active: string
  onChange: (id: string) => void
  className?: string
}) {
  return (
    <div className={`scrollbar-thin flex gap-1 overflow-x-auto rounded-2xl border border-ink-100 bg-white p-1.5 ${className}`}>
      {items.map((item) => (
        <button
          key={item.id}
          onClick={() => onChange(item.id)}
          className={`flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2.5 text-[13px] font-semibold transition ${
            active === item.id
              ? 'bg-ink-900 text-white shadow-sm'
              : 'text-ink-500 hover:bg-ink-50 hover:text-ink-800'
          }`}
        >
          {item.icon}
          {item.label}
          {item.count !== undefined && (
            <span
              className={`rounded-md px-1.5 py-0.5 text-[10.5px] font-bold ${
                active === item.id ? 'bg-white/20 text-white' : 'bg-ink-100 text-ink-600'
              }`}
            >
              {item.count}
            </span>
          )}
        </button>
      ))}
    </div>
  )
}

/* ---------- Stat card ---------- */
export function StatCard({
  label,
  value,
  hint,
  icon,
  tone = 'brand',
  trend,
}: {
  label: string
  value: string | number
  hint?: string
  icon?: ReactNode
  tone?: 'brand' | 'amber' | 'rose' | 'violet' | 'sky' | 'green'
  trend?: { value: string; up: boolean }
}) {
  const tones = {
    brand: 'bg-brand-50 text-brand-700',
    amber: 'bg-amber-50 text-amber-600',
    rose: 'bg-rose-50 text-rose-600',
    violet: 'bg-violet-50 text-violet-600',
    sky: 'bg-sky-50 text-sky-600',
    green: 'bg-emerald-50 text-emerald-600',
  }
  return (
    <Card className="flex items-start gap-4">
      {icon && (
        <span className={`flex size-11 shrink-0 items-center justify-center rounded-xl ${tones[tone]}`}>
          {icon}
        </span>
      )}
      <div className="min-w-0 flex-1">
        <p className="text-[12.5px] font-medium text-ink-500">{label}</p>
        <div className="mt-1 flex items-baseline gap-2">
          <p className="font-display text-2xl font-extrabold text-ink-900">{value}</p>
          {trend && (
            <span
              className={`text-[11.5px] font-bold ${trend.up ? 'text-emerald-600' : 'text-rose-600'}`}
            >
              {trend.up ? '▲' : '▼'} {trend.value}
            </span>
          )}
        </div>
        {hint && <p className="mt-0.5 truncate text-[11.5px] text-ink-400">{hint}</p>}
      </div>
    </Card>
  )
}

/* ---------- Avatar ---------- */
export function Avatar({
  name,
  image,
  size = 44,
  className = '',
}: {
  name: string
  image?: string
  size?: number
  className?: string
}) {
  if (image) {
    return (
      <img
        src={image}
        alt={name}
        style={{ width: size, height: size }}
        className={`shrink-0 rounded-2xl object-cover object-top ${className}`}
      />
    )
  }
  return (
    <span
      style={{ width: size, height: size, fontSize: size * 0.34 }}
      className={`flex shrink-0 items-center justify-center rounded-2xl bg-brand-100 font-bold text-brand-700 ${className}`}
    >
      {initials(name)}
    </span>
  )
}

/* ---------- Empty state ---------- */
export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: ReactNode
  title: string
  description?: string
  action?: ReactNode
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-ink-200 bg-ink-50/50 px-6 py-12 text-center">
      <span className="flex size-14 items-center justify-center rounded-2xl bg-white text-ink-400 shadow-sm">
        {icon}
      </span>
      <h3 className="text-base font-bold text-ink-800">{title}</h3>
      {description && <p className="max-w-sm text-sm text-ink-500">{description}</p>}
      {action}
    </div>
  )
}

/* ---------- Progress ---------- */
export function Progress({ value, tone = 'brand' }: { value: number; tone?: 'brand' | 'rose' | 'amber' }) {
  const colors = { brand: 'bg-brand-500', rose: 'bg-rose-500', amber: 'bg-amber-500' }
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-ink-100">
      <div
        className={`h-full rounded-full transition-all duration-500 ${colors[tone]}`}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  )
}

/* ---------- Info row ---------- */
export function InfoRow({
  label,
  value,
  icon,
}: {
  label: string
  value: ReactNode
  icon?: ReactNode
}) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-ink-50 py-2.5 last:border-0">
      <span className="flex shrink-0 items-center gap-1.5 text-[12.5px] font-medium text-ink-500">
        {icon}
        {label}
      </span>
      <span className="text-left text-[13px] font-semibold text-ink-800">{value}</span>
    </div>
  )
}
