import { useMemo, useState } from 'react'
import {
  AlertTriangle,
  CalendarCheck,
  CalendarX,
  Clock,
  Download,
  Lightbulb,
  RotateCcw,
  Stethoscope,
  TrendingDown,
  TrendingUp,
  UserCheck,
  UserX,
} from 'lucide-react'
import { useDB, clearAttendanceRecord, setAttendanceRecord } from '../lib/db'
import { useToast } from './Toast'
import { Avatar, Badge, Button, Card, EmptyState, Modal, Progress, SectionTitle, Select, StatCard } from './ui'
import { BarChart, DonutChart, LineChart } from './charts'
import { addDays, AR_DAYS, AR_DAYS_SHORT, downloadCsv, formatFullDate, toDateKey } from '../lib/format'
import { isDoctorOffNow } from '../lib/slots'
import {
  gradeOf,
  statusLabel,
  statusTone,
  summarize,
  todayRow,
  weeklyTrend,
} from '../lib/attendance'
import type { AttendanceData, AttendanceSummary, DayStatus } from '../lib/attendance'
import type { AttendanceStatus, Doctor } from '../lib/types'

const RANGES = [
  { days: 7, label: 'آخر 7 أيام' },
  { days: 30, label: 'آخر 30 يوم' },
  { days: 90, label: 'آخر 90 يوم' },
]

const toneBar = (rate: number | null): 'brand' | 'rose' | 'amber' =>
  rate === null || rate >= 85 ? 'brand' : rate >= 70 ? 'amber' : 'rose'

export function hourLabel(h: number) {
  const period = h >= 12 && h < 24 ? 'م' : 'ص'
  const h12 = h % 12 === 0 ? 12 : h % 12
  return `${h12}:00 ${period}`
}

/* =========================================================================
 *  الحضور والغياب + الظروف — تحليل للمالك
 * ========================================================================= */
export function AttendanceHub() {
  const db = useDB()
  const { push } = useToast()
  const [days, setDays] = useState(30)
  const [openId, setOpenId] = useState<string | null>(null)

  const doctors = useMemo(() => db.doctors.filter((d) => d.active), [db.doctors])
  const data: AttendanceData = useMemo(
    () => ({ records: db.attendance, leaves: db.leaves, appointments: db.appointments }),
    [db.attendance, db.leaves, db.appointments],
  )

  const now = new Date()
  const today = toDateKey(now)
  const from = toDateKey(addDays(now, -(days - 1)))

  const summaries = useMemo(
    () => doctors.map((d) => ({ doctor: d, s: summarize(d, data, from, today) })),
    [doctors, data, from, today],
  )

  const totals = useMemo(() => {
    const t = { present: 0, late: 0, absent: 0, leave: 0, leaveEvents: 0 }
    summaries.forEach(({ s }) => {
      t.present += s.present
      t.late += s.late
      t.absent += s.absent
      t.leave += s.leave
      t.leaveEvents += s.leaveEvents
    })
    const worked = t.present + t.late
    return { ...t, worked, rate: worked + t.absent ? Math.round((worked / (worked + t.absent)) * 100) : null }
  }, [summaries])

  const trend = useMemo(
    () => weeklyTrend(doctors, data, 8),
    [doctors, data, today],
  )

  const weekdayAbsence = useMemo(() => {
    const arr = [0, 0, 0, 0, 0, 0, 0]
    summaries.forEach(({ s }) => s.absentByWeekday.forEach((n, i) => (arr[i] += n)))
    return arr
  }, [summaries])

  const reasons = useMemo(() => {
    const m: Record<string, number> = {}
    summaries.forEach(({ s }) => Object.entries(s.leaveReasons).forEach(([r, n]) => (m[r] = (m[r] ?? 0) + n)))
    return Object.entries(m).sort((a, b) => b[1] - a[1])
  }, [summaries])

  /* ---------- تحليل نصي للمالك ---------- */
  const insights = useMemo(() => {
    const out: { tone: 'green' | 'rose' | 'amber' | 'sky'; text: string }[] = []
    const withData = summaries.filter(({ s }) => s.present + s.late + s.absent >= 3)
    if (totals.rate !== null) {
      out.push({
        tone: totals.rate >= 90 ? 'green' : totals.rate >= 75 ? 'amber' : 'rose',
        text: `نسبة الحضور الإجمالية ${totals.rate}% خلال آخر ${days} يوم: ${totals.worked} يوم حضور مقابل ${totals.absent} يوم غياب، و${totals.leave} يوم ظرف/إجازة معلن (مش محسوب غياب).`,
      })
    }
    const best = [...withData].sort((a, b) => (b.s.rate ?? 0) - (a.s.rate ?? 0) || b.s.present - a.s.present)[0]
    if (best && best.s.rate !== null) {
      out.push({ tone: 'green', text: `أكتر الأطباء التزاماً: ${best.doctor.name} بنسبة حضور ${best.s.rate}% والتزام بالميعاد ${best.s.punctuality ?? 0}%.` })
    }
    const worst = [...summaries].sort((a, b) => b.s.absent - a.s.absent)[0]
    if (worst && worst.s.absent > 0) {
      out.push({
        tone: 'rose',
        text: `أكتر طبيب غياب: ${worst.doctor.name} — ${worst.s.absent} يوم غياب${
          worst.s.longestAbsentStreak > 1 ? `، وأطول غياب متتالي ${worst.s.longestAbsentStreak} أيام` : ''
        }${worst.s.lastAbsence ? `، آخر غياب ${formatFullDate(worst.s.lastAbsence)}` : ''}. يحتاج متابعة.`,
      })
    }
    const mostLeave = [...summaries].sort((a, b) => b.s.leaveEvents - a.s.leaveEvents || b.s.leave - a.s.leave)[0]
    if (mostLeave && mostLeave.s.leaveEvents > 0) {
      out.push({
        tone: mostLeave.s.leaveEvents >= 3 ? 'amber' : 'sky',
        text: `أكتر طبيب أعلن «عندي ظرف»: ${mostLeave.doctor.name} — ${mostLeave.s.leaveEvents} ${mostLeave.s.leaveEvents > 2 ? 'مرات' : 'مرة'} (${mostLeave.s.leave} يوم).${
          mostLeave.s.leaveEvents >= 3 ? ' التكرار ده يستاهل مراجعة جدول دوامه.' : ''
        }`,
      })
    }
    if (reasons[0]) {
      out.push({ tone: 'sky', text: `أشهر سبب للظروف: «${reasons[0][0]}» (${reasons[0][1]} ${reasons[0][1] > 2 ? 'مرات' : 'مرة'} من ${totals.leaveEvents}).` })
    }
    const maxAbs = Math.max(...weekdayAbsence)
    if (maxAbs > 0) {
      out.push({ tone: 'amber', text: `أكتر يوم فيه غياب: ${AR_DAYS[weekdayAbsence.indexOf(maxAbs)]} (${maxAbs} حالة غياب).` })
    }
    if (trend.length >= 2) {
      const last = trend[trend.length - 1].value
      const prev = trend[trend.length - 2].value
      if (last !== prev && (last || prev)) {
        out.push({
          tone: last > prev ? 'green' : 'rose',
          text: `الحضور ${last > prev ? 'تحسّن' : 'نزل'} ${Math.abs(last - prev)} نقطة عن الأسبوع اللي فات (${prev}% ← ${last}%).`,
        })
      }
    }
    const low = withData.filter(({ s }) => s.rate !== null && s.rate < 85).map(({ doctor }) => doctor.name)
    if (low.length) out.push({ tone: 'rose', text: `أطباء نسبة حضورهم أقل من 85%: ${low.join('، ')}.` })
    return out
  }, [summaries, totals, days, reasons, weekdayAbsence, trend])

  const openDoctor = doctors.find((d) => d.id === openId) ?? null

  function exportCsv() {
    downloadCsv(`doctors-attendance-${from}_${today}.csv`, [
      ['الطبيب', 'حضر', 'متأخر', 'غائب', 'ظرف (أيام)', 'ظرف (مرات)', 'نسبة الحضور %', 'الالتزام بالميعاد %', 'متوسط وقت الحضور', 'أطول غياب متتالي'],
      ...summaries.map(({ doctor, s }) => [
        doctor.name,
        s.present,
        s.late,
        s.absent,
        s.leave,
        s.leaveEvents,
        s.rate ?? '',
        s.punctuality ?? '',
        s.avgCheckIn ?? '',
        s.longestAbsentStreak,
      ]),
    ])
    push('تم تصدير تقرير الحضور والغياب')
  }

  if (doctors.length === 0) {
    return (
      <div className="mt-5">
        <EmptyState icon={<Stethoscope size={24} />} title="لا يوجد أطباء نشطون" description="أضف أطباء من تبويب «الأطباء» ليظهر تحليل الحضور هنا." />
      </div>
    )
  }

  return (
    <div className="mt-5 space-y-5">
      {/* header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-1.5 rounded-2xl border border-ink-100 bg-white p-1.5">
          {RANGES.map((r) => (
            <button
              key={r.days}
              onClick={() => setDays(r.days)}
              className={`rounded-xl px-3.5 py-2 text-[12.5px] font-bold transition ${
                days === r.days ? 'bg-ink-900 text-white' : 'text-ink-500 hover:bg-ink-50'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
        <Button variant="secondary" size="sm" onClick={exportCsv}>
          <Download size={15} />
          تصدير التقرير
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="أيام الحضور" value={totals.worked} icon={<UserCheck size={20} />} tone="green" hint={`منها ${totals.late} يوم تأخير`} />
        <StatCard label="أيام الغياب" value={totals.absent} icon={<UserX size={20} />} tone="rose" hint="غياب من غير إخطار" />
        <StatCard
          label="«عندي ظرف»"
          value={`${totals.leaveEvents} ${totals.leaveEvents > 2 ? 'مرات' : 'مرة'}`}
          icon={<CalendarX size={20} />}
          tone="amber"
          hint={`${totals.leave} يوم ظرف/إجازة`}
        />
        <StatCard
          label="نسبة الحضور الإجمالية"
          value={totals.rate === null ? '—' : `${totals.rate}%`}
          icon={<CalendarCheck size={20} />}
          tone="brand"
          hint={gradeOf(totals.rate).label}
        />
      </div>

      {/* owner insights */}
      <Card>
        <SectionTitle
          title="تحليل للمالك"
          subtitle={`ملخص تلقائي من بيانات آخر ${days} يوم`}
          icon={<Lightbulb size={18} />}
        />
        {insights.length === 0 ? (
          <p className="text-[13px] text-ink-500">لسه مفيش بيانات كفاية للتحليل — هتظهر الملاحظات بعد ما الأطباء يسجلوا حضورهم.</p>
        ) : (
          <ul className="space-y-2.5">
            {insights.map((i, idx) => (
              <li key={idx} className="flex items-start gap-3 rounded-xl bg-ink-50/70 px-4 py-3 text-[13px] leading-7 text-ink-700">
                <span
                  className={`mt-2 size-2 shrink-0 rounded-full ${
                    { green: 'bg-emerald-500', rose: 'bg-rose-500', amber: 'bg-amber-500', sky: 'bg-sky-500' }[i.tone]
                  }`}
                />
                {i.text}
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* charts */}
      <div className="grid gap-5 lg:grid-cols-3">
        <Card>
          <SectionTitle title="اتجاه الحضور" subtitle="نسبة الحضور الأسبوعية (آخر 8 أسابيع)" icon={<TrendingUp size={18} />} />
          <LineChart data={trend} suffix="%" height={200} />
        </Card>
        <Card>
          <SectionTitle title="توزيع الأيام" subtitle="كل أيام الدوام المحسوبة" icon={<UserCheck size={18} />} />
          <DonutChart
            size={140}
            centerValue={totals.rate === null ? '—' : `${totals.rate}%`}
            centerLabel="حضور"
            segments={[
              { label: 'حضر في الميعاد', value: totals.present, color: '#10b981' },
              { label: 'متأخر', value: totals.late, color: '#f59e0b' },
              { label: 'غائب', value: totals.absent, color: '#f43f5e' },
              { label: 'ظرف / إجازة', value: totals.leave, color: '#38bdf8' },
            ]}
          />
        </Card>
        <Card>
          <SectionTitle title="الغياب حسب اليوم" subtitle="أكتر أيام الأسبوع غياباً" icon={<TrendingDown size={18} />} />
          <BarChart data={AR_DAYS_SHORT.map((l, i) => ({ label: l, value: weekdayAbsence[i] }))} color="#f43f5e" height={190} />
        </Card>
      </div>

      {/* today board */}
      <Card>
        <SectionTitle title="حالة النهارده" subtitle={formatFullDate(today)} icon={<Clock size={18} />} />
        <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {doctors.map((d) => {
            const row = todayRow(d, data)
            const off = isDoctorOffNow(d)
            const status: DayStatus | 'off-day' = row ? row.status : 'off-day'
            return (
              <div key={d.id} className="flex items-center gap-3 rounded-xl border border-ink-100 px-3.5 py-3">
                <Avatar name={d.name} image={d.image} size={38} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-bold text-ink-900">{d.name}</p>
                  <p className="text-[11px] text-ink-400">
                    {row?.checkIn ? `حضر ${row.checkIn}${row.checkOut ? ` • انصرف ${row.checkOut}` : ''}` : off ? d.unavailable?.reason : 'دوامه ' + hourLabel(d.startHour)}
                  </p>
                </div>
                {status === 'off-day' ? <Badge tone="slate">مش يوم دوامه</Badge> : <Badge tone={statusTone[status]}>{statusLabel[status]}</Badge>}
              </div>
            )
          })}
        </div>
      </Card>

      {/* per doctor table */}
      <Card className="!p-0 overflow-hidden">
        <div className="px-5 pt-5 sm:px-6 sm:pt-6">
          <SectionTitle title="الحضور لكل طبيب" subtitle="اضغط «التفاصيل» لعرض السجل اليومي وتعديل أي يوم" icon={<UserCheck size={18} />} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[920px] text-right">
            <thead className="bg-ink-50 text-[11.5px] font-bold text-ink-500">
              <tr>
                <th className="px-5 py-3">الطبيب</th>
                <th className="px-3 py-3">حضر</th>
                <th className="px-3 py-3">متأخر</th>
                <th className="px-3 py-3">غائب</th>
                <th className="px-3 py-3">ظرف (مرات / أيام)</th>
                <th className="w-44 px-3 py-3">نسبة الحضور</th>
                <th className="px-3 py-3">الالتزام بالميعاد</th>
                <th className="px-3 py-3">التقييم</th>
                <th className="px-5 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-50 text-[12.5px]">
              {[...summaries]
                .sort((a, b) => (a.s.rate ?? 101) - (b.s.rate ?? 101))
                .map(({ doctor, s }) => {
                  const grade = gradeOf(s.rate)
                  return (
                    <tr key={doctor.id} className="transition hover:bg-ink-50/50">
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <Avatar name={doctor.name} image={doctor.image} size={36} />
                          <div>
                            <p className="font-bold text-ink-900">{doctor.name}</p>
                            <p className="text-[11px] text-ink-400">{db.specialties.find((x) => x.id === doctor.specialtyId)?.name}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-3.5 font-bold text-emerald-700">{s.present}</td>
                      <td className="px-3 py-3.5 font-bold text-amber-600">{s.late}</td>
                      <td className="px-3 py-3.5 font-bold text-rose-600">{s.absent}</td>
                      <td className="px-3 py-3.5 text-ink-700">
                        <span className="font-bold">{s.leaveEvents}</span> <span className="text-ink-400">/</span> {s.leave}
                      </td>
                      <td className="px-3 py-3.5">
                        <div className="flex items-center gap-2">
                          <div className="flex-1">
                            <Progress value={s.rate ?? 0} tone={toneBar(s.rate)} />
                          </div>
                          <span className="w-10 text-left font-bold text-ink-800">{s.rate === null ? '—' : `${s.rate}%`}</span>
                        </div>
                      </td>
                      <td className="px-3 py-3.5 text-ink-700">{s.punctuality === null ? '—' : `${s.punctuality}%`}</td>
                      <td className="px-3 py-3.5">
                        <Badge tone={grade.tone}>{grade.label}</Badge>
                      </td>
                      <td className="px-5 py-3.5">
                        <Button size="sm" variant="secondary" onClick={() => setOpenId(doctor.id)}>
                          التفاصيل
                        </Button>
                      </td>
                    </tr>
                  )
                })}
            </tbody>
          </table>
        </div>
        <p className="border-t border-ink-50 px-5 py-3 text-[11.5px] leading-6 text-ink-400 sm:px-6">
          طريقة الحساب: نسبة الحضور = (حضر + متأخر) ÷ (حضر + متأخر + غائب). أيام الظرف المعلنة مش بتتحسب غياب. يوم دوام فات من غير تسجيل ولا ظرف
          ولا كشف مكتمل = غياب. «متأخر» = أكتر من 15 دقيقة بعد بداية الدوام.
        </p>
      </Card>

      <DoctorAttendanceModal
        doctor={openDoctor}
        data={data}
        from={from}
        to={today}
        days={days}
        onClose={() => setOpenId(null)}
        onChanged={(m) => push(m)}
      />
    </div>
  )
}

/* ---------------- تفاصيل طبيب + تعديل يدوي ---------------- */
function DoctorAttendanceModal({
  doctor,
  data,
  from,
  to,
  days,
  onClose,
  onChanged,
}: {
  doctor: Doctor | null
  data: AttendanceData
  from: string
  to: string
  days: number
  onClose: () => void
  onChanged: (message: string) => void
}) {
  const s: AttendanceSummary | null = useMemo(
    () => (doctor ? summarize(doctor, data, from, to) : null),
    [doctor, data, from, to],
  )
  const leaves = useMemo(
    () => (doctor ? data.leaves.filter((l) => l.doctorId === doctor.id).sort((a, b) => (a.since < b.since ? 1 : -1)) : []),
    [doctor, data.leaves],
  )

  return (
    <Modal
      open={!!doctor}
      onClose={onClose}
      title={doctor ? `حضور ${doctor.name}` : ''}
      subtitle={`آخر ${days} يوم — ${formatFullDate(from)} إلى ${formatFullDate(to)}`}
      size="lg"
    >
      {doctor && s && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
            {[
              { l: 'حضر', v: s.present, c: 'text-emerald-700' },
              { l: 'متأخر', v: s.late, c: 'text-amber-600' },
              { l: 'غائب', v: s.absent, c: 'text-rose-600' },
              { l: 'ظرف (يوم)', v: s.leave, c: 'text-sky-600' },
              { l: 'ظرف (مرة)', v: s.leaveEvents, c: 'text-sky-700' },
            ].map((k) => (
              <div key={k.l} className="rounded-xl bg-ink-50 px-3 py-3 text-center">
                <p className={`font-display text-xl font-extrabold ${k.c}`}>{k.v}</p>
                <p className="text-[11px] text-ink-500">{k.l}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-2 text-[12px]">
            {s.avgCheckIn && <Badge tone="slate">متوسط وقت الحضور {s.avgCheckIn}</Badge>}
            {s.longestAbsentStreak > 0 && (
              <Badge tone="rose">
                <AlertTriangle size={11} />
                أطول غياب متتالي {s.longestAbsentStreak} أيام
              </Badge>
            )}
            {Object.entries(s.leaveReasons).map(([r, n]) => (
              <Badge key={r} tone="sky">
                {r} × {n}
              </Badge>
            ))}
          </div>

          {leaves.length > 0 && (
            <div>
              <h4 className="mb-2 text-[13px] font-bold text-ink-800">سجل «عندي ظرف»</h4>
              <ul className="space-y-1.5">
                {leaves.slice(0, 8).map((l) => (
                  <li key={l.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-sky-50/70 px-3.5 py-2.5 text-[12.5px]">
                    <span className="font-bold text-sky-900">
                      {l.reason}
                      {l.note ? <span className="font-normal text-ink-500"> — {l.note}</span> : null}
                    </span>
                    <span className="text-ink-500">
                      {formatFullDate(l.since)}
                      {l.until ? ` ← ${formatFullDate(l.until)}` : l.endedAt ? '' : ' ← مفتوح'}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div>
            <h4 className="mb-2 text-[13px] font-bold text-ink-800">السجل اليومي</h4>
            {s.rows.length === 0 ? (
              <p className="text-[12.5px] text-ink-500">مفيش أيام دوام محسوبة في الفترة دي.</p>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-ink-100">
                <table className="w-full min-w-[560px] text-right text-[12.5px]">
                  <thead className="bg-ink-50 text-[11.5px] font-bold text-ink-500">
                    <tr>
                      <th className="px-4 py-2.5">اليوم</th>
                      <th className="px-3 py-2.5">الحالة</th>
                      <th className="px-3 py-2.5">حضور</th>
                      <th className="px-3 py-2.5">انصراف</th>
                      <th className="px-3 py-2.5">تعديل</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-50">
                    {[...s.rows].reverse().slice(0, 60).map((r) => (
                      <tr key={r.date}>
                        <td className="px-4 py-2.5 font-semibold text-ink-800">{formatFullDate(r.date)}</td>
                        <td className="px-3 py-2.5">
                          <Badge tone={statusTone[r.status]}>{statusLabel[r.status]}</Badge>
                          {r.derived && r.status !== 'pending' && <span className="mr-1.5 text-[10.5px] text-ink-400">تلقائي</span>}
                          {r.note && <span className="mr-1.5 text-[10.5px] text-ink-400">{r.note}</span>}
                        </td>
                        <td className="px-3 py-2.5 text-ink-600" dir="ltr">{r.checkIn || '—'}</td>
                        <td className="px-3 py-2.5 text-ink-600" dir="ltr">{r.checkOut || '—'}</td>
                        <td className="px-3 py-2.5">
                          <div className="flex items-center gap-1.5">
                            <Select
                              value=""
                              aria-label="تعديل الحالة"
                              className="!w-auto !rounded-lg !px-2.5 !py-1.5 !text-[12px]"
                              onChange={(e) => {
                                const v = e.target.value as AttendanceStatus
                                if (!v) return
                                setAttendanceRecord(doctor.id, r.date, { status: v })
                                onChanged(`تم تعديل ${formatFullDate(r.date)} إلى «${statusLabel[v]}»`)
                              }}
                            >
                              <option value="">تغيير...</option>
                              <option value="present">حضر</option>
                              <option value="late">متأخر</option>
                              <option value="absent">غائب</option>
                              <option value="leave">ظرف / إجازة</option>
                            </Select>
                            {!r.derived && (
                              <button
                                title="رجّع الحساب التلقائي"
                                onClick={() => {
                                  clearAttendanceRecord(doctor.id, r.date)
                                  onChanged('رجع اليوم للحساب التلقائي')
                                }}
                                className="rounded-lg p-1.5 text-ink-400 transition hover:bg-ink-100 hover:text-ink-700"
                              >
                                <RotateCcw size={14} />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}
    </Modal>
  )
}

/* =========================================================================
 *  جداول دوام الأطباء — قسم مستقل في لوحة الإدارة
 *  الطبيب بيحددها من «إدارة المواعيد» وبتتحفظ في Supabase (doctor_schedules) وبتظهر هنا لحظياً.
 * ========================================================================= */
export function DoctorSchedulesBoard() {
  const db = useDB()
  const todayIdx = new Date().getDay()

  return (
    <div className="mt-5 space-y-5">
      <Card className="!p-0 overflow-hidden">
        <div className="px-5 pt-5 sm:px-6 sm:pt-6">
          <SectionTitle
            title="جداول دوام الأطباء"
            subtitle="الأيام والساعات اللي حددها كل طبيب — بتتحدّث لحظياً أول ما الطبيب يحفظ"
            icon={<CalendarCheck size={18} />}
          />
        </div>
        {db.doctors.length === 0 ? (
          <div className="p-6">
            <EmptyState icon={<Stethoscope size={24} />} title="لا يوجد أطباء" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-right">
              <thead className="bg-ink-50 text-[11.5px] font-bold text-ink-500">
                <tr>
                  <th className="px-5 py-3">الطبيب</th>
                  {AR_DAYS.map((d, i) => (
                    <th key={d} className={`px-2 py-3 text-center ${i === todayIdx ? 'bg-brand-50 text-brand-700' : ''}`}>
                      {d}
                      {i === todayIdx && <span className="block text-[10px] font-semibold">النهارده</span>}
                    </th>
                  ))}
                  <th className="px-4 py-3">ساعات الأسبوع</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-50 text-[12px]">
                {db.doctors.map((d) => {
                  const hours = d.endHour - d.startHour
                  return (
                    <tr key={d.id} className={`transition hover:bg-ink-50/50 ${d.active ? '' : 'opacity-55'}`}>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <Avatar name={d.name} image={d.image} size={36} />
                          <div>
                            <p className="font-bold text-ink-900">{d.name}</p>
                            <div className="mt-0.5 flex flex-wrap gap-1">
                              {!d.active && <Badge tone="rose">موقوف</Badge>}
                              {isDoctorOffNow(d) && <Badge tone="amber">غير متاح: {d.unavailable?.reason}</Badge>}
                            </div>
                          </div>
                        </div>
                      </td>
                      {AR_DAYS.map((day, i) => {
                        const works = d.days.includes(i)
                        return (
                          <td key={day} className={`px-2 py-3.5 text-center ${i === todayIdx ? 'bg-brand-50/40' : ''}`}>
                            {works ? (
                              <span className="inline-block rounded-lg bg-brand-50 px-2 py-1 text-[11px] font-bold leading-5 text-brand-700">
                                {hourLabel(d.startHour)}
                                <br />
                                {hourLabel(d.endHour)}
                              </span>
                            ) : (
                              <span className="text-ink-300">—</span>
                            )}
                          </td>
                        )
                      })}
                      <td className="px-4 py-3.5 font-bold text-ink-800">
                        {hours * d.days.length} ساعة
                        <span className="block text-[11px] font-normal text-ink-400">
                          {d.days.length} أيام × {hours} ساعات
                        </span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  )
}
