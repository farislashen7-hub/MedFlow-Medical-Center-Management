import { useState } from 'react'
import type { ChangeEvent, ReactNode } from 'react'
import {
  Building2,
  Clock,
  Globe,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  Receipt,
  UserCog,
  RotateCcw,
  Save,
  Upload,
  X,
} from 'lucide-react'
import { updateSettings, useSettings } from '../lib/db'
import { fileToDataUrl } from '../lib/image'
import { useToast } from './Toast'
import { Button, Card, Field, Input, SectionTitle, Textarea } from './ui'
import type { CenterSettings } from '../lib/types'

type Errors = Partial<Record<keyof CenterSettings, string>>

const phoneOk = (v: string) => !v || /^\+?[\d\s-]{8,16}$/.test(v)
const urlOk = (v: string) => !v || /^https?:\/\/\S+\.\S+/.test(v)

function validate(f: CenterSettings): Errors {
  const e: Errors = {}
  if (!f.name.trim()) e.name = 'اسم المركز مطلوب'
  if (!phoneOk(f.phone)) e.phone = 'رقم هاتف غير صحيح'
  if (!phoneOk(f.whatsapp)) e.whatsapp = 'رقم واتساب غير صحيح'
  if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) e.email = 'بريد إلكتروني غير صحيح'
  if (f.managerEmail && !/^\S+@\S+\.\S+$/.test(f.managerEmail)) e.managerEmail = 'بريد إلكتروني غير صحيح'
  if (!phoneOk(f.managerPhone)) e.managerPhone = 'رقم هاتف غير صحيح'
  if (!urlOk(f.website)) e.website = 'الرابط يجب أن يبدأ بـ https://'
  if (!urlOk(f.mapUrl)) e.mapUrl = 'الرابط يجب أن يبدأ بـ https://'
  if (!urlOk(f.instagram)) e.instagram = 'الرابط يجب أن يبدأ بـ https://'
  if (!urlOk(f.facebook)) e.facebook = 'الرابط يجب أن يبدأ بـ https://'
  if (!urlOk(f.x)) e.x = 'الرابط يجب أن يبدأ بـ https://'
  if (!/^\d{1,4}$/.test(f.countryCode.trim())) e.countryCode = 'رمز الدولة أرقام فقط، مثل 966 أو 20'
  if (!f.currency.trim()) e.currency = 'رمز العملة مطلوب'
  return e
}

function Section({ icon, title, subtitle, children }: { icon: ReactNode; title: string; subtitle: string; children: ReactNode }) {
  return (
    <Card>
      <SectionTitle title={title} subtitle={subtitle} icon={icon} />
      <div className="mt-4 grid gap-4 sm:grid-cols-2">{children}</div>
    </Card>
  )
}

export function CenterSettingsForm() {
  const saved = useSettings()
  const { push } = useToast()
  const [form, setForm] = useState<CenterSettings>(saved)
  const [errors, setErrors] = useState<Errors>({})

  const dirty = JSON.stringify(form) !== JSON.stringify(saved)
  const set = <K extends keyof CenterSettings>(key: K, value: CenterSettings[K]) => {
    setForm((f) => ({ ...f, [key]: value }))
    if (errors[key]) setErrors((e) => ({ ...e, [key]: undefined }))
  }

  async function onLogo(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (!file.type.startsWith('image/')) {
      push('اختر ملف صورة فقط', 'error')
      return
    }
    try {
      const url = await fileToDataUrl(file, 256)
      if (url.length > 400_000) {
        push('الصورة كبيرة، جرّب صورة أصغر', 'error')
        return
      }
      set('logo', url)
    } catch (err) {
      push(err instanceof Error ? err.message : 'تعذر معالجة الصورة', 'error')
    }
  }

  function save() {
    const trimmed = Object.fromEntries(
      Object.entries(form).map(([k, v]) => [k, k === 'logo' ? v : String(v).trim()]),
    ) as unknown as CenterSettings
    const found = validate(trimmed)
    setErrors(found)
    if (Object.keys(found).length) {
      push('راجع الحقول المعلّمة بالأحمر', 'error')
      return
    }
    updateSettings(trimmed)
    setForm(trimmed)
    push('تم حفظ بيانات المركز')
  }

  const ltr = { dir: 'ltr' as const, className: 'text-left' }

  return (
    <div className="mt-5 space-y-5">
      <Section icon={<Building2 size={18} />} title="هوية المركز" subtitle="الاسم والشعار والنبذة التعريفية — تظهر في الموقع والروشتات">
        <Field label="اسم المركز" required error={errors.name}>
          <Input value={form.name} onChange={(e) => set('name', e.target.value)} />
        </Field>
        <Field label="الشعار النصي (تحت الاسم)">
          <Input value={form.tagline} onChange={(e) => set('tagline', e.target.value)} placeholder="مثال: مركز متخصص" />
        </Field>
        <div className="sm:col-span-2">
          <span className="mb-1.5 block text-[13px] font-semibold text-ink-700">شعار المركز</span>
          <div className="flex items-center gap-4">
            <span className="flex size-16 items-center justify-center overflow-hidden rounded-2xl border border-ink-100 bg-ink-50">
              {form.logo ? <img src={form.logo} alt="الشعار" className="size-full object-cover" /> : <Building2 size={24} className="text-ink-300" />}
            </span>
            <label className="inline-flex h-10 cursor-pointer items-center gap-2 rounded-xl bg-ink-900 px-4 text-[12.5px] font-bold text-white transition hover:bg-ink-800">
              <Upload size={15} />
              رفع شعار
              <input type="file" accept="image/*" className="hidden" onChange={onLogo} />
            </label>
            {form.logo && (
              <Button variant="ghost" size="sm" onClick={() => set('logo', '')}>
                <X size={14} />
                إزالة
              </Button>
            )}
          </div>
        </div>
        <Field label="نبذة عن المركز" className="sm:col-span-2">
          <Textarea value={form.about} onChange={(e) => set('about', e.target.value)} />
        </Field>
      </Section>

      <Section icon={<Phone size={18} />} title="بيانات التواصل" subtitle="الأرقام والبريد المعروضة للمرضى وفي روابط واتساب">
        <Field label="رقم الهاتف" error={errors.phone}>
          <Input value={form.phone} onChange={(e) => set('phone', e.target.value)} {...ltr} />
        </Field>
        <Field label="رقم واتساب" error={errors.whatsapp} hint="لو فاضي هيُستخدم رقم الهاتف">
          <Input value={form.whatsapp} onChange={(e) => set('whatsapp', e.target.value)} {...ltr} />
        </Field>
        <Field label="البريد الإلكتروني" error={errors.email}>
          <Input value={form.email} onChange={(e) => set('email', e.target.value)} {...ltr} />
        </Field>
        <Field label="الموقع الإلكتروني" error={errors.website}>
          <Input value={form.website} onChange={(e) => set('website', e.target.value)} placeholder="https://" {...ltr} />
        </Field>
      </Section>

      <Section icon={<MapPin size={18} />} title="الموقع" subtitle="المدينة والعنوان ورابط الخريطة">
        <Field label="المدينة">
          <Input value={form.city} onChange={(e) => set('city', e.target.value)} />
        </Field>
        <Field label="رابط الخريطة" error={errors.mapUrl}>
          <Input value={form.mapUrl} onChange={(e) => set('mapUrl', e.target.value)} placeholder="https://maps.google.com/..." {...ltr} />
        </Field>
        <Field label="العنوان بالتفصيل" className="sm:col-span-2">
          <Input value={form.address} onChange={(e) => set('address', e.target.value)} />
        </Field>
      </Section>

      <Section icon={<Clock size={18} />} title="مواعيد العمل" subtitle="تظهر في صفحة التواصل والفوتر">
        <Field label="أيام العمل">
          <Input value={form.workDays} onChange={(e) => set('workDays', e.target.value)} placeholder="السبت — الخميس" />
        </Field>
        <Field label="ساعات العمل">
          <Input value={form.workHours} onChange={(e) => set('workHours', e.target.value)} placeholder="8:00 ص — 10:00 م" />
        </Field>
      </Section>

      <Section icon={<Receipt size={18} />} title="الفوترة والترخيص" subtitle="العملة ورمز الدولة وأرقام الترخيص">
        <Field label="رمز العملة" required error={errors.currency}>
          <Input value={form.currency} onChange={(e) => set('currency', e.target.value)} placeholder="ر.س أو ج.م" />
        </Field>
        <Field label="رمز الدولة للواتساب" required error={errors.countryCode} hint="966 للسعودية • 20 لمصر">
          <Input value={form.countryCode} onChange={(e) => set('countryCode', e.target.value)} {...ltr} />
        </Field>
        <Field label="رقم ترخيص المركز">
          <Input value={form.licenseNo} onChange={(e) => set('licenseNo', e.target.value)} {...ltr} />
        </Field>
        <Field label="الرقم الضريبي">
          <Input value={form.taxNo} onChange={(e) => set('taxNo', e.target.value)} {...ltr} />
        </Field>
      </Section>

      <Section icon={<UserCog size={18} />} title="مدير المركز" subtitle="بيانات استلام التقارير — بيتبعتله التقرير بالإيميل أو الواتساب من قسم التقارير">
        <Field label="اسم المدير">
          <Input value={form.managerName} onChange={(e) => set('managerName', e.target.value)} />
        </Field>
        <Field label="بريد المدير" error={errors.managerEmail}>
          <Input value={form.managerEmail} onChange={(e) => set('managerEmail', e.target.value)} {...ltr} />
        </Field>
        <Field label="واتساب المدير" error={errors.managerPhone}>
          <Input value={form.managerPhone} onChange={(e) => set('managerPhone', e.target.value)} {...ltr} />
        </Field>
      </Section>

      <Section icon={<Globe size={18} />} title="حسابات التواصل الاجتماعي" subtitle="روابط كاملة تبدأ بـ https://">
        <Field label="إنستجرام" error={errors.instagram}>
          <Input value={form.instagram} onChange={(e) => set('instagram', e.target.value)} {...ltr} />
        </Field>
        <Field label="فيسبوك" error={errors.facebook}>
          <Input value={form.facebook} onChange={(e) => set('facebook', e.target.value)} {...ltr} />
        </Field>
        <Field label="X (تويتر)" error={errors.x}>
          <Input value={form.x} onChange={(e) => set('x', e.target.value)} {...ltr} />
        </Field>
      </Section>

      <div className="sticky bottom-4 z-10 flex items-center justify-between gap-3 rounded-2xl border border-ink-100 bg-white/95 p-3.5 shadow-lg backdrop-blur">
        <p className="flex items-center gap-2 text-[12.5px] text-ink-500">
          <MessageCircle size={14} className="text-brand-600" />
          {dirty ? 'لديك تعديلات غير محفوظة' : 'كل البيانات محفوظة'}
        </p>
        <div className="flex gap-2">
          <Button variant="secondary" disabled={!dirty} onClick={() => { setForm(saved); setErrors({}) }}>
            <RotateCcw size={15} />
            تراجع
          </Button>
          <Button disabled={!dirty} onClick={save}>
            <Save size={16} />
            حفظ بيانات المركز
          </Button>
        </div>
      </div>
    </div>
  )
}
