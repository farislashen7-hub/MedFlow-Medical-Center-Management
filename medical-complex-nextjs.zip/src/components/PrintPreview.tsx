import { buildDocument } from '../lib/print'

const PREVIEW_CSS = 'body{padding:22px 26px;background:#fff}'

/** معاينة طبق الأصل للمستند اللي هيتطبع (نفس الـ HTML بتاع الطباعة) */
export function PrintPreview({
  html,
  title = 'معاينة',
  height = '66vh',
  css = '',
}: {
  html: string
  title?: string
  height?: string
  css?: string
}) {
  return (
    <iframe
      title={title}
      srcDoc={buildDocument(title, html, PREVIEW_CSS + css)}
      className="w-full rounded-2xl border border-ink-100 bg-white"
      style={{ height }}
    />
  )
}
