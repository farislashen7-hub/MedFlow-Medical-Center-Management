import { useId } from 'react'

export interface ChartPoint {
  label: string
  value: number
}

export function BarChart({
  data,
  color = '#0f8271',
  height = 200,
  suffix = '',
}: {
  data: ChartPoint[]
  color?: string
  height?: number
  suffix?: string
}) {
  const id = useId().replace(/:/g, '')
  const max = Math.max(1, ...data.map((d) => d.value))
  const barW = 100 / Math.max(data.length, 1)

  return (
    <div className="w-full">
      <svg viewBox={`0 0 100 ${height / 2.2}`} className="w-full" preserveAspectRatio="none" style={{ height }}>
        <defs>
          <linearGradient id={`grad-${id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.95" />
            <stop offset="100%" stopColor={color} stopOpacity="0.35" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75, 1].map((g) => (
          <line
            key={g}
            x1="0"
            x2="100"
            y1={(height / 2.2) * (1 - g)}
            y2={(height / 2.2) * (1 - g)}
            stroke="#e8eeef"
            strokeWidth="1"
            vectorEffect="non-scaling-stroke"
          />
        ))}
        {data.map((d, i) => {
          const h = (d.value / max) * (height / 2.2) * 0.86
          return (
            <rect
              key={d.label}
              x={i * barW + barW * 0.22}
              y={height / 2.2 - h}
              width={barW * 0.56}
              height={Math.max(h, 1)}
              rx="1.4"
              fill={`url(#grad-${id})`}
            />
          )
        })}
      </svg>
      <div className="mt-2 flex justify-between">
        {data.map((d) => (
          <div key={d.label} className="flex-1 text-center">
            <p className="text-[11px] font-bold text-ink-700">{d.value}{suffix}</p>
            <p className="text-[10px] text-ink-400">{d.label}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export function LineChart({
  data,
  color = '#0f8271',
  height = 220,
  suffix = '',
}: {
  data: ChartPoint[]
  color?: string
  height?: number
  suffix?: string
}) {
  const id = useId().replace(/:/g, '')
  const max = Math.max(1, ...data.map((d) => d.value))
  const min = 0
  const w = 100
  const h = height / 2.4
  const step = data.length > 1 ? w / (data.length - 1) : w
  const points = data.map((d, i) => {
    const x = i * step
    const y = h - ((d.value - min) / (max - min || 1)) * (h * 0.8) - h * 0.1
    return { x, y, ...d }
  })
  const line = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ')
  const area = `${line} L ${w} ${h} L 0 ${h} Z`

  return (
    <div className="w-full">
      <div className="relative w-full">
        <svg viewBox={`0 0 ${w} ${h}`} className="w-full" style={{ height }} preserveAspectRatio="none">
          <defs>
            <linearGradient id={`line-${id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity="0.28" />
              <stop offset="100%" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          {[0.25, 0.5, 0.75].map((g) => (
            <line key={g} x1="0" x2={w} y1={h * g} y2={h * g} stroke="#e8eeef" strokeWidth="1" vectorEffect="non-scaling-stroke" />
          ))}
          <path d={area} fill={`url(#line-${id})`} />
          <path d={line} fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        </svg>
        {points.map((p) => (
          <span
            key={p.label}
            className="absolute size-2.5 rounded-full border-2 bg-white"
            style={{
              left: `${p.x}%`,
              top: `${(p.y / h) * 100}%`,
              transform: 'translate(-50%, -50%)',
              borderColor: color,
            }}
          />
        ))}
      </div>
      <div className="mt-2 flex justify-between">
        {data.map((d) => (
          <div key={d.label} className="flex-1 text-center">
            <p className="text-[11px] font-bold text-ink-700">{d.value}{suffix}</p>
            <p className="text-[10px] text-ink-400">{d.label}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export function DonutChart({
  segments,
  size = 170,
  centerLabel,
  centerValue,
}: {
  segments: { label: string; value: number; color: string }[]
  size?: number
  centerLabel?: string
  centerValue?: string
}) {
  const total = segments.reduce((sum, s) => sum + s.value, 0) || 1
  const radius = 42
  const circumference = 2 * Math.PI * radius
  let offset = 0

  return (
    <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center sm:gap-6">
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg viewBox="0 0 100 100" className="size-full -rotate-90">
          <circle cx="50" cy="50" r={radius} fill="none" stroke="#eef2f3" strokeWidth="14" />
          {segments.map((s) => {
            const len = (s.value / total) * circumference
            const el = (
              <circle
                key={s.label}
                cx="50"
                cy="50"
                r={radius}
                fill="none"
                stroke={s.color}
                strokeWidth="14"
                strokeDasharray={`${len} ${circumference - len}`}
                strokeDashoffset={-offset}
                strokeLinecap="butt"
              />
            )
            offset += len
            return el
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-2xl font-extrabold text-ink-900">{centerValue ?? total}</span>
          {centerLabel && <span className="text-[11px] text-ink-500">{centerLabel}</span>}
        </div>
      </div>
      <div className="w-full space-y-2">
        {segments.map((s) => (
          <div key={s.label} className="flex items-center justify-between gap-3 text-[12.5px]">
            <span className="flex items-center gap-2 text-ink-600">
              <span className="size-2.5 rounded-full" style={{ background: s.color }} />
              {s.label}
            </span>
            <span className="font-bold text-ink-800">
              {s.value} · {Math.round((s.value / total) * 100)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
