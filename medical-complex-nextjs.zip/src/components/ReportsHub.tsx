import { useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import {
  Activity,
  BarChart3,
  CalendarDays,
  CheckCircle2,
  Copy,
  DollarSign,
  Download,
  Eye,
  FileBarChart,
  FileText,
  Loader2,
  Mail,
  MessageCircle,
  Pill,
  Printer,
  Send,
  Star,
  Stethoscope,
  Users,
} from 'lucide-react'
import { logActivity, updateSettings, useDB } from '../lib/db'
import { downloadCsv, formatFullDate, formatTime, money, waLink } from '../lib/format'
import { PRESETS, buildReport, periodLabel, presetRange, reportSummaryText } from '../lib/reports'
import type { Bar, PresetId } from '../lib/reports'
import { ALL_SECTIONS, REPORT_CSS, SECTIONS, printReport, reportHtml } from '../lib/reportPrint'
import type { SectionKey } from '../lib/reportPrint'
import { statusLabel, typeLabel } from '../lib/print'
import { blobToBase64, downloadBlob, htmlToPdfBlob, safeFilename } from '../lib/capture'
import { notify } from '../lib/notify'
import { BarChart, DonutChart } from './charts'
import { PrintPreview } from './PrintPreview'
import { useToast } from './Toast'
import { Badge, Button, Card, Field, Input, Modal, SectionTitle, Select, Tabs, Textarea } from './ui'

const tones: Record<string, 'green' | 'rose' | 'amber' | 'sky' | 'brand'> = {
  completed: 'green',
  cancelled: 'rose',
  'no-show': 'amber',
  scheduled: 'sky',
  confirmed: 'brand',
}

function Kpi({ label, value, icon, hi }: { label: string; value: ReactNode; icon: ReactNode; hi?: boolean }) {
  return (
    <Card className={`!p-4 ${hi ? '!border-brand-600 !bg-brand-600 !text-white' : ''}`}>
      <span className={`flex size-9 items-center justify-center rounded-xl ${hi ? 'bg-white/15 text-white' : 'bg-brand-50 text-brand-700'}`}>
        {icon}
      </span>
      <p className={`mt-3 font-display text-xl font-extrabold ${hi ? 'text-white' : 'text-ink-900'}`}>{value}</p>
      <p className={`text-[11.5px] ${hi ? 'text-brand-100' : 'text-ink-500'}`}>{label}</p>
    </Card>
  )
}

function HBars({ items, fmt = String, color = '#0f8271' }: { items: Bar[]; fmt?: (n: number) => string; color?: string }) {
  const list = items.filter((i) => i.value > 0)
  if (!list.length) return <p className="text-[12.5px] text-ink-400">لا توجد بيانات في الفترة المحددة.</p>
  const max = Math.max(...list.map((i) => i.value), 1)
  return (
    <div className="space-y-3">
      {list.map((i) => (
        <div key={i.label}>
          <div className="mb-1.5 flex items-center justify-between text-[12px]">
            <span className="font-semibold text-ink-700">{i.label}</span>
            <span className="font-bold text-ink-900">{fmt(i.value)}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-ink-100">
            <div className="h-full rounded-full" style={{ width: `${(i.value / max) * 100}%`, background: i.color ?? color }} />
          </div>
        </div>
      ))}
    </div>
  )
}

function MiniTable({ head, rows, empty = 'لا توجد بيانات' }: { head: string[]; rows: ReactNode[][]; empty?: string }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] text-right">
        <thead className="bg-ink-50 text-[11.5px] font-bold text-ink-500">
          <tr>
            {head.map((h) => (
              <th key={h} className="px-4 py-3">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-ink-50 text-[12.5px]">
          {rows.length === 0 ? (
            <tr>
              <td colSpan={head.length} className="px-4 py-6 text-center text-ink-400">
                {empty}
              </td>
            </tr>
          ) : (
            rows.map((cells, i) => (
              <tr key={i} className="transition hover:bg-ink-50/50">
                {cells.map((c, j) => (
                  <td key={j} className="px-4 py-3 text-ink-700">
                    {c}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )
}

export function ReportsHub() {
  const db = useDB()
  const { push } = useToast()
  const [preset, setPreset] = useState<PresetId>('month')
  const [custom, setCustom] = useState(() => presetRange('last30', db))
  const [doctorId, setDoctorId] = useState('')
  const [view, setView] = useState<SectionKey>('summary')
  const [sections, setSections] = useState<SectionKey[]>(ALL_SECTIONS)
  const [previewOpen, setPreviewOpen] = useState(false)
  const [sendOpen, setSendOpen] = useState(false)
  const [manager, setManager] = useState({ name: '', email: '', phone: '' })
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)

  const range = preset === 'custom' ? custom : presetRange(preset, db)
  const report = useMemo(
    () => buildReport(db, { from: range.from, to: range.to, doctorId }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [db, range.from, range.to, doctorId],
  )
  const t = report.totals
  const f = report.finance

  function toggleSection(id: SectionKey) {
    setSections((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]))
  }

  function openSend() {
    const s = db.settings
    setManager({ name: s.managerName, email: s.managerEmail, phone: s.managerPhone })
    setText(reportSummaryText(report, s.name))
    setSendOpen(true)
  }

  function saveManager() {
    if (
      manager.name !== db.settings.managerName ||
      manager.email !== db.settings.managerEmail ||
      manager.phone !== db.settings.managerPhone
    ) {
      updateSettings({ managerName: manager.name.trim(), managerEmail: manager.email.trim(), managerPhone: manager.phone.trim() })
    }
  }

  /** PDF التقرير (الأقسام المختارة) — نفس HTML الطباعة */
  function reportPdf() {
    return htmlToPdfBlob(
      reportHtml(report, db.settings, ALL_SECTIONS.filter((s) => sections.includes(s))),
      REPORT_CSS,
    )
  }

  /** يبعت ملخص التقرير + ملف PDF للمدير عبر webhook (n8n) */
  async function sendPdfToManager() {
    if (sending) return
    if (!manager.email.trim() && !manager.phone.trim()) {
      push('اكتب بريد المدير أو واتساب المدير', 'error')
      return
    }
    if (manager.email.trim() && !/^\S+@\S+\.\S+$/.test(manager.email.trim())) {
      push('اكتب بريد المدير بشكل صحيح', 'error')
      return
    }
    setSending(true)
    try {
      saveManager()
      const blob = await reportPdf()
      const pdf = await blobToBase64(blob)
      if (pdf.length > 3_800_000) {
        push('ملف الـ PDF كبير — قلّل الأقسام أو الفترة وجرّب تاني', 'error')
        return
      }
      const period = periodLabel(report.filter)
      const r = await notify('report.send', {
        centerName: db.settings.name,
        period,
        managerName: manager.name.trim(),
        managerEmail: manager.email.trim(),
        managerPhone: manager.phone.trim(),
        summary: text,
        pdf,
        filename: safeFilename(`تقرير-${db.settings.name}-${period}`),
      })
      if (r.ok) {
        logActivity('الإدارة', 'admin', 'إرسال تقرير للمدير', `ملف PDF لتقرير ${period} أُرسل إلى المدير`, 'admin')
        push('تم إرسال ملف PDF الملخص للمدير')
      } else if (r.skipped) {
        downloadBlob(blob, `${safeFilename(`تقرير-${period}`)}.pdf`)
        push('الإرسال غير متاح محلياً — تم تنزيل الـ PDF على جهازك', 'info')
      } else {
        push('تعذر الإرسال عبر الـ webhook — جرّب تاني', 'error')
      }
    } catch (err) {
      console.error('[report] send failed', err)
      push('تعذر تجهيز ملف الـ PDF', 'error')
    } finally {
      setSending(false)
    }
  }

  async function downloadPdf() {
    if (sending) return
    setSending(true)
    try {
      downloadBlob(await reportPdf(), `${safeFilename(`تقرير-${periodLabel(report.filter)}`)}.pdf`)
    } catch (err) {
      console.error('[report] pdf failed', err)
      push('تعذر تجهيز ملف الـ PDF', 'error')
    } finally {
      setSending(false)
    }
  }

  function sendEmail() {
    if (!/^\S+@\S+\.\S+$/.test(manager.email.trim())) {
      push('اكتب بريد المدير بشكل صحيح', 'error')
      return
    }
    saveManager()
    const subject = `تقرير ${db.settings.name} — ${periodLabel(report.filter)}`
    window.location.href = `mailto:${manager.email.trim()}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`
    logActivity('الإدارة', 'admin', 'إرسال تقرير للمدير', `تقرير ${periodLabel(report.filter)} بالإيميل إلى ${manager.email.trim()}`, 'admin')
    push('اتفتح تطبيق الإيميل — أرفق ملف الـ PDF من زرار الطباعة')
  }

  function sendWhatsApp() {
    if (!manager.phone.trim()) {
      push('اكتب رقم واتساب المدير', 'error')
      return
    }
    saveManager()
    window.open(waLink(manager.phone.trim(), text), '_blank', 'noopener')
    logActivity('الإدارة', 'admin', 'إرسال تقرير للمدير', `ملخص تقرير ${periodLabel(report.filter)} على واتساب ${manager.phone.trim()}`, 'whatsapp')
  }

  async function copyText() {
    try {
      await navigator.clipboard.writeText(text)
      push('تم نسخ الملخص')
    } catch {
      push('تعذر النسخ — انسخ النص يدوياً', 'error')
    }
  }

  function exportAppointmentsCsv() {
    downloadCsv('report-appointments.csv', [
      ['رقم الحجز', 'التاريخ', 'الوقت', 'المريض', 'الجوال', 'الطبيب', 'النوع', 'الحالة', 'الدفع', 'المبلغ'],
      ...report.appointments.map((a) => [
        a.id,
        a.date,
        a.time,
        a.patientName,
        a.patientPhone,
        db.doctors.find((d) => d.id === a.doctorId)?.name ?? '',
        typeLabel[a.type],
        statusLabel[a.status],
        a.status === 'cancelled' ? '—' : a.paid ? 'مدفوع' : 'غير مدفوع',
        a.fee,
      ]),
    ])
    push('تم تصدير المواعيد')
  }

  function exportDoctorsCsv() {
    downloadCsv('report-doctors.csv', [
      ['الطبيب', 'التخصص', 'المواعيد', 'مكتمل', 'ملغي', 'لم يحضر', 'نسبة الإتمام', 'الإيراد', 'التقييم', 'الوصفات', 'غير متاح'],
      ...report.doctors.map((d) => [d.doctor.name, d.specialty, d.total, d.completed, d.cancelled, d.noShow, `${d.rate}%`, d.revenue, d.rating, d.prescriptions, d.off ? 'نعم' : 'لا']),
    ])
    push('تم تصدير الأطباء')
  }

  const tabItems = SECTIONS.map((s) => ({
    id: s.id,
    label: s.label.replace('ملحق: ', ''),
  }))

  return (
    <div className="mt-5 space-y-5">
      {/* header + actions */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-xl font-extrabold text-ink-950">التقارير والإحصائيات الشاملة</h3>
          <p className="text-[12.5px] text-ink-500">
            {periodLabel(report.filter)} — {report.doctorName}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={() => setPreviewOpen(true)}>
            <Printer size={15} />
            معاينة وطباعة
          </Button>
          <Button size="sm" variant="secondary" onClick={openSend}>
            <Send size={15} />
            إرسال للمدير
          </Button>
          <Button size="sm" variant="secondary" onClick={exportAppointmentsCsv}>
            <Download size={15} />
            المواعيد CSV
          </Button>
          <Button size="sm" variant="secondary" onClick={exportDoctorsCsv}>
            <Download size={15} />
            الأطباء CSV
          </Button>
        </div>
      </div>

      {/* filters */}
      <Card className="!p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPreset(p.id)}
                className={`rounded-xl px-3.5 py-2 text-[12.5px] font-bold transition ${
                  preset === p.id ? 'bg-ink-900 text-white' : 'bg-ink-50 text-ink-600 hover:bg-ink-100'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
          {preset === 'custom' && (
            <div className="flex items-end gap-2">
              <Field label="من">
                <Input type="date" value={custom.from} max={custom.to} onChange={(e) => setCustom({ ...custom, from: e.target.value })} />
              </Field>
              <Field label="إلى">
                <Input type="date" value={custom.to} min={custom.from} onChange={(e) => setCustom({ ...custom, to: e.target.value })} />
              </Field>
            </div>
          )}
          <Field label="الطبيب" className="min-w-52">
            <Select value={doctorId} onChange={(e) => setDoctorId(e.target.value)}>
              <option value="">كل الأطباء</option>
              {db.doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </Field>
        </div>
      </Card>

      {/* KPIs */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6">
        <Kpi hi label="إجمالي المواعيد" value={t.total} icon={<CalendarDays size={18} />} />
        <Kpi label="مكتملة" value={t.completed} icon={<CheckCircle2 size={18} />} />
        <Kpi hi label="الإيرادات" value={money(f.revenue)} icon={<DollarSign size={18} />} />
        <Kpi label="غير محصّل" value={money(f.outstanding)} icon={<DollarSign size={18} />} />
        <Kpi label="نسبة الإتمام" value={`${t.attendance}%`} icon={<Activity size={18} />} />
        <Kpi label="متوسط التقييم" value={report.feedback.avg || '—'} icon={<Star size={18} />} />
      </div>

      <Tabs items={tabItems} active={view} onChange={(id) => setView(id as SectionKey)} />

      {/* ---------------- summary ---------------- */}
      {view === 'summary' && (
        <div className="space-y-5">
          <div className="grid gap-5 lg:grid-cols-2">
            <Card>
              <SectionTitle title="توزيع حالات المواعيد" subtitle="من إجمالي مواعيد الفترة" icon={<BarChart3 size={18} />} />
              <DonutChart
                segments={report.byStatus.filter((s) => s.value > 0).map((s) => ({ label: s.label, value: s.value, color: s.color ?? '#0f8271' }))}
                centerLabel="موعد"
                centerValue={String(t.total)}
              />
            </Card>
            <Card>
              <SectionTitle title="نوع الكشف" subtitle="جديد / متابعة / عاجل" icon={<Stethoscope size={18} />} />
              <HBars items={report.byType} />
              <div className="mt-5 grid grid-cols-3 gap-2 text-center">
                {[
                  ['ملغاة', `${t.cancelled} (${t.cancelRate}%)`],
                  ['لم يحضر', `${t.noShow} (${t.noShowRate}%)`],
                  ['متوسط/يوم', t.perDay],
                ].map(([l, v]) => (
                  <div key={l as string} className="rounded-xl bg-ink-50 px-2 py-2.5">
                    <p className="font-display text-[14px] font-extrabold text-ink-900">{v}</p>
                    <p className="text-[10.5px] text-ink-400">{l}</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>
          <Card>
            <SectionTitle title="ملاحظات وتوصيات" subtitle="مستخرجة تلقائياً من بيانات الفترة" icon={<FileBarChart size={18} />} />
            {report.insights.length === 0 ? (
              <p className="text-[12.5px] text-ink-400">لا توجد ملاحظات خاصة في هذه الفترة.</p>
            ) : (
              <ul className="space-y-2">
                {report.insights.map((i, idx) => (
                  <li
                    key={idx}
                    className={`rounded-xl px-4 py-2.5 text-[12.5px] font-semibold ${
                      i.tone === 'good' ? 'bg-emerald-50 text-emerald-800' : i.tone === 'warn' ? 'bg-rose-50 text-rose-800' : 'bg-ink-50 text-ink-700'
                    }`}
                  >
                    {i.text}
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      )}

      {/* ---------------- activity ---------------- */}
      {view === 'activity' && (
        <div className="space-y-5">
          <Card>
            <SectionTitle title={`المواعيد حسب ${report.timeline.unit === 'day' ? 'اليوم' : 'الشهر'}`} subtitle="حركة الحجوزات خلال الفترة" icon={<CalendarDays size={18} />} />
            <BarChart data={report.timeline.appointments} color="#0f8271" />
          </Card>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card>
              <SectionTitle title="حسب أيام الأسبوع" subtitle="أكثر الأيام ازدحاماً" icon={<CalendarDays size={18} />} />
              <BarChart data={report.byWeekday} color="#8b5cf6" />
            </Card>
            <Card>
              <SectionTitle title="ساعات الذروة" subtitle="توزيع المواعيد على ساعات اليوم" icon={<Activity size={18} />} />
              {report.byHour.length ? <BarChart data={report.byHour} color="#0ea5e9" /> : <p className="text-[12.5px] text-ink-400">لا توجد بيانات.</p>}
            </Card>
          </div>
        </div>
      )}

      {/* ---------------- finance ---------------- */}
      {view === 'finance' && (
        <div className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Kpi hi label="إجمالي الإيرادات (المكتملة)" value={money(f.revenue)} icon={<DollarSign size={18} />} />
            <Kpi label="المحصّل فعلياً" value={money(f.collected)} icon={<DollarSign size={18} />} />
            <Kpi label="غير محصّل" value={money(f.outstanding)} icon={<DollarSign size={18} />} />
            <Kpi label="متوسط قيمة الكشف" value={money(f.avgFee)} icon={<DollarSign size={18} />} />
            <Kpi label="إيرادات متوقعة (قادمة)" value={money(f.expected)} icon={<DollarSign size={18} />} />
            <Kpi label="إيراد ضائع (إلغاء/غياب)" value={money(f.lost)} icon={<DollarSign size={18} />} />
          </div>
          <Card>
            <SectionTitle title={`الإيراد حسب ${report.timeline.unit === 'day' ? 'اليوم' : 'الشهر'}`} subtitle="قيمة الكشوفات المكتملة" icon={<DollarSign size={18} />} />
            <BarChart data={report.timeline.revenue} color="#10b981" suffix={` ${db.settings.currency}`} />
          </Card>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card>
              <SectionTitle title="الإيراد حسب الطبيب" subtitle="ترتيب تنازلي" icon={<Stethoscope size={18} />} />
              <HBars items={f.byDoctor} fmt={money} />
            </Card>
            <Card>
              <SectionTitle title="الإيراد حسب التخصص" subtitle="ترتيب تنازلي" icon={<Stethoscope size={18} />} />
              <HBars items={f.bySpecialty} fmt={money} color="#8b5cf6" />
            </Card>
          </div>
        </div>
      )}

      {/* ---------------- doctors ---------------- */}
      {view === 'doctors' && (
        <div className="space-y-5">
          <Card className="!p-0 overflow-hidden">
            <div className="border-b border-ink-100 px-5 py-4">
              <h3 className="font-display text-[16px] font-extrabold text-ink-900">أداء الأطباء</h3>
              <p className="text-[12px] text-ink-500">المواعيد والإيرادات والتقييم والوصفات خلال الفترة</p>
            </div>
            <MiniTable
              head={['الطبيب', 'التخصص', 'المواعيد', 'مكتمل', 'ملغي', 'غياب', 'الإتمام', 'الإيراد', 'التقييم', 'وصفات']}
              rows={report.doctors.map((d) => [
                <span key="n" className="flex items-center gap-2 font-bold text-ink-800">
                  {d.doctor.name}
                  {d.off && <Badge tone="rose">غير متاح</Badge>}
                </span>,
                d.specialty,
                d.total,
                d.completed,
                d.cancelled,
                d.noShow,
                `${d.rate}%`,
                money(d.revenue),
                <Badge key="r" tone="amber">★ {d.rating.toFixed(1)}</Badge>,
                d.prescriptions,
              ])}
            />
          </Card>
          <Card className="!p-0 overflow-hidden">
            <div className="border-b border-ink-100 px-5 py-4">
              <h3 className="font-display text-[16px] font-extrabold text-ink-900">أداء التخصصات</h3>
            </div>
            <MiniTable
              head={['التخصص', 'المواعيد', 'النسبة', 'مكتمل', 'الإيراد']}
              rows={report.specialties.map((s) => [<b key="n">{s.name}</b>, s.total, `${s.share}%`, s.completed, money(s.revenue)])}
            />
          </Card>
        </div>
      )}

      {/* ---------------- patients ---------------- */}
      {view === 'patients' && (
        <div className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Kpi hi label="إجمالي المسجلين" value={report.patients.total} icon={<Users size={18} />} />
            <Kpi label="جدد في الفترة" value={report.patients.newInRange} icon={<Users size={18} />} />
            <Kpi label="نشطون في الفترة" value={report.patients.active} icon={<Users size={18} />} />
            <Kpi label="عائدون (أكثر من زيارة)" value={report.patients.returning} icon={<Users size={18} />} />
          </div>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card>
              <SectionTitle title="الفئات العمرية" subtitle="المرضى النشطون" icon={<Users size={18} />} />
              <BarChart data={report.patients.ageGroups} color="#0ea5e9" />
            </Card>
            <Card>
              <SectionTitle title="الجنس والحالة الصحية" subtitle="المرضى النشطون" icon={<Users size={18} />} />
              <HBars
                items={[
                  { label: 'ذكور', value: report.patients.male, color: '#0f8271' },
                  { label: 'إناث', value: report.patients.female, color: '#ec4899' },
                  { label: 'لديهم حساسية', value: report.patients.withAllergies, color: '#e11d48' },
                  { label: 'أمراض مزمنة', value: report.patients.withChronic, color: '#f59e0b' },
                ]}
              />
            </Card>
          </div>
          <Card className="!p-0 overflow-hidden">
            <div className="border-b border-ink-100 px-5 py-4">
              <h3 className="font-display text-[16px] font-extrabold text-ink-900">أكثر المرضى زيارة</h3>
            </div>
            <MiniTable
              head={['#', 'المريض', 'الجوال', 'الزيارات', 'إجمالي المدفوع']}
              rows={report.patients.top.map((p, i) => [
                i + 1,
                <b key="n">{p.name}</b>,
                <span key="p" dir="ltr">
                  {p.phone}
                </span>,
                p.visits,
                money(p.spent),
              ])}
            />
          </Card>
        </div>
      )}

      {/* ---------------- clinical ---------------- */}
      {view === 'clinical' && (
        <div className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-3">
            <Kpi hi label="وصفات صادرة" value={report.clinical.count} icon={<Pill size={18} />} />
            <Kpi label="متوسط الأدوية بالوصفة" value={report.clinical.avgMeds} icon={<Pill size={18} />} />
            <Kpi label="وصفات بها متابعة" value={report.clinical.withFollowUp} icon={<Pill size={18} />} />
          </div>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card>
              <SectionTitle title="أكثر التشخيصات" subtitle="من الوصفات الصادرة" icon={<Stethoscope size={18} />} />
              <HBars items={report.clinical.topDiagnoses} color="#8b5cf6" />
            </Card>
            <Card>
              <SectionTitle title="أكثر الأدوية وصفاً" subtitle="حسب عدد مرات الوصف" icon={<Pill size={18} />} />
              <HBars items={report.clinical.topMeds} />
            </Card>
          </div>
        </div>
      )}

      {/* ---------------- feedback ---------------- */}
      {view === 'feedback' && (
        <div className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-3">
            <Kpi hi label="متوسط التقييم" value={report.feedback.avg ? `${report.feedback.avg} / 5` : '—'} icon={<Star size={18} />} />
            <Kpi label="عدد التقييمات" value={report.feedback.count} icon={<Star size={18} />} />
            <Kpi label="تقييمات مخفية" value={report.feedback.hidden} icon={<Star size={18} />} />
          </div>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card>
              <SectionTitle title="توزيع التقييمات" subtitle="التقييمات المنشورة" icon={<Star size={18} />} />
              <HBars items={report.feedback.distribution} color="#f59e0b" />
            </Card>
            <Card>
              <SectionTitle title="أحدث الآراء" subtitle="آخر 5 تقييمات" icon={<MessageCircle size={18} />} />
              {report.feedback.recent.length === 0 ? (
                <p className="text-[12.5px] text-ink-400">لا توجد تقييمات في الفترة.</p>
              ) : (
                <div className="space-y-2.5">
                  {report.feedback.recent.map((x, i) => (
                    <div key={i} className="rounded-xl border border-ink-100 p-3">
                      <p className="flex items-center justify-between text-[12.5px] font-bold text-ink-800">
                        <span>
                          {x.patient} ← {x.doctor}
                        </span>
                        <Badge tone="amber">{x.rating} ★</Badge>
                      </p>
                      <p className="mt-1 text-[12px] text-ink-500">{x.comment || '—'}</p>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        </div>
      )}

      {/* ---------------- comms ---------------- */}
      {view === 'comms' && (
        <div className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Kpi label="محادثات نشطة بالفترة" value={report.comms.threads} icon={<MessageCircle size={18} />} />
            <Kpi label="مفتوحة الآن" value={report.comms.open} icon={<MessageCircle size={18} />} />
            <Kpi label="بتدخل بشري" value={report.comms.human} icon={<MessageCircle size={18} />} />
            <Kpi label="رسائل غير مقروءة" value={report.comms.unread} icon={<MessageCircle size={18} />} />
          </div>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card>
              <SectionTitle title="الرسائل خلال الفترة" subtitle="حسب المرسل" icon={<MessageCircle size={18} />} />
              <HBars
                items={[
                  { label: 'رسائل المرضى', value: report.comms.patientMsgs, color: '#0ea5e9' },
                  { label: 'ردود الموظفين', value: report.comms.agentMsgs, color: '#0f8271' },
                  { label: 'ردود المساعد الآلي', value: report.comms.botMsgs, color: '#8b5cf6' },
                ]}
              />
            </Card>
            <Card>
              <SectionTitle title="العروض" subtitle="الحالة الحالية" icon={<Send size={18} />} />
              <div className="rounded-xl bg-ink-50 px-2 py-4 text-center">
                <p className="font-display text-2xl font-extrabold text-ink-900">{report.comms.activeOffers}</p>
                <p className="text-[11px] text-ink-400">عروض مفعّلة حالياً</p>
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* ---------------- detailed list ---------------- */}
      {view === 'list' && (
        <Card className="!p-0 overflow-hidden">
          <div className="border-b border-ink-100 px-5 py-4">
            <h3 className="font-display text-[16px] font-extrabold text-ink-900">كشف المواعيد التفصيلي ({report.appointments.length})</h3>
            <p className="text-[12px] text-ink-500">الأحدث في الأسفل — التقرير المطبوع يحتوي على الكشف كاملاً</p>
          </div>
          <MiniTable
            head={['التاريخ', 'المريض', 'الطبيب', 'النوع', 'الحالة', 'الدفع', 'المبلغ']}
            rows={report.appointments.slice(-150).map((a) => [
              <span key="d">
                {formatFullDate(a.date)}
                <span className="block text-[11px] text-ink-400">{formatTime(a.time)}</span>
              </span>,
              a.patientName,
              db.doctors.find((d) => d.id === a.doctorId)?.name ?? '—',
              typeLabel[a.type],
              <Badge key="s" tone={tones[a.status]}>
                {statusLabel[a.status]}
              </Badge>,
              a.status === 'cancelled' ? '—' : a.paid ? 'مدفوع' : 'غير مدفوع',
              money(a.fee),
            ])}
          />
        </Card>
      )}

      {/* ---------------- preview + print ---------------- */}
      <Modal
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        title="معاينة التقرير"
        subtitle="اختر الأقسام اللي تظهر في الطباعة"
        size="xl"
        footer={
          <>
            <Button variant="secondary" onClick={() => setPreviewOpen(false)}>
              إغلاق
            </Button>
            <Button variant="secondary" onClick={openSend}>
              <Send size={16} />
              إرسال للمدير
            </Button>
            <Button disabled={sections.length === 0} onClick={() => printReport(report, db.settings, ALL_SECTIONS.filter((s) => sections.includes(s)))}>
              <Printer size={16} />
              طباعة / حفظ PDF
            </Button>
          </>
        }
      >
        <div className="mb-4 flex flex-wrap gap-2">
          {SECTIONS.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => toggleSection(s.id)}
              className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-[12px] font-bold transition ${
                sections.includes(s.id) ? 'border-brand-500 bg-brand-50 text-brand-800' : 'border-ink-200 bg-white text-ink-400'
              }`}
            >
              <Eye size={12} />
              {s.label}
            </button>
          ))}
        </div>
        {previewOpen && (
          <PrintPreview
            title="تقرير"
            css={REPORT_CSS}
            height="62vh"
            html={reportHtml(report, db.settings, ALL_SECTIONS.filter((s) => sections.includes(s)))}
          />
        )}
      </Modal>

      {/* ---------------- send to manager ---------------- */}
      <Modal
        open={sendOpen}
        onClose={() => setSendOpen(false)}
        title="إرسال التقرير للمدير"
        subtitle={periodLabel(report.filter)}
        size="lg"
        footer={
          <>
            <Button variant="secondary" onClick={() => setSendOpen(false)}>
              إغلاق
            </Button>
            <Button variant="secondary" disabled={sending} onClick={downloadPdf}>
              <Download size={16} />
              تنزيل PDF
            </Button>
            <Button variant="secondary" onClick={sendEmail}>
              <Mail size={16} />
              إيميل
            </Button>
            <Button variant="secondary" onClick={sendWhatsApp}>
              <MessageCircle size={16} />
              واتساب
            </Button>
            <Button disabled={sending || sections.length === 0} onClick={sendPdfToManager}>
              {sending ? <Loader2 size={16} className="animate-spin" /> : <FileText size={16} />}
              {sending ? 'جاري التجهيز…' : 'إرسال PDF للمدير'}
            </Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="اسم المدير">
            <Input value={manager.name} onChange={(e) => setManager({ ...manager, name: e.target.value })} />
          </Field>
          <Field label="بريد المدير">
            <Input dir="ltr" className="text-left" value={manager.email} onChange={(e) => setManager({ ...manager, email: e.target.value })} />
          </Field>
          <Field label="واتساب المدير">
            <Input dir="ltr" className="text-left" value={manager.phone} onChange={(e) => setManager({ ...manager, phone: e.target.value })} />
          </Field>
        </div>
        <Field label="ملخص التقرير (تقدر تعدّله قبل الإرسال)" className="mt-4">
          <Textarea rows={12} value={text} onChange={(e) => setText(e.target.value)} />
        </Field>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="max-w-xl text-[11.5px] leading-6 text-ink-500">
            «إرسال PDF للمدير» بيبعت ملف PDF بالأقسام المختارة (من المعاينة) مع الملخص للمدير تلقائياً. زرار الإيميل والواتساب بيفتحوا
            رسالة جاهزة بالنص بس. بيانات المدير بتتحفظ تلقائياً.
          </p>
          <Button size="sm" variant="ghost" onClick={copyText}>
            <Copy size={14} />
            نسخ الملخص
          </Button>
        </div>
      </Modal>
    </div>
  )
}
