import { useMemo, useState } from 'react'
import type { ChangeEvent } from 'react'
import {
  EyeOff,
  Eye,
  Megaphone,
  Pencil,
  Plus,
  Save,
  Send,
  Star,
  Trash2,
  Upload,
  Users,
  X,
} from 'lucide-react'
import {
  createOffer,
  logOfferSent,
  removeOffer,
  updateOffer,
  updateReview,
  useDB,
} from '../lib/db'
import { fileToDataUrl } from '../lib/image'
import { getLastOfferFailure, offerFailureHint, sendOfferWhatsApp } from '../lib/whatsapp'
import { formatFullDate, formatStamp, money, toDateKey } from '../lib/format'
import { offerMessage, offerStatus, offerStatusMeta, renderWhatsAppText } from '../lib/offers'
import { OfferCard, themeMeta } from './OfferCard'
import { Stars } from './Stars'
import { useToast } from './Toast'
import { Avatar, Badge, Button, Card, EmptyState, Field, Input, Modal, SectionTitle, Select, Tabs, Textarea } from './ui'
import type { Offer, OfferTheme } from '../lib/types'

type Form = {
  title: string
  details: string
  price: string
  oldPrice: string
  validUntil: string
  image: string
  theme: OfferTheme
  message: string
  active: boolean
}

const emptyForm: Form = {
  title: '',
  details: '',
  price: '',
  oldPrice: '',
  validUntil: '',
  image: '',
  theme: 'brand',
  message: '',
  active: true,
}

/* =============================================================== */
export function OffersHub() {
  const db = useDB()
  const [sub, setSub] = useState('offers')

  return (
    <div className="mt-5 space-y-5">
      <Tabs
        active={sub}
        onChange={setSub}
        items={[
          { id: 'offers', label: 'العروض', icon: <Megaphone size={15} />, count: db.offers.length },
          { id: 'reviews', label: 'آراء العملاء', icon: <Star size={15} />, count: db.reviews.length },
        ]}
      />
      {sub === 'offers' && <OffersManager />}
      {sub === 'reviews' && <ReviewsManager />}
    </div>
  )
}

/* =============================================================== */
function OffersManager() {
  const db = useDB()
  const { push } = useToast()
  const [form, setForm] = useState<Form>(emptyForm)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [errors, setErrors] = useState<{ title?: string; price?: string }>({})
  const [sendTarget, setSendTarget] = useState<Offer | null>(null)

  const draft = {
    title: form.title,
    details: form.details,
    price: Number(form.price) || 0,
    oldPrice: form.oldPrice ? Number(form.oldPrice) : null,
    validUntil: form.validUntil,
  }
  const autoMessage = offerMessage(draft, db.settings)
  const shownMessage = form.message.trim() || autoMessage

  function set<K extends keyof Form>(k: K, v: Form[K]) {
    setForm((f) => ({ ...f, [k]: v }))
    if (k === 'title' || k === 'price') setErrors((e) => ({ ...e, [k]: undefined }))
  }

  async function onImage(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (!file.type.startsWith('image/') || file.size > 3 * 1024 * 1024) {
      push('اختر صورة JPG/PNG/WebP بحجم أقصى 3MB', 'error')
      return
    }
    try {
      const url = await fileToDataUrl(file, 720)
      if (url.length > 600_000) {
        push('الصورة كبيرة بعد المعالجة، جرّب صورة أصغر', 'error')
        return
      }
      set('image', url)
    } catch (err) {
      push(err instanceof Error ? err.message : 'تعذر معالجة الصورة', 'error')
    }
  }

  function reset() {
    setForm(emptyForm)
    setEditingId(null)
    setErrors({})
  }

  function startEdit(o: Offer) {
    setEditingId(o.id)
    setForm({
      title: o.title,
      details: o.details,
      price: String(o.price),
      oldPrice: o.oldPrice ? String(o.oldPrice) : '',
      validUntil: o.validUntil,
      image: o.image,
      theme: o.theme,
      message: o.message,
      active: o.active,
    })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function submit() {
    const e: typeof errors = {}
    if (!form.title.trim()) e.title = 'عنوان العرض مطلوب'
    if (form.price === '' || Number(form.price) < 0 || Number.isNaN(Number(form.price))) e.price = 'أدخل سعر العرض (0 للمجاني)'
    setErrors(e)
    if (Object.keys(e).length) return
    const payload = {
      title: form.title.trim(),
      details: form.details.trim(),
      price: Number(form.price),
      oldPrice: form.oldPrice ? Number(form.oldPrice) : null,
      validUntil: form.validUntil,
      image: form.image,
      theme: form.theme,
      message: form.message.trim(),
      active: form.active,
    }
    if (editingId) {
      updateOffer(editingId, payload)
      push('تم حفظ تعديل العرض')
    } else {
      createOffer(payload)
      push('تمت إضافة العرض')
    }
    reset()
  }

  return (
    <>
      <div className="grid gap-5 lg:grid-cols-2">
        {/* ---------- form ---------- */}
        <Card className="lg:order-2">
          <SectionTitle
            title={editingId ? 'تعديل العرض' : 'عرض جديد'}
            subtitle="املأ البيانات وشوف المعاينة على الجنب لحظياً"
            icon={<Megaphone size={18} />}
            action={
              editingId ? (
                <Button size="sm" variant="ghost" onClick={reset}>
                  <X size={14} />
                  إلغاء التعديل
                </Button>
              ) : undefined
            }
          />
          <div className="space-y-4">
            <div>
              <span className="mb-1.5 block text-[13px] font-semibold text-ink-700">صورة العرض (اختياري)</span>
              <div className="flex items-center gap-3">
                <label className="inline-flex h-10 cursor-pointer items-center gap-2 rounded-xl bg-ink-900 px-4 text-[12.5px] font-bold text-white transition hover:bg-ink-800">
                  <Upload size={15} />
                  اختيار صورة
                  <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={onImage} />
                </label>
                {form.image && (
                  <Button size="sm" variant="ghost" onClick={() => set('image', '')}>
                    <X size={14} />
                    إزالة
                  </Button>
                )}
                <span className="text-[11.5px] text-ink-400">JPG أو PNG أو WebP، أقصى حجم 3MB.</span>
              </div>
            </div>

            <Field label="عنوان العرض" required error={errors.title}>
              <Input value={form.title} onChange={(e) => set('title', e.target.value)} placeholder="مثال: باقة الفحص الشامل" />
            </Field>
            <Field label="تفاصيل العرض">
              <Textarea value={form.details} onChange={(e) => set('details', e.target.value)} placeholder="مثال: كشف + تحاليل أساسية + تخطيط قلب" />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={`سعر العرض (${db.settings.currency})`} required error={errors.price}>
                <Input type="number" min={0} value={form.price} onChange={(e) => set('price', e.target.value)} />
              </Field>
              <Field label="السعر قبل الخصم (اختياري)">
                <Input type="number" min={0} value={form.oldPrice} onChange={(e) => set('oldPrice', e.target.value)} />
              </Field>
            </div>
            <Field label="ساري لحد (اختياري)">
              <Input type="date" min={toDateKey(new Date())} value={form.validUntil} onChange={(e) => set('validUntil', e.target.value)} />
            </Field>

            <div>
              <span className="mb-2 block text-[13px] font-semibold text-ink-700">شكل العرض — الألوان</span>
              <div className="flex flex-wrap gap-2">
                {(Object.keys(themeMeta) as OfferTheme[]).map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => set('theme', k)}
                    aria-pressed={form.theme === k}
                    className={`flex items-center gap-2 rounded-xl border px-3.5 py-2 text-[12.5px] font-bold transition ${
                      form.theme === k ? 'border-ink-900 bg-ink-50 text-ink-900' : 'border-ink-200 text-ink-500 hover:border-ink-300'
                    }`}
                  >
                    <span className={`size-3.5 rounded-full ${themeMeta[k].dot}`} />
                    {themeMeta[k].label}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-ink-50 p-4">
              <Field label="رسالة واتساب" hint="سيبها فاضية والرسالة هتتكتب أوتوماتيك من بيانات العرض. *غامق* و ~مشطوب~ شغالين زي واتساب.">
                <Textarea
                  rows={6}
                  value={form.message}
                  onChange={(e) => set('message', e.target.value)}
                  placeholder="سيبها فاضية والرسالة هتتكتب أوتوماتيك من بيانات العرض."
                />
              </Field>
              <Button size="sm" variant="secondary" className="mt-3" onClick={() => set('message', autoMessage)}>
                املأ بالنص التلقائي وعدّل عليه
              </Button>
            </div>

            <label className="flex cursor-pointer items-center gap-2.5 text-[13px] font-semibold text-ink-700">
              <input
                type="checkbox"
                checked={form.active}
                onChange={(e) => set('active', e.target.checked)}
                className="size-4 accent-brand-600"
              />
              العرض شغال
            </label>

            <Button size="lg" className="w-full" onClick={submit}>
              {editingId ? <Save size={17} /> : <Plus size={17} />}
              {editingId ? 'حفظ التعديل' : 'إضافة العرض'}
            </Button>
          </div>
        </Card>

        {/* ---------- previews ---------- */}
        <div className="space-y-5 lg:order-1">
          <div>
            <p className="mb-2 text-[13px] font-bold text-ink-700">شكل العرض في الموقع</p>
            <OfferCard offer={{ ...draft, image: form.image, theme: form.theme }} preview />
          </div>
          <div>
            <p className="mb-2 flex items-center gap-2 text-[13px] font-bold text-ink-700">
              <Users size={14} />
              هيوصل لـ {db.patients.length} عميل سابق
            </p>
            <div className="overflow-hidden rounded-3xl border border-ink-100">
              <div className="flex items-center gap-3 bg-[#075e54] px-4 py-3 text-white">
                <Avatar name={db.settings.name} size={38} />
                <div>
                  <p className="text-[13.5px] font-bold">{db.settings.name}</p>
                  <p className="text-[11px] text-white/70">حساب تجاري</p>
                </div>
              </div>
              <div className="bg-[#ece5dd] p-4">
                <div className="max-w-[92%] rounded-2xl rounded-tr-sm bg-white p-1.5 shadow-sm">
                  {form.image && <img src={form.image} alt="" className="mb-1.5 max-h-64 w-full rounded-xl object-cover" />}
                  <p
                    className="whitespace-pre-wrap break-words px-2 pb-1 text-[13px] leading-6 text-ink-800"
                    dangerouslySetInnerHTML={{ __html: renderWhatsAppText(shownMessage) }}
                  />
                  <p className="mt-1.5 px-2 text-left text-[10.5px] text-ink-400">الآن ✓✓</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ---------- offers list ---------- */}
      <div>
        <h3 className="mb-3 font-display text-lg font-extrabold text-ink-900">العروض المضافة</h3>
        {db.offers.length === 0 ? (
          <EmptyState icon={<Megaphone size={24} />} title="لا توجد عروض بعد" description="أضف أول عرض من النموذج أعلاه." />
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {db.offers.map((o) => {
              const st = offerStatus(o)
              const meta = offerStatusMeta[st]
              const sent = db.threads.filter((t) => t.subject === `عرض: ${o.title}`).length
              return (
                <Card key={o.id}>
                  <div className="flex items-start gap-3">
                    <span className={`flex size-16 shrink-0 items-center justify-center overflow-hidden rounded-2xl ${themeMeta[o.theme].soft}`}>
                      {o.image ? <img src={o.image} alt="" className="size-full object-cover" /> : <Megaphone size={22} />}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <p className="truncate text-[14.5px] font-extrabold text-ink-900">{o.title}</p>
                        <Badge tone={meta.tone}>{meta.label}</Badge>
                      </div>
                      <p className="mt-0.5 text-[12.5px] text-ink-600">
                        <span className="font-bold">{o.price > 0 ? money(o.price) : 'مجاناً'}</span>
                        {o.oldPrice ? <s className="mr-2 text-ink-400">{money(o.oldPrice)}</s> : null}
                      </p>
                      <p className="mt-1 text-[11.5px] text-ink-400">
                        {sent > 0 ? `اتبعت لـ ${sent} عميل` : 'لم يُرسل بعد'}
                        {o.validUntil ? ` · حتى ${formatFullDate(o.validUntil)}` : ''}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Button size="sm" onClick={() => setSendTarget(o)} disabled={st === 'expired'}>
                      <Send size={14} />
                      أرسل على واتساب
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => startEdit(o)}>
                      <Pencil size={14} />
                      تعديل
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => {
                        updateOffer(o.id, { active: !o.active })
                        push(o.active ? 'تم إيقاف العرض' : 'تم تشغيل العرض')
                      }}
                    >
                      {o.active ? <EyeOff size={14} /> : <Eye size={14} />}
                      {o.active ? 'إيقاف' : 'تشغيل'}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      aria-label="حذف العرض"
                      className="!text-rose-600"
                      onClick={() => {
                        if (confirm(`حذف العرض «${o.title}»؟`)) {
                          removeOffer(o.id)
                          if (editingId === o.id) reset()
                          push('تم حذف العرض')
                        }
                      }}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </Card>
              )
            })}
          </div>
        )}
      </div>

      <SendModal
        offer={sendTarget}
        onClose={() => setSendTarget(null)}
        onDone={() => setSendTarget(null)}
      />
    </>
  )
}

/* =============================================================== */
function SendModal({ offer, onClose, onDone }: { offer: Offer | null; onClose: () => void; onDone: () => void }) {
  const db = useDB()
  const { push } = useToast()
  const [picked, setPicked] = useState<Set<string> | null>(null)
  const [q, setQ] = useState('')
  const [sending, setSending] = useState(false)

  // أول فتح: كل المرضى محددين
  const selected = picked ?? new Set(db.patients.map((p) => p.id))
  const list = db.patients.filter((p) => !q.trim() || p.name.includes(q.trim()) || p.phone.includes(q.trim()))
  const message = offer ? offer.message.trim() || offerMessage(offer, db.settings) : ''

  function toggle(id: string) {
    const next = new Set(selected)
    if (next.has(id)) next.delete(id)
    else next.add(id)
    setPicked(next)
  }

  function close() {
    if (sending) return
    setPicked(null)
    setQ('')
    onClose()
  }

  async function sendAll() {
    if (!offer || sending) return
    const targets = db.patients.filter((p) => selected.has(p.id))
    if (targets.length === 0) return
    setSending(true)
    // طلب واحد للـ webhook لكل المستلمين — n8n هو اللي بيلف عليهم
    const res = await sendOfferWhatsApp(targets, message, offer.image || undefined, offer.title)
    setSending(false)
    if (res === 'failed') {
      push(offerFailureHint(getLastOfferFailure()), 'error')
      return
    }
    if (res === 'skipped') {
      push('الإرسال لأكتر من مريض محتاج السيرفر (/api) — شغّل vercel dev أو انشر المشروع', 'error')
      return
    }
    targets.forEach((p) => logOfferSent(offer.id, message, p))
    setPicked(null)
    setQ('')
    if (res === 'api') push(`تم إرسال العرض إلى n8n — هيوصل لـ ${targets.length} عميل`)
    else if (res === 'clipboard') push('الصورة اتنسخت — اضغط Ctrl+V في محادثة واتساب عشان تتبعت مع الرسالة')
    else push('اتفتحت المحادثة بالنص بس — واتساب ما بيقبلش إرفاق الصورة تلقائياً')
    onDone()
  }

  return (
    <Modal
      open={!!offer}
      onClose={close}
      title={offer ? `إرسال «${offer.title}»` : ''}
      subtitle="اختر المرضى اللي هيوصلهم العرض"
      size="md"
      footer={
        <>
          <Button variant="secondary" onClick={close} disabled={sending}>
            إلغاء
          </Button>
          <Button disabled={selected.size === 0 || sending} onClick={() => void sendAll()}>
            <Send size={16} />
            {sending ? 'جارٍ الإرسال...' : `إرسال (${selected.size})`}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="max-h-56 overflow-y-auto rounded-2xl bg-[#ece5dd] p-3">
          {offer?.image && <img src={offer.image} alt="" className="mb-2 max-h-40 w-full rounded-xl object-cover" />}
          <p
            className="whitespace-pre-wrap break-words rounded-xl bg-white p-3 text-[12.5px] leading-6 text-ink-800"
            dangerouslySetInnerHTML={{ __html: renderWhatsAppText(message) }}
          />
        </div>
        <div className="flex items-center gap-2">
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث بالاسم أو الرقم..." />
          <Button size="sm" variant="secondary" disabled={sending} onClick={() => setPicked(new Set(db.patients.map((p) => p.id)))}>
            الكل
          </Button>
          <Button size="sm" variant="ghost" disabled={sending} onClick={() => setPicked(new Set())}>
            لا أحد
          </Button>
        </div>
        <ul className="max-h-64 divide-y divide-ink-50 overflow-y-auto rounded-2xl border border-ink-100">
          {list.map((p) => (
            <li key={p.id}>
              <label className="flex cursor-pointer items-center gap-3 px-4 py-2.5 hover:bg-ink-50/60">
                <input
                  type="checkbox"
                  checked={selected.has(p.id)}
                  disabled={sending}
                  onChange={() => toggle(p.id)}
                  className="size-4 accent-brand-600"
                />
                <Avatar name={p.name} size={30} />
                <span className="flex-1 text-[13px] font-semibold text-ink-800">{p.name}</span>
                <span className="text-[11.5px] text-ink-400" dir="ltr">
                  {p.phone}
                </span>
              </label>
            </li>
          ))}
          {list.length === 0 && <li className="px-4 py-6 text-center text-[12.5px] text-ink-400">لا نتائج</li>}
        </ul>
      </div>
    </Modal>
  )
}

/* =============================================================== */
export function ReviewsManager() {
  const db = useDB()
  const { push } = useToast()
  const [status, setStatus] = useState('all')
  const [stars, setStars] = useState('all')
  const [drafts, setDrafts] = useState<Record<string, string>>({})

  const avg = db.reviews.length ? db.reviews.reduce((s, r) => s + r.rating, 0) / db.reviews.length : 0
  const dist = [5, 4, 3, 2, 1].map((n) => ({ n, c: db.reviews.filter((r) => r.rating === n).length }))
  const list = useMemo(
    () =>
      db.reviews
        .filter((r) => (status === 'all' ? true : r.status === status))
        .filter((r) => (stars === 'all' ? true : r.rating === Number(stars)))
        .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)),
    [db.reviews, status, stars],
  )

  return (
    <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
      <Card className="h-fit">
        <SectionTitle title="ملخص التقييمات" icon={<Star size={18} />} />
        <div className="flex items-end gap-3">
          <span className="font-display text-5xl font-extrabold text-ink-900">{avg ? avg.toFixed(1) : '—'}</span>
          <div className="pb-1.5">
            <Stars value={avg} size={16} />
            <p className="mt-1 text-[11.5px] text-ink-400">{db.reviews.length} تقييم</p>
          </div>
        </div>
        <div className="mt-4 space-y-2">
          {dist.map((d) => (
            <div key={d.n} className="flex items-center gap-2 text-[12px] text-ink-500">
              <span className="w-3 font-bold">{d.n}</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-ink-100">
                <div
                  className="h-full rounded-full bg-amber-400"
                  style={{ width: `${db.reviews.length ? (d.c / db.reviews.length) * 100 : 0}%` }}
                />
              </div>
              <span className="w-5 text-left">{d.c}</span>
            </div>
          ))}
        </div>
      </Card>

      <div className="space-y-4">
        <div className="flex flex-wrap gap-2">
          <Select value={status} onChange={(e) => setStatus(e.target.value)} className="!w-auto">
            <option value="all">كل الحالات</option>
            <option value="published">منشور</option>
            <option value="hidden">مخفي</option>
          </Select>
          <Select value={stars} onChange={(e) => setStars(e.target.value)} className="!w-auto">
            <option value="all">كل النجوم</option>
            {[5, 4, 3, 2, 1].map((n) => (
              <option key={n} value={n}>
                {n} نجوم
              </option>
            ))}
          </Select>
        </div>

        {list.length === 0 ? (
          <EmptyState icon={<Star size={24} />} title="لا توجد تقييمات مطابقة" description="التقييمات بتظهر هنا لما المرضى يقيّموا زياراتهم من بوابة المريض." />
        ) : (
          list.map((r) => {
            const doctor = db.doctors.find((d) => d.id === r.doctorId)
            const draft = drafts[r.id] ?? r.reply
            return (
              <Card key={r.id}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <Avatar name={r.patientName} size={42} />
                    <div>
                      <p className="text-[13.5px] font-extrabold text-ink-900">{r.patientName}</p>
                      <p className="text-[11.5px] text-ink-400">
                        {doctor?.name ?? '—'} · {formatStamp(r.createdAt)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Stars value={r.rating} />
                    <Badge tone={r.status === 'published' ? 'green' : 'slate'}>{r.status === 'published' ? 'منشور' : 'مخفي'}</Badge>
                  </div>
                </div>
                {r.comment && <p className="mt-3 text-[13px] leading-7 text-ink-700">{r.comment}</p>}

                <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                  <Input
                    value={draft}
                    onChange={(e) => setDrafts({ ...drafts, [r.id]: e.target.value })}
                    placeholder="اكتب ردّ المركز على التقييم..."
                  />
                  <Button
                    size="sm"
                    variant="secondary"
                    disabled={draft.trim() === r.reply}
                    onClick={() => {
                      updateReview(r.id, { reply: draft.trim() })
                      push('تم حفظ الرد')
                    }}
                  >
                    <Send size={14} />
                    حفظ الرد
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      updateReview(r.id, { status: r.status === 'published' ? 'hidden' : 'published' })
                      push(r.status === 'published' ? 'تم إخفاء التقييم من الموقع' : 'تم نشر التقييم')
                    }}
                  >
                    {r.status === 'published' ? <EyeOff size={14} /> : <Eye size={14} />}
                    {r.status === 'published' ? 'إخفاء' : 'نشر'}
                  </Button>
                </div>
              </Card>
            )
          })
        )}
      </div>
    </div>
  )
}
