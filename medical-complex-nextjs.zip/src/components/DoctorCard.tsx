import { Link } from 'react-router-dom'
import { Badge, Card } from './ui'
import { Avatar } from './ui'
import { MapPin, Star } from 'lucide-react'
import type { Doctor, Specialty } from '../lib/types'
import { money } from '../lib/format'
import { isDoctorOffNow } from '../lib/slots'
import { useAuth } from '../lib/auth'

export function DoctorCard({
  doctor,
  specialty,
  onBook,
}: {
  doctor: Doctor
  specialty?: Specialty
  onBook?: (doctor: Doctor) => void
}) {
  const off = isDoctorOffNow(doctor)
  const { session } = useAuth()
  const isDoctorUser = session?.role === 'doctor' // الطبيب مالوش صلاحية حجز
  return (
    <Card className="group flex flex-col overflow-hidden !p-0 transition duration-300 hover:-translate-y-1 hover:shadow-[0_18px_40px_-24px_rgba(16,40,45,0.45)]">
      <div className="relative h-44 w-full overflow-hidden bg-gradient-to-br from-brand-50 to-ink-50">
        <img
          src={doctor.image}
          alt={doctor.name}
          className="h-full w-full object-cover object-top transition duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-ink-950/55 to-transparent" />
        <span className="absolute right-3 top-3 rounded-lg bg-white/95 px-2.5 py-1 text-[11px] font-bold text-ink-800 shadow-sm">
          {specialty?.name}
        </span>
        {off && (
          <span className="absolute left-3 top-3 rounded-lg bg-rose-600 px-2.5 py-1 text-[11px] font-bold text-white shadow-sm">
            غير متاح حالياً
          </span>
        )}
        <span className="absolute bottom-3 right-3 flex items-center gap-1 rounded-lg bg-white/95 px-2 py-1 text-[11.5px] font-bold text-ink-900 shadow-sm">
          <Star size={12} className="fill-amber-400 text-amber-400" />
          {doctor.rating.toFixed(1)}
          <span className="font-medium text-ink-400">({doctor.reviews})</span>
        </span>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-[17px] font-extrabold text-ink-900">{doctor.name}</h3>
        <p className="mt-0.5 text-[12.5px] font-medium text-brand-700">{doctor.title}</p>

        <div className="mt-3 flex flex-wrap items-center gap-2 text-[11.5px] text-ink-500">
          <span className="flex items-center gap-1 rounded-lg bg-ink-50 px-2 py-1">
            <MapPin size={12} />
            {doctor.location}
          </span>
          <Badge tone="brand">{doctor.years} سنة خبرة</Badge>
        </div>

        <p className="mt-3 line-clamp-2 text-[12.5px] leading-6 text-ink-500">{doctor.bio}</p>

        <div className="mt-auto flex items-center justify-between gap-3 pt-4">
          <div>
            <p className="text-[10.5px] text-ink-400">سعر الكشف</p>
            <p className="font-display text-lg font-extrabold text-ink-900">{money(doctor.fee)}</p>
          </div>
          {isDoctorUser ? null : off ? (
            <span className="rounded-xl bg-ink-100 px-4 py-2.5 text-[12.5px] font-bold text-ink-400">غير متاح</span>
          ) : onBook ? (
            <button
              onClick={() => onBook(doctor)}
              className="rounded-xl bg-brand-600 px-4 py-2.5 text-[12.5px] font-bold text-white transition hover:bg-brand-700"
            >
              احجز الآن
            </button>
          ) : (
            <Link
              to={`/book?doctor=${doctor.id}`}
              className="rounded-xl bg-brand-600 px-4 py-2.5 text-[12.5px] font-bold text-white transition hover:bg-brand-700"
            >
              احجز الآن
            </Link>
          )}
        </div>
      </div>
    </Card>
  )
}
