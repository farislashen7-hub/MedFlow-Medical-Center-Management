import { useMemo, useState } from 'react'
import { MessageCircle, RefreshCw, Search, ShieldAlert } from 'lucide-react'
import { useDB } from '../lib/db'
import { useToast } from './Toast'
import { Badge, Button, Card, EmptyState, Field, Modal, Select, Textarea } from './ui'
import { formatStamp, relativeTime, waLink } from '../lib/format'
import {
  refreshComplaints,
  updateComplaint,
  useComplaints,
  type Complaint,
  type ComplaintCategory,
  type ComplaintPriority,
  type ComplaintStatus,
} from '../lib/complaints'

type Tone = 'brand' | 'green' | 'rose' | 'amber' | 'violet' | 'sky' | 'slate'

const complaintStatusMeta: Record<ComplaintStatus, { label: string; tone: Tone }> = {
  new: { label: 'جديدة', tone: 'rose' },
  in_review: { label: 'قيد المراجعة', tone: 'amber' },
  resolved: { label: 'تم الحل', tone: 'green' },
  rejected: { label: 'مرفوضة', tone: 'slate' },
}
const categoryLabel: Record<ComplaintCategory, string> = {
  doctor: 'دكتور',
  staff: 'موظف',
  waiting: 'انتظار',
  billing: 'فواتير',
  facility: 'مرافق',
  booking: 'حجز',
  other: 'أخرى',
}
const priorityMeta: Record<ComplaintPriority, { label: string; tone: Tone }> = {
  low: { label: 'منخفضة', tone: 'slate' },
  normal: { label: 'عادية', tone: 'sky' },
  high: { label: 'عالية', tone: 'rose' },
}
const sourceLabel = { whatsapp: 'واتساب', web: 'الموقع', manual: 'يدوي' }

export function ComplaintsHub() {
  const db = useDB()
  const { push } = useToast()
  const { items, signedIn, loaded, error } = useComplaints()
  const [filter, setFilter] = useState<'all' | ComplaintStatus>('all')
  const [query, setQuery] = useState('')
  const [open, setOpen] = useState<Complaint | null>(null)
  const [status, setStatus] = useState<ComplaintStatus>('new')
  const [priority, setPriority] = useState<ComplaintPriority>('normal')
  const [response, setResponse] = useState('')
  const [busy, setBusy] = useState(false)

  const counts = useMemo(() => {
    const c = { all: items.length, new: 0, in_review: 0, resolved: 0, rejected: 0 }
    items.forEach((x) => {
      c[x.status]++
    })
    return c
  }, [items])

  const list = items.filter(
    (c) =>
      (filter === 'all' || c.status === filter) &&
      (!query || `${c.patientName} ${c.patientPhone} ${c.subject} ${c.message}`.includes(query)),
  )
  const doctorName = (id: string | null) => (id ? db.doctors.find((d) => d.id === id)?.name : undefined)

  function openComplaint(c: Complaint) {
    setOpen(c)
    setStatus(c.status === 'new' ? 'in_review' : c.status)
    setPriority(c.priority)
    setResponse(c.adminResponse)
  }

  async function save() {
    if (!open) return
    setBusy(true)
    const r = await updateComplaint(open.id, { status, priority, adminResponse: response })
    setBusy(false)
    if (!r.ok) return push(r.error ?? 'تعذر الحفظ', 'error')
    push('تم حفظ الشكوى')
    setOpen(null)
  }

  if (!signedIn) {
    return (
      <div className="mt-5">
        <EmptyState
          icon={<ShieldAlert size={24} />}
          title="سجّل دخول الإدارة بحساب Supabase"
          description="الشكاوى محمية (RLS) وبتظهر بس لما تدخل بحساب إدارة موجود في Supabase Auth وجدول profiles."
        />
      </div>
    )
  }

  return (
    <div className="mt-5 space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        {(['all', 'new', 'in_review', 'resolved', 'rejected'] as const).map((k) => (
          <button
            key={k}
            onClick={() => setFilter(k)}
            className={`rounded-full px-3.5 py-1.5 text-[12.5px] font-bold ring-1 transition ${
              filter === k ? 'bg-ink-900 text-white ring-ink-900' : 'bg-white text-ink-600 ring-ink-200 hover:bg-ink-50'
            }`}
          >
            {k === 'all' ? 'الكل' : complaintStatusMeta[k].label} <span className="opacity-70">({counts[k]})</span>
          </button>
        ))}
        <div className="relative mr-auto min-w-[200px] flex-1 sm:max-w-xs">
          <Search size={15} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث بالاسم أو الرقم أو النص..."
            className="h-10 w-full rounded-xl border border-ink-200 bg-white pr-10 pl-3 text-[12.5px] outline-none focus:border-brand-400 focus:ring-4 focus:ring-brand-100"
          />
        </div>
        <Button variant="secondary" size="sm" onClick={() => void refreshComplaints()}>
          <RefreshCw size={14} />
          تحديث
        </Button>
      </div>

      {error && <p className="rounded-xl bg-rose-50 px-4 py-3 text-[12.5px] font-semibold text-rose-700 ring-1 ring-rose-200">{error}</p>}

      {!loaded ? (
        <p className="py-10 text-center text-[13px] text-ink-400">جارٍ التحميل...</p>
      ) : list.length === 0 ? (
        <EmptyState
          icon={<MessageCircle size={24} />}
          title="مفيش شكاوى"
          description="أي شكوى توصل من واتساب هتظهر هنا فوراً."
        />
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {list.map((c) => (
            <button key={c.id} onClick={() => openComplaint(c)} className="text-right">
              <Card className={`h-full transition hover:shadow-md ${c.status === 'new' ? 'ring-2 ring-rose-200' : ''}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-[14px] font-extrabold text-ink-900">{c.subject}</p>
                    <p className="mt-0.5 text-[12px] text-ink-500">
                      {c.patientName} —{' '}
                      <span dir="ltr" className="inline-block">
                        {c.patientPhone}
                      </span>
                    </p>
                  </div>
                  <span className="shrink-0 text-[11px] text-ink-400">{relativeTime(c.createdAt)}</span>
                </div>
                <p className="mt-2.5 line-clamp-2 text-[12.5px] leading-6 text-ink-600">{c.message}</p>
                <div className="mt-3 flex flex-wrap items-center gap-1.5">
                  <Badge tone={complaintStatusMeta[c.status].tone}>{complaintStatusMeta[c.status].label}</Badge>
                  <Badge tone={priorityMeta[c.priority].tone}>{priorityMeta[c.priority].label}</Badge>
                  <Badge tone="violet">{categoryLabel[c.category]}</Badge>
                  <Badge tone="green">{sourceLabel[c.source]}</Badge>
                  {doctorName(c.doctorId) && <Badge tone="brand">{doctorName(c.doctorId)}</Badge>}
                </div>
              </Card>
            </button>
          ))}
        </div>
      )}

      <Modal
        open={!!open}
        onClose={() => !busy && setOpen(null)}
        title={open?.subject ?? ''}
        subtitle={open ? `${open.patientName} — ${formatStamp(open.createdAt)}` : undefined}
        size="lg"
        footer={
          <>
            {open && (
              <a href={waLink(open.patientPhone, response.trim() || undefined)} target="_blank" rel="noreferrer">
                <Button variant="secondary">
                  <MessageCircle size={16} />
                  رد على واتساب
                </Button>
              </a>
            )}
            <Button variant="ghost" onClick={() => setOpen(null)} disabled={busy}>
              إغلاق
            </Button>
            <Button onClick={() => void save()} disabled={busy}>
              {busy ? 'جارٍ الحفظ...' : 'حفظ'}
            </Button>
          </>
        }
      >
        {open && (
          <div className="space-y-4">
            <div className="whitespace-pre-wrap rounded-xl bg-ink-50 px-4 py-3.5 text-[13px] leading-7 text-ink-800">{open.message}</div>
            <div className="flex flex-wrap gap-1.5 text-[12px] text-ink-500">
              <Badge tone="violet">{categoryLabel[open.category]}</Badge>
              <Badge tone="green">{sourceLabel[open.source]}</Badge>
              {doctorName(open.doctorId) && <Badge tone="brand">{doctorName(open.doctorId)}</Badge>}
              <span dir="ltr">{open.patientPhone}</span>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="الحالة">
                <Select value={status} onChange={(e) => setStatus(e.target.value as ComplaintStatus)}>
                  {(Object.keys(complaintStatusMeta) as ComplaintStatus[]).map((s) => (
                    <option key={s} value={s}>
                      {complaintStatusMeta[s].label}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="الأولوية">
                <Select value={priority} onChange={(e) => setPriority(e.target.value as ComplaintPriority)}>
                  {(Object.keys(priorityMeta) as ComplaintPriority[]).map((p) => (
                    <option key={p} value={p}>
                      {priorityMeta[p].label}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            <Field label="رد الإدارة">
              <Textarea rows={4} value={response} onChange={(e) => setResponse(e.target.value)} placeholder="اكتب الرد أو ملاحظات المتابعة..." />
            </Field>
          </div>
        )}
      </Modal>
    </div>
  )
}
