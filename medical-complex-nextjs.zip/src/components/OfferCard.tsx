import { Link } from 'react-router-dom'
import { Clock, ImageOff, Tag } from 'lucide-react'
import { formatFullDate, money } from '../lib/format'
import type { Offer, OfferTheme } from '../lib/types'
import { useAuth } from '../lib/auth'

export const themeMeta: Record<OfferTheme, { label: string; soft: string; btn: string; dot: string }> = {
  brand: { label: 'كلاسيك', soft: 'bg-brand-50 text-brand-700', btn: 'bg-brand-600 hover:bg-brand-700 text-white', dot: 'bg-brand-600' },
  amber: { label: 'ذهبي', soft: 'bg-amber-50 text-amber-700', btn: 'bg-amber-500 hover:bg-amber-600 text-ink-950', dot: 'bg-amber-500' },
  violet: { label: 'بنفسجي', soft: 'bg-violet-50 text-violet-700', btn: 'bg-violet-600 hover:bg-violet-700 text-white', dot: 'bg-violet-600' },
  rose: { label: 'وردي', soft: 'bg-rose-50 text-rose-700', btn: 'bg-rose-600 hover:bg-rose-700 text-white', dot: 'bg-rose-600' },
}

type OfferView = Pick<Offer, 'title' | 'details' | 'price' | 'oldPrice' | 'validUntil' | 'image' | 'theme'>

/** نفس الكارت اللي بيظهر للمرضى في الموقع — مع وضع معاينة للإدارة */
export function OfferCard({ offer, preview = false }: { offer: OfferView; preview?: boolean }) {
  const { session } = useAuth()
  const t = themeMeta[offer.theme]
  const price = offer.price > 0 ? money(offer.price) : 'مجاناً'
  const cta = `${t.btn} inline-flex h-10 items-center justify-center rounded-xl px-5 text-[13px] font-bold transition`

  return (
    <article className="overflow-hidden rounded-3xl border border-ink-100 bg-white shadow-sm">
      <div className={`relative h-44 ${t.soft}`}>
        {offer.image ? (
          <img src={offer.image} alt={offer.title} className="size-full object-cover" />
        ) : (
          <div className="flex size-full items-center justify-center opacity-50">
            <ImageOff size={34} />
          </div>
        )}
        <span className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-ink-900 px-3 py-1 text-[11.5px] font-bold text-white">
          <Tag size={12} />
          عرض
        </span>
      </div>
      <div className="p-5">
        <h3 className="font-display text-[17px] font-extrabold text-ink-900">{offer.title || 'عنوان العرض'}</h3>
        {offer.details && <p className="mt-1.5 text-[12.5px] leading-6 text-ink-500">{offer.details}</p>}
        <div className="mt-3 flex items-baseline gap-2">
          <span className="font-display text-xl font-extrabold text-ink-900">{price}</span>
          {offer.oldPrice ? <s className="text-[12.5px] text-ink-400">{money(offer.oldPrice)}</s> : null}
        </div>
        {offer.validUntil && (
          <p className="mt-1.5 flex items-center gap-1.5 text-[11.5px] text-ink-400">
            <Clock size={12} />
            ساري حتى {formatFullDate(offer.validUntil)}
          </p>
        )}
        <div className="mt-4">
          {preview ? (
            <span className={cta}>+ احجز الآن</span>
          ) : session?.role === 'doctor' ? null : (
            <Link to="/book" className={cta}>
              + احجز الآن
            </Link>
          )}
        </div>
      </div>
    </article>
  )
}
