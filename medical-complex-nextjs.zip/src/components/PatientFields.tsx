import { Field, Input, Select } from './ui'
import { ageFrom, formatStamp, isValidPhone, normalizePhone } from '../lib/format'
import { PHONE_HINT } from '../lib/phone'

/**
 * بيانات المريض الجديد (مشتركة بين صفحة التسجيل وصفحة الحجز).
 * أي مريض جديد لازم يدخل البيانات دي قبل ما يتسجل.
 */
export const BLOOD_TYPES = ['غير محدد', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
export const RELATIONS = ['الأب', 'الأم', 'الزوج', 'الزوجة', 'الأخ', 'الأخت', 'الابن', 'الابنة', 'صديق', 'أخرى']

export interface PatientFormState {
  nationalId: string
  birthDate: string
  gender: 'male' | 'female'
  bloodType: string
  allergies: string
  chronic: string
  insurance: string
  address: string
  emergencyName: string
  emergencyRelation: string
  emergencyPhone: string
}

export const emptyPatientForm = (): PatientFormState => ({
  nationalId: '',
  birthDate: '',
  gender: 'male',
  bloodType: 'غير محدد',
  allergies: '',
  chronic: '',
  insurance: '',
  address: '',
  emergencyName: '',
  emergencyRelation: 'الأب',
  emergencyPhone: '',
})

/** أرقام عربية/فارسية -> لاتينية (للهوية وتاريخ الميلاد) */
export const toLatin = (v: string) =>
  v.replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))

export const todayKey = () => new Date().toISOString().slice(0, 10)

/** يرجع رسالة الخطأ (أو null) + القيم بعد التنظيف جاهزة لـ createPatient */
export interface PatientValues {
  nationalId: string
  birthDate: string
  gender: 'male' | 'female'
  bloodType: string
  allergies: string
  chronic: string
  insurance: string
  address: string
  emergency?: { name: string; relation: string; phone: string }
}

export function validatePatientForm(form: PatientFormState): { error: string | null; values?: PatientValues } {
  const nationalId = toLatin(form.nationalId).trim()
  const birthDate = toLatin(form.birthDate).trim()
  if (!/^[A-Za-z0-9]{6,20}$/.test(nationalId)) return { error: 'رقم الهوية غير صحيح (6 إلى 20 رقماً أو حرفاً).' }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(birthDate) || birthDate > todayKey() || birthDate < '1900-01-01') {
    return { error: 'يرجى إدخال تاريخ ميلاد صحيح.' }
  }
  if (form.emergencyPhone.trim() && !isValidPhone(form.emergencyPhone)) return { error: 'رقم جهة الطوارئ غير صحيح. ' + PHONE_HINT }
  if (form.emergencyName.trim() && !form.emergencyPhone.trim()) return { error: 'أدخل رقم جوال جهة الطوارئ.' }
  const hasEmergency = form.emergencyName.trim() && form.emergencyPhone.trim()
  return {
    error: null,
    values: {
      nationalId,
      birthDate,
      gender: form.gender,
      bloodType: form.bloodType,
      allergies: form.allergies,
      chronic: form.chronic,
      insurance: form.insurance,
      address: form.address,
      emergency: hasEmergency
        ? { name: form.emergencyName.trim(), relation: form.emergencyRelation, phone: normalizePhone(form.emergencyPhone) }
        : undefined,
    },
  }
}

function SubTitle({ children }: { children: string }) {
  return <h3 className="border-b border-ink-100 pb-2 pt-2 text-[12.5px] font-bold text-brand-700">{children}</h3>
}

interface Props {
  form: PatientFormState
  onChange: (patch: Partial<PatientFormState>) => void
  errors?: Record<string, string>
}

/** الأقسام: البيانات الشخصية + الطبية + العنوان وجهة الطوارئ + تاريخ الانضمام */
export function PatientFields({ form, onChange, errors = {} }: Props) {
  const age = form.birthDate ? ageFrom(form.birthDate) : null
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <SubTitle>البيانات الشخصية</SubTitle>
      </div>
      <Field label="رقم الهوية" required error={errors.patient}>
        <Input value={form.nationalId} onChange={(e) => onChange({ nationalId: e.target.value })} inputMode="numeric" dir="ltr" className="text-left" />
      </Field>
      <Field label="الجنس" required>
        <Select value={form.gender} onChange={(e) => onChange({ gender: e.target.value as 'male' | 'female' })}>
          <option value="male">ذكر</option>
          <option value="female">أنثى</option>
        </Select>
      </Field>
      <Field label="تاريخ الميلاد" required>
        <Input type="date" value={form.birthDate} max={todayKey()} min="1900-01-01" onChange={(e) => onChange({ birthDate: e.target.value })} dir="ltr" className="text-left" />
      </Field>
      <Field label="العمر" hint="يُحسب تلقائياً من تاريخ الميلاد">
        <Input value={age !== null && typeof age === 'number' && age >= 0 ? `${age} سنة` : ''} readOnly placeholder="—" className="bg-ink-50" />
      </Field>

      <div className="sm:col-span-2">
        <SubTitle>البيانات الطبية</SubTitle>
      </div>
      <Field label="فصيلة الدم">
        <Select value={form.bloodType} onChange={(e) => onChange({ bloodType: e.target.value })}>
          {BLOOD_TYPES.map((t) => (
            <option key={t}>{t}</option>
          ))}
        </Select>
      </Field>
      <Field label="التأمين">
        <Input value={form.insurance} onChange={(e) => onChange({ insurance: e.target.value })} placeholder="اسم شركة التأمين (إن وجد)" />
      </Field>
      <Field label="الحساسية">
        <Input value={form.allergies} onChange={(e) => onChange({ allergies: e.target.value })} placeholder="مثال: البنسلين (أو اتركه فارغاً)" />
      </Field>
      <Field label="الأمراض المزمنة">
        <Input value={form.chronic} onChange={(e) => onChange({ chronic: e.target.value })} placeholder="مثال: السكري (أو اتركه فارغاً)" />
      </Field>

      <div className="sm:col-span-2">
        <SubTitle>العنوان وجهة الطوارئ</SubTitle>
      </div>
      <Field label="العنوان" className="sm:col-span-2">
        <Input value={form.address} onChange={(e) => onChange({ address: e.target.value })} placeholder="المدينة — الحي — الشارع" />
      </Field>
      <Field label="اسم جهة الطوارئ">
        <Input value={form.emergencyName} onChange={(e) => onChange({ emergencyName: e.target.value })} />
      </Field>
      <Field label="صلة القرابة">
        <Select value={form.emergencyRelation} onChange={(e) => onChange({ emergencyRelation: e.target.value })}>
          {RELATIONS.map((r) => (
            <option key={r}>{r}</option>
          ))}
        </Select>
      </Field>
      <Field label="جوال جهة الطوارئ" className="sm:col-span-2">
        <Input value={form.emergencyPhone} onChange={(e) => onChange({ emergencyPhone: e.target.value })} placeholder="01xxxxxxxxx أو 05xxxxxxxx" dir="ltr" className="text-left" />
      </Field>
      <Field label="تاريخ الانضمام" hint="يُسجَّل تلقائياً" className="sm:col-span-2">
        <Input value={formatStamp(new Date().toISOString())} readOnly className="bg-ink-50" />
      </Field>
    </div>
  )
}
