import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  ArrowLeft,
  CalendarCheck,
  CalendarPlus,
  CheckCircle2,
  Clock,
  MessageCircle,
  ShieldCheck,
  Sparkles,
  Star,
  Stethoscope,
  TrendingUp,
  Users,
} from 'lucide-react'
import { PageShell } from '../components/Layout'
import { Badge, Button, Card } from '../components/ui'
import { DoctorCard } from '../components/DoctorCard'
import { OfferCard } from '../components/OfferCard'
import { Stars } from '../components/Stars'
import { offerStatus } from '../lib/offers'
import { useDB } from '../lib/db'
import { waLink } from '../lib/format'
import { getSpecialtyIcon } from '../lib/icons'
import { formatFullDate } from '../lib/format'

export default function Landing() {
  const db = useDB()
  const featuredDoctors = db.doctors.slice(0, 3)
  const activeOffers = db.offers.filter((o) => offerStatus(o) === 'active')
  const shownReviews = db.reviews
    .filter((r) => r.status === 'published')
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
    .slice(0, 6)
  const totalAppointments = db.appointments.length
  const avgRating =
    db.doctors.reduce((s, d) => s + d.rating, 0) / Math.max(1, db.doctors.length)

  return (
    <PageShell>
      {/* ---------------- HERO ---------------- */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -top-32 right-0 size-[420px] rounded-full bg-brand-200/40 blur-3xl" />
        <div className="pointer-events-none absolute top-40 -left-24 size-[360px] rounded-full bg-sky-200/30 blur-3xl" />

        <div className="grid items-center gap-10 py-12 lg:grid-cols-2 lg:py-20">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55 }}
          >
            <span className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-3.5 py-1.5 text-[12px] font-bold text-brand-700">
              <Sparkles size={14} />
              {db.settings.name}
            </span>

            <h1 className="mt-5 font-display text-[34px] leading-[1.25] font-extrabold text-ink-950 sm:text-5xl lg:text-[52px]">
              رعايتك تبدأ من
              <span className="relative mx-2 inline-block">
                <span className="relative z-10 text-brand-600">موعد أسهل</span>
                <span className="absolute inset-x-0 bottom-1 z-0 h-3 rounded bg-brand-200/60" />
              </span>
              <br />
              وتجربة عيادة أسرع
            </h1>

            <p className="mt-5 max-w-xl text-[15px] leading-8 text-ink-600">
              احجز موعدك مع أفضل الأطباء حسب التخصص، تابع نتائجك وملفك الطبي، واحصل على وصفتك
              الطبية وكل تحديثات العيادة مباشرة على واتساب — من مكان واحد.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link to="/book">
                <Button size="lg">
                  <CalendarPlus size={19} />
                  احجز موعدك الآن
                </Button>
              </Link>
              <Link to="/doctors">
                <Button size="lg" variant="secondary">
                  <Stethoscope size={18} />
                  تصفّح الأطباء
                </Button>
              </Link>
              <a
                href={waLink(db.settings.whatsapp || db.settings.phone, `أريد استفساراً عن الحجز في ${db.settings.name}`)}
                target="_blank"
                rel="noreferrer"
                className="inline-flex h-13 items-center gap-2.5 rounded-xl bg-[#25D366] px-6 text-[15px] font-bold text-ink-950 transition hover:bg-[#1eb958]"
              >
                <MessageCircle size={18} />
                استفسر عبر واتساب
              </a>
            </div>

            <div className="mt-9 flex flex-wrap items-center gap-x-7 gap-y-3">
              {[
                { icon: CalendarCheck, label: `${totalAppointments}+ موعد منجز` },
                { icon: Users, label: `${db.patients.length * 412}+ مسجل في المنصة` },
                { icon: Star, label: `تقييم ${avgRating.toFixed(1)} من 5` },
              ].map((s) => (
                <div key={s.label} className="flex items-center gap-2 text-[13px] font-semibold text-ink-600">
                  <s.icon size={16} className="text-brand-600" />
                  {s.label}
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative"
          >
            <div className="overflow-hidden rounded-[28px] border border-ink-100 shadow-[0_30px_70px_-40px_rgba(11,18,21,0.6)]">
              <img src="/images/hero.jpg" alt={db.settings.name} className="h-[340px] w-full object-cover sm:h-[430px]" />
            </div>

            <div className="animate-floaty absolute -bottom-6 -left-3 rounded-2xl border border-ink-100 bg-white p-4 shadow-xl sm:-left-8">
              <div className="flex items-center gap-3">
                <span className="flex size-11 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                  <CalendarCheck size={22} />
                </span>
                <div>
                  <p className="text-[11.5px] text-ink-500">موعدك القادم</p>
                  <p className="text-[13px] font-bold text-ink-900">
                    {formatFullDate(new Date().toISOString().slice(0, 10))}
                  </p>
                </div>
              </div>
            </div>

            <div className="absolute -top-4 right-4 rounded-2xl border border-ink-100 bg-white px-4 py-3 shadow-xl">
              <p className="text-[11px] text-ink-500">رضا المرضى</p>
              <p className="font-display text-xl font-extrabold text-brand-600">98%</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ---------------- SPECIALTIES ---------------- */}
      <section className="py-16" id="specialties">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="text-[12px] font-bold tracking-widest text-brand-600">التخصصات</span>
            <h2 className="mt-2 font-display text-3xl font-extrabold text-ink-950">
              اختر التخصص المناسب لاشتكاك
            </h2>
            <p className="mt-2 max-w-xl text-[14px] leading-7 text-ink-500">
              ثم اختر الطبيب المناسب والموعد الملائم — كل ذلك بثلاث خطوات فقط دون انتظار.
            </p>
          </div>
          <Link to="/specialties" className="hidden sm:block">
            <Button variant="secondary">
              عرض كل التخصصات
              <ArrowLeft size={16} />
            </Button>
          </Link>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {db.specialties.slice(0, 8).map((sp, i) => {
            const Icon = getSpecialtyIcon(sp.icon)
            const count = db.doctors.filter((d) => d.specialtyId === sp.id).length
            return (
              <motion.div
                key={sp.id}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
              >
                <Link to={`/book?specialty=${sp.id}`} className="block h-full">
                  <Card className="group h-full transition duration-300 hover:-translate-y-1 hover:border-brand-200 hover:shadow-[0_18px_38px_-26px_rgba(16,40,45,0.5)]">
                    <span
                      className="flex size-12 items-center justify-center rounded-2xl text-white transition group-hover:scale-110"
                      style={{ background: sp.color }}
                    >
                      <Icon size={22} />
                    </span>
                    <h3 className="mt-4 font-display text-[16px] font-extrabold text-ink-900">{sp.name}</h3>
                    <p className="mt-1 text-[11.5px] font-medium uppercase tracking-wide text-ink-400">
                      {sp.nameEn}
                    </p>
                    <p className="mt-2.5 line-clamp-2 text-[12.5px] leading-6 text-ink-500">{sp.description}</p>
                    <p className="mt-4 flex items-center gap-1.5 text-[12px] font-bold text-brand-700">
                      <Users size={13} />
                      {count} طبيب متخصص
                    </p>
                  </Card>
                </Link>
              </motion.div>
            )
          })}
        </div>
      </section>

      {/* ---------------- HOW IT WORKS ---------------- */}
      <section className="rounded-[28px] bg-ink-950 px-6 py-14 text-white sm:px-12">
        <div className="text-center">
          <span className="text-[12px] font-bold tracking-widest text-brand-300">ثلاث خطوات فقط</span>
          <h2 className="mt-2 font-display text-3xl font-extrabold">كيف تحجز موعدك؟</h2>
        </div>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            {
              n: '1',
              icon: Stethoscope,
              title: 'حدّد التخصص',
              text: 'اختر التخصص الطبي المناسب لحالتك من بين تخصصات العيادة.',
            },
            {
              n: '2',
              icon: Users,
              title: 'اختر طبيبك وموعدك',
              text: 'تصفّح الأطباء المتاحين في التخصص، وشاهد الأوقات الفارغة لحظة بلحظة.',
            },
            {
              n: '3',
              icon: CheckCircle2,
              title: 'أكّد بياناتك',
              text: 'أدخل اسمك ورقم جوالك، واحصل على تأكيد فوري عبر واتساب.',
            },
          ].map((s) => (
            <div key={s.n} className="rounded-2xl border border-ink-800 bg-ink-900/60 p-6">
              <div className="flex items-center gap-3">
                <span className="flex size-11 items-center justify-center rounded-xl bg-brand-600 text-white">
                  <s.icon size={20} />
                </span>
                <span className="font-display text-3xl font-extrabold text-ink-700">0{s.n}</span>
              </div>
              <h3 className="mt-4 font-display text-lg font-extrabold">{s.title}</h3>
              <p className="mt-2 text-[13px] leading-7 text-ink-400">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ---------------- FEATURES ---------------- */}
      <section className="py-16">
        <div className="grid gap-6 lg:grid-cols-3">
          {[
            {
              icon: ShieldCheck,
              title: 'ملفات طبية آمنة',
              text: 'سجل كامل لكل مريض: تاريخ المواعيد، الروشتات، الحساسية والأمراض المزمنة.',
            },
            {
              icon: MessageCircle,
              title: 'متابعة عبر واتساب',
              text: 'تذكيرات المواعيد، تأكيد الحجز، وتحويل المحادثة لموظف بشري عند الحاجة.',
            },
            {
              icon: TrendingUp,
              title: 'تقارير وإحصائيات',
              text: 'لوحة إدارة متكاملة تقيس أداء الأطباء والعيادة وتكشف فرص النمو.',
            },
          ].map((f) => (
            <Card key={f.title} className="flex gap-4">
              <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-brand-50 text-brand-700">
                <f.icon size={22} />
              </span>
              <div>
                <h3 className="font-display text-[16px] font-extrabold text-ink-900">{f.title}</h3>
                <p className="mt-1.5 text-[13px] leading-7 text-ink-500">{f.text}</p>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* ---------------- OFFERS ---------------- */}
      {activeOffers.length > 0 && (
        <section className="pb-16">
          <span className="text-[12px] font-bold tracking-widest text-brand-600">عروض خاصة</span>
          <h2 className="mt-2 font-display text-3xl font-extrabold text-ink-950">عروض {db.settings.name}</h2>
          <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {activeOffers.map((o) => (
              <OfferCard key={o.id} offer={o} />
            ))}
          </div>
        </section>
      )}

      {/* ---------------- REVIEWS ---------------- */}
      {shownReviews.length > 0 && (
        <section className="pb-16">
          <span className="text-[12px] font-bold tracking-widest text-brand-600">آراء العملاء</span>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 className="mt-2 font-display text-3xl font-extrabold text-ink-950">ماذا يقول مرضانا</h2>
            <Link to="/reviews" className="text-[13px] font-bold text-brand-700 transition hover:text-brand-900">
              كل الآراء ←
            </Link>
          </div>
          <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {shownReviews.map((r) => (
              <Card key={r.id}>
                <Stars value={r.rating} />
                <p className="mt-3 text-[13.5px] leading-7 text-ink-700">{r.comment}</p>
                <p className="mt-3 text-[12.5px] font-bold text-ink-900">{r.patientName}</p>
                {r.reply && (
                  <p className="mt-3 rounded-xl bg-brand-50 px-3.5 py-2.5 text-[12px] leading-6 text-brand-800">
                    رد المركز: {r.reply}
                  </p>
                )}
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* ---------------- DOCTORS ---------------- */}
      <section className="pb-16">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="text-[12px] font-bold tracking-widest text-brand-600">فريق العيادة</span>
            <h2 className="mt-2 font-display text-3xl font-extrabold text-ink-950">أطباء معتمدون</h2>
          </div>
          <Link to="/doctors" className="hidden sm:block">
            <Button variant="secondary">
              كل الأطباء
              <ArrowLeft size={16} />
            </Button>
          </Link>
        </div>

        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {featuredDoctors.map((d) => (
            <DoctorCard
              key={d.id}
              doctor={d}
              specialty={db.specialties.find((s) => s.id === d.specialtyId)}
            />
          ))}
        </div>
      </section>

      {/* ---------------- CTA ---------------- */}
      <section className="overflow-hidden rounded-[28px] bg-gradient-to-l from-brand-700 to-brand-500 px-6 py-12 text-white sm:px-12">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <div>
            <Badge tone="dark" className="!bg-white/15 !text-white !ring-white/25">
              <Clock size={12} />
              متاحون يومياً 8 صباحاً — 10 مساءً
            </Badge>
            <h2 className="mt-4 font-display text-3xl font-extrabold">جاهز لحجز موعدك؟</h2>
            <p className="mt-2 max-w-lg text-[14px] leading-7 text-brand-50/90">
              أنشئ حسابك برقم جوالك، احجز في أقل من دقيقة، وتابع كل تفاصيل رعايتك من مكان واحد.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link to="/register">
              <Button size="lg" variant="dark">
                إنشاء حساب مجاني
              </Button>
            </Link>
            <Link to="/book">
              <Button size="lg" variant="secondary" className="!border-white/40 !bg-white/15 !text-white hover:!bg-white/25">
                حجز كزائر
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </PageShell>
  )
}
