import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, Search, Users } from 'lucide-react'
import { PageShell } from '../components/Layout'
import { Card, Input } from '../components/ui'
import { useDB } from '../lib/db'
import { getSpecialtyIcon } from '../lib/icons'

export default function Specialties() {
  const db = useDB()
  const [query, setQuery] = useState('')

  const filtered = db.specialties.filter(
    (s) =>
      s.name.includes(query) ||
      s.nameEn.toLowerCase().includes(query.toLowerCase()) ||
      s.description.includes(query),
  )

  return (
    <PageShell className="py-10">
      <div className="text-center">
        <span className="text-[12px] font-bold tracking-widest text-brand-600">دليل العيادة</span>
        <h1 className="mt-2 font-display text-4xl font-extrabold text-ink-950">التخصصات الطبية</h1>
        <p className="mx-auto mt-3 max-w-2xl text-[14.5px] leading-8 text-ink-500">
          اختر التخصص المناسب ثم تصفّح الأطباء المتاحين فيه وحدّد الموعد الملائم لك.
        </p>
      </div>

      <div className="mx-auto mt-8 max-w-md">
        <div className="relative">
          <Search size={17} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-400" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث عن تخصص..."
            className="pr-11"
          />
        </div>
      </div>

      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((sp, i) => {
          const Icon = getSpecialtyIcon(sp.icon)
          const doctors = db.doctors.filter((d) => d.specialtyId === sp.id)
          return (
            <motion.div
              key={sp.id}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.4, delay: i * 0.04 }}
            >
              <Card className="group h-full">
                <div className="flex items-start gap-4">
                  <span
                    className="flex size-13 shrink-0 items-center justify-center rounded-2xl text-white shadow-sm transition group-hover:scale-105"
                    style={{ background: sp.color }}
                  >
                    <Icon size={24} />
                  </span>
                  <div className="min-w-0">
                    <h2 className="font-display text-[17px] font-extrabold text-ink-900">{sp.name}</h2>
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">
                      {sp.nameEn}
                    </p>
                  </div>
                </div>
                <p className="mt-4 text-[13px] leading-7 text-ink-500">{sp.description}</p>
                <div className="mt-5 flex items-center justify-between border-t border-ink-100 pt-4">
                  <span className="flex items-center gap-1.5 text-[12.5px] font-bold text-ink-600">
                    <Users size={14} className="text-brand-600" />
                    {doctors.length} طبيب
                  </span>
                  <Link
                    to={`/book?specialty=${sp.id}`}
                    className="flex items-center gap-1 text-[12.5px] font-bold text-brand-700 transition hover:gap-2"
                  >
                    احجز في هذا التخصص
                    <ArrowLeft size={15} />
                  </Link>
                </div>
              </Card>
            </motion.div>
          )
        })}
      </div>

      {filtered.length === 0 && (
        <p className="mt-16 text-center text-sm text-ink-500">لا توجد نتائج مطابقة لبحثك.</p>
      )}
    </PageShell>
  )
}
