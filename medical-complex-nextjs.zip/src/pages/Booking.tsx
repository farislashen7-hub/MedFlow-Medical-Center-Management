import { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ArrowLeft,
  ArrowRight,
  CalendarCheck,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Clock,
  MapPin,
  Phone,
  RefreshCw,
  Stethoscope,
  User,
} from 'lucide-react'
import { PageShell } from '../components/Layout'
import { Badge, Button, Card, Field, Input, Textarea } from '../components/ui'
import { useToast } from '../components/Toast'
import { useDB, createAppointment, findPatientByNationalId, findPatientByPhone } from '../lib/db'
import { useAuth } from '../lib/auth'
import { getSpecialtyIcon } from '../lib/icons'
import { generateSlots, isDoctorOffNow, isDoctorOffOn } from '../lib/slots'
import { formatFullDate, formatTime, isValidPhone, money, normalizePhone, toDateKey, uid, AR_DAYS_SHORT, AR_MONTHS } from '../lib/format'
import { PHONE_HINT } from '../lib/phone'
import { PatientFields, emptyPatientForm, validatePatientForm } from '../components/PatientFields'
import type { PatientFormState } from '../components/PatientFields'
import { submitBooking } from '../lib/bookingApi'
import type { AppointmentType } from '../lib/types'

const steps = [
  { id: 1, label: 'التخصص', icon: Stethoscope },
  { id: 2, label: 'الطبيب', icon: User },
  { id: 3, label: 'الموعد', icon: CalendarDays },
  { id: 4, label: 'البيانات', icon: CheckCircle2 },
]

export default function Booking() {
  const db = useDB()
  const { session, registerPatient } = useAuth()
  const { push } = useToast()
  const navigate = useNavigate()
  const [params] = useSearchParams()

  const followupId = params.get('followup')
  const followup = db.appointments.find((a) => a.id === followupId)

  const loggedPatient = session?.role === 'patient' ? db.patients.find((p) => p.id === session.id) : undefined

  const [step, setStep] = useState(1)
  const [specialtyId, setSpecialtyId] = useState<string>(params.get('specialty') || followup?.specialtyId || '')
  const [doctorId, setDoctorId] = useState<string>(params.get('doctor') || followup?.doctorId || '')
  const [date, setDate] = useState('')
  const [time, setTime] = useState('')
  const [form, setForm] = useState({
    name: loggedPatient?.name || '',
    phone: loggedPatient?.phone || '',
    reason: followup?.reason || '',
    type: (followup ? 'followup' : 'new') as AppointmentType, // إعادة حجز = متابعة دايماً (كان بيورّث نوع الموعد القديم فيروح لـ cli-booking)
  })
  // بيانات المريض الجديد (بتظهر بس لو الرقم مش مسجل عندنا)
  const [pf, setPf] = useState<PatientFormState>(emptyPatientForm())
  const [extra, setExtra] = useState({ email: '', password: '' })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [sending, setSending] = useState(false)
  const [done, setDone] = useState<null | { id: string; name: string; date: string; time: string; doctor: string; created: boolean }>(null)

  useEffect(() => {
    if (doctorId && !specialtyId) {
      const doc = db.doctors.find((d) => d.id === doctorId)
      if (doc) setSpecialtyId(doc.specialtyId)
    }
  }, [doctorId, specialtyId, db.doctors])

  const phoneOk = isValidPhone(form.phone)
  const existingPatient = !loggedPatient && phoneOk ? findPatientByPhone(normalizePhone(form.phone)) : undefined
  // مريض جديد = رقم صحيح ومفيش ملف بيه -> لازم يسجّل بياناته ويتعمل له ملف طبي
  const isNewPatient = !loggedPatient && phoneOk && !existingPatient
  const specialty = db.specialties.find((s) => s.id === specialtyId)
  const doctor = db.doctors.find((d) => d.id === doctorId)
  const doctors = db.doctors.filter((d) => d.specialtyId === specialtyId && d.active)

  const dateOptions = useMemo(() => {
    if (!doctor) return []
    const now = new Date()
    const out: { key: string; weekday: string; day: number; month: string; working: boolean }[] = []
    for (let i = 1; i <= 21; i++) {
      const d = new Date(now)
      d.setDate(d.getDate() + i)
      out.push({
        key: toDateKey(d),
        weekday: AR_DAYS_SHORT[d.getDay()],
        day: d.getDate(),
        month: AR_MONTHS[d.getMonth()],
        working: doctor.days.includes(d.getDay()) && !isDoctorOffOn(doctor, toDateKey(d)),
      })
    }
    return out
  }, [doctor])

  const slots = useMemo(() => {
    if (!doctor || !date) return []
    return generateSlots(doctor, date, db.appointments)
  }, [doctor, date, db.appointments])

  function pickSpecialty(id: string) {
    setSpecialtyId(id)
    setDoctorId('')
    setDate('')
    setTime('')
    setStep(2)
  }

  function pickDoctor(id: string) {
    setDoctorId(id)
    setDate('')
    setTime('')
    setStep(3)
  }

  function validateForm() {
    const e: Record<string, string> = {}
    if (!form.name.trim()) e.name = 'يرجى إدخال الاسم الكامل'
    if (!isValidPhone(form.phone)) e.phone = PHONE_HINT
    if (!form.reason.trim()) e.reason = 'يرجى كتابة سبب الزيارة'
    if (isNewPatient) {
      if (extra.email.trim() && !/^\S+@\S+\.\S+$/.test(extra.email.trim())) e.email = 'البريد الإلكتروني غير صحيح'
      const checked = validatePatientForm(pf)
      if (checked.error) e.patient = checked.error
      else if (checked.values?.nationalId && findPatientByNationalId(checked.values.nationalId)) {
        e.patient = 'رقم الهوية مسجل مسبقاً بملف آخر — ادخل برقم جوالك المسجل أو تواصل مع الاستقبال.'
      }
      if (extra.password.length < 6) e.password = 'كلمة المرور 6 أحرف على الأقل'
    }
    setErrors(e)
    return Object.keys(e).length === 0
  }

  async function confirmBooking() {
    if (sending || !validateForm() || !doctor || !specialty) return
    const cleanPhone = normalizePhone(form.phone)
    const apptId = uid('apt')

    // bookingApi: المتصفح -> Supabase مباشرة (publishable key + RLS) ثم /api/n8n -> n8n (appointment.created)
    setSending(true)
    const remote = await submitBooking({
      appointmentId: apptId,
      patientName: form.name.trim(),
      patientPhone: cleanPhone,
      doctorId: doctor.id,
      specialtyId: specialty.id,
      doctorName: doctor.name,
      specialtyName: specialty.name,
      date,
      time,
      type: form.type,
      reason: form.reason.trim(),
    })
    setSending(false)
    if (!remote.ok && remote.reason === 'invalid_phone') {
      setErrors({ phone: PHONE_HINT })
      return
    }
    if (!remote.ok && remote.reason === 'rate_limited') {
      push('محاولات كتير، جرّب بعد شوية')
      return
    }
    if (!remote.ok && remote.reason === 'slot_taken') {
      push('الموعد ده اتحجز لتوّه، اختار وقت تاني')
      setTime('')
      setStep(3)
      return
    }

    // مريض جديد: بنعمل له ملف (محلي + Supabase) وندخّله حسابه تلقائياً قبل تسجيل الموعد
    let patient = findPatientByPhone(cleanPhone)
    let created = false
    if (!patient) {
      const checked = validatePatientForm(pf)
      const reg = registerPatient(
        {
          name: form.name.trim(),
          phone: cleanPhone,
          password: extra.password,
          email: extra.email.trim(),
          ...checked.values,
        },
        { login: !session }, // لو الإدارة هي اللي بتحجز بنعمل الملف من غير ما نبدّل جلستها
      )
      if (!reg.ok) {
        push(reg.error || 'تعذر إنشاء ملف المريض', 'error')
        setErrors({ patient: reg.error || 'تعذر إنشاء ملف المريض' })
        return
      }
      patient = findPatientByPhone(cleanPhone)
      created = true
    }
    if (!patient) return
    const appt = createAppointment(
      {
        id: apptId,
        patientId: patient.id,
        patientName: form.name,
        patientPhone: cleanPhone,
        doctorId: doctor.id,
        specialtyId: specialty.id,
        date,
        time,
        type: form.type,
        reason: form.reason,
      },
      { name: form.name, role: 'patient' },
    )
    push(created ? 'تم إنشاء ملفك وتأكيد حجزك' : 'تم تأكيد حجزك بنجاح')
    setDone({
      id: appt.id,
      name: form.name,
      date,
      time,
      doctor: doctor.name,
      created,
    })
  }

  return (
    <PageShell className="py-8">
      {/* header */}
      <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <span className="text-[12px] font-bold tracking-widest text-brand-600">الحجز الإلكتروني</span>
          <h1 className="mt-2 font-display text-3xl font-extrabold text-ink-950">احجز موعدك في 4 خطوات</h1>
          <p className="mt-2 text-[13.5px] text-ink-500">
            اختر التخصص، ثم الطبيب، ثم الموعد، وأدخل بياناتك للتأكيد الفوري.
          </p>
        </div>
        {followup && (
          <Badge tone="amber">
            <RefreshCw size={12} />
            إعادة حجز — متابعة لـ: {followup.reason.slice(0, 24)}
          </Badge>
        )}
      </div>

      {/* stepper */}
      <div className="mb-7 overflow-x-auto scrollbar-thin">
        <div className="flex min-w-max items-center gap-2">
          {steps.map((s, i) => {
            const active = step === s.id
            const complete = step > s.id
            return (
              <div key={s.id} className="flex items-center gap-2">
                <button
                  onClick={() => {
                    if (s.id === 1) return setStep(1)
                    if (s.id === 2 && specialtyId) return setStep(2)
                    if (s.id === 3 && doctorId) return setStep(3)
                    if (s.id === 4 && doctorId && date && time) return setStep(4)
                  }}
                  className={`flex items-center gap-2 rounded-xl px-3 py-2 text-[12.5px] font-bold transition ${
                    active
                      ? 'bg-ink-900 text-white'
                      : complete
                        ? 'bg-brand-50 text-brand-700'
                        : 'bg-white text-ink-400 ring-1 ring-ink-100'
                  }`}
                >
                  <s.icon size={15} />
                  {s.label}
                </button>
                {i < steps.length - 1 && <ChevronRight size={15} className="text-ink-300" />}
              </div>
            )
          })}
        </div>
      </div>

      {done ? (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="mx-auto max-w-2xl text-center">
            <span className="mx-auto flex size-16 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600">
              <CheckCircle2 size={32} />
            </span>
            <h2 className="mt-5 font-display text-2xl font-extrabold text-ink-900">تم تأكيد موعدك بنجاح</h2>
            <p className="mt-2 text-[13.5px] text-ink-500">
              سنرسل تفاصيل الموعد إلى رقم جوالك عبر واتساب قبل الموعد بيوم.
            </p>

            <div className="mt-6 grid gap-3 rounded-2xl bg-ink-50 p-5 text-right sm:grid-cols-2">
              {[
                { l: 'اسم المريض', v: done.name },
                { l: 'الطبيب', v: done.doctor },
                { l: 'التاريخ', v: formatFullDate(done.date) },
                { l: 'الوقت', v: formatTime(done.time) },
                { l: 'رقم الحجز', v: done.id.toUpperCase() },
                { l: 'سعر الكشف', v: money(doctor?.fee ?? 0) },
              ].map((row) => (
                <div key={row.l}>
                  <p className="text-[11px] text-ink-400">{row.l}</p>
                  <p className="text-[13.5px] font-bold text-ink-800">{row.v}</p>
                </div>
              ))}
            </div>

            {done.created && (
              <p className="mt-4 rounded-xl bg-amber-50 px-4 py-3 text-[12.5px] font-semibold text-amber-800 ring-1 ring-amber-200">
                تم إنشاء ملفك الطبي. ادخل برقم جوالك وكلمة المرور التي اخترتها لمتابعة مواعيدك ووصفاتك.
              </p>
            )}

            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Button onClick={() => navigate('/patient')}>
                <CalendarCheck size={17} />
                الذهاب إلى ملف المريض
              </Button>
              <Button
                variant="secondary"
                onClick={() => {
                  setDone(null)
                  setStep(1)
                  setDoctorId('')
                  setDate('')
                  setTime('')
                  setForm({ ...form, reason: '' })
                }}
              >
                حجز موعد آخر
              </Button>
            </div>
          </Card>
        </motion.div>
      ) : (
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.25 }}
          >
            {/* STEP 1 — SPECIALTY */}
            {step === 1 && (
              <div>
                <h2 className="mb-4 font-display text-xl font-extrabold text-ink-900">١. ما التخصص المناسب لحالتك؟</h2>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  {db.specialties.map((sp) => {
                    const Icon = getSpecialtyIcon(sp.icon)
                    const count = db.doctors.filter((d) => d.specialtyId === sp.id && d.active).length
                    return (
                      <button
                        key={sp.id}
                        onClick={() => pickSpecialty(sp.id)}
                        className="group rounded-2xl border border-ink-100 bg-white p-5 text-right transition hover:-translate-y-1 hover:border-brand-300 hover:shadow-[0_18px_38px_-26px_rgba(16,40,45,0.5)]"
                      >
                        <span
                          className="flex size-12 items-center justify-center rounded-2xl text-white transition group-hover:scale-110"
                          style={{ background: sp.color }}
                        >
                          <Icon size={22} />
                        </span>
                        <p className="mt-4 font-display text-[16px] font-extrabold text-ink-900">{sp.name}</p>
                        <p className="mt-1 text-[11.5px] text-ink-400">{count} طبيب متخصص</p>
                      </button>
                    )
                  })}
                </div>
              </div>
            )}

            {/* STEP 2 — DOCTOR */}
            {step === 2 && (
              <div>
                <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                  <h2 className="font-display text-xl font-extrabold text-ink-900">
                    ٢. اختر الطبيب المناسب
                    {specialty && <span className="text-brand-600"> — {specialty.name}</span>}
                  </h2>
                  <Button variant="ghost" size="sm" onClick={() => setStep(1)}>
                    <ArrowRight size={15} />
                    تغيير التخصص
                  </Button>
                </div>

                {doctors.length === 0 ? (
                  <Card className="text-center text-sm text-ink-500">
                    لا يوجد أطباء متاحون في هذا التخصص حالياً.
                  </Card>
                ) : (
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {doctors.map((d) => (
                      <button
                        key={d.id}
                        onClick={() => pickDoctor(d.id)}
                        className="group flex gap-4 rounded-2xl border border-ink-100 bg-white p-4 text-right transition hover:-translate-y-1 hover:border-brand-300 hover:shadow-[0_18px_38px_-26px_rgba(16,40,45,0.5)]"
                      >
                        <img
                          src={d.image}
                          alt={d.name}
                          className="size-16 shrink-0 rounded-2xl object-cover object-top transition group-hover:scale-105"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="font-display text-[15px] font-extrabold text-ink-900">{d.name}</p>
                          <p className="text-[12px] font-medium text-brand-700">{d.title}</p>
                          <p className="mt-1.5 flex items-center gap-1 text-[11.5px] text-ink-500">
                            <MapPin size={12} />
                            {d.location}
                          </p>
                          <div className="mt-2 flex flex-wrap items-center gap-1.5">
                            <Badge tone="amber">★ {d.rating.toFixed(1)}</Badge>
                            <Badge tone="brand">{d.years} سنة</Badge>
                            {isDoctorOffNow(d) && <Badge tone="rose">غير متاح حالياً</Badge>}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* STEP 3 — DATE & TIME */}
            {step === 3 && doctor && (
              <div>
                <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                  <h2 className="font-display text-xl font-extrabold text-ink-900">
                    ٣. اختر الموعد المناسب
                    <span className="text-brand-600"> — {doctor.name}</span>
                  </h2>
                  <Button variant="ghost" size="sm" onClick={() => setStep(2)}>
                    <ArrowRight size={15} />
                    تغيير الطبيب
                  </Button>
                </div>

                {doctor.unavailable && (
                  <div className="mb-4 rounded-2xl border border-rose-200 bg-rose-50 p-4 text-[13px] leading-6 text-rose-800">
                    <p className="font-bold">الطبيب غير متاح حالياً — {doctor.unavailable.reason}</p>
                    <p className="text-[12px] text-rose-700">
                      {doctor.unavailable.until
                        ? `المواعيد مقفولة حتى ${formatFullDate(doctor.unavailable.until)}، وتقدر تحجز بعد كده.`
                        : 'المواعيد مقفولة لحد ما الطبيب يرجع. جرّب طبيب تاني أو ارجع بعدين.'}
                    </p>
                  </div>
                )}

                <div className="scrollbar-thin mb-5 flex gap-2 overflow-x-auto pb-2">
                  {dateOptions.map((d) => (
                    <button
                      key={d.key}
                      disabled={!d.working}
                      onClick={() => {
                        setDate(d.key)
                        setTime('')
                      }}
                      className={`flex min-w-[84px] shrink-0 flex-col items-center rounded-2xl border px-3 py-3 transition ${
                        !d.working
                          ? 'cursor-not-allowed border-ink-100 bg-ink-50 text-ink-300'
                          : date === d.key
                            ? 'border-brand-500 bg-brand-600 text-white shadow-lg shadow-brand-600/25'
                            : 'border-ink-100 bg-white text-ink-700 hover:border-brand-300'
                      }`}
                    >
                      <span className="text-[11px] font-semibold">{d.weekday}</span>
                      <span className="font-display text-xl font-extrabold">{d.day}</span>
                      <span className="text-[10px] opacity-75">{d.month}</span>
                    </button>
                  ))}
                </div>

                {date ? (
                  <>
                    <p className="mb-3 text-[13px] font-bold text-ink-700">
                      الأوقات المتاحة — {formatFullDate(date)}
                    </p>
                    <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-5 lg:grid-cols-7">
                      {slots.map((s) => (
                        <button
                          key={s.time}
                          disabled={!s.available}
                          onClick={() => {
                            setTime(s.time)
                            setStep(4)
                          }}
                          className={`rounded-xl border px-3 py-2.5 text-[12.5px] font-bold transition ${
                            !s.available
                              ? 'cursor-not-allowed border-ink-100 bg-ink-50 text-ink-300 line-through'
                              : time === s.time
                                ? 'border-brand-600 bg-brand-600 text-white'
                                : 'border-ink-100 bg-white text-ink-700 hover:border-brand-400 hover:text-brand-700'
                          }`}
                        >
                          {s.label}
                        </button>
                      ))}
                    </div>
                    {slots.every((s) => !s.available) && (
                      <p className="mt-4 text-[13px] text-ink-500">
                        لا توجد أوقات متاحة في هذا اليوم — اختر يوماً آخر.
                      </p>
                    )}
                  </>
                ) : (
                  <Card className="flex items-center gap-3 text-[13px] text-ink-500">
                    <CalendarDays size={18} className="text-brand-600" />
                    اختر اليوم المناسب من القائمة أعلاه لعرض الأوقات المتاحة.
                  </Card>
                )}
              </div>
            )}

            {/* STEP 4 — DETAILS */}
            {step === 4 && doctor && specialty && (
              <div className="grid gap-5 lg:grid-cols-[1.2fr_1fr]">
                <Card>
                  <h2 className="font-display text-xl font-extrabold text-ink-900">٤. أدخل بياناتك للتأكيد</h2>
                  <div className="mt-5 space-y-4">
                    <Field label="الاسم الكامل" required error={errors.name}>
                      <Input
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        placeholder="الاسم كما سيظهر في الحجز"
                      />
                    </Field>
                    <Field label="رقم الجوال" required error={errors.phone} hint="سنرسل تأكيد الحجز عبر واتساب على هذا الرقم — لو عندك ملف هنتعرف عليه تلقائياً">
                      <Input
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        placeholder="05xxxxxxxx"
                        dir="ltr"
                        className="text-left"
                      />
                    </Field>
                    {existingPatient && (
                      <p className="flex items-start gap-2 rounded-xl bg-emerald-50 px-4 py-3 text-[12.5px] font-semibold leading-6 text-emerald-800 ring-1 ring-emerald-200">
                        <CheckCircle2 size={16} className="mt-0.5 shrink-0" />
                        ملفك موجود عندنا باسم «{existingPatient.name}» — هنربط الحجز بيه.
                      </p>
                    )}
                    {isNewPatient && (
                      <div className="space-y-4 rounded-2xl bg-brand-50/50 p-4 ring-1 ring-brand-200">
                        <div>
                          <p className="flex items-center gap-2 text-[13px] font-extrabold text-brand-800">
                            <User size={15} />
                            مريض جديد — هنعمل لك ملف طبي
                          </p>
                          <p className="mt-1 text-[12px] leading-6 text-ink-500">
                            رقمك مش مسجل عندنا. املأ بياناتك مرة واحدة وهيتعمل ملفك وتدخل بيه بوابة المريض برقم جوالك وكلمة المرور.
                          </p>
                        </div>
                        <Field label="البريد الإلكتروني (اختياري)" error={errors.email}>
                          <Input
                            type="email"
                            value={extra.email}
                            onChange={(e) => setExtra({ ...extra, email: e.target.value })}
                            placeholder="name@example.com"
                            dir="ltr"
                            className="text-left"
                          />
                        </Field>
                        <PatientFields form={pf} onChange={(patch) => setPf((f) => ({ ...f, ...patch }))} errors={errors} />
                        <Field label="كلمة مرور حسابك" required error={errors.password} hint="تدخل بها بوابة المريض برقم جوالك">
                          <Input
                            type="password"
                            value={extra.password}
                            onChange={(e) => setExtra({ ...extra, password: e.target.value })}
                            placeholder="6 أحرف على الأقل"
                            dir="ltr"
                            className="text-left"
                          />
                        </Field>
                      </div>
                    )}
                    <Field label="نوع الزيارة">
                      <div className="grid grid-cols-3 gap-2">
                        {(
                          [
                            { id: 'new', label: 'زيارة جديدة' },
                            { id: 'followup', label: 'متابعة' },
                            { id: 'urgent', label: 'عاجلة' },
                          ] as { id: AppointmentType; label: string }[]
                        ).map((t) => (
                          <button
                            key={t.id}
                            type="button"
                            onClick={() => setForm({ ...form, type: t.id })}
                            className={`rounded-xl border px-3 py-2.5 text-[12.5px] font-bold transition ${
                              form.type === t.id
                                ? 'border-brand-600 bg-brand-50 text-brand-700'
                                : 'border-ink-200 bg-white text-ink-600 hover:border-brand-300'
                            }`}
                          >
                            {t.label}
                          </button>
                        ))}
                      </div>
                    </Field>
                    <Field label="سبب الزيارة" required error={errors.reason}>
                      <Textarea
                        value={form.reason}
                        onChange={(e) => setForm({ ...form, reason: e.target.value })}
                        placeholder="صف الأعراض التي تعاني منها بشكل مختصر"
                      />
                    </Field>

                    <div className="flex flex-wrap gap-3 pt-1">
                      <Button size="lg" onClick={confirmBooking} disabled={sending}>
                        <CheckCircle2 size={18} />
                        {sending ? 'جاري التأكيد…' : 'تأكيد الحجز'}
                      </Button>
                      <Button size="lg" variant="secondary" onClick={() => setStep(3)}>
                        <ArrowLeft size={17} />
                        رجوع
                      </Button>
                    </div>
                  </div>
                </Card>

                <div className="space-y-4">
                  <Card>
                    <h3 className="font-display text-[16px] font-extrabold text-ink-900">ملخص الحجز</h3>
                    <div className="mt-4 space-y-3 text-[13px]">
                      {[
                        { icon: Stethoscope, label: 'التخصص', value: specialty.name },
                        { icon: User, label: 'الطبيب', value: doctor.name },
                        { icon: CalendarDays, label: 'التاريخ', value: formatFullDate(date) },
                        { icon: Clock, label: 'الوقت', value: formatTime(time) },
                        { icon: MapPin, label: 'الموقع', value: `${doctor.clinic} — ${doctor.location}` },
                      ].map((r) => (
                        <div key={r.label} className="flex items-start justify-between gap-3 border-b border-ink-50 pb-3 last:border-0 last:pb-0">
                          <span className="flex items-center gap-1.5 text-ink-500">
                            <r.icon size={14} />
                            {r.label}
                          </span>
                          <span className="text-left font-bold text-ink-800">{r.value}</span>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 flex items-center justify-between rounded-xl bg-brand-50 px-4 py-3">
                      <span className="text-[12.5px] font-semibold text-brand-700">سعر الكشف</span>
                      <span className="font-display text-lg font-extrabold text-brand-700">{money(doctor.fee)}</span>
                    </div>
                  </Card>

                  <Card className="!bg-ink-950 !text-white">
                    <h4 className="flex items-center gap-2 font-display text-[15px] font-extrabold">
                      <Phone size={15} className="text-brand-300" />
                      تأكيد فوري عبر واتساب
                    </h4>
                    <p className="mt-2 text-[12.5px] leading-7 text-ink-300">
                      بمجرد التأكيد سيصلك على واتساب رقم جوالك رسالة تحتوي على بيانات الموعد والطبيب والموقع.
                    </p>
                  </Card>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      )}
    </PageShell>
  )
}
