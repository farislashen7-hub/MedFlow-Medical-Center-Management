import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, CalendarPlus, Eye, EyeOff, FilePlus2, HeartPulse, Lock, ShieldCheck } from 'lucide-react'
import { Logo } from '../components/Logo'
import { Button, Field, Input } from '../components/ui'
import { useAuth } from '../lib/auth'
import { useToast } from '../components/Toast'
import { findPatientByPhone } from '../lib/db'

export default function Login() {
  const { login } = useAuth()
  const { push } = useToast()
  const navigate = useNavigate()
  const location = useLocation()
  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [notFound, setNotFound] = useState(false)

  const state = location.state as { from?: string } | null

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setNotFound(false)
    if (!identifier.trim() || !password) {
      setError('يرجى إدخال رقم الجوال وكلمة المرور.')
      return
    }
    // مفيش ملف بالرقم ده؟ نعرض زرار إنشاء ملف جديد بدل رسالة خطأ بس
    if (!findPatientByPhone(identifier)) {
      setNotFound(true)
      setError('لا يوجد ملف مريض بهذا الرقم. لو أول مرة تزورنا، أنشئ ملفك في دقيقة.')
      return
    }
    setBusy(true)
    const result = login('patient', identifier, password)
    setBusy(false)
    if (!result.ok) {
      setError(result.error || 'تعذر تسجيل الدخول.')
      return
    }
    push('تم تسجيل الدخول بنجاح، أهلاً بك')
    const from = state?.from
    navigate(from && from !== '/login' && from.startsWith('/patient') ? from : '/patient', { replace: true })
  }

  const demoPatient = { id: '0551234567', pass: '123456' }

  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1.05fr]">
      {/* form side */}
      <div className="flex flex-col justify-center px-5 py-10 sm:px-12 lg:px-16">
        <div className="mx-auto w-full max-w-md">
          <Link to="/" className="inline-block">
            <Logo />
          </Link>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45 }}
            className="mt-10"
          >
            <h1 className="font-display text-3xl font-extrabold text-ink-950">بوابة المريض</h1>
            <p className="mt-2 text-[13.5px] leading-7 text-ink-500">
              ادخل برقم جوالك وكلمة المرور لمتابعة مواعيدك ووصفاتك وملفك الطبي.
            </p>

            <form onSubmit={handleSubmit} className="mt-7 space-y-4">
              <Field label="رقم الجوال" required>
                <Input
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="01xxxxxxxxx أو 05xxxxxxxx"
                  dir="ltr"
                  className="text-left"
                  inputMode="tel"
                  autoComplete="username"
                />
              </Field>

              <Field label="كلمة المرور" required>
                <div className="relative">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    dir="auto"
                    autoComplete="current-password"
                    className="pl-11"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-ink-400 transition hover:text-ink-700"
                    aria-label="إظهار كلمة المرور"
                  >
                    {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                  </button>
                </div>
              </Field>

              <div className="-mt-1 flex justify-end">
                <Link
                  to="/forgot-password"
                  state={{ phone: identifier.trim() }}
                  className="text-[12.5px] font-bold text-brand-700 hover:underline"
                >
                  نسيت كلمة المرور؟
                </Link>
              </div>

              {error && (
                <p className="rounded-xl bg-rose-50 px-4 py-3 text-[12.5px] font-semibold text-rose-700 ring-1 ring-rose-200">
                  {error}
                </p>
              )}
              {notFound && (
                <Link to="/register" state={{ phone: identifier.trim() }}>
                  <Button type="button" variant="secondary" size="lg" className="w-full">
                    <FilePlus2 size={17} />
                    إنشاء ملف مريض جديد
                  </Button>
                </Link>
              )}

              <Button type="submit" size="lg" className="w-full" disabled={busy}>
                <Lock size={17} />
                {busy ? 'جارٍ الدخول...' : 'دخول'}
              </Button>
            </form>

            {import.meta.env.DEV && (
              <div className="mt-6 rounded-2xl border border-dashed border-brand-200 bg-brand-50/60 p-4">
                <p className="flex items-center gap-1.5 text-[12px] font-bold text-brand-700">
                  <HeartPulse size={14} />
                  حساب تجريبي (بيظهر في وضع التطوير بس)
                </p>
                <button
                  onClick={() => {
                    setIdentifier(demoPatient.id)
                    setPassword(demoPatient.pass)
                  }}
                  className="mt-2.5 flex w-full items-center justify-between rounded-xl bg-white px-3.5 py-2.5 text-[12px] font-semibold text-ink-700 ring-1 ring-brand-100 transition hover:ring-brand-300"
                  dir="auto"
                >
                  <span>{demoPatient.id}</span>
                  <span className="text-brand-600">{demoPatient.pass}</span>
                </button>
              </div>
            )}

            <p className="mt-7 text-center text-[13px] text-ink-500">
              أول مرة تزورنا؟{' '}
              <Link to="/register" className="font-bold text-brand-700 hover:underline">
                أنشئ ملف مريض جديد
              </Link>
            </p>
            <Link
              to="/book"
              className="mt-4 flex items-center justify-center gap-1.5 text-[12.5px] font-semibold text-ink-500 hover:text-brand-700"
            >
              تخطي الدخول وحجز موعد (هنعمل لك ملف لو أول زيارة)
              <ArrowLeft size={14} />
            </Link>
            <Link
              to="/staff"
              className="mt-6 flex items-center justify-center gap-1.5 border-t border-ink-100 pt-5 text-[12.5px] font-semibold text-ink-400 hover:text-ink-700"
            >
              <ShieldCheck size={14} />
              دخول الأطباء والمالك
            </Link>
          </motion.div>
        </div>
      </div>

      {/* visual side */}
      <div className="relative hidden overflow-hidden lg:block">
        <img src="/images/login-side.jpg" alt="مركز طبي" className="absolute inset-0 size-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/55 to-ink-900/25" />
        <div className="relative flex h-full flex-col justify-end p-14 text-white">
          <span className="inline-flex w-fit items-center gap-2 rounded-full bg-white/12 px-3.5 py-1.5 text-[12px] font-bold backdrop-blur">
            <CalendarPlus size={14} />
            حجز فوري خلال 60 ثانية
          </span>
          <h2 className="mt-5 max-w-lg font-display text-4xl leading-[1.3] font-extrabold">
            كل سجلات عيادتك تحت سقف واحد
          </h2>
          <p className="mt-4 max-w-md text-[14px] leading-8 text-ink-200">
            مواعيد، وصفات، تقارير، ومحادثات واتساب — مُدارة بذكاء بين المريض والطبيب والإدارة.
          </p>
          <div className="mt-9 grid grid-cols-3 gap-4 border-t border-white/15 pt-7">
            {[
              { v: '+12 ألف', l: 'موعد منجز' },
              { v: '48', l: 'طبيباً متخصصاً' },
              { v: '4.8/5', l: 'تقييم المرضى' },
            ].map((s) => (
              <div key={s.l}>
                <p className="font-display text-2xl font-extrabold">{s.v}</p>
                <p className="mt-1 text-[12px] text-ink-300">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
