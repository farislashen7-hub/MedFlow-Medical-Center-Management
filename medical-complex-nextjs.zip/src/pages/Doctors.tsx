import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Search, SlidersHorizontal } from 'lucide-react'
import { PageShell } from '../components/Layout'
import { DoctorCard } from '../components/DoctorCard'
import { Button, Select } from '../components/ui'
import { useDB } from '../lib/db'

export default function Doctors() {
  const db = useDB()
  const [query, setQuery] = useState('')
  const [specialty, setSpecialty] = useState('all')

  const list = useMemo(() => {
    return db.doctors.filter((d) => {
      const matchesSp = specialty === 'all' || d.specialtyId === specialty
      const q = query.trim()
      const matchesQ =
        !q ||
        d.name.includes(q) ||
        d.title.includes(q) ||
        d.location.includes(q) ||
        d.bio.includes(q)
      return matchesSp && matchesQ
    })
  }, [db.doctors, query, specialty])

  return (
    <PageShell className="py-10">
      <div className="text-center">
        <span className="text-[12px] font-bold tracking-widest text-brand-600">الفريق الطبي</span>
        <h1 className="mt-2 font-display text-4xl font-extrabold text-ink-950">دليل الأطباء</h1>
        <p className="mx-auto mt-3 max-w-2xl text-[14.5px] leading-8 text-ink-500">
          تصفّح الأطباء حسب التخصص، اقرأ نبذة الطبيب، واحجز موعدك مباشرة بأقل من دقيقة.
        </p>
      </div>

      <div className="mt-8 flex flex-col gap-3 rounded-2xl border border-ink-100 bg-white p-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={17} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث بالاسم أو التخصص أو المدينة..."
            className="h-11 w-full rounded-xl border border-ink-200 bg-white pr-11 pl-4 text-sm outline-none transition placeholder:text-ink-300 focus:border-brand-400 focus:ring-4 focus:ring-brand-100"
          />
        </div>
        <div className="flex items-center gap-2">
          <SlidersHorizontal size={16} className="text-ink-400" />
          <Select value={specialty} onChange={(e) => setSpecialty(e.target.value)} className="!w-auto min-w-52">
            <option value="all">كل التخصصات</option>
            {db.specialties.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
        </div>
      </div>

      <p className="mt-5 text-[13px] font-semibold text-ink-500">
        {list.length} طبيب متاح للحجز
      </p>

      <div className="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((d, i) => (
          <motion.div
            key={d.id}
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.4, delay: Math.min(i, 6) * 0.05 }}
          >
            <DoctorCard doctor={d} specialty={db.specialties.find((s) => s.id === d.specialtyId)} />
          </motion.div>
        ))}
      </div>

      {list.length === 0 && (
        <div className="mt-12 flex flex-col items-center gap-3 text-center">
          <p className="text-sm text-ink-500">لم نعثر على أطباء مطابقين لبحثك.</p>
          <Button variant="secondary" onClick={() => { setQuery(''); setSpecialty('all') }}>
            إعادة ضبط البحث
          </Button>
        </div>
      )}
    </PageShell>
  )
}
