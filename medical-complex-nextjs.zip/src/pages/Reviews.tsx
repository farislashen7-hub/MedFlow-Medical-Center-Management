import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { MessageSquareQuote, Star } from 'lucide-react'
import { PageShell } from '../components/Layout'
import { Stars } from '../components/Stars'
import { Avatar, Badge, Button, Card, EmptyState, Select } from '../components/ui'
import { useDB } from '../lib/db'
import { useAuth } from '../lib/auth'
import { formatFullDate } from '../lib/format'

/** صفحة آراء العملاء — التقييمات المنشورة فقط (الإدارة تقدر تخفي/ترد من لوحة التحكم) */
export default function Reviews() {
  const db = useDB()
  const { session } = useAuth()
  const [doctorId, setDoctorId] = useState('all')
  const [stars, setStars] = useState('all')

  const published = useMemo(() => db.reviews.filter((r) => r.status === 'published'), [db.reviews])
  const avg = published.length ? published.reduce((s, r) => s + r.rating, 0) / published.length : 0
  const dist = [5, 4, 3, 2, 1].map((n) => ({ n, c: published.filter((r) => r.rating === n).length }))
  const happy = published.length ? Math.round((published.filter((r) => r.rating >= 4).length / published.length) * 100) : 0

  const list = useMemo(
    () =>
      published
        .filter((r) => doctorId === 'all' || r.doctorId === doctorId)
        .filter((r) => stars === 'all' || r.rating === Number(stars))
        .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)),
    [published, doctorId, stars],
  )

  const rateLink = session?.role === 'patient' ? '/patient' : '/login'

  return (
    <PageShell className="py-10">
      <div className="text-center">
        <span className="text-[12px] font-bold tracking-widest text-brand-600">آراء العملاء</span>
        <h1 className="mt-2 font-display text-3xl font-extrabold text-ink-950 sm:text-4xl">ماذا يقول مرضانا</h1>
        <p className="mx-auto mt-3 max-w-xl text-[14px] leading-7 text-ink-500">
          تقييمات حقيقية من مرضى أتموا زيارتهم في {db.settings.name}.
        </p>
      </div>

      <div className="mt-10 grid gap-5 lg:grid-cols-[320px_1fr]">
        <Card className="h-fit lg:sticky lg:top-24">
          <div className="text-center">
            <p className="font-display text-5xl font-extrabold text-ink-950">{avg ? avg.toFixed(1) : '—'}</p>
            <div className="mt-2 flex justify-center">
              <Stars value={avg} size={20} />
            </div>
            <p className="mt-1.5 text-[12px] text-ink-400">{published.length} تقييم</p>
            {published.length > 0 && (
              <Badge tone="green" className="mt-3">
                {happy}% راضون عن الزيارة
              </Badge>
            )}
          </div>

          <div className="mt-5 space-y-2">
            {dist.map((d) => (
              <button
                key={d.n}
                type="button"
                onClick={() => setStars(stars === String(d.n) ? 'all' : String(d.n))}
                className={`flex w-full items-center gap-2 rounded-lg px-1.5 py-1 text-[12px] transition hover:bg-ink-50 ${
                  stars === String(d.n) ? 'bg-brand-50' : ''
                }`}
                aria-pressed={stars === String(d.n)}
              >
                <span className="flex w-7 items-center gap-0.5 font-bold text-ink-700">
                  {d.n}
                  <Star size={11} className="fill-amber-400 text-amber-400" />
                </span>
                <span className="h-2 flex-1 overflow-hidden rounded-full bg-ink-100">
                  <span
                    className="block h-full rounded-full bg-amber-400"
                    style={{ width: `${published.length ? (d.c / published.length) * 100 : 0}%` }}
                  />
                </span>
                <span className="w-6 text-left text-ink-400">{d.c}</span>
              </button>
            ))}
          </div>

          <Link to={rateLink} className="mt-6 block">
            <Button className="w-full">
              <Star size={16} />
              قيّم زيارتك
            </Button>
          </Link>
          <p className="mt-2 text-center text-[11px] text-ink-400">التقييم متاح للمرضى بعد اكتمال الزيارة من لوحة المريض.</p>
        </Card>

        <div>
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <Select value={doctorId} onChange={(e) => setDoctorId(e.target.value)} className="max-w-[240px]">
              <option value="all">كل الأطباء</option>
              {db.doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
            <Select value={stars} onChange={(e) => setStars(e.target.value)} className="max-w-[160px]">
              <option value="all">كل النجوم</option>
              {[5, 4, 3, 2, 1].map((n) => (
                <option key={n} value={n}>
                  {n} نجوم
                </option>
              ))}
            </Select>
            <span className="text-[12px] text-ink-400">{list.length} نتيجة</span>
          </div>

          {list.length === 0 ? (
            <EmptyState
              icon={<MessageSquareQuote size={24} />}
              title="لا توجد تقييمات مطابقة"
              description="جرّب تغيير الفلتر أو كن أول من يشارك رأيه بعد زيارتك."
            />
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {list.map((r, i) => {
                const doctor = db.doctors.find((d) => d.id === r.doctorId)
                return (
                  <motion.div
                    key={r.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: Math.min(i, 8) * 0.04 }}
                  >
                    <Card className="h-full">
                      <div className="flex items-center justify-between gap-3">
                        <Stars value={r.rating} />
                        <span className="text-[11px] text-ink-400">{formatFullDate(r.createdAt.slice(0, 10))}</span>
                      </div>
                      <p className="mt-3 text-[13.5px] leading-7 text-ink-700">{r.comment || 'بدون تعليق'}</p>
                      <div className="mt-4 flex items-center gap-2.5 border-t border-ink-100 pt-3">
                        <Avatar name={r.patientName} size={32} />
                        <div className="min-w-0">
                          <p className="truncate text-[12.5px] font-bold text-ink-900">{r.patientName}</p>
                          {doctor && <p className="truncate text-[11px] text-ink-400">زيارة مع {doctor.name}</p>}
                        </div>
                      </div>
                      {r.reply && (
                        <p className="mt-3 rounded-xl bg-brand-50 px-3.5 py-2.5 text-[12px] leading-6 text-brand-800">
                          <span className="font-bold">رد المركز: </span>
                          {r.reply}
                        </p>
                      )}
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </PageShell>
  )
}
