import { useEffect, useRef, useState } from 'react'
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowRight, Crown, Eye, EyeOff, KeyRound, Lock, ShieldAlert, Stethoscope } from 'lucide-react'
import { Logo } from '../components/Logo'
import { Button, Field, Input } from '../components/ui'
import { useAuth } from '../lib/auth'
import { useToast } from '../components/Toast'
import { useSettings } from '../lib/db'

type StaffRole = 'doctor' | 'admin'

const ROLES: { id: StaffRole; label: string; sub: string; icon: typeof Crown; home: string }[] = [
  { id: 'doctor', label: 'طبيب', sub: 'جدولك ومرضاك وحضورك', icon: Stethoscope, home: '/doctor' },
  { id: 'admin', label: 'المالك', sub: 'إدارة العيادة والتقارير', icon: Crown, home: '/admin' },
]

const PREF_KEY = 'medflow.staff-login.v1'
const MAX_ATTEMPTS = 5
const LOCK_SECONDS = 30

/** آخر دور + آخر معرّف (من غير الباسورد) — راحة للمستخدم بس */
function loadPref(): { role: StaffRole; identifier: string } {
  try {
    const raw = window.localStorage.getItem(PREF_KEY)
    if (raw) {
      const p = JSON.parse(raw) as { role?: string; identifier?: string }
      if (p.role === 'doctor' || p.role === 'admin') return { role: p.role, identifier: p.identifier ?? '' }
    }
  } catch {
    /* ignore */
  }
  return { role: 'doctor', identifier: '' }
}

function savePref(role: StaffRole, identifier: string) {
  try {
    window.localStorage.setItem(PREF_KEY, JSON.stringify({ role, identifier }))
  } catch {
    /* ignore */
  }
}

export default function StaffLogin() {
  const { loginStaff, session, loading } = useAuth()
  const { push } = useToast()
  const center = useSettings()
  const navigate = useNavigate()
  const location = useLocation()
  const from = (location.state as { from?: string } | null)?.from

  const pref = useRef(loadPref()).current
  const [role, setRole] = useState<StaffRole>(pref.role)
  const [identifier, setIdentifier] = useState(pref.identifier)
  const [password, setPassword] = useState('')
  const [show, setShow] = useState(false)
  const [caps, setCaps] = useState(false)
  const [error, setError] = useState('')
  const [fails, setFails] = useState(0)
  const [lockLeft, setLockLeft] = useState(0)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (lockLeft <= 0) return
    const t = setTimeout(() => setLockLeft((n) => n - 1), 1000)
    return () => clearTimeout(t)
  }, [lockLeft])

  const active = ROLES.find((r) => r.id === role)!

  // داخل بالفعل -> على لوحته
  if (!loading && session && session.role !== 'patient') {
    return <Navigate to={session.role === 'admin' ? '/admin' : '/doctor'} replace />
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (lockLeft > 0 || busy) return
    setError('')
    if (!identifier.trim() || !password) {
      setError(role === 'admin' ? 'أدخل البريد الإلكتروني وكلمة المرور.' : 'أدخل رقم الجوال أو البريد وكلمة المرور.')
      return
    }
    if (role === 'admin' && !/^\S+@\S+\.\S+$/.test(identifier.trim())) {
      setError('دخول المالك بالبريد الإلكتروني.')
      return
    }
    setBusy(true)
    const result = await loginStaff(role, identifier, password)
    setBusy(false)
    if (!result.ok) {
      // رسالة موحدة: مانكشفش هل الحساب موجود ولا لأ
      const next = fails + 1
      setFails(next)
      setPassword('')
      if (next >= MAX_ATTEMPTS) {
        setLockLeft(LOCK_SECONDS)
        setFails(0)
        setError(`محاولات كتير غلط. استنى ${LOCK_SECONDS} ثانية وجرّب تاني.`)
      } else {
        setError(`بيانات الدخول غير صحيحة. (${MAX_ATTEMPTS - next} محاولات متبقية)`)
      }
      return
    }
    savePref(role, identifier.trim())
    push(role === 'admin' ? 'أهلاً بك يا مالك العيادة' : 'أهلاً دكتور، تم تسجيل الدخول')
    const target = from && from.startsWith(active.home) ? from : active.home
    navigate(target, { replace: true })
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-ink-950 px-4 py-10">
      <div className="pointer-events-none absolute -right-32 -top-32 size-[28rem] rounded-full bg-brand-600/25 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -left-24 size-[26rem] rounded-full bg-sky-500/10 blur-3xl" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="relative w-full max-w-md"
      >
        <div className="flex items-center justify-between">
          <Link to="/" className="inline-block">
            <Logo light />
          </Link>
          <Link to="/" className="flex items-center gap-1 text-[12px] font-semibold text-ink-400 transition hover:text-white">
            الموقع الرئيسي
            <ArrowRight size={13} className="rotate-180" />
          </Link>
        </div>

        <div className="mt-8 rounded-3xl border border-white/10 bg-white p-6 shadow-2xl sm:p-8">
          <div className="flex items-center gap-3">
            <span className="flex size-11 items-center justify-center rounded-2xl bg-ink-900 text-white">
              <KeyRound size={20} />
            </span>
            <div>
              <h1 className="font-display text-xl font-extrabold text-ink-950">دخول الطاقم</h1>
              <p className="text-[12px] text-ink-500">{center.name || 'العيادة'} — للأطباء والمالك فقط</p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-2" role="tablist" aria-label="نوع الحساب">
            {ROLES.map((r) => {
              const on = role === r.id
              return (
                <button
                  key={r.id}
                  type="button"
                  role="tab"
                  aria-selected={on}
                  onClick={() => {
                    setRole(r.id)
                    setError('')
                    setIdentifier(r.id === pref.role ? pref.identifier : '')
                    setPassword('')
                  }}
                  className={`flex flex-col items-start gap-1 rounded-2xl border p-3.5 text-right transition ${
                    on ? 'border-ink-900 bg-ink-900 text-white shadow-lg' : 'border-ink-200 bg-white text-ink-700 hover:border-brand-300'
                  }`}
                >
                  <r.icon size={18} className={on ? 'text-brand-300' : 'text-ink-400'} />
                  <span className="text-[14px] font-extrabold">{r.label}</span>
                  <span className={`text-[11px] leading-5 ${on ? 'text-ink-300' : 'text-ink-400'}`}>{r.sub}</span>
                </button>
              )
            })}
          </div>

          <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
            <Field label={role === 'admin' ? 'البريد الإلكتروني' : 'رقم الجوال أو البريد الإلكتروني'} required>
              <Input
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder={role === 'admin' ? 'owner@clinic.com' : '01xxxxxxxxx أو name@clinic.com'}
                dir="ltr"
                className="text-left"
                autoComplete="username"
                autoFocus
              />
            </Field>

            <Field label="كلمة المرور" required>
              <div className="relative">
                <Input
                  type={show ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyUp={(e) => setCaps(e.getModifierState('CapsLock'))}
                  placeholder="••••••••"
                  dir="ltr"
                  className="pl-11 text-left"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShow((v) => !v)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-ink-400 transition hover:text-ink-700"
                  aria-label={show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                >
                  {show ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
              {caps && <span className="mt-1.5 block text-xs font-semibold text-amber-600">زر Caps Lock شغّال</span>}
            </Field>

            {error && (
              <p role="alert" className="flex items-start gap-2 rounded-xl bg-rose-50 px-4 py-3 text-[12.5px] font-semibold leading-6 text-rose-700 ring-1 ring-rose-200">
                <ShieldAlert size={16} className="mt-0.5 shrink-0" />
                {error}
              </p>
            )}

            <Button type="submit" size="lg" className="w-full" disabled={lockLeft > 0 || busy}>
              <Lock size={17} />
              {lockLeft > 0 ? `استنى ${lockLeft} ثانية` : role === 'admin' ? 'دخول المالك' : 'دخول الطبيب'}
            </Button>
          </form>

          <p className="mt-5 text-center text-[12px] leading-6 text-ink-400">
            نسيت كلمة المرور؟ {role === 'admin' ? 'تواصل مع الدعم الفني للنظام.' : 'اطلب من المالك يغيّرها لك من تبويب «الأطباء».'}
          </p>
        </div>

        <p className="mt-6 text-center text-[12.5px] text-ink-400">
          مريض؟{' '}
          <Link to="/login" className="font-bold text-brand-300 hover:text-white">
            بوابة المريض
          </Link>
        </p>
      </motion.div>
    </div>
  )
}
