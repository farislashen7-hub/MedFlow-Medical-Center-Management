import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Activity,
  AlertCircle,
  CalendarDays,
  CalendarPlus,
  CheckCircle2,
  ClipboardList,
  FileText,
  HeartPulse,
  History,
  LogOut,
  Pill,
  Download,
  Loader2,
  Printer,
  Receipt,
  RefreshCw,
  Star,
  Stethoscope,
  User,
} from 'lucide-react'
import { useDB, createReview, cancelAppointmentByPatient, updatePatient } from '../lib/db'
import { StarInput, Stars } from '../components/Stars'
import { useAuth } from '../lib/auth'
import { notify } from '../lib/notify'
import { useToast } from '../components/Toast'
import { Header, Footer } from '../components/Layout'
import {
  Avatar,
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  InfoRow,
  Input,
  Modal,
  SectionTitle,
  Select,
  StatCard,
  Tabs,
  Textarea,
} from '../components/ui'
import {
  ageFrom,
  formatFullDate,
  formatStamp,
  formatTime,
  genderLabel,
  isValidPhone,
  normalizePhone,
} from '../lib/format'
import type { Appointment, Prescription } from '../lib/types'
import { PrintPreview } from '../components/PrintPreview'
import { invoiceHtml, invoiceNumber, prescriptionHtml, printPrescription } from '../lib/print'
import { downloadBlob, htmlToPdfBlob, safeFilename } from '../lib/capture'

const statusMeta: Record<Appointment['status'], { label: string; tone: 'brand' | 'green' | 'rose' | 'amber' | 'sky' }> = {
  scheduled: { label: 'مجدول', tone: 'sky' },
  confirmed: { label: 'مؤكد', tone: 'brand' },
  completed: { label: 'مكتمل', tone: 'green' },
  cancelled: { label: 'ملغي', tone: 'rose' },
  'no-show': { label: 'لم يحضر', tone: 'amber' },
}

export default function PatientDashboard() {
  const db = useDB()
  const { session, logout } = useAuth()
  const { push } = useToast()
  const [tab, setTab] = useState('appointments')
  const [editing, setEditing] = useState(false)
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    nationalId: '',
    birthDate: '',
    gender: 'male' as 'male' | 'female',
    bloodType: '',
    allergies: '',
    chronic: '',
    insurance: '',
    address: '',
    emergencyName: '',
    emergencyRelation: 'الأب',
    emergencyPhone: '',
  })
  const [rx, setRx] = useState<Prescription | null>(null)
  const [inv, setInv] = useState<Appointment | null>(null)
  const [saving, setSaving] = useState(false)
  const [rateTarget, setRateTarget] = useState<Appointment | null>(null)
  const [rating, setRating] = useState(5)
  const [comment, setComment] = useState('')
  const [cancelTarget, setCancelTarget] = useState<Appointment | null>(null)
  const [cancelling, setCancelling] = useState(false)

  async function confirmCancel() {
    if (!cancelTarget || !session) return
    setCancelling(true)
    const r = await cancelAppointmentByPatient(cancelTarget.id, session.id)
    setCancelling(false)
    if (!r.ok) return push(r.error, 'error')
    setCancelTarget(null)
    push('تم إلغاء الموعد وبعتنا تأكيد على واتساب')
  }

  const patient = db.patients.find((p) => p.id === session?.id)

  const appointments = useMemo(
    () =>
      db.appointments
        .filter((a) => a.patientId === session?.id)
        .sort((a, b) => (a.date + a.time < b.date + b.time ? 1 : -1)),
    [db.appointments, session?.id],
  )

  const prescriptions = useMemo(
    () => db.prescriptions.filter((p) => p.patientId === session?.id),
    [db.prescriptions, session?.id],
  )

  const today = new Date().toISOString().slice(0, 10)
  const upcoming = appointments.filter((a) => a.date >= today && a.status !== 'cancelled')
  const past = appointments.filter((a) => a.date < today || a.status === 'cancelled')

  // التقييم: أي زيارة خلصت (مكتملة، أو موعدها عدّى ومش ملغي/لم يحضر). مرة واحدة لكل زيارة.
  const canRate = (a: Appointment) => a.status !== 'cancelled' && a.status !== 'no-show' && (a.status === 'completed' || a.date < today)
  const reviewOf = (id: string) => db.reviews.find((r) => r.appointmentId === id)
  const openRate = (a: Appointment) => {
    setRateTarget(a)
    setRating(5)
    setComment('')
  }
  const rateAction = (a: Appointment, small = false) => {
    if (!canRate(a)) return null
    const mine = reviewOf(a.id)
    return mine ? (
      <span className="flex items-center gap-1.5 rounded-lg bg-amber-50 px-2.5 py-1.5 text-[11.5px] font-bold text-amber-700">
        <Stars value={mine.rating} size={12} />
        تم التقييم
      </span>
    ) : small ? (
      <button
        onClick={() => openRate(a)}
        className="flex items-center gap-1 rounded-lg bg-amber-50 px-2.5 py-1.5 text-[11.5px] font-bold text-amber-700 transition hover:bg-amber-100"
      >
        <Star size={12} />
        قيّم
      </button>
    ) : (
      <Button size="sm" variant="ghost" onClick={() => openRate(a)}>
        <Star size={14} />
        قيّم الزيارة
      </Button>
    )
  }

  const myReviews = db.reviews.filter((r) => r.patientId === session?.id)
  const toRate = appointments.filter((a) => canRate(a) && !reviewOf(a.id))

  if (!patient) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-sm text-ink-500">تعذر العثور على بيانات حسابك.</p>
      </div>
    )
  }

  async function saveInvoice() {
    if (!inv || !patient || saving) return
    setSaving(true)
    try {
      const html = invoiceHtml({
        settings: db.settings,
        appointment: inv,
        patient,
        doctors: db.doctors,
        specialties: db.specialties,
        appointments: db.appointments,
        prescriptions: db.prescriptions,
      })
      const blob = await htmlToPdfBlob(html)
      downloadBlob(blob, `${safeFilename(`فاتورة-${invoiceNumber(inv)}`)}.pdf`)
      push('تم حفظ الفاتورة على جهازك')
    } catch (err) {
      console.error('[invoice] save failed', err)
      push('تعذر حفظ الفاتورة — جرّب تاني', 'error')
    } finally {
      setSaving(false)
    }
  }

  function openEdit() {
    setProfile({
      name: patient!.name,
      email: patient!.email,
      nationalId: patient!.nationalId,
      birthDate: patient!.birthDate,
      gender: patient!.gender,
      emergencyName: patient!.emergency?.name ?? '',
      emergencyRelation: patient!.emergency?.relation || 'الأب',
      emergencyPhone: patient!.emergency?.phone ?? '',
      bloodType: patient!.bloodType,
      allergies: patient!.allergies,
      chronic: patient!.chronic,
      insurance: patient!.insurance,
      address: patient!.address,
    })
    setEditing(true)
  }

  function saveProfile() {
    if (!profile.name.trim()) return push('الاسم مطلوب')
    if (profile.birthDate && (profile.birthDate > today || profile.birthDate < '1900-01-01')) return push('تاريخ الميلاد غير صحيح')
    if (profile.emergencyPhone.trim() && !isValidPhone(profile.emergencyPhone)) return push('رقم جهة الطوارئ غير صحيح')
    updatePatient(patient!.id, {
      name: profile.name,
      email: profile.email,
      nationalId: profile.nationalId.trim(),
      birthDate: profile.birthDate,
      gender: profile.gender,
      emergency: {
        name: profile.emergencyName.trim(),
        relation: profile.emergencyRelation,
        phone: profile.emergencyPhone.trim() ? normalizePhone(profile.emergencyPhone) : '',
      },
      bloodType: profile.bloodType,
      allergies: profile.allergies,
      chronic: profile.chronic,
      insurance: profile.insurance,
      address: profile.address,
    })
    setEditing(false)
    push('تم تحديث بياناتك بنجاح')
  }

  return (
    <div className="min-h-screen bg-[#f5f8f8]">
      <Header />

      <main className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* ---- welcome header ---- */}
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <Card className="relative overflow-hidden !bg-ink-950 !text-white">
            <div className="absolute -left-16 -top-16 size-64 rounded-full bg-brand-600/20 blur-3xl" />
            <div className="relative flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-5">
                <Avatar name={patient.name} size={76} className="!rounded-3xl !bg-brand-600 !text-2xl !text-white" />
                <div>
                  <p className="text-[12px] font-semibold text-brand-300">بوابة المريض</p>
                  <h1 className="mt-1 font-display text-2xl font-extrabold sm:text-3xl">
                    أهلاً {patient.name.split(' ').slice(0, 2).join(' ')} 👋
                  </h1>
                  <div className="mt-2.5 flex flex-wrap items-center gap-2 text-[12px]">
                    <span className="flex items-center gap-1.5 rounded-lg bg-white/10 px-2.5 py-1.5">
                      <User size={13} />
                      {patient.phone}
                    </span>
                    <span className="rounded-lg bg-white/10 px-2.5 py-1.5">{genderLabel(patient.gender)}</span>
                    <span className="rounded-lg bg-white/10 px-2.5 py-1.5">
                      {patient.birthDate ? `${ageFrom(patient.birthDate)} سنة` : 'العمر غير محدد'}
                    </span>
                    <span className="rounded-lg bg-white/10 px-2.5 py-1.5">فصيلة {patient.bloodType}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2.5">
                <Link to="/book">
                  <Button>
                    <CalendarPlus size={17} />
                    حجز موعد جديد
                  </Button>
                </Link>
                {upcoming[0] && (
                  <Link to={`/book?followup=${upcoming[0].id}`}>
                    <Button variant="secondary" className="!border-white/25 !bg-white/10 !text-white hover:!bg-white/20">
                      <RefreshCw size={16} />
                      إعادة حجز الموعد
                    </Button>
                  </Link>
                )}
                <Button
                  variant="ghost"
                  className="!text-ink-300 hover:!bg-white/10 hover:!text-white"
                  onClick={logout}
                >
                  <LogOut size={16} />
                  خروج
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* ---- stats ---- */}
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            label="إجمالي المواعيد"
            value={appointments.length}
            icon={<CalendarDays size={20} />}
            tone="brand"
            hint={`${upcoming.length} موعد قادم`}
          />
          <StatCard
            label="المواعيد القادمة"
            value={upcoming.length}
            icon={<CheckCircle2 size={20} />}
            tone="green"
            hint="في انتظار الزيارة"
          />
          <StatCard
            label="الوصفات الطبية"
            value={prescriptions.length}
            icon={<Pill size={20} />}
            tone="violet"
            hint="متاحة للتحميل والطباعة"
          />
          <StatCard
            label="الحالات المزمنة"
            value={patient.chronic && patient.chronic !== 'لا يوجد' ? 1 : 0}
            icon={<HeartPulse size={20} />}
            tone="rose"
            hint={patient.chronic}
          />
        </div>

        {/* ---- tabs ---- */}
        <div className="mt-6">
          <Tabs
            active={tab}
            onChange={setTab}
            items={[
              { id: 'appointments', label: 'مواعيدي', icon: <CalendarDays size={15} />, count: appointments.length },
              { id: 'prescriptions', label: 'الوصفات الطبية', icon: <Pill size={15} />, count: prescriptions.length },
              { id: 'followup', label: 'المتابعة', icon: <RefreshCw size={15} />, count: past.filter((a) => a.status === 'completed').length },
              { id: 'reviews', label: 'تقييماتي', icon: <Star size={15} />, count: toRate.length || undefined },
              { id: 'profile', label: 'بياناتي', icon: <User size={15} /> },
            ]}
          />
        </div>

        {/* ---- APPOINTMENTS ---- */}
        {tab === 'appointments' && (
          <div className="mt-5 space-y-5">
            <div>
              <SectionTitle title="المواعيد القادمة" subtitle="تابع مواعيدك القادمة أو أعد حجزها" icon={<CalendarDays size={18} />} />
              {upcoming.length === 0 ? (
                <EmptyState
                  icon={<CalendarDays size={24} />}
                  title="لا توجد مواعيد قادمة"
                  description="احجز موعدك الجديد مع الطبيب المناسب حسب التخصص."
                  action={
                    <Link to="/book">
                      <Button>
                        <CalendarPlus size={16} />
                        حجز موعد
                      </Button>
                    </Link>
                  }
                />
              ) : (
                <div className="grid gap-4 lg:grid-cols-2">
                  {upcoming.map((a) => {
                    const doctor = db.doctors.find((d) => d.id === a.doctorId)
                    const specialty = db.specialties.find((s) => s.id === a.specialtyId)
                    const meta = statusMeta[a.status]
                    return (
                      <Card key={a.id} className="!p-0 overflow-hidden">
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-100 bg-ink-50/60 px-5 py-3">
                          <div className="flex items-center gap-2.5">
                            <span className="flex size-9 items-center justify-center rounded-xl bg-brand-600 text-white">
                              <CalendarDays size={16} />
                            </span>
                            <div>
                              <p className="text-[13.5px] font-bold text-ink-900">{formatFullDate(a.date)}</p>
                              <p className="text-[11.5px] text-ink-500">{formatTime(a.time)} — {doctor?.name}</p>
                            </div>
                          </div>
                          <Badge tone={meta.tone}>{meta.label}</Badge>
                        </div>
                        <div className="space-y-3 p-5">
                          <div className="flex items-center gap-3">
                            <img src={doctor?.image} alt="" className="size-12 rounded-xl object-cover object-top" />
                            <div>
                              <p className="text-[13.5px] font-bold text-ink-900">{doctor?.name}</p>
                              <p className="text-[11.5px] text-brand-700">{specialty?.name} — {doctor?.clinic}</p>
                            </div>
                          </div>
                          <p className="rounded-xl bg-ink-50 px-3.5 py-2.5 text-[12.5px] leading-6 text-ink-600">
                            <span className="font-bold text-ink-800">سبب الزيارة: </span>
                            {a.reason}
                          </p>
                          <div className="flex flex-wrap gap-2">
                            <Link to={`/book?followup=${a.id}`}>
                              <Button size="sm">
                                <RefreshCw size={14} />
                                إعادة حجز
                              </Button>
                            </Link>
                            <Button
                              size="sm"
                              variant="secondary"
                              onClick={() => setCancelTarget(a)}
                            >
                              إلغاء الموعد
                            </Button>
                            {rateAction(a)}
                          </div>
                        </div>
                      </Card>
                    )
                  })}
                </div>
              )}
            </div>

            <div>
              <SectionTitle title="سجل المواعيد السابقة" subtitle="مواعيد مكتملة أو ملغاة" icon={<History size={18} />} />
              {past.length === 0 ? (
                <EmptyState icon={<History size={24} />} title="لا يوجد سجل سابق" description="ستظهر هنا مواعيدك السابقة بعد أول زيارة." />
              ) : (
                <Card className="!p-0 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[640px] text-right">
                      <thead className="bg-ink-50 text-[11.5px] font-bold text-ink-500">
                        <tr>
                          <th className="px-5 py-3">التاريخ</th>
                          <th className="px-5 py-3">الطبيب</th>
                          <th className="px-5 py-3">السبب</th>
                          <th className="px-5 py-3">الحالة</th>
                          <th className="px-5 py-3">إجراء</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-ink-50 text-[12.5px]">
                        {past.slice(0, 12).map((a) => {
                          const doctor = db.doctors.find((d) => d.id === a.doctorId)
                          const meta = statusMeta[a.status]
                          const hasRx = prescriptions.some((p) => p.appointmentId === a.id)
                          return (
                            <tr key={a.id} className="transition hover:bg-ink-50/50">
                              <td className="px-5 py-3.5 font-semibold text-ink-800">
                                {formatFullDate(a.date)}
                                <span className="block text-[11px] font-normal text-ink-400">{formatTime(a.time)}</span>
                              </td>
                              <td className="px-5 py-3.5 text-ink-700">{doctor?.name}</td>
                              <td className="px-5 py-3.5 text-ink-600">{a.reason}</td>
                              <td className="px-5 py-3.5">
                                <Badge tone={meta.tone}>{meta.label}</Badge>
                              </td>
                              <td className="px-5 py-3.5">
                                <div className="flex gap-2">
                                  {hasRx && (
                                    <button
                                      onClick={() => setRx(prescriptions.find((p) => p.appointmentId === a.id)!)}
                                      className="flex items-center gap-1 rounded-lg bg-violet-50 px-2.5 py-1.5 text-[11.5px] font-bold text-violet-700 transition hover:bg-violet-100"
                                    >
                                      <FileText size={12} />
                                      الوصفة
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setInv(a)}
                                    className="flex items-center gap-1 rounded-lg bg-ink-50 px-2.5 py-1.5 text-[11.5px] font-bold text-ink-700 transition hover:bg-ink-100"
                                  >
                                    <Receipt size={12} />
                                    الفاتورة
                                  </button>
                                  <Link
                                    to={`/book?followup=${a.id}`}
                                    className="flex items-center gap-1 rounded-lg bg-brand-50 px-2.5 py-1.5 text-[11.5px] font-bold text-brand-700 transition hover:bg-brand-100"
                                  >
                                    <RefreshCw size={12} />
                                    متابعة
                                  </Link>
                                  {rateAction(a, true)}
                                </div>
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                </Card>
              )}
            </div>
          </div>
        )}

        {/* ---- PRESCRIPTIONS ---- */}
        {tab === 'prescriptions' && (
          <div className="mt-5">
            <SectionTitle title="الوصفات الطبية" subtitle="كل الروشتات التي صدرت لك" icon={<Pill size={18} />} />
            {prescriptions.length === 0 ? (
              <EmptyState
                icon={<Pill size={24} />}
                title="لا توجد وصفات بعد"
                description="بعد إتمام visit للطبيب ستجد الوصفة هنا مع إمكانية الطباعة."
              />
            ) : (
              <div className="grid gap-4 lg:grid-cols-2">
                {prescriptions.map((p) => {
                  const doctor = db.doctors.find((d) => d.id === p.doctorId)
                  return (
                    <Card key={p.id} className="!p-0 overflow-hidden">
                      <div className="flex items-center justify-between gap-2 border-b border-ink-100 bg-violet-50/60 px-5 py-3">
                        <div className="flex items-center gap-2.5">
                          <span className="flex size-9 items-center justify-center rounded-xl bg-violet-600 text-white">
                            <Pill size={16} />
                          </span>
                          <div>
                            <p className="text-[13px] font-bold text-ink-900">{p.diagnosis}</p>
                            <p className="text-[11px] text-ink-500">{doctor?.name} — {formatStamp(p.issuedAt)}</p>
                          </div>
                        </div>
                        <Badge tone="violet">{p.code}</Badge>
                      </div>
                      <div className="space-y-3 p-5">
                        {p.items.map((m) => (
                          <div key={m.id} className="flex items-start justify-between gap-3 rounded-xl bg-ink-50 px-3.5 py-2.5">
                            <span className="text-[13px] font-bold text-ink-800">{m.name}</span>
                            <span className="text-left text-[11.5px] text-ink-500">
                              {m.dosage}
                              <span className="block">{m.duration}</span>
                            </span>
                          </div>
                        ))}
                        {p.advice && (
                          <p className="rounded-xl bg-brand-50 px-3.5 py-2.5 text-[12px] leading-6 text-brand-800">
                            <span className="font-bold">إرشادات: </span>
                            {p.advice}
                          </p>
                        )}
                        <div className="flex flex-wrap gap-2">
                          <Button size="sm" variant="secondary" onClick={() => setRx(p)}>
                            <Printer size={14} />
                            عرض وطباعة
                          </Button>
                          {p.followUp && (
                            <Link to="/book">
                              <Button size="sm" variant="ghost">
                                <RefreshCw size={14} />
                                حجز متابعة
                              </Button>
                            </Link>
                          )}
                        </div>
                      </div>
                    </Card>
                  )
                })}
              </div>
            )}
          </div>
        )}

        {/* ---- FOLLOW UP ---- */}
        {tab === 'followup' && (
          <div className="mt-5">
            <SectionTitle
              title="المتابعة العلاجية"
              subtitle="مواعيد مكتملة تحتاج متابعة — أعد الحجز بسهولة"
              icon={<RefreshCw size={18} />}
            />
            {past.filter((a) => a.status === 'completed').length === 0 ? (
              <EmptyState
                icon={<Stethoscope size={24} />}
                title="لا توجد حالات تحتاج متابعة"
                description="بعد إتمام الزيارة سيظهر زر المتابعة هنا لإعادة الحجز مع نفس الطبيب."
              />
            ) : (
              <div className="grid gap-4 lg:grid-cols-2">
                {past
                  .filter((a) => a.status === 'completed')
                  .slice(0, 8)
                  .map((a) => {
                    const doctor = db.doctors.find((d) => d.id === a.doctorId)
                    const rxFor = prescriptions.find((p) => p.appointmentId === a.id)
                    return (
                      <Card key={a.id}>
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <img src={doctor?.image} alt="" className="size-12 rounded-xl object-cover object-top" />
                            <div>
                              <p className="text-[13.5px] font-bold text-ink-900">{doctor?.name}</p>
                              <p className="text-[11.5px] text-ink-500">آخر زيارة: {formatFullDate(a.date)}</p>
                            </div>
                          </div>
                          {rxFor?.followUp && (
                            <Badge tone="amber">
                              <RefreshCw size={11} />
                              {rxFor.followUp}
                            </Badge>
                          )}
                        </div>
                        <p className="mt-3 rounded-xl bg-ink-50 px-3.5 py-2.5 text-[12.5px] text-ink-600">
                          {rxFor?.diagnosis || a.reason}
                        </p>
                        <div className="mt-3 flex flex-wrap gap-2">
                          <Link to={`/book?followup=${a.id}`}>
                            <Button size="sm">
                              <RefreshCw size={14} />
                              إعادة حجز للمتابعة
                            </Button>
                          </Link>
                          {rxFor && (
                            <Button size="sm" variant="secondary" onClick={() => setRx(rxFor)}>
                              <FileText size={14} />
                              عرض الوصفة
                            </Button>
                          )}
                          {(() => {
                            const mine = db.reviews.find((r) => r.appointmentId === a.id)
                            return mine ? (
                              <span className="flex items-center gap-1.5 rounded-xl bg-amber-50 px-3 py-1.5 text-[12px] font-bold text-amber-700">
                                <Stars value={mine.rating} size={12} />
                                تم التقييم
                              </span>
                            ) : (
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  setRateTarget(a)
                                  setRating(5)
                                  setComment('')
                                }}
                              >
                                <Star size={14} />
                                قيّم الزيارة
                              </Button>
                            )
                          })()}
                        </div>
                      </Card>
                    )
                  })}
              </div>
            )}
          </div>
        )}

        {/* ---- REVIEWS ---- */}
        {tab === 'reviews' && (
          <div className="mt-5 space-y-6">
            <div>
              <SectionTitle title="زيارات بانتظار تقييمك" subtitle="رأيك يساعدنا ويساعد غيرك في اختيار الطبيب" icon={<Star size={18} />} />
              {toRate.length === 0 ? (
                <EmptyState
                  icon={<Star size={24} />}
                  title="لا توجد زيارات بانتظار التقييم"
                  description="بعد كل زيارة ستجدها هنا لتقييم الطبيب وكتابة رأيك."
                />
              ) : (
                <div className="grid gap-4 lg:grid-cols-2">
                  {toRate.map((a) => {
                    const doctor = db.doctors.find((d) => d.id === a.doctorId)
                    return (
                      <Card key={a.id}>
                        <div className="flex items-center gap-3">
                          <img src={doctor?.image} alt="" className="size-12 rounded-xl object-cover object-top" />
                          <div className="min-w-0 flex-1">
                            <p className="text-[13.5px] font-bold text-ink-900">{doctor?.name}</p>
                            <p className="text-[11.5px] text-ink-500">
                              {formatFullDate(a.date)} — {formatTime(a.time)}
                            </p>
                          </div>
                          {rateAction(a)}
                        </div>
                        {a.reason && <p className="mt-3 rounded-xl bg-ink-50 px-3.5 py-2.5 text-[12.5px] text-ink-600">{a.reason}</p>}
                      </Card>
                    )
                  })}
                </div>
              )}
            </div>

            <div>
              <SectionTitle title="تقييماتي السابقة" subtitle="كل التقييمات التي أرسلتها" icon={<History size={18} />} />
              {myReviews.length === 0 ? (
                <EmptyState icon={<Star size={24} />} title="لم ترسل أي تقييم بعد" description="ستظهر تقييماتك هنا بعد إرسالها." />
              ) : (
                <div className="grid gap-4 lg:grid-cols-2">
                  {myReviews.map((r) => {
                    const doctor = db.doctors.find((d) => d.id === r.doctorId)
                    return (
                      <Card key={r.id}>
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <img src={doctor?.image} alt="" className="size-11 rounded-xl object-cover object-top" />
                            <div>
                              <p className="text-[13.5px] font-bold text-ink-900">{doctor?.name}</p>
                              <p className="text-[11.5px] text-ink-500">{formatStamp(r.createdAt)}</p>
                            </div>
                          </div>
                          <Stars value={r.rating} size={14} />
                        </div>
                        {r.comment && <p className="mt-3 rounded-xl bg-ink-50 px-3.5 py-2.5 text-[12.5px] leading-6 text-ink-700">{r.comment}</p>}
                        {r.reply && (
                          <p className="mt-2 rounded-xl bg-brand-50 px-3.5 py-2.5 text-[12.5px] leading-6 text-brand-800">
                            <span className="font-bold">رد المركز: </span>
                            {r.reply}
                          </p>
                        )}
                      </Card>
                    )
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ---- PROFILE ---- */}
        {tab === 'profile' && (
          <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_1.2fr]">
            <Card>
              <SectionTitle title="بياناتي الشخصية" icon={<User size={18} />} />
              <div className="space-y-1">
                <InfoRow label="الاسم" value={patient.name} />
                <InfoRow label="رقم الجوال" value={<span dir="ltr">{patient.phone}</span>} />
                <InfoRow label="البريد الإلكتروني" value={patient.email || '—'} />
                <InfoRow label="رقم الهوية" value={patient.nationalId || '—'} />
                <InfoRow label="تاريخ الميلاد" value={patient.birthDate || '—'} />
                <InfoRow label="العمر" value={patient.birthDate ? `${ageFrom(patient.birthDate)} سنة` : '—'} />
                <InfoRow label="الجنس" value={genderLabel(patient.gender)} />
                <InfoRow label="فصيلة الدم" value={patient.bloodType} />
                <InfoRow label="الحساسية" value={patient.allergies} />
                <InfoRow label="الأمراض المزمنة" value={patient.chronic} />
                <InfoRow label="التأمين" value={patient.insurance} />
                <InfoRow label="العنوان" value={patient.address || '—'} />
                <InfoRow
                  label="جهات الطوارئ"
                  value={
                    patient.emergency.name
                      ? `${patient.emergency.name} (${patient.emergency.relation}) — ${patient.emergency.phone}`
                      : '—'
                  }
                />
                <InfoRow label="تاريخ الانضمام" value={formatStamp(patient.createdAt)} />
              </div>
              <Button variant="secondary" className="mt-4 w-full" onClick={openEdit}>
                تعديل البيانات
              </Button>
            </Card>

            <Card>
              <SectionTitle title="نشاطك على المنصة" subtitle="آخر الإجراءات المسجلة في ملفك" icon={<Activity size={18} />} />
              <div className="space-y-3">
                {db.activities
                  .filter((a) => a.detail.includes(patient.name) || a.actor === patient.name)
                  .slice(0, 12)
                  .map((a) => (
                    <div key={a.id} className="flex items-start gap-3 rounded-xl border border-ink-100 p-3.5">
                      <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
                        {a.category === 'booking' ? <CalendarDays size={15} /> : a.category === 'medical' ? <Pill size={15} /> : <ClipboardList size={15} />}
                      </span>
                      <div className="min-w-0">
                        <p className="text-[12.5px] font-bold text-ink-800">{a.action}</p>
                        <p className="truncate text-[11.5px] text-ink-500">{a.detail}</p>
                        <p className="mt-0.5 text-[10.5px] text-ink-400">{formatStamp(a.at)}</p>
                      </div>
                    </div>
                  ))}
                {db.activities.filter((a) => a.detail.includes(patient.name) || a.actor === patient.name).length === 0 && (
                  <EmptyState icon={<History size={22} />} title="لا يوجد نشاط مسجل" />
                )}
              </div>
            </Card>
          </div>
        )}
      </main>

      <Footer />

      {/* cancel appointment modal */}
      <Modal
        open={!!cancelTarget}
        onClose={() => !cancelling && setCancelTarget(null)}
        title="إلغاء الموعد"
        subtitle="هيتفتح الميعاد ده لمريض تاني، وهتوصلك رسالة تأكيد على واتساب."
        size="sm"
        footer={
          <>
            <Button variant="ghost" onClick={() => setCancelTarget(null)} disabled={cancelling}>
              رجوع
            </Button>
            <Button variant="danger" onClick={() => void confirmCancel()} disabled={cancelling}>
              {cancelling ? 'جارٍ الإلغاء...' : 'تأكيد الإلغاء'}
            </Button>
          </>
        }
      >
        {cancelTarget && (
          <div className="space-y-1.5 rounded-xl bg-ink-50 px-4 py-3.5 text-[13px] leading-7 text-ink-700">
            <p>
              <span className="font-bold text-ink-900">الطبيب: </span>
              {db.doctors.find((d) => d.id === cancelTarget.doctorId)?.name}
            </p>
            <p>
              <span className="font-bold text-ink-900">الموعد: </span>
              {formatFullDate(cancelTarget.date)} — {formatTime(cancelTarget.time)}
            </p>
          </div>
        )}
      </Modal>

      {/* edit profile modal */}
      <Modal
        open={!!rateTarget}
        onClose={() => setRateTarget(null)}
        title="قيّم زيارتك"
        subtitle={rateTarget ? `${db.doctors.find((d) => d.id === rateTarget.doctorId)?.name ?? ''} — ${formatFullDate(rateTarget.date)}` : ''}
        size="sm"
        footer={
          <>
            <Button variant="secondary" onClick={() => setRateTarget(null)}>
              إلغاء
            </Button>
            <Button
              onClick={() => {
                if (!rateTarget || !patient) return
                if (reviewOf(rateTarget.id)) {
                  push('تم تقييم هذه الزيارة من قبل')
                  setRateTarget(null)
                  return
                }
                const review = createReview({
                  patientId: patient.id,
                  patientName: patient.name,
                  doctorId: rateTarget.doctorId,
                  appointmentId: rateTarget.id,
                  rating,
                  comment: comment.trim(),
                })
                void notify('review.submitted', {
                  reviewId: review.id,
                  patientName: review.patientName,
                  doctorName: db.doctors.find((d) => d.id === review.doctorId)?.name ?? '',
                  rating: review.rating,
                  comment: review.comment,
                  date: review.createdAt.slice(0, 10),
                })
                push('شكراً لتقييمك!')
                setRateTarget(null)
              }}
            >
              <Star size={16} />
              إرسال التقييم
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="flex justify-center">
            <StarInput value={rating} onChange={setRating} />
          </div>
          <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="اكتب رأيك في الزيارة (اختياري)..." />
        </div>
      </Modal>

      <Modal
        open={editing}
        onClose={() => setEditing(false)}
        title="تعديل البيانات الشخصية"
        subtitle="حدّث معلوماتك ليتم التواصل معك بشكل أدق"
        footer={
          <>
            <Button variant="secondary" onClick={() => setEditing(false)}>
              إلغاء
            </Button>
            <Button onClick={saveProfile}>حفظ التعديلات</Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="الاسم الكامل" className="sm:col-span-2">
            <Input value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} />
          </Field>
          <Field label="البريد الإلكتروني" className="sm:col-span-2">
            <Input value={profile.email} onChange={(e) => setProfile({ ...profile, email: e.target.value })} dir="ltr" className="text-left" />
          </Field>
          <Field label="رقم الهوية">
            <Input value={profile.nationalId} onChange={(e) => setProfile({ ...profile, nationalId: e.target.value })} dir="ltr" className="text-left" />
          </Field>
          <Field label="الجنس">
            <Select value={profile.gender} onChange={(e) => setProfile({ ...profile, gender: e.target.value as 'male' | 'female' })}>
              <option value="male">ذكر</option>
              <option value="female">أنثى</option>
            </Select>
          </Field>
          <Field label="تاريخ الميلاد" hint={profile.birthDate ? `العمر: ${ageFrom(profile.birthDate)} سنة` : undefined}>
            <Input type="date" value={profile.birthDate} max={today} min="1900-01-01" onChange={(e) => setProfile({ ...profile, birthDate: e.target.value })} dir="ltr" className="text-left" />
          </Field>
          <Field label="فصيلة الدم">
            <Select value={profile.bloodType} onChange={(e) => setProfile({ ...profile, bloodType: e.target.value })}>
              {['غير محدد', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((t) => (
                <option key={t}>{t}</option>
              ))}
            </Select>
          </Field>
          <Field label="شركة التأمين">
            <Input value={profile.insurance} onChange={(e) => setProfile({ ...profile, insurance: e.target.value })} />
          </Field>
          <Field label="الحساسية">
            <Input value={profile.allergies} onChange={(e) => setProfile({ ...profile, allergies: e.target.value })} />
          </Field>
          <Field label="الأمراض المزمنة">
            <Input value={profile.chronic} onChange={(e) => setProfile({ ...profile, chronic: e.target.value })} />
          </Field>
          <Field label="العنوان" className="sm:col-span-2">
            <Input value={profile.address} onChange={(e) => setProfile({ ...profile, address: e.target.value })} />
          </Field>
          <Field label="اسم جهة الطوارئ">
            <Input value={profile.emergencyName} onChange={(e) => setProfile({ ...profile, emergencyName: e.target.value })} />
          </Field>
          <Field label="صلة القرابة">
            <Select value={profile.emergencyRelation} onChange={(e) => setProfile({ ...profile, emergencyRelation: e.target.value })}>
              {['الأب', 'الأم', 'الزوج', 'الزوجة', 'الأخ', 'الأخت', 'الابن', 'الابنة', 'صديق', 'أخرى'].map((r) => (
                <option key={r}>{r}</option>
              ))}
            </Select>
          </Field>
          <Field label="جوال جهة الطوارئ" className="sm:col-span-2">
            <Input value={profile.emergencyPhone} onChange={(e) => setProfile({ ...profile, emergencyPhone: e.target.value })} dir="ltr" className="text-left" placeholder="01xxxxxxxxx أو 05xxxxxxxx" />
          </Field>
        </div>
      </Modal>

      {/* prescription modal */}
      <Modal
        open={!!rx}
        onClose={() => setRx(null)}
        title="الوصفة الطبية"
        subtitle={rx?.code}
        size="lg"
        footer={
          <>
            <Button variant="secondary" onClick={() => setRx(null)}>
              إغلاق
            </Button>
            <Button
              onClick={() =>
                rx &&
                printPrescription({
                  settings: db.settings,
                  rx,
                  patient,
                  doctors: db.doctors,
                  specialties: db.specialties,
                  appointments: db.appointments,
                })
              }
            >
              <Printer size={16} />
              طباعة الوصفة
            </Button>
          </>
        }
      >
        {rx && (
          <PrintPreview
            title={`وصفة ${rx.code}`}
            html={prescriptionHtml({
              settings: db.settings,
              rx,
              patient,
              doctors: db.doctors,
              specialties: db.specialties,
              appointments: db.appointments,
            })}
          />
        )}
      </Modal>

      {/* invoice modal */}
      <Modal
        open={!!inv}
        onClose={() => setInv(null)}
        title="تفاصيل الفاتورة"
        subtitle={inv ? formatFullDate(inv.date) : ''}
        size="lg"
        footer={
          <>
            <Button variant="secondary" onClick={() => setInv(null)}>
              إغلاق
            </Button>
            <Button disabled={saving} onClick={saveInvoice}>
              {saving ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />}
              {saving ? 'جاري الحفظ…' : 'حفظ'}
            </Button>
          </>
        }
      >
        {inv && (
          <PrintPreview
            title="فاتورة"
            html={invoiceHtml({
              settings: db.settings,
              appointment: inv,
              patient,
              doctors: db.doctors,
              specialties: db.specialties,
              appointments: db.appointments,
              prescriptions: db.prescriptions,
            })}
          />
        )}
      </Modal>
    </div>
  )
}
