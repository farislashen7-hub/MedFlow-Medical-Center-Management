import { Clock, Mail, MapPin, MessageCircle, Phone } from 'lucide-react'
import { PageShell } from '../components/Layout'
import { Card, Input, Textarea, Button } from '../components/ui'
import { useToast } from '../components/Toast'
import { useState } from 'react'
import { useSettings } from '../lib/db'
import { waLink } from '../lib/format'

export default function Contact() {
  const { push } = useToast()
  const center = useSettings()
  const [form, setForm] = useState({ name: '', phone: '', message: '' })

  return (
    <PageShell className="py-10">
      <div className="text-center">
        <span className="text-[12px] font-bold tracking-widest text-brand-600">الدعم</span>
        <h1 className="mt-2 font-display text-4xl font-extrabold text-ink-950">تواصل معنا</h1>
        <p className="mx-auto mt-3 max-w-2xl text-[14.5px] leading-8 text-ink-500">
          فريق خدمة العملاء جاهز لمساعدتك في أي استفسار related بالحجز أو المتابعة الطبية.
        </p>
      </div>

      <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_1.2fr]">
        <div className="space-y-4">
          {[
            { icon: Phone, title: 'الهاتف الموحد', value: center.phone, sub: [center.workDays, center.workHours].filter(Boolean).join(' • ') },
            { icon: MessageCircle, title: 'واتساب', value: center.whatsapp || center.phone, sub: 'رد فوري خلال دقائق', href: waLink(center.whatsapp || center.phone) },
            { icon: Mail, title: 'البريد الإلكتروني', value: center.email, sub: 'خلال ساعات العمل' },
            { icon: MapPin, title: center.name, value: center.city, sub: center.address, href: center.mapUrl || undefined },
            { icon: Clock, title: 'ساعات العمل', value: center.workDays, sub: center.workHours },
          ]
            .filter((c) => c.value)
            .map((c) => (
            <Card key={c.title} className="flex items-start gap-4">
              <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                <c.icon size={20} />
              </span>
              <div>
                <p className="text-[11.5px] font-semibold text-ink-400">{c.title}</p>
                <p className="mt-0.5 font-display text-[16px] font-extrabold text-ink-900" dir="auto">
                  {c.href ? (
                    <a href={c.href} target="_blank" rel="noreferrer" className="transition hover:text-brand-700">
                      {c.value}
                    </a>
                  ) : (
                    c.value
                  )}
                </p>
                {c.sub && <p className="mt-0.5 text-[12px] text-ink-500">{c.sub}</p>}
              </div>
            </Card>
          ))}
        </div>

        <Card>
          <h2 className="font-display text-xl font-extrabold text-ink-900">أرسل لنا رسالة</h2>
          <p className="mt-1 text-[13px] text-ink-500">نرد عادة خلال أقل من 30 دقيقة في أوقات العمل.</p>
          <form
            className="mt-5 space-y-4"
            onSubmit={(e) => {
              e.preventDefault()
              if (!form.name || !form.phone) {
                push('يرجى تعبئة الاسم ورقم الجوال', 'error')
                return
              }
              push('تم استلام رسالتك، سنعاود التواصل معك قريباً')
              setForm({ name: '', phone: '', message: '' })
            }}
          >
            <Input
              placeholder="الاسم الكامل"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
            <Input
              placeholder="رقم الجوال"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />
            <Textarea
              placeholder="نص الرسالة..."
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
            />
            <Button type="submit" className="w-full">
              إرسال الرسالة
            </Button>
          </form>
        </Card>
      </div>
    </PageShell>
  )
}
