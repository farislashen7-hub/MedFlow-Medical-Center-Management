import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, CheckCircle2, Eye, EyeOff, Lock, Phone, User } from 'lucide-react'
import { Logo } from '../components/Logo'
import { Button, Field, Input } from '../components/ui'
import { useAuth } from '../lib/auth'
import { useToast } from '../components/Toast'
import { isValidPhone } from '../lib/format'
import { PatientFields, emptyPatientForm, validatePatientForm } from '../components/PatientFields'
import type { PatientFormState } from '../components/PatientFields'
import { PHONE_HINT } from '../lib/phone'

function SubTitle({ children }: { children: string }) {
  return <h3 className="border-b border-ink-100 pb-2 pt-2 text-[12.5px] font-bold text-brand-700">{children}</h3>
}

export default function Register() {
  const { registerPatient } = useAuth()
  const { push } = useToast()
  const navigate = useNavigate()
  const location = useLocation()
  const prefillPhone = (location.state as { phone?: string } | null)?.phone ?? ''
  const [form, setForm] = useState({
    name: '',
    phone: prefillPhone,
    email: '',
    password: '',
    confirm: '',
  })
  const [pf, setPf] = useState<PatientFormState>(emptyPatientForm())
  const [show, setShow] = useState(false)
  const [error, setError] = useState('')
  const set = (patch: Partial<typeof form>) => setForm((f) => ({ ...f, ...patch }))

  function submit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!form.name.trim()) return setError('يرجى إدخال الاسم الكامل.')
    if (!isValidPhone(form.phone)) return setError(PHONE_HINT)
    if (form.email.trim() && !/^\S+@\S+\.\S+$/.test(form.email.trim())) return setError('البريد الإلكتروني غير صحيح.')
    const checked = validatePatientForm(pf)
    if (checked.error || !checked.values) return setError(checked.error || 'بيانات المريض غير مكتملة.')
    if (form.password.length < 6) return setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل.')
    if (form.password !== form.confirm) return setError('كلمتا المرور غير متطابقتين.')

    const result = registerPatient({
      name: form.name,
      phone: form.phone,
      password: form.password,
      email: form.email.trim(),
      ...checked.values,
    })
    if (!result.ok) {
      setError(result.error || 'تعذر إنشاء الحساب.')
      return
    }
    push('تم إنشاء حسابك بنجاح، أهلاً بك في medflow')
    navigate('/patient', { replace: true })
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex flex-col justify-center px-5 py-10 sm:px-12 lg:px-16">
        <div className="mx-auto w-full max-w-xl">
          <Link to="/" className="inline-block">
            <Logo />
          </Link>

          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }} className="mt-9">
            <h1 className="font-display text-3xl font-extrabold text-ink-950">إنشاء حساب مريض</h1>
            <p className="mt-2 text-[13.5px] leading-7 text-ink-500">
              أدخل بياناتك مرة واحدة ليكون ملفك الطبي جاهزاً عند كل زيارة. رقم الجوال هو رقم الدخول إلى حسابك.
            </p>

            <form onSubmit={submit} className="mt-7 grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <SubTitle>البيانات الأساسية</SubTitle>
              </div>
              <Field label="الاسم الكامل" required className="sm:col-span-2">
                <div className="relative">
                  <User size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-400" />
                  <Input value={form.name} onChange={(e) => set({ name: e.target.value })} placeholder="مثال: محمد عبدالله الفهد" className="pr-11" />
                </div>
              </Field>

              <Field label="رقم الجوال" hint="مصري (01xxxxxxxxx) أو خليجي (05xxxxxxxx / +966…)" required>
                <div className="relative">
                  <Phone size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-400" />
                  <Input value={form.phone} onChange={(e) => set({ phone: e.target.value })} placeholder="01xxxxxxxxx أو 05xxxxxxxx" dir="ltr" className="pr-11 text-left" />
                </div>
              </Field>
              <Field label="البريد الإلكتروني (اختياري)">
                <Input type="email" value={form.email} onChange={(e) => set({ email: e.target.value })} placeholder="name@example.com" dir="ltr" className="text-left" />
              </Field>

              <div className="sm:col-span-2">
                <PatientFields form={pf} onChange={(patch) => setPf((f) => ({ ...f, ...patch }))} />
              </div>

              <div className="sm:col-span-2">
                <SubTitle>الحساب</SubTitle>
              </div>
              <Field label="كلمة المرور" required>
                <div className="relative">
                  <Input
                    type={show ? 'text' : 'password'}
                    value={form.password}
                    onChange={(e) => set({ password: e.target.value })}
                    placeholder="6 أحرف على الأقل"
                    dir="ltr"
                    className="pl-10 text-left"
                  />
                  <button
                    type="button"
                    onClick={() => setShow((v) => !v)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 p-1 text-ink-400 hover:text-ink-700"
                    aria-label="إظهار كلمة المرور"
                  >
                    {show ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </Field>
              <Field label="تأكيد كلمة المرور" required>
                <div className="relative">
                  <Lock size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-400" />
                  <Input
                    type={show ? 'text' : 'password'}
                    value={form.confirm}
                    onChange={(e) => set({ confirm: e.target.value })}
                    placeholder="أعد كتابة كلمة المرور"
                    dir="ltr"
                    className="pr-11 text-left"
                  />
                </div>
              </Field>

              {error && (
                <p className="rounded-xl bg-rose-50 px-4 py-3 text-[12.5px] font-semibold text-rose-700 ring-1 ring-rose-200 sm:col-span-2">
                  {error}
                </p>
              )}

              <Button type="submit" size="lg" className="w-full sm:col-span-2">
                <CheckCircle2 size={17} />
                إنشاء الحساب
              </Button>
            </form>

            <p className="mt-6 text-center text-[13px] text-ink-500">
              لديك حساب بالفعل؟{' '}
              <Link to="/login" className="font-bold text-brand-700 hover:underline">
                تسجيل الدخول
              </Link>
            </p>
            <Link
              to="/"
              className="mt-4 flex items-center justify-center gap-1.5 text-[12.5px] font-semibold text-ink-500 hover:text-brand-700"
            >
              العودة للرئيسية
              <ArrowLeft size={14} />
            </Link>
          </motion.div>
        </div>
      </div>

      <div className="relative hidden overflow-hidden bg-brand-900 lg:block">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-800 via-brand-700 to-ink-900" />
        <div className="absolute -right-20 top-20 size-80 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-24 -left-16 size-96 rounded-full bg-brand-400/20 blur-3xl" />
        <div className="relative flex h-full flex-col justify-center px-16 text-white">
          <h2 className="font-display text-4xl leading-[1.35] font-extrabold">
            كل ما تحتاجه لرعايتك
            <br />
            في بوابة واحدة
          </h2>
          <ul className="mt-9 space-y-4">
            {[
              'حجز فوري مع أفضل الأطباء حسب التخصص',
              'سجل كامل لمواعيدك وتاريخ الحالات',
              'وصفاتك الطبية جاهزة للتحميل والمتابعة',
              'تذكيرات واتساب تلقائية لكل موعد',
            ].map((t) => (
              <li key={t} className="flex items-center gap-3 text-[14px] text-brand-50">
                <span className="flex size-6 items-center justify-center rounded-full bg-white/15">
                  <CheckCircle2 size={14} />
                </span>
                {t}
              </li>
            ))}
          </ul>
          <p className="mt-12 text-[12.5px] text-brand-100/80">
            بياناتك محمية ولا تتم مشاركتها مع أي جهة خارجية دون إذنك.
          </p>
        </div>
      </div>
    </div>
  )
}
