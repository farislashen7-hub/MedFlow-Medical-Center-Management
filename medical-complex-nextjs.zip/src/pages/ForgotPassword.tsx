import { useEffect, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowRight, Eye, EyeOff, FilePlus2, KeyRound, MessageCircle, RefreshCw } from 'lucide-react'
import { Logo } from '../components/Logo'
import { Button, Field, Input } from '../components/ui'
import { OtpInput } from '../components/OtpInput'
import { useAuth } from '../lib/auth'
import { useToast } from '../components/Toast'
import { findPatientByPhone, logActivity, updatePatient } from '../lib/db'
import { isValidPhone } from '../lib/format'
import { PHONE_HINT } from '../lib/phone'
import { requestResetCode, resetErrorText, verifyResetCode } from '../lib/passwordReset'

type Step = 'phone' | 'code'

export default function ForgotPassword() {
  const { login } = useAuth()
  const { push } = useToast()
  const navigate = useNavigate()
  const location = useLocation()
  const [step, setStep] = useState<Step>('phone')
  const [phone, setPhone] = useState((location.state as { phone?: string } | null)?.phone ?? '')
  const [code, setCode] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [notFound, setNotFound] = useState(false)
  const [busy, setBusy] = useState(false)
  const [wait, setWait] = useState(0)

  // عدّاد إعادة الإرسال
  useEffect(() => {
    if (wait <= 0) return
    const t = setTimeout(() => setWait((w) => w - 1), 1000)
    return () => clearTimeout(t)
  }, [wait])

  async function sendCode(e?: React.FormEvent) {
    e?.preventDefault()
    setError('')
    setNotFound(false)
    if (!isValidPhone(phone)) return setError(PHONE_HINT)
    // الحسابات محلية: لو مفيش ملف بالرقم ده على الجهاز مفيش داعي نبعت كود
    if (!findPatientByPhone(phone)) {
      setNotFound(true)
      return setError('لا يوجد ملف مريض بهذا الرقم على هذا الجهاز. لو أول مرة تزورنا، أنشئ ملفك.')
    }
    setBusy(true)
    const r = await requestResetCode(phone)
    setBusy(false)
    if (!r.ok) {
      if (r.error === 'TOO_SOON') {
        setWait(r.retryAfter ?? 60)
        setStep('code') // الكود اتبعت قبل كده، كمّل بيه
      }
      return setError(resetErrorText(r))
    }
    setCode('')
    setWait(r.cooldown ?? 60)
    setStep('code')
    push('بعتنا كود التحقق على واتساب')
  }

  async function resetPassword(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (code.length !== 6) return setError('اكتب الكود المكوّن من 6 أرقام.')
    if (password.length < 6) return setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل.')
    if (password !== confirm) return setError('كلمتا المرور غير متطابقتين.')
    const patient = findPatientByPhone(phone)
    if (!patient) return setError('لا يوجد ملف مريض بهذا الرقم على هذا الجهاز.')

    setBusy(true)
    const v = await verifyResetCode(phone, code)
    if (!v.ok) {
      setBusy(false)
      if (v.error === 'INVALID_CODE') setCode('')
      return setError(resetErrorText(v))
    }
    updatePatient(patient.id, { password })
    logActivity(patient.name, 'patient', 'تغيير كلمة المرور', 'استعاد كلمة المرور بكود التحقق', 'login')
    const result = login('patient', phone, password)
    setBusy(false)
    if (!result.ok) {
      push('تم تحديث كلمة المرور، سجّل الدخول الآن')
      return navigate('/login', { replace: true })
    }
    push('تم تحديث كلمة المرور بنجاح')
    navigate('/patient', { replace: true })
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1.05fr]">
      <div className="flex flex-col justify-center px-5 py-10 sm:px-12 lg:px-16">
        <div className="mx-auto w-full max-w-md">
          <Link to="/" className="inline-block">
            <Logo />
          </Link>

          <motion.div
            key={step}
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="mt-10"
          >
            <span className="grid size-12 place-items-center rounded-2xl bg-brand-50 text-brand-600 ring-1 ring-brand-100">
              {step === 'phone' ? <KeyRound size={22} /> : <MessageCircle size={22} />}
            </span>
            <h1 className="mt-5 font-display text-3xl font-extrabold text-ink-950">
              {step === 'phone' ? 'نسيت كلمة المرور؟' : 'اكتب كود التحقق'}
            </h1>
            <p className="mt-2 text-[13.5px] leading-7 text-ink-500">
              {step === 'phone'
                ? 'اكتب رقم جوالك وهنبعتلك كود من 6 أرقام على واتساب علشان تعمل كلمة مرور جديدة.'
                : 'بعتنا كود من 6 أرقام على واتساب للرقم '}
              {step === 'code' && (
                <span dir="ltr" className="font-bold text-ink-800">
                  {phone}
                </span>
              )}
            </p>

            {step === 'phone' ? (
              <form onSubmit={sendCode} className="mt-7 space-y-4">
                <Field label="رقم الجوال" required>
                  <Input
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="01xxxxxxxxx أو 05xxxxxxxx"
                    dir="ltr"
                    className="text-left"
                    inputMode="tel"
                    autoComplete="username"
                    autoFocus
                  />
                </Field>

                {error && (
                  <p className="rounded-xl bg-rose-50 px-4 py-3 text-[12.5px] font-semibold text-rose-700 ring-1 ring-rose-200">
                    {error}
                  </p>
                )}
                {notFound && (
                  <Link to="/register" state={{ phone: phone.trim() }}>
                    <Button type="button" variant="secondary" size="lg" className="w-full">
                      <FilePlus2 size={17} />
                      إنشاء ملف مريض جديد
                    </Button>
                  </Link>
                )}

                <Button type="submit" size="lg" className="w-full" disabled={busy}>
                  <MessageCircle size={17} />
                  {busy ? 'جارٍ الإرسال...' : 'إرسال الكود'}
                </Button>
              </form>
            ) : (
              <form onSubmit={resetPassword} className="mt-7 space-y-4">
                <Field label="كود التحقق" required>
                  <OtpInput value={code} onChange={setCode} invalid={!!error && code.length === 0} autoFocus />
                </Field>

                <Field label="كلمة المرور الجديدة" required hint="6 أحرف على الأقل">
                  <div className="relative">
                    <Input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      dir="auto"
                      autoComplete="new-password"
                      className="pl-11"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((v) => !v)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-ink-400 transition hover:text-ink-700"
                      aria-label="إظهار كلمة المرور"
                    >
                      {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                    </button>
                  </div>
                </Field>

                <Field label="تأكيد كلمة المرور" required>
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    placeholder="••••••••"
                    dir="auto"
                    autoComplete="new-password"
                  />
                </Field>

                {error && (
                  <p className="rounded-xl bg-rose-50 px-4 py-3 text-[12.5px] font-semibold text-rose-700 ring-1 ring-rose-200">
                    {error}
                  </p>
                )}

                <Button type="submit" size="lg" className="w-full" disabled={busy}>
                  <KeyRound size={17} />
                  {busy ? 'جارٍ التحديث...' : 'تحديث كلمة المرور'}
                </Button>

                <div className="flex items-center justify-between text-[12.5px]">
                  <button
                    type="button"
                    onClick={() => {
                      setStep('phone')
                      setError('')
                    }}
                    className="font-semibold text-ink-500 hover:text-ink-800"
                  >
                    تغيير الرقم
                  </button>
                  <button
                    type="button"
                    onClick={() => void sendCode()}
                    disabled={wait > 0 || busy}
                    className="inline-flex items-center gap-1.5 font-bold text-brand-700 transition hover:underline disabled:cursor-not-allowed disabled:text-ink-300 disabled:no-underline"
                  >
                    <RefreshCw size={13} />
                    {wait > 0 ? `إعادة الإرسال بعد ${wait} ث` : 'إعادة إرسال الكود'}
                  </button>
                </div>
              </form>
            )}

            <Link
              to="/login"
              className="mt-8 flex items-center justify-center gap-1.5 border-t border-ink-100 pt-5 text-[12.5px] font-semibold text-ink-500 hover:text-brand-700"
            >
              <ArrowRight size={14} />
              رجوع لتسجيل الدخول
            </Link>
          </motion.div>
        </div>
      </div>

      <div className="relative hidden overflow-hidden lg:block">
        <img src="/images/login-side.jpg" alt="مركز طبي" className="absolute inset-0 size-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/55 to-ink-900/25" />
        <div className="relative flex h-full flex-col justify-end p-14 text-white">
          <h2 className="max-w-lg font-display text-4xl leading-[1.3] font-extrabold">حسابك في أمان</h2>
          <p className="mt-4 max-w-md text-[14px] leading-8 text-ink-200">
            الكود بيوصل على واتساب رقمك بس، وصلاحيته 10 دقايق، ويشتغل مرة واحدة.
          </p>
        </div>
      </div>
    </div>
  )
}
