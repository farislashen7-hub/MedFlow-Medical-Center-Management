import { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Activity,
  BarChart3,
  Building2,
  CalendarDays,
  CalendarClock,
  CheckCircle2,
  ClipboardList,
  DollarSign,
  Download,
  FileBarChart,
  Filter,
  History,
  MessageCircle,
  Megaphone,
  ShieldAlert,
  Phone,
  PieChart,
  Plus,
  Printer,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  Stethoscope,
  Trash2,
  TrendingUp,
  Star,
  Upload,
  UserCheck,
  UserCog,
  Users,
  X,
  XCircle,
} from 'lucide-react'
import {
  useDB,
  createDoctor,
  logActivity,
  clearAllThreads,
  markThreadRead,
  removeDoctor,
  resetDB,
  sendWhatsApp,
  setAppointmentStatus,
  setThreadAgent,
  toggleThreadStatus,
  updateDoctor,
} from '../lib/db'
import { useToast } from '../components/Toast'
import { Header, Footer } from '../components/Layout'
import {
  Avatar,
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Input,
  Modal,
  SectionTitle,
  Select,
  StatCard,
  Tabs,
  Textarea,
} from '../components/ui'
import { BarChart, DonutChart, LineChart } from '../components/charts'
import { isValidPhone, downloadCsv, formatFullDate, formatStamp, formatStampTime, formatTime, fromDateKey, money, toDateKey, waLink } from '../lib/format'
import { fileToDataUrl } from '../lib/image'
import { DoctorCredentials, doctorUsername, generatePassword, RegenIcon } from '../components/DoctorCredentials'
import { PHONE_HINT, samePhone } from '../lib/phone'
import { CenterSettingsForm } from '../components/CenterSettingsForm'
import { OffersHub } from '../components/OffersHub'
import { ReviewsDashboard } from '../components/ReviewsDashboard'
import { wipeRemoteChats } from '../lib/wipeChats'
import { ComplaintsHub } from '../components/ComplaintsHub'
import { onNewComplaint, useComplaints } from '../lib/complaints'
import { ReportsHub } from '../components/ReportsHub'
import { AttendanceHub, DoctorSchedulesBoard } from '../components/AttendanceHub'
import { printInvoice } from '../lib/print'
import { isDoctorOffNow } from '../lib/slots'
import type { Activity as ActivityType, Appointment, Doctor } from '../lib/types'

const statusMeta: Record<Appointment['status'], { label: string; tone: 'brand' | 'green' | 'rose' | 'amber' | 'sky' }> = {
  scheduled: { label: 'مجدول', tone: 'sky' },
  confirmed: { label: 'مؤكد', tone: 'brand' },
  completed: { label: 'مكتمل', tone: 'green' },
  cancelled: { label: 'ملغي', tone: 'rose' },
  'no-show': { label: 'لم يحضر', tone: 'amber' },
}

const categoryMeta: Record<ActivityType['category'], { label: string; tone: 'brand' | 'green' | 'rose' | 'amber' | 'violet' | 'sky' | 'slate' }> = {
  booking: { label: 'حجز', tone: 'sky' },
  login: { label: 'دخول', tone: 'slate' },
  medical: { label: 'طبي', tone: 'violet' },
  whatsapp: { label: 'واتساب', tone: 'green' },
  admin: { label: 'إدارة', tone: 'amber' },
  patient: { label: 'مريض', tone: 'brand' },
}

const roleLabel = { admin: 'إدارة', doctor: 'طبيب', patient: 'مريض' }

export default function AdminDashboard() {
  const db = useDB()
  const { push } = useToast()
  const [tab, setTab] = useState('overview')
  const [showWipe, setShowWipe] = useState(false)
  const [wiping, setWiping] = useState(false)
  const { items: complaints } = useComplaints()
  const newComplaints = complaints.filter((c) => c.status === 'new').length
  // شكوى جديدة من واتساب: تنبيه لحظي (توست + عنوان التبويب لو الصفحة في الخلفية)
  useEffect(() => {
    const orig = document.title
    const reset = () => {
      if (!document.hidden) document.title = orig
    }
    document.addEventListener('visibilitychange', reset)
    const off = onNewComplaint((c) => {
      push(`شكوى جديدة من ${c.patientName}: ${c.subject}`, 'error')
      if (document.hidden) document.title = '🔴 شكوى جديدة'
    })
    return () => {
      document.removeEventListener('visibilitychange', reset)
      off()
      document.title = orig
    }
  }, [push])
  const [activityFilter, setActivityFilter] = useState('all')
  const [activityQuery, setActivityQuery] = useState('')
  const [threadQuery, setThreadQuery] = useState('')
  const [apptFilter, setApptFilter] = useState('all')
  const [apptQuery, setApptQuery] = useState('')
  const [selectedThread, setSelectedThread] = useState<string>(db.threads[0]?.id || '')
  const [message, setMessage] = useState('')
  const [agentName, setAgentName] = useState('أ. سلمى - خدمة العملاء')
  const replyAsOptions = Array.from(
    new Set([db.settings.name, 'أ. سلمى - خدمة العملاء', ...db.admins.map((a) => a.name), agentName].filter(Boolean)),
  )
  const [showAddDoctor, setShowAddDoctor] = useState(false)
  const [editDoctor, setEditDoctor] = useState<Doctor | null>(null)
  /** الطبيب اللي لسه متضاف — بنعرض له بيانات الدخول مرة في نافذة */
  const [createdDoctor, setCreatedDoctor] = useState<Doctor | null>(null)
  const [doctorForm, setDoctorForm] = useState({
    name: '',
    title: '',
    specialtyId: '',
    phone: '',
    password: generatePassword(),
    email: '',
    fee: 250,
    location: 'الرياض',
    clinic: '',
    bio: '',
    image: '',
    days: [0, 1, 2, 3, 4] as number[],
    startHour: 9,
    endHour: 17,
  })

  const today = toDateKey(new Date())

  /* ---------------- derived stats ---------------- */
  const stats = useMemo(() => {
    const total = db.appointments.length
    const completed = db.appointments.filter((a) => a.status === 'completed').length
    const cancelled = db.appointments.filter((a) => a.status === 'cancelled').length
    const noShow = db.appointments.filter((a) => a.status === 'no-show').length
    const upcoming = db.appointments.filter((a) => a.date >= today && a.status !== 'cancelled').length
    const revenue = db.appointments
      .filter((a) => a.status === 'completed')
      .reduce((s, a) => s + a.fee, 0)
    const todayCount = db.appointments.filter((a) => a.date === today && a.status !== 'cancelled').length
    return {
      total,
      completed,
      cancelled,
      noShow,
      upcoming,
      revenue,
      todayCount,
      patients: db.patients.length,
      doctors: db.doctors.length,
      activeDoctors: db.doctors.filter((d) => d.active).length,
      prescriptions: db.prescriptions.length,
      openThreads: db.threads.filter((t) => t.status === 'open').length,
      humanThreads: db.threads.filter((t) => t.humanAgent).length,
      unread: db.threads.reduce((s, t) => s + t.unread, 0),
      attendance: total ? Math.round((completed / total) * 100) : 0,
      cancelRate: total ? Math.round((cancelled / total) * 100) : 0,
      noShowRate: total ? Math.round((noShow / total) * 100) : 0,
      avgRating:
        db.doctors.reduce((s, d) => s + d.rating, 0) / Math.max(1, db.doctors.length),
      reviewCount: db.reviews.filter((r) => r.status === 'published').length,
      reviewAvg:
        db.reviews.filter((r) => r.status === 'published').reduce((s, r) => s + r.rating, 0) /
        Math.max(1, db.reviews.filter((r) => r.status === 'published').length),
    }
  }, [db, today])

  const monthly = useMemo(() => {
    const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
    const now = new Date()
    const out: { label: string; value: number }[] = []
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
      out.push({
        label: months[d.getMonth()],
        value: db.appointments.filter((a) => a.date.startsWith(key)).length,
      })
    }
    return out
  }, [db.appointments])

  const revenueMonthly = useMemo(() => {
    const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
    const now = new Date()
    return Array.from({ length: 6 }, (_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1)
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
      return {
        label: months[d.getMonth()],
        value: db.appointments
          .filter((a) => a.date.startsWith(key) && a.status === 'completed')
          .reduce((s, a) => s + a.fee, 0),
      }
    })
  }, [db.appointments])

  const specialtyStats = useMemo(() => {
    const colors = ['#0f8271', '#e11d48', '#0ea5e9', '#8b5cf6', '#f59e0b', '#ec4899', '#10b981', '#06b6d4']
    return db.specialties.map((sp, i) => ({
      label: sp.name,
      value: db.appointments.filter((a) => a.specialtyId === sp.id).length,
      color: colors[i % colors.length],
    }))
  }, [db.specialties, db.appointments])

  const statusStats = useMemo(
    () =>
      (['completed', 'scheduled', 'confirmed', 'cancelled', 'no-show'] as const).map((s) => ({
        label: statusMeta[s].label,
        value: db.appointments.filter((a) => a.status === s).length,
        color:
          s === 'completed'
            ? '#10b981'
            : s === 'scheduled'
              ? '#38bdf8'
              : s === 'confirmed'
                ? '#0f8271'
                : s === 'cancelled'
                  ? '#f43f5e'
                  : '#f59e0b',
      })),
    [db.appointments],
  )

  const weekdayStats = useMemo(() => {
    const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']
    return days.map((d, i) => ({
      label: d,
      value: db.appointments.filter((a) => fromDateKey(a.date).getDay() === i).length,
    }))
  }, [db.appointments])

  const doctorPerformance = useMemo(
    () =>
      db.doctors
        .map((d) => {
          const appts = db.appointments.filter((a) => a.doctorId === d.id)
          const completed = appts.filter((a) => a.status === 'completed').length
          const noShow = appts.filter((a) => a.status === 'no-show').length
          return {
            doctor: d,
            total: appts.length,
            completed,
            noShow,
            revenue: appts.filter((a) => a.status === 'completed').reduce((s, a) => s + a.fee, 0),
            rate: appts.length ? Math.round((completed / appts.length) * 100) : 0,
          }
        })
        .sort((a, b) => b.total - a.total),
    [db.doctors, db.appointments],
  )

  const filteredActivities = useMemo(() => {
    const q = activityQuery.trim()
    return db.activities.filter((a) => {
      const catOk = activityFilter === 'all' || a.category === activityFilter
      const qOk = !q || a.actor.includes(q) || a.action.includes(q) || a.detail.includes(q)
      return catOk && qOk
    })
  }, [db.activities, activityFilter, activityQuery])

  const filteredAppointments = useMemo(() => {
    const q = apptQuery.trim()
    return db.appointments.filter((a) => {
      const sOk = apptFilter === 'all' || a.status === apptFilter
      const qOk =
        !q ||
        a.patientName.includes(q) ||
        a.patientPhone.includes(q) ||
        db.doctors.find((d) => d.id === a.doctorId)?.name.includes(q)
      return sOk && qOk
    })
  }, [db.appointments, apptFilter, apptQuery, db.doctors])

  const thread = db.threads.find((t) => t.id === selectedThread)

  /* ---------------- actions ---------------- */
  function openDoctorModal(d?: Doctor) {
    if (d) {
      setEditDoctor(d)
      setDoctorForm({
        name: d.name,
        title: d.title,
        specialtyId: d.specialtyId,
        phone: d.phone,
        password: d.password,
        email: d.email,
        fee: d.fee,
        location: d.location,
        clinic: d.clinic,
        bio: d.bio,
        image: d.image,
        days: d.days,
        startHour: d.startHour,
        endHour: d.endHour,
      })
    } else {
      setEditDoctor(null)
      setDoctorForm({
        name: '',
        title: 'استشاري',
        specialtyId: db.specialties[0]?.id || '',
        phone: '',
        password: generatePassword(),
        email: '',
        fee: 250,
        location: 'الرياض',
        clinic: '',
        bio: '',
        image: '',
        days: [0, 1, 2, 3, 4],
        startHour: 9,
        endHour: 17,
      })
    }
    setShowAddDoctor(true)
  }

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (file.size > 8 * 1024 * 1024) {
      push('حجم الصورة كبير جداً — اختر صورة أصغر من 8 ميجابايت', 'error')
      return
    }
    try {
      const dataUrl = await fileToDataUrl(file, 480)
      if (dataUrl.length > 900_000) {
        push('تعذر تصغير الصورة، جرّب صورة أخرى', 'error')
        return
      }
      setDoctorForm((f) => ({ ...f, image: dataUrl }))
      push('تم رفع صورة الطبيب')
    } catch (err) {
      push(err instanceof Error ? err.message : 'تعذر معالجة الصورة', 'error')
    }
  }

  function saveDoctor() {
    const f = doctorForm
    if (!f.name.trim() || !f.specialtyId) {
      push('يرجى تعبئة اسم الطبيب والتخصص', 'error')
      return
    }
    if (!isValidPhone(f.phone)) {
      push(PHONE_HINT, 'error')
      return
    }
    const email = f.email.trim().toLowerCase()
    if (email && !/^\S+@\S+\.\S+$/.test(email)) {
      push('البريد الإلكتروني غير صحيح', 'error')
      return
    }
    if (f.password.length < 6) {
      push('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'error')
      return
    }
    // اليوزر لازم يكون فريد: ماينفعش طبيب/مالك تاني بنفس الرقم أو البريد
    const clash =
      db.doctors.some((d) => d.id !== editDoctor?.id && (samePhone(d.phone, f.phone) || (email && d.email.toLowerCase() === email))) ||
      db.admins.some((a) => samePhone(a.phone, f.phone) || (email && a.email.toLowerCase() === email))
    if (clash) {
      push('الرقم أو البريد مستخدم لحساب آخر، غيّره', 'error')
      return
    }
    const payload = { ...f, email }
    if (editDoctor) {
      updateDoctor(editDoctor.id, payload)
      logActivity('الإدارة', 'admin', 'تعديل طبيب', `تم تحديث بيانات ${f.name}`, 'admin')
      push('تم تحديث بيانات الطبيب')
    } else {
      const created = createDoctor(payload)
      logActivity('الإدارة', 'admin', 'إضافة طبيب', `تمت إضافة ${f.name} إلى العيادة`, 'admin')
      push('تمت إضافة الطبيب بنجاح')
      setCreatedDoctor(created)
    }
    setShowAddDoctor(false)
  }

  function deleteDoctor(d: Doctor) {
    if (!confirm(`هل تريد حذف الطبيب ${d.name}؟`)) return
    removeDoctor(d.id)
    logActivity('الإدارة', 'admin', 'حذف طبيب', `تم حذف ${d.name}`, 'admin')
    push('تم حذف الطبيب')
  }

  async function wipeAllChats() {
    setWiping(true)
    const remote = await wipeRemoteChats()
    clearAllThreads(remote.ok)
    setSelectedThread('')
    setWiping(false)
    setShowWipe(false)
    if (remote.ok) push('تم مسح كل المحادثات وبيانات واتساب')
    else push(`اتمسحت من الموقع بس. ${remote.error ?? ''}`, 'error')
  }

  function sendMessage(from: 'agent' | 'bot') {
    if (!thread || !message.trim()) return
    sendWhatsApp(thread.id, message.trim(), from)
    setMessage('')
  }

  function toggleHuman() {
    if (!thread) return
    if (thread.humanAgent) {
      setThreadAgent(thread.id, null)
      logActivity('الإدارة', 'admin', 'إنهاء تفاعل بشري', `إنهاء التفاعل البشري مع ${thread.patientName}`, 'whatsapp')
      push('تم إنهاء التفاعل البشري وإعادة المحادثة للمساعد الآلي')
    } else {
      setThreadAgent(thread.id, agentName)
      logActivity('الإدارة', 'admin', 'بدء تفاعل بشري', `تحويل محادثة ${thread.patientName} إلى ${agentName}`, 'whatsapp')
      push('تم تحويل المحادثة إلى موظف بشري')
    }
  }

  function exportAppointments() {
    downloadCsv('appointments.csv', [
      ['رقم الحجز', 'المريض', 'الجوال', 'الطبيب', 'التاريخ', 'الوقت', 'الحالة', 'النوع', 'المبلغ'],
      ...db.appointments.map((a) => [
        a.id,
        a.patientName,
        a.patientPhone,
        db.doctors.find((d) => d.id === a.doctorId)?.name || '',
        a.date,
        a.time,
        statusMeta[a.status].label,
        a.type,
        a.fee,
      ]),
    ])
    push('تم تصدير تقرير المواعيد')
  }

  function exportDoctors() {
    downloadCsv('doctors.csv', [
      ['الطبيب', 'التخصص', 'الجوال', 'سنوات الخبرة', 'التقييم', 'سعر الكشف', 'الحالة'],
      ...db.doctors.map((d) => [
        d.name,
        db.specialties.find((s) => s.id === d.specialtyId)?.name || '',
        d.phone,
        d.years,
        d.rating,
        d.fee,
        d.active ? 'نشط' : 'موقوف',
      ]),
    ])
    push('تم تصدير تقرير الأطباء')
  }

  function exportPatients() {
    downloadCsv('patients.csv', [
      ['المريض', 'الجوال', 'البريد', 'العمر', 'فصيلة الدم', 'الحساسية', 'الأمراض المزمنة'],
      ...db.patients.map((p) => [p.name, p.phone, p.email, p.birthDate, p.bloodType, p.allergies, p.chronic]),
    ])
    push('تم تصدير تقرير المرضى')
  }

  function exportActivities() {
    downloadCsv('activities.csv', [
      ['النشاط', 'التفاصيل', 'المنفذ', 'الدور', 'التاريخ'],
      ...db.activities.map((a) => [a.action, a.detail, a.actor, roleLabel[a.actorRole], a.at]),
    ])
    push('تم تصدير سجل الأنشطة')
  }

  return (
    <div className="min-h-screen bg-[#f5f8f8]">
      <Header />

      <main className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* admin header */}
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <Card className="relative overflow-hidden !bg-ink-950 !text-white">
            <div className="absolute -left-20 -top-24 size-72 rounded-full bg-brand-600/20 blur-3xl" />
            <div className="relative flex flex-col items-start gap-5 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-5">
                <span className="flex size-16 shrink-0 items-center justify-center rounded-3xl bg-brand-600">
                  <ShieldCheck size={30} />
                </span>
                <div>
                  <p className="text-[12px] font-semibold text-brand-300">لوحة الإدارة</p>
                  <h1 className="mt-1 font-display text-2xl font-extrabold sm:text-3xl">إدارة العيادة</h1>
                  <p className="mt-1.5 text-[13px] text-ink-300">
                    نظرة شاملة على المواعيد والأطباء والمرضى والأنشطة ومحادثات واتساب
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2.5">
                <Button
                  variant="secondary"
                  className="!border-white/25 !bg-white/10 !text-white hover:!bg-white/20"
                  onClick={() => {
                    if (confirm('سيتم إعادة ضبط جميع البيانات التجريبية. هل أنت متأكد؟')) {
                      resetDB()
                      push('تمت إعادة ضبط البيانات التجريبية')
                    }
                  }}
                >
                  <RefreshCw size={16} />
                  إعادة ضبط البيانات
                </Button>
                <Button onClick={() => openDoctorModal()}>
                  <Plus size={17} />
                  إضافة طبيب
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* KPIs */}
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="إجمالي المواعيد" value={stats.total} icon={<CalendarDays size={20} />} tone="brand" hint={`${stats.upcoming} موعد قادم`} />
          <StatCard label="الإيرادات المحصلة" value={money(stats.revenue)} icon={<DollarSign size={20} />} tone="green" hint="من المواعيد المكتملة" />
          <StatCard label="المرضى المسجلون" value={stats.patients} icon={<Users size={20} />} tone="violet" hint={`${stats.activeDoctors} طبيب نشط`} />
          <StatCard label="محادثات واتساب" value={stats.openThreads} icon={<MessageCircle size={20} />} tone="amber" hint={`${stats.unread} رسالة غير مقروءة`} />
        </div>

        {/* tabs */}
        <div className="mt-6">
          <Tabs
            active={tab}
            onChange={setTab}
            items={[
              { id: 'overview', label: 'نظرة عامة', icon: <PieChart size={15} /> },
              { id: 'activities', label: 'الأنشطة', icon: <Activity size={15} />, count: db.activities.length },
              { id: 'doctors', label: 'الأطباء', icon: <Stethoscope size={15} />, count: db.doctors.length },
              { id: 'schedules', label: 'جداول الأطباء', icon: <CalendarClock size={15} /> },
              { id: 'attendance', label: 'حضور وغياب الأطباء', icon: <UserCheck size={15} /> },
              { id: 'appointments', label: 'المواعيد', icon: <CalendarDays size={15} />, count: db.appointments.length },
              { id: 'whatsapp', label: 'محادثات واتساب', icon: <MessageCircle size={15} />, count: stats.unread },
              { id: 'reports', label: 'التقارير والإحصائيات', icon: <FileBarChart size={15} /> },
              { id: 'offers', label: 'العروض والآراء', icon: <Megaphone size={15} /> },
              { id: 'complaints', label: 'الشكاوي', icon: <ShieldAlert size={15} />, count: newComplaints },
              { id: 'reviews', label: 'آراء العملاء', icon: <Star size={15} />, count: db.reviews.length },
              { id: 'center', label: 'بيانات المركز', icon: <Building2 size={15} /> },
            ]}
          />
        </div>

        {/* ---------------- OVERVIEW ---------------- */}
        {tab === 'offers' && <OffersHub />}
        {tab === 'reviews' && <ReviewsDashboard />}
        {tab === 'complaints' && <ComplaintsHub />}

        {tab === 'center' && <CenterSettingsForm />}

        {tab === 'overview' && (
          <div className="mt-5 space-y-5">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
              <StatCard label="مواعيد اليوم" value={stats.todayCount} icon={<CalendarDays size={20} />} tone="sky" />
              <StatCard label="الوصفات الصادرة" value={stats.prescriptions} icon={<ClipboardList size={20} />} tone="violet" />
              <StatCard label="نسبة الحضور" value={`${stats.attendance}%`} icon={<UserCheck size={20} />} tone="green" />
              <StatCard label="نسبة الإلغاء" value={`${stats.cancelRate}%`} icon={<XCircle size={20} />} tone="rose" />
              <StatCard
                label="تقييم المرضى"
                value={stats.reviewCount ? `${stats.reviewAvg.toFixed(1)} / 5` : '—'}
                icon={<Star size={20} />}
                tone="amber"
                hint={`${stats.reviewCount} تقييم منشور`}
              />
            </div>

            <div className="grid gap-5 lg:grid-cols-2">
              <Card>
                <SectionTitle title="حركة المواعيد" subtitle="آخر 6 أشهر" icon={<TrendingUp size={18} />} />
                <LineChart data={monthly} color="#0f8271" />
              </Card>
              <Card>
                <SectionTitle title="الطلب حسب التخصص" subtitle="توزيع المواعيد على التخصصات" icon={<PieChart size={18} />} />
                <DonutChart segments={specialtyStats} centerLabel="موعد" />
              </Card>
            </div>

            <Card className="!p-0 overflow-hidden">
              <div className="flex items-center justify-between gap-3 border-b border-ink-100 px-5 py-4">
                <div>
                  <h3 className="font-display text-[16px] font-extrabold text-ink-900">آخر الأنشطة</h3>
                  <p className="text-[12px] text-ink-500">سجل مباشر لأهم ما يحدث في النظام</p>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setTab('activities')}>
                  عرض الكل
                </Button>
              </div>
              <div className="divide-y divide-ink-50">
                {db.activities.slice(0, 8).map((a) => (
                  <div key={a.id} className="flex items-center gap-3 px-5 py-3.5">
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-ink-50 text-ink-500">
                      <Activity size={15} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-[12.5px] font-bold text-ink-800">{a.action}</p>
                      <p className="truncate text-[11.5px] text-ink-500">{a.detail}</p>
                    </div>
                    <Badge tone={categoryMeta[a.category].tone}>{categoryMeta[a.category].label}</Badge>
                    <span className="hidden shrink-0 text-[11px] text-ink-400 sm:block">{formatStamp(a.at)}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {/* ---------------- ACTIVITIES ---------------- */}
        {tab === 'activities' && (
          <div className="mt-5 space-y-4">
            <div className="flex flex-col gap-3 rounded-2xl border border-ink-100 bg-white p-4 lg:flex-row lg:items-center">
              <div className="relative flex-1">
                <Search size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-400" />
                <Input
                  value={activityQuery}
                  onChange={(e) => setActivityQuery(e.target.value)}
                  placeholder="ابحث في الأنشطة..."
                  className="pr-11"
                />
              </div>
              <div className="flex items-center gap-2">
                <Filter size={16} className="text-ink-400" />
                <Select value={activityFilter} onChange={(e) => setActivityFilter(e.target.value)} className="!w-auto min-w-40">
                  <option value="all">كل الأنشطة</option>
                  <option value="booking">الحجوزات</option>
                  <option value="login">الدخول والخروج</option>
                  <option value="medical">النشاط الطبي</option>
                  <option value="whatsapp">واتساب</option>
                  <option value="admin">الإدارة</option>
                  <option value="patient">المرضى</option>
                </Select>
              </div>
              <Button variant="secondary" size="sm" onClick={exportActivities}>
                <Download size={15} />
                تصدير CSV
              </Button>
            </div>

            <Card className="!p-0 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[820px] text-right">
                  <thead className="bg-ink-50 text-[11.5px] font-bold text-ink-500">
                    <tr>
                      <th className="px-5 py-3">النشاط</th>
                      <th className="px-5 py-3">التفاصيل</th>
                      <th className="px-5 py-3">المنفّذ</th>
                      <th className="px-5 py-3">الدور</th>
                      <th className="px-5 py-3">التصنيف</th>
                      <th className="px-5 py-3">الوقت</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-50 text-[12.5px]">
                    {filteredActivities.slice(0, 60).map((a) => (
                      <tr key={a.id} className="transition hover:bg-ink-50/50">
                        <td className="px-5 py-3.5 font-bold text-ink-800">{a.action}</td>
                        <td className="px-5 py-3.5 text-ink-600">{a.detail}</td>
                        <td className="px-5 py-3.5 text-ink-700">{a.actor}</td>
                        <td className="px-5 py-3.5 text-ink-500">{roleLabel[a.actorRole]}</td>
                        <td className="px-5 py-3.5">
                          <Badge tone={categoryMeta[a.category].tone}>{categoryMeta[a.category].label}</Badge>
                        </td>
                        <td className="px-5 py-3.5 text-[11.5px] text-ink-400">{formatStamp(a.at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {filteredActivities.length === 0 && (
                <p className="p-8 text-center text-sm text-ink-500">لا توجد أنشطة مطابقة.</p>
              )}
            </Card>
          </div>
        )}

        {/* ---------------- DOCTORS ---------------- */}
        {tab === 'doctors' && (
          <div className="mt-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-[13px] font-semibold text-ink-600">
                {db.doctors.length} طبيب — {stats.activeDoctors} نشط — {db.doctors.length - stats.activeDoctors} موقوف
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" onClick={exportDoctors}>
                  <Download size={15} />
                  تصدير
                </Button>
                <Button size="sm" onClick={() => openDoctorModal()}>
                  <Plus size={15} />
                  إضافة طبيب
                </Button>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {db.doctors.map((d) => {
                const sp = db.specialties.find((s) => s.id === d.specialtyId)
                const count = db.appointments.filter((a) => a.doctorId === d.id).length
                return (
                  <Card key={d.id} className="flex flex-col">
                    <div className="flex items-start gap-3">
                      <img src={d.image} alt={d.name} className="size-14 shrink-0 rounded-2xl object-cover object-top" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[14px] font-extrabold text-ink-900">{d.name}</p>
                        <p className="text-[11.5px] text-brand-700">{sp?.name}</p>
                        <p className="mt-0.5 text-[11px] text-ink-500" dir="ltr">
                          {d.phone}
                        </p>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <Badge tone={d.active ? 'green' : 'rose'}>{d.active ? 'نشط' : 'موقوف'}</Badge>
                        {isDoctorOffNow(d) && <Badge tone="amber">غير متاح: {d.unavailable?.reason}</Badge>}
                      </div>
                    </div>

                    <div className="mt-3 rounded-xl border border-ink-100 px-3 py-2.5">
                      <p className="flex items-center gap-1.5 text-[11px] font-bold text-ink-500">
                        <CalendarDays size={12} />
                        دوام الطبيب: {d.startHour}:00 – {d.endHour}:00
                      </p>
                      <div className="mt-1.5 flex flex-wrap gap-1">
                        {d.days.length === 0 ? (
                          <span className="text-[11px] text-ink-400">لا توجد أيام دوام</span>
                        ) : (
                          d.days.map((x) => (
                            <span key={x} className="rounded-md bg-brand-50 px-1.5 py-0.5 text-[10.5px] font-bold text-brand-700">
                              {['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'][x]}
                            </span>
                          ))
                        )}
                      </div>
                    </div>

                    <DoctorCredentials doctor={d} />

                    <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                      {[
                        { l: 'مواعيد', v: count },
                        { l: 'سنوات', v: d.years },
                        { l: 'تقييم', v: d.rating.toFixed(1) },
                      ].map((s) => (
                        <div key={s.l} className="rounded-xl bg-ink-50 px-2 py-2">
                          <p className="font-display text-[15px] font-extrabold text-ink-900">{s.v}</p>
                          <p className="text-[10px] text-ink-400">{s.l}</p>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 flex gap-2">
                      <Button size="sm" variant="secondary" className="flex-1" onClick={() => openDoctorModal(d)}>
                        <UserCog size={14} />
                        تعديل
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          updateDoctor(d.id, { active: !d.active })
                          push(d.active ? 'تم إيقاف الطبيب' : 'تم تفعيل الطبيب')
                        }}
                      >
                        {d.active ? 'إيقاف' : 'تفعيل'}
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => deleteDoctor(d)}>
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </Card>
                )
              })}
            </div>
          </div>
        )}

        {/* ---------------- APPOINTMENTS ---------------- */}
        {tab === 'appointments' && (
          <div className="mt-5 space-y-4">
            <div className="flex flex-col gap-3 rounded-2xl border border-ink-100 bg-white p-4 lg:flex-row lg:items-center">
              <div className="relative flex-1">
                <Search size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-400" />
                <Input
                  value={apptQuery}
                  onChange={(e) => setApptQuery(e.target.value)}
                  placeholder="ابحث باسم المريض أو رقمه أو الطبيب..."
                  className="pr-11"
                />
              </div>
              <div className="flex items-center gap-2">
                <Filter size={16} className="text-ink-400" />
                <Select value={apptFilter} onChange={(e) => setApptFilter(e.target.value)} className="!w-auto min-w-40">
                  <option value="all">كل الحالات</option>
                  {Object.entries(statusMeta).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v.label}
                    </option>
                  ))}
                </Select>
              </div>
              <Button variant="secondary" size="sm" onClick={exportAppointments}>
                <Download size={15} />
                تصدير CSV
              </Button>
            </div>

            <Card className="!p-0 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[920px] text-right">
                  <thead className="bg-ink-50 text-[11.5px] font-bold text-ink-500">
                    <tr>
                      <th className="px-5 py-3">المريض</th>
                      <th className="px-5 py-3">الطبيب</th>
                      <th className="px-5 py-3">التاريخ</th>
                      <th className="px-5 py-3">الوقت</th>
                      <th className="px-5 py-3">الحالة</th>
                      <th className="px-5 py-3">المبلغ</th>
                      <th className="px-5 py-3">إجراء</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-50 text-[12.5px]">
                    {filteredAppointments.slice(0, 80).map((a) => {
                      const meta = statusMeta[a.status]
                      const doc = db.doctors.find((d) => d.id === a.doctorId)
                      return (
                        <tr key={a.id} className="transition hover:bg-ink-50/50">
                          <td className="px-5 py-3.5">
                            <p className="font-bold text-ink-800">{a.patientName}</p>
                            <p className="text-[11px] text-ink-400" dir="ltr">
                              {a.patientPhone}
                            </p>
                          </td>
                          <td className="px-5 py-3.5 text-ink-700">{doc?.name}</td>
                          <td className="px-5 py-3.5 text-ink-700">{formatFullDate(a.date)}</td>
                          <td className="px-5 py-3.5 text-ink-600">{formatTime(a.time)}</td>
                          <td className="px-5 py-3.5">
                            <Badge tone={meta.tone}>{meta.label}</Badge>
                          </td>
                          <td className="px-5 py-3.5 font-semibold text-ink-700">{money(a.fee)}</td>
                          <td className="px-5 py-3.5">
                            <div className="flex gap-1.5">
                              <button
                                onClick={() =>
                                  printInvoice({
                                    settings: db.settings,
                                    appointment: a,
                                    patient: db.patients.find((p) => p.id === a.patientId),
                                    doctors: db.doctors,
                                    specialties: db.specialties,
                                    appointments: db.appointments,
                                    prescriptions: db.prescriptions,
                                  })
                                }
                                className="flex items-center gap-1 rounded-lg bg-ink-50 px-2 py-1.5 text-[11px] font-bold text-ink-700 transition hover:bg-ink-100"
                              >
                                <Printer size={11} />
                                فاتورة
                              </button>
                              {a.status !== 'completed' && (
                                <button
                                  onClick={() => {
                                    setAppointmentStatus(a.id, 'completed', { name: 'الإدارة', role: 'admin' })
                                    push('تم تعليم الموعد كمكتمل')
                                  }}
                                  className="rounded-lg bg-emerald-50 px-2 py-1.5 text-[11px] font-bold text-emerald-700 transition hover:bg-emerald-100"
                                >
                                  إكمال
                                </button>
                              )}
                              {a.status !== 'cancelled' && (
                                <button
                                  onClick={() => {
                                    setAppointmentStatus(a.id, 'cancelled', { name: 'الإدارة', role: 'admin' })
                                    push('تم إلغاء الموعد')
                                  }}
                                  className="rounded-lg bg-rose-50 px-2 py-1.5 text-[11px] font-bold text-rose-700 transition hover:bg-rose-100"
                                >
                                  إلغاء
                                </button>
                              )}
                              {a.status === 'cancelled' && (
                                <button
                                  onClick={() => {
                                    setAppointmentStatus(a.id, 'scheduled', { name: 'الإدارة', role: 'admin' })
                                    push('تمت إعادة الموعد للجدولة')
                                  }}
                                  className="rounded-lg bg-sky-50 px-2 py-1.5 text-[11px] font-bold text-sky-700 transition hover:bg-sky-100"
                                >
                                  إعادة جدولة
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
              {filteredAppointments.length === 0 && (
                <p className="p-8 text-center text-sm text-ink-500">لا توجد مواعيد مطابقة.</p>
              )}
            </Card>
          </div>
        )}

        {/* ---------------- WHATSAPP ---------------- */}
        {tab === 'whatsapp' && (
          <div className="mt-5 grid gap-5 lg:grid-cols-[320px_1fr]">
            {/* threads list */}
            <Card className="!p-0 overflow-hidden">
              <div className="border-b border-ink-100 p-4">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="font-display text-[15px] font-extrabold text-ink-900">المحادثات</h3>
                  <Button variant="danger" size="sm" onClick={() => setShowWipe(true)}>
                    <Trash2 size={14} />
                    مسح كل الشات
                  </Button>
                </div>
                <p className="text-[11.5px] text-ink-500">{stats.unread} غير مقروءة — {stats.humanThreads} بتدخل بشري</p>
                <div className="relative mt-3">
                  <Search size={15} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                  <Input
                    placeholder="ابحث في المحادثات..."
                    className="h-10 pr-10 text-[12.5px]"
                    value={threadQuery}
                    onChange={(e) => setThreadQuery(e.target.value)}
                  />
                </div>
              </div>
              <div className="scrollbar-thin max-h-[520px] divide-y divide-ink-50 overflow-y-auto">
                {db.threads
                  .filter((t) => !threadQuery || t.patientName.includes(threadQuery))
                  .map((t) => (
                    <button
                      key={t.id}
                      onClick={() => {
                        setSelectedThread(t.id)
                        markThreadRead(t.id)
                      }}
                      className={`flex w-full items-start gap-3 p-4 text-right transition ${
                        selectedThread === t.id ? 'bg-brand-50/70' : 'hover:bg-ink-50/70'
                      }`}
                    >
                      <span className="relative flex size-10 shrink-0 items-center justify-center rounded-xl bg-ink-900 text-[12px] font-bold text-white">
                        {t.patientName.slice(0, 1)}
                        {t.humanAgent && (
                          <span className="absolute -bottom-0.5 -left-0.5 size-3 rounded-full border-2 border-white bg-amber-500" />
                        )}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center justify-between gap-2">
                          <span className="truncate text-[12.5px] font-bold text-ink-900">{t.patientName}</span>
                          <span className="shrink-0 text-[10px] text-ink-400">{formatStampTime(t.lastAt)}</span>
                        </span>
                        <span className="mt-0.5 block truncate text-[11.5px] text-ink-500">{t.subject}</span>
                        <span className="mt-1.5 flex items-center gap-1.5">
                          {t.humanAgent ? (
                            <Badge tone="amber">تدخل بشري</Badge>
                          ) : (
                            <Badge tone="sky">مساعد آلي</Badge>
                          )}
                          {t.status === 'closed' && <Badge tone="rose">مغلقة</Badge>}
                          {t.unread > 0 && (
                            <span className="flex size-5 items-center justify-center rounded-full bg-brand-600 text-[10px] font-bold text-white">
                              {t.unread}
                            </span>
                          )}
                        </span>
                      </span>
                    </button>
                  ))}
              </div>
            </Card>

            {/* chat panel */}
            <Card className="flex !p-0 flex-col overflow-hidden">
              {thread ? (
                <>
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink-100 bg-ink-50/50 px-5 py-3.5">
                    <div className="flex items-center gap-3">
                      <Avatar name={thread.patientName} size={40} />
                      <div>
                        <p className="text-[13.5px] font-extrabold text-ink-900">{thread.patientName}</p>
                        <p className="text-[11.5px] text-ink-500" dir="ltr">
                          {thread.patientPhone} • {thread.subject}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      {thread.humanAgent ? (
                        <>
                          <Badge tone="amber">يتواصل معك: {thread.humanAgent}</Badge>
                          <Button size="sm" variant="danger" onClick={toggleHuman}>
                            <XCircle size={14} />
                            إنهاء التفاعل البشري
                          </Button>
                        </>
                      ) : (
                        <Button size="sm" onClick={toggleHuman}>
                          <UserCheck size={14} />
                          بدء التفاعل البشري
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => {
                          toggleThreadStatus(thread.id)
                          push(thread.status === 'closed' ? 'تم فتح المحادثة' : 'تم إغلاق المحادثة')
                        }}
                      >
                        {thread.status === 'closed' ? 'فتح' : 'إغلاق'}
                      </Button>
                      <a
                        href={waLink(thread.patientPhone)}
                        target="_blank"
                        rel="noreferrer"
                        className="flex size-9 items-center justify-center rounded-xl bg-[#25D366] text-ink-950 transition hover:bg-[#1eb958]"
                        title="فتح واتساب"
                      >
                        <Phone size={15} />
                      </a>
                    </div>
                  </div>

                  <div className="scrollbar-thin flex-1 space-y-3 overflow-y-auto bg-[#f2f7f6] p-5" style={{ minHeight: 380 }}>
                    {thread.messages.map((m) => (
                      <motion.div
                        key={m.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${m.from === 'patient' ? 'justify-start' : 'justify-end'}`}
                      >
                        <div
                          className={`max-w-[78%] rounded-2xl px-4 py-2.5 text-[12.5px] leading-6 shadow-sm ${
                            m.from === 'patient'
                              ? 'rounded-tl-sm bg-white text-ink-700'
                              : m.from === 'bot'
                                ? 'rounded-tr-sm bg-ink-100 text-ink-700'
                                : 'rounded-tr-sm bg-brand-600 text-white'
                          }`}
                        >
                          {m.from !== 'patient' && (
                            <p className={`mb-0.5 text-[10px] font-bold ${m.from === 'bot' ? 'text-ink-400' : 'text-brand-100'}`}>
                              {m.from === 'bot' ? 'المساعد الآلي' : 'موظف خدمة العملاء'}
                            </p>
                          )}
                          {m.imageId && db.media[m.imageId] && (
                            <img
                              src={db.media[m.imageId]}
                              alt="صورة العرض"
                              className="mb-2 max-h-64 w-full rounded-xl object-cover"
                            />
                          )}
                          <span className="whitespace-pre-wrap break-words">{m.text}</span>
                          <p className={`mt-1 text-[9.5px] ${m.from === 'patient' ? 'text-ink-400' : 'text-white/70'}`}>
                            {formatStampTime(m.at)}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                  </div>

                  <div className="border-t border-ink-100 p-4">
                    <div className="flex gap-2">
                      <Input
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') sendMessage(thread.humanAgent ? 'agent' : 'bot')
                        }}
                        placeholder={
                          thread.humanAgent ? 'اكتب رداً بصيغة الموظف البشري...' : 'اكتب رد المساعد الآلي...'
                        }
                        className="flex-1"
                      />
                      <Button onClick={() => sendMessage(thread.humanAgent ? 'agent' : 'bot')}>
                        <Send size={16} />
                        إرسال
                      </Button>
                    </div>
                    <div className="mt-2.5 flex flex-wrap items-center gap-2">
                      <span className="text-[11px] text-ink-400">الرد يُرسل باسم:</span>
                      <Select
                        value={agentName}
                        onChange={(e) => setAgentName(e.target.value)}
                        className="h-8 max-w-64 text-[11.5px]"
                      >
                        {replyAsOptions.map((n) => (
                          <option key={n} value={n}>
                            {n === db.settings.name ? `${n} (اسم العيادة)` : n}
                          </option>
                        ))}
                      </Select>
                    </div>
                  </div>
                </>
              ) : (
                <EmptyState icon={<MessageCircle size={24} />} title="اختر محادثة لعرضها" />
              )}
            </Card>
          </div>
        )}

        {/* ---------------- REPORTS ---------------- */}
        <Modal
          open={showWipe}
          onClose={() => !wiping && setShowWipe(false)}
          title="مسح كل محادثات واتساب"
          subtitle="العملية دي نهائية ومينفعش ترجّعها."
          size="sm"
          footer={
            <>
              <Button variant="ghost" onClick={() => setShowWipe(false)} disabled={wiping}>
                رجوع
              </Button>
              <Button variant="danger" onClick={() => void wipeAllChats()} disabled={wiping}>
                <Trash2 size={15} />
                {wiping ? 'جارٍ المسح...' : 'نعم، امسح الكل'}
              </Button>
            </>
          }
        >
          <p className="rounded-xl bg-rose-50 px-4 py-3.5 text-[13px] leading-7 text-rose-800 ring-1 ring-rose-200">
            هيتمسح <b>{db.threads.length}</b> محادثة من اللوحة، وكل الرسائل وجهات الاتصال والملفات المحفوظة في قاعدة بيانات واتساب
            (جداول <span dir="ltr">whatsapp_messages</span> و<span dir="ltr">whatsapp_contacts</span> وملفات الـ Storage). الإعدادات
            والموظفين مش هيتمسحوا.
          </p>
        </Modal>

        {tab === 'reports' && <ReportsHub />}
        {tab === 'schedules' && <DoctorSchedulesBoard />}
        {tab === 'attendance' && <AttendanceHub />}
      </main>

      <Footer />

      {/* بيانات دخول الطبيب الجديد */}
      <Modal
        open={!!createdDoctor}
        onClose={() => setCreatedDoctor(null)}
        title="تم إنشاء حساب الطبيب"
        subtitle={createdDoctor?.name}
        footer={<Button onClick={() => setCreatedDoctor(null)}>تم</Button>}
      >
        {createdDoctor && (
          <div>
            <DoctorCredentials doctor={createdDoctor} defaultShow />
            <p className="mt-3 text-[12px] leading-6 text-ink-500">
              الطبيب يدخل من صفحة <span className="font-bold" dir="ltr">/staff</span> باليوزر <span className="font-bold" dir="ltr">{doctorUsername(createdDoctor)}</span> والباسورد اللي فوق. بيانات الدخول متاحة دايماً في كارت الطبيب.
            </p>
          </div>
        )}
      </Modal>

      {/* add / edit doctor modal */}
      <Modal
        open={showAddDoctor}
        onClose={() => setShowAddDoctor(false)}
        title={editDoctor ? 'تعديل بيانات الطبيب' : 'إضافة طبيب جديد'}
        subtitle={editDoctor ? editDoctor.name : 'أدخل بيانات الطبيب ليظهر في دليل الحجز'}
        size="lg"
        footer={
          <>
            <Button variant="secondary" onClick={() => setShowAddDoctor(false)}>
              إلغاء
            </Button>
            <Button onClick={saveDoctor}>
              <CheckCircle2 size={16} />
              {editDoctor ? 'حفظ التعديلات' : 'إضافة الطبيب'}
            </Button>
          </>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <span className="mb-2 block text-[13px] font-semibold text-ink-700">صورة الطبيب</span>
            <div className="flex flex-wrap items-start gap-4 rounded-2xl border border-dashed border-ink-200 bg-ink-50/60 p-4">
              <div className="relative shrink-0">
                <img
                  src={doctorForm.image || '/images/doc-2.jpg'}
                  alt="صورة الطبيب"
                  className="size-20 rounded-2xl border border-ink-100 object-cover object-top"
                />
                {doctorForm.image && (
                  <button
                    type="button"
                    onClick={() => setDoctorForm({ ...doctorForm, image: '' })}
                    title="إزالة الصورة"
                    className="absolute -left-2 -top-2 flex size-6 items-center justify-center rounded-lg bg-rose-600 text-white shadow transition hover:bg-rose-700"
                  >
                    <X size={13} />
                  </button>
                )}
              </div>

              <div className="min-w-[220px] flex-1">
                <div className="flex flex-wrap gap-2">
                  <label className="inline-flex h-10 cursor-pointer items-center gap-2 rounded-xl bg-ink-900 px-4 text-[12.5px] font-bold text-white transition hover:bg-ink-800">
                    <Upload size={15} />
                    رفع صورة من الجهاز
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageUpload}
                    />
                  </label>
                  {doctorForm.image && (
                    <button
                      type="button"
                      onClick={() => setDoctorForm({ ...doctorForm, image: '' })}
                      className="inline-flex h-10 items-center gap-2 rounded-xl border border-ink-200 bg-white px-4 text-[12.5px] font-bold text-ink-600 transition hover:border-rose-200 hover:text-rose-600"
                    >
                      <Trash2 size={15} />
                      إزالة
                    </button>
                  )}
                </div>

                <Input
                  value={doctorForm.image.startsWith('data:') ? '' : doctorForm.image}
                  onChange={(e) => setDoctorForm({ ...doctorForm, image: e.target.value })}
                  placeholder="أو ألصق رابط صورة (اختياري)"
                  dir="ltr"
                  className="mt-2.5 text-left"
                />
                <p className="mt-2 text-[11px] leading-5 text-ink-400">
                  يفضّل صورة مربعة للطبيب. تُحفظ الصورة داخل النظام وتظهر مباشرةً في دليل الأطباء وصفحة
                  الحجز ولوحة الطبيب.
                </p>
              </div>
            </div>
          </div>

          <Field label="اسم الطبيب" required>
            <Input value={doctorForm.name} onChange={(e) => setDoctorForm({ ...doctorForm, name: e.target.value })} placeholder="د. ..." />
          </Field>
          <Field label="المسمى الوظيفي">
            <Input value={doctorForm.title} onChange={(e) => setDoctorForm({ ...doctorForm, title: e.target.value })} />
          </Field>
          <Field label="التخصص" required>
            <Select value={doctorForm.specialtyId} onChange={(e) => setDoctorForm({ ...doctorForm, specialtyId: e.target.value })}>
              {db.specialties.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="رقم الجوال" required>
            <Input value={doctorForm.phone} onChange={(e) => setDoctorForm({ ...doctorForm, phone: e.target.value })} dir="ltr" className="text-left" />
          </Field>
          <Field label="البريد الإلكتروني" hint="اختياري — لو موجود يبقى هو اليوزر، وإلا اليوزر رقم الجوال">
            <Input value={doctorForm.email} onChange={(e) => setDoctorForm({ ...doctorForm, email: e.target.value })} dir="ltr" className="text-left" />
          </Field>
          <Field label="كلمة المرور" hint="يدخل بيها الطبيب من صفحة الطاقم (6 أحرف على الأقل)" required>
            <div className="flex gap-2">
              <Input value={doctorForm.password} onChange={(e) => setDoctorForm({ ...doctorForm, password: e.target.value })} dir="ltr" className="text-left font-mono" />
              <Button type="button" variant="secondary" onClick={() => setDoctorForm({ ...doctorForm, password: generatePassword() })} aria-label="توليد باسورد جديد">
                <RegenIcon size={15} />
              </Button>
            </div>
          </Field>
          <Field label={`سعر الكشف (${db.settings.currency})`}>
            <Input
              type="number"
              value={doctorForm.fee}
              onChange={(e) => setDoctorForm({ ...doctorForm, fee: Number(e.target.value) })}
            />
          </Field>
          <Field label="المدينة">
            <Input value={doctorForm.location} onChange={(e) => setDoctorForm({ ...doctorForm, location: e.target.value })} />
          </Field>
          <Field label="العيادة" className="sm:col-span-2">
            <Input value={doctorForm.clinic} onChange={(e) => setDoctorForm({ ...doctorForm, clinic: e.target.value })} placeholder="اسم المركز أو العيادة" />
          </Field>
          <Field label="النبذة" className="sm:col-span-2">
            <Textarea value={doctorForm.bio} onChange={(e) => setDoctorForm({ ...doctorForm, bio: e.target.value })} />
          </Field>

          <div className="sm:col-span-2">
            <span className="mb-2 block text-[13px] font-semibold text-ink-700">أيام الدوام</span>
            <div className="flex flex-wrap gap-2">
              {['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'].map((d, i) => (
                <button
                  key={d}
                  type="button"
                  onClick={() =>
                    setDoctorForm({
                      ...doctorForm,
                      days: doctorForm.days.includes(i)
                        ? doctorForm.days.filter((x) => x !== i)
                        : [...doctorForm.days, i].sort(),
                    })
                  }
                  className={`rounded-xl px-3.5 py-2 text-[12px] font-bold transition ${
                    doctorForm.days.includes(i)
                      ? 'bg-brand-600 text-white'
                      : 'bg-ink-50 text-ink-500 hover:bg-ink-100'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          <Field label="بداية الدوام">
            <Select
              value={String(doctorForm.startHour)}
              onChange={(e) => setDoctorForm({ ...doctorForm, startHour: Number(e.target.value) })}
            >
              {Array.from({ length: 13 }, (_, i) => i + 6).map((h) => (
                <option key={h} value={h}>
                  {h}:00
                </option>
              ))}
            </Select>
          </Field>
          <Field label="نهاية الدوام">
            <Select
              value={String(doctorForm.endHour)}
              onChange={(e) => setDoctorForm({ ...doctorForm, endHour: Number(e.target.value) })}
            >
              {Array.from({ length: 15 }, (_, i) => i + 8).map((h) => (
                <option key={h} value={h}>
                  {h}:00
                </option>
              ))}
            </Select>
          </Field>
        </div>
      </Modal>
    </div>
  )
}
