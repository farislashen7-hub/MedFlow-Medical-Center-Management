import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Activity,
  AlertCircle,
  CalendarCheck,
  CalendarDays,
  CalendarX,
  CheckCircle2,
  ChevronLeft,
  LogIn,
  UserCheck,
  ClipboardList,
  Clock,
  FileHeart,
  History,
  LogOut,
  MessageCircle,
  Phone,
  Pill,
  Plus,
  Printer,
  Receipt,
  RotateCcw,
  Search,
  Save,
  Star,
  Stethoscope,
  Trash2,
  TrendingUp,
  User,
  Users,
  XCircle,
} from 'lucide-react'
import {
  useDB,
  useSettings,
  createPrescription,
  logActivity,
  setAppointmentStatus,
  setDoctorSchedule,
  checkInDoctor,
  checkOutDoctor,
  setDoctorUnavailable,
  updateAppointment,
} from '../lib/db'
import type { ScheduleSyncResult } from '../lib/db'
import { useAuth } from '../lib/auth'
import { useToast } from '../components/Toast'
import { Header, Footer } from '../components/Layout'
import {
  Avatar,
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Input,
  Modal,
  SectionTitle,
  Select,
  StatCard,
  Tabs,
  Textarea,
} from '../components/ui'
import { BarChart, DonutChart } from '../components/charts'
import {
  ageFrom,
  formatFullDate,
  formatStamp,
  formatTime,
  genderLabel,
  telHref,
  toDateKey,
  waLink,
} from '../lib/format'
import type { Appointment, Doctor, Medication, Patient, Prescription } from '../lib/types'
import { isDoctorOffNow } from '../lib/slots'
import { gradeOf, statusLabel, statusTone, summarize, todayRow } from '../lib/attendance'
import type { AttendanceData } from '../lib/attendance'
import { printInvoice, printPatientFile, printPrescription, prescriptionHtml } from '../lib/print'
import { htmlToJpegDataUrl } from '../lib/capture'
import { Stars } from '../components/Stars'
import { notify } from '../lib/notify'

const statusMeta: Record<Appointment['status'], { label: string; tone: 'brand' | 'green' | 'rose' | 'amber' | 'sky' }> = {
  scheduled: { label: 'مجدول', tone: 'sky' },
  confirmed: { label: 'مؤكد', tone: 'brand' },
  completed: { label: 'مكتمل', tone: 'green' },
  cancelled: { label: 'ملغي', tone: 'rose' },
  'no-show': { label: 'لم يحضر', tone: 'amber' },
}

const typeMeta: Record<Appointment['type'], string> = {
  new: 'زيارة جديدة',
  followup: 'متابعة',
  urgent: 'عاجلة',
}

export default function DoctorDashboard() {
  const db = useDB()
  const { session, logout } = useAuth()
  const { push } = useToast()
  const [tab, setTab] = useState('today')
  const [search, setSearch] = useState('')
  const [openPatient, setOpenPatient] = useState<Patient | null>(null)
  const [rxTarget, setRxTarget] = useState<Patient | null>(null)
  const [rxAppointment, setRxAppointment] = useState<Appointment | null>(null)
  const [rxForm, setRxForm] = useState({ diagnosis: '', advice: '', followUp: '' })
  const [meds, setMeds] = useState<Omit<Medication, 'id'>[]>([
    { name: '', dosage: '', duration: '', notes: '' },
  ])

  const doctor = db.doctors.find((d) => d.id === session?.id)
  const today = toDateKey(new Date())

  const myReviews = useMemo(
    () =>
      db.reviews
        .filter((r) => r.doctorId === session?.id && r.status === 'published')
        .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)),
    [db.reviews, session?.id],
  )
  const myRating = myReviews.length ? myReviews.reduce((s, r) => s + r.rating, 0) / myReviews.length : 0

  const myAppointments = useMemo(
    () =>
      db.appointments
        .filter((a) => a.doctorId === session?.id)
        .sort((a, b) => (a.date + a.time < b.date + b.time ? 1 : -1)),
    [db.appointments, session?.id],
  )

  const todayAppointments = myAppointments.filter((a) => a.date === today && a.status !== 'cancelled')
  const upcoming = myAppointments.filter((a) => a.date > today && a.status !== 'cancelled')
  const myPrescriptions = db.prescriptions.filter((p) => p.doctorId === session?.id)

  const patientMap = useMemo(() => {
    const map = new Map<string, Patient>()
    myAppointments.forEach((a) => {
      const p = db.patients.find((x) => x.id === a.patientId)
      if (p) map.set(p.id, p)
    })
    return [...map.values()]
  }, [myAppointments, db.patients])

  const filteredPatients = patientMap.filter((p) => {
    const q = search.trim()
    if (!q) return true
    return p.name.includes(q) || p.phone.includes(q)
  })

  const monthly = useMemo(() => {
    const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
    const now = new Date()
    const out: { label: string; value: number }[] = []
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
      out.push({
        label: months[d.getMonth()],
        value: myAppointments.filter((a) => a.date.startsWith(key)).length,
      })
    }
    return out
  }, [myAppointments])

  if (!doctor) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-sm text-ink-500">تعذر العثور على بيانات حساب الطبيب.</p>
      </div>
    )
  }

  const specialty = db.specialties.find((s) => s.id === doctor.specialtyId)
  const isOff = isDoctorOffNow(doctor)
  const todayAttendance = todayRow(doctor, { records: db.attendance, leaves: db.leaves, appointments: db.appointments })

  function openFile(p: Patient) {
    setOpenPatient(p)
    logActivity(doctor!.name, 'doctor', 'فتح ملف مريض', `فتح ملف المريض ${p.name}`, 'medical')
  }

  /** الوصفة بتتحول لصورة وتتبعت لـ webhook «Treatment» — الفشل مبيكسرش الإصدار */
  async function sendPrescriptionImage(rx: Prescription, patient: Patient, doc: Doctor) {
    try {
      const html = prescriptionHtml({
        settings: db.settings,
        rx,
        patient,
        doctors: db.doctors,
        specialties: db.specialties,
        appointments: db.appointments,
      })
      const image = await htmlToJpegDataUrl(html)
      const r = await notify('prescription.issued', {
        code: rx.code,
        patientName: patient.name,
        patientPhone: patient.phone,
        doctorName: doc.name,
        specialtyName: db.specialties.find((x) => x.id === doc.specialtyId)?.name ?? '',
        diagnosis: rx.diagnosis,
        issuedAt: rx.issuedAt,
        image: image.split(',')[1],
        mimetype: 'image/jpeg',
      })
      if (r.ok) push('اتبعتت صورة الوصفة للمريض')
      else if (!r.skipped) push('الوصفة اتحفظت لكن تعذر إرسال صورتها (Treatment)', 'error')
    } catch (err) {
      console.error('[rx] image send failed', err)
      push('الوصفة اتحفظت لكن تعذر تجهيز صورتها', 'error')
    }
  }

  function issuePrescription() {
    if (!rxTarget || !doctor) return
    const validMeds = meds.filter((m) => m.name.trim())
    if (!rxForm.diagnosis.trim()) {
      push('يرجى كتابة التشخيص', 'error')
      return
    }
    if (validMeds.length === 0) {
      push('يرجى إضافة دواء واحداً على الأقل', 'error')
      return
    }
    const issued = createPrescription({
      appointmentId: rxAppointment?.id || '',
      patientId: rxTarget.id,
      doctorId: doctor.id,
      diagnosis: rxForm.diagnosis,
      items: validMeds,
      advice: rxForm.advice,
      followUp: rxForm.followUp,
    })
    if (rxAppointment) setAppointmentStatus(rxAppointment.id, 'completed')
    push('تم إصدار الوصفة الطبية بنجاح')
    void sendPrescriptionImage(issued, rxTarget, doctor)
    setRxTarget(null)
    setRxAppointment(null)
    setRxForm({ diagnosis: '', advice: '', followUp: '' })
    setMeds([{ name: '', dosage: '', duration: '', notes: '' }])
  }

  const attendanceRate = myAppointments.length
    ? Math.round(
        (myAppointments.filter((a) => a.status === 'completed').length / myAppointments.length) * 100,
      )
    : 0

  const statusCounts = (['completed', 'scheduled', 'cancelled', 'no-show'] as const).map((s) => ({
    label: statusMeta[s].label,
    value: myAppointments.filter((a) => a.status === s).length,
    color:
      s === 'completed'
        ? '#10b981'
        : s === 'scheduled'
          ? '#38bdf8'
          : s === 'cancelled'
            ? '#f43f5e'
            : '#f59e0b',
  }))

  return (
    <div className="min-h-screen bg-[#f5f8f8]">
      <Header />

      <main className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* ---- welcome ---- */}
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <Card className="relative overflow-hidden !bg-gradient-to-l from-brand-800 to-brand-600 !text-white">
            <div className="absolute -left-20 -top-24 size-72 rounded-full bg-white/10 blur-3xl" />
            <div className="relative flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-5">
                <div className="relative">
                  <img
                    src={doctor.image}
                    alt={doctor.name}
                    className="size-20 rounded-3xl border-2 border-white/40 object-cover object-top"
                  />
                  <span className={`absolute -bottom-1 -left-1 size-4 rounded-full border-2 border-brand-700 ${isOff ? 'bg-rose-400' : 'bg-emerald-400'}`} />
                </div>
                <div>
                  <p className="flex items-center gap-1.5 text-[12px] font-semibold text-brand-100">
                    <Stethoscope size={13} />
                    لوحة الطبيب
                  </p>
                  <h1 className="mt-1 font-display text-2xl font-extrabold sm:text-3xl">
                    مرحباً د. {doctor.name.replace(/^د\.\s*/, '')} 👋
                  </h1>
                  <p className="mt-1.5 text-[13px] text-brand-50/90">
                    {doctor.title} — {specialty?.name} • {doctor.clinic}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2 text-[11.5px]">
                    <span className="flex items-center gap-1.5 rounded-lg bg-white/15 px-2.5 py-1.5">
                      <CalendarDays size={12} />
                      {todayAppointments.length} موعد اليوم
                    </span>
                    <span className="flex items-center gap-1.5 rounded-lg bg-white/15 px-2.5 py-1.5">
                      <Users size={12} />
                      {patientMap.length} ملف مريض
                    </span>
                    <span className="flex items-center gap-1.5 rounded-lg bg-white/15 px-2.5 py-1.5">
                      <TrendingUp size={12} />
                      حضور {attendanceRate}%
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2.5">
                <Button
                  variant="secondary"
                  className="!border-white/25 !bg-white/15 !text-white hover:!bg-white/25"
                  onClick={() => setTab('schedule')}
                >
                  <CalendarCheck size={16} />
                  إدارة المواعيد
                </Button>
                <Button
                  variant="ghost"
                  className="!text-white/80 hover:!bg-white/15 hover:!text-white"
                  onClick={logout}
                >
                  <LogOut size={16} />
                  خروج
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {isOff && doctor.unavailable && (
          <div className="mt-5 flex flex-col gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 sm:flex-row sm:items-center sm:justify-between">
            <p className="flex items-center gap-2 text-[13px] font-bold text-rose-800">
              <CalendarX size={18} />
              مواعيدك مقفولة حالياً — {doctor.unavailable.reason}
              {doctor.unavailable.until ? ` (حتى ${formatFullDate(doctor.unavailable.until)})` : ''}
            </p>
            <Button size="sm" onClick={() => setTab('availability')}>
              إدارة التواجد
            </Button>
          </div>
        )}

        {!isOff && todayAttendance?.status === 'pending' && (
          <div className="mt-5 flex flex-col gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 sm:flex-row sm:items-center sm:justify-between">
            <p className="flex items-center gap-2 text-[13px] font-bold text-amber-900">
              <LogIn size={18} />
              النهارده يوم دوامك ولسه ما سجلتش حضورك
            </p>
            <Button
              size="sm"
              onClick={() => {
                const r = checkInDoctor(doctor.id)
                push(r.ok ? 'تم تسجيل حضورك' : r.error, r.ok ? 'success' : 'error')
              }}
            >
              <LogIn size={15} />
              تسجيل حضور
            </Button>
          </div>
        )}

        {/* ---- stats ---- */}
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="مواعيد اليوم" value={todayAppointments.length} icon={<CalendarDays size={20} />} tone="brand" />
          <StatCard label="المواعيد القادمة" value={upcoming.length} icon={<Clock size={20} />} tone="sky" />
          <StatCard label="ملفات المرضى" value={patientMap.length} icon={<FileHeart size={20} />} tone="violet" />
          <StatCard label="الوصفات الصادرة" value={myPrescriptions.length} icon={<Pill size={20} />} tone="green" />
        </div>

        {/* ---- tabs ---- */}
        <div className="mt-6">
          <Tabs
            active={tab}
            onChange={setTab}
            items={[
              { id: 'today', label: 'جدول اليوم', icon: <CalendarDays size={15} />, count: todayAppointments.length },
              { id: 'upcoming', label: 'المواعيد القادمة', icon: <Clock size={15} />, count: upcoming.length },
              { id: 'patients', label: 'ملفات المرضى', icon: <Users size={15} />, count: patientMap.length },
              { id: 'schedule', label: 'إدارة المواعيد', icon: <CalendarCheck size={15} /> },
              { id: 'attendance', label: 'حضوري وغيابي', icon: <UserCheck size={15} /> },
              { id: 'stats', label: 'إحصائياتي', icon: <Activity size={15} /> },
              { id: 'reviews', label: 'تقييمات المرضى', icon: <Star size={15} />, count: myReviews.length || undefined },
              {
                id: 'availability',
                label: isOff ? 'غير متاح الآن' : 'عندي ظرف / غير متاح',
                icon: <CalendarX size={15} />,
              },
            ]}
          />
        </div>

        {/* ---- TODAY ---- */}
        {tab === 'today' && (
          <div className="mt-5 space-y-4">
            {todayAppointments.length === 0 ? (
              <EmptyState
                icon={<CalendarCheck size={24} />}
                title="لا توجد مواعيد اليوم"
                description="يمكنك مراجعة المواعيد القادمة أو ملفات المرضى من التبويبات أعلاه."
              />
            ) : (
              todayAppointments.map((a, index) => {
                const meta = statusMeta[a.status]
                const p = db.patients.find((x) => x.id === a.patientId)
                return (
                  <Card key={a.id} className="!p-0 overflow-hidden">
                    <div className="flex flex-col gap-4 p-5 md:flex-row md:items-center">
                      <div className="flex items-center gap-4 md:w-56">
                        <span className="flex size-14 shrink-0 flex-col items-center justify-center rounded-2xl bg-brand-50 text-brand-700">
                          <span className="font-display text-[15px] font-extrabold leading-none">{formatTime(a.time).split(' ')[0]}</span>
                          <span className="mt-0.5 text-[10px] font-bold">{formatTime(a.time).split(' ')[1]}</span>
                        </span>
                        <div>
                          <p className="text-[14px] font-extrabold text-ink-900">{a.patientName}</p>
                          <p className="text-[11.5px] text-ink-500" dir="ltr">
                            {a.patientPhone}
                          </p>
                        </div>
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <Badge tone={meta.tone}>{meta.label}</Badge>
                          <Badge tone="slate">{typeMeta[a.type]}</Badge>
                          {p && (
                            <Badge tone="rose">
                              <AlertCircle size={11} />
                              {p.allergies === 'لا يوجد' ? 'لا حساسية' : p.allergies}
                            </Badge>
                          )}
                        </div>
                        <p className="mt-2 text-[12.5px] leading-6 text-ink-600">{a.reason}</p>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {p && (
                          <Button size="sm" variant="secondary" onClick={() => openFile(p)}>
                            <FileHeart size={14} />
                            فتح الملف
                          </Button>
                        )}
                        {a.status !== 'completed' && (
                          <Button
                            size="sm"
                            onClick={() => {
                              setRxTarget(p || null)
                              setRxAppointment(a)
                              setRxForm({ diagnosis: a.reason, advice: '', followUp: 'بعد أسبوعين' })
                              setMeds([{ name: '', dosage: '', duration: '', notes: '' }])
                            }}
                          >
                            <Pill size={14} />
                            وصفة
                          </Button>
                        )}
                        {a.status === 'scheduled' && (
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => {
                              setAppointmentStatus(a.id, 'confirmed')
                              push('تم تأكيد الموعد')
                            }}
                          >
                            <CheckCircle2 size={14} />
                            تأكيد
                          </Button>
                        )}
                        {a.status === 'completed' && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setAppointmentStatus(a.id, 'no-show')
                              push('تم تسجيل عدم الحضور')
                            }}
                          >
                            <XCircle size={14} />
                            لم يحضر
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setAppointmentStatus(a.id, 'cancelled')
                            push('تم إلغاء الموعد')
                          }}
                        >
                          إلغاء
                        </Button>
                      </div>
                    </div>
                  </Card>
                )
              })
            )}
          </div>
        )}

        {/* ---- UPCOMING ---- */}
        {tab === 'upcoming' && (
          <div className="mt-5">
            {upcoming.length === 0 ? (
              <EmptyState icon={<Clock size={24} />} title="لا توجد مواعيد قادمة" />
            ) : (
              <Card className="!p-0 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[760px] text-right">
                    <thead className="bg-ink-50 text-[11.5px] font-bold text-ink-500">
                      <tr>
                        <th className="px-5 py-3">التاريخ</th>
                        <th className="px-5 py-3">المريض</th>
                        <th className="px-5 py-3">النوع</th>
                        <th className="px-5 py-3">السبب</th>
                        <th className="px-5 py-3">الحالة</th>
                        <th className="px-5 py-3">إجراء</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-ink-50 text-[12.5px]">
                      {upcoming.map((a) => {
                        const meta = statusMeta[a.status]
                        const p = db.patients.find((x) => x.id === a.patientId)
                        return (
                          <tr key={a.id} className="transition hover:bg-ink-50/50">
                            <td className="px-5 py-3.5 font-semibold text-ink-800">
                              {formatFullDate(a.date)}
                              <span className="block text-[11px] font-normal text-ink-400">{formatTime(a.time)}</span>
                            </td>
                            <td className="px-5 py-3.5 text-ink-700">{a.patientName}</td>
                            <td className="px-5 py-3.5 text-ink-600">{typeMeta[a.type]}</td>
                            <td className="px-5 py-3.5 text-ink-600">{a.reason}</td>
                            <td className="px-5 py-3.5">
                              <Badge tone={meta.tone}>{meta.label}</Badge>
                            </td>
                            <td className="px-5 py-3.5">
                              <div className="flex gap-2">
                                {p && (
                                  <button
                                    onClick={() => openFile(p)}
                                    className="flex items-center gap-1 rounded-lg bg-brand-50 px-2.5 py-1.5 text-[11.5px] font-bold text-brand-700 transition hover:bg-brand-100"
                                  >
                                    <FileHeart size={12} />
                                    الملف
                                  </button>
                                )}
                                <button
                                  onClick={() => {
                                    setRxTarget(p || null)
                                    setRxAppointment(a)
                                    setRxForm({ diagnosis: a.reason, advice: '', followUp: '' })
                                    setMeds([{ name: '', dosage: '', duration: '', notes: '' }])
                                  }}
                                  className="flex items-center gap-1 rounded-lg bg-violet-50 px-2.5 py-1.5 text-[11.5px] font-bold text-violet-700 transition hover:bg-violet-100"
                                >
                                  <Pill size={12} />
                                  وصفة
                                </button>
                              </div>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>
            )}
          </div>
        )}

        {/* ---- PATIENT FILES ---- */}
        {tab === 'patients' && (
          <div className="mt-5">
            <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="relative max-w-md flex-1">
                <Search size={17} className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-400" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="ابحث بالاسم أو رقم الجوال..."
                  className="pr-11"
                />
              </div>
              <p className="text-[12.5px] font-semibold text-ink-500">{filteredPatients.length} ملف</p>
            </div>

            {filteredPatients.length === 0 ? (
              <EmptyState icon={<Users size={24} />} title="لا توجد ملفات مطابقة" />
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {filteredPatients.map((p) => {
                  const appts = myAppointments.filter((a) => a.patientId === p.id)
                  const last = appts[0]
                  return (
                    <Card key={p.id} className="flex flex-col">
                      <div className="flex items-start gap-3">
                        <Avatar name={p.name} size={46} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[14px] font-extrabold text-ink-900">{p.name}</p>
                          <p className="text-[11.5px] text-ink-500" dir="ltr">
                            {p.phone}
                          </p>
                        </div>
                        {p.allergies !== 'لا يوجد' && (
                          <Badge tone="rose" className="!px-2 !py-0.5 !text-[10px]">
                            حساسية
                          </Badge>
                        )}
                      </div>
                      <div className="mt-3 space-y-1.5 text-[11.5px] text-ink-500">
                        <p className="flex items-center gap-1.5">
                          <ClipboardList size={12} />
                          {appts.length} زيارة — آخرها {last ? formatFullDate(last.date) : '—'}
                        </p>
                        <p className="flex items-center gap-1.5">
                          <HeartPulseIcon />
                          {p.chronic === 'لا يوجد' ? 'لا أمراض مزمنة' : p.chronic}
                        </p>
                      </div>
                      <Button size="sm" variant="secondary" className="mt-4 w-full" onClick={() => openFile(p)}>
                        <FileHeart size={14} />
                        فتح ملف المريض
                      </Button>
                    </Card>
                  )
                })}
              </div>
            )}
          </div>
        )}

        {/* ---- STATS ---- */}
        {tab === 'stats' && (
          <div className="mt-5 grid gap-5 lg:grid-cols-2">
            <Card>
              <SectionTitle title="المواعيد الشهرية" subtitle="عدد المواعيد في آخر 6 أشهر" icon={<TrendingUp size={18} />} />
              <BarChart data={monthly} color="#0f8271" />
            </Card>
            <Card>
              <SectionTitle title="توزيع حالات المواعيد" subtitle="نسبة كل حالة من إجمالي مواعيدك" icon={<Activity size={18} />} />
              <DonutChart segments={statusCounts} centerLabel="إجمالي المواعيد" centerValue={String(myAppointments.length)} />
            </Card>
            <Card className="lg:col-span-2">
              <SectionTitle
                title="تقييمات المرضى"
                subtitle={myReviews.length ? `${myReviews.length} تقييم منشور` : 'لا توجد تقييمات بعد'}
                icon={<Star size={18} />}
              />
              {myReviews.length > 0 && (
                <>
                  <div className="mt-4 flex items-center gap-4">
                    <p className="font-display text-4xl font-extrabold text-ink-950">{myRating.toFixed(1)}</p>
                    <Stars value={myRating} size={20} />
                  </div>
                  <div className="mt-4 grid gap-3 md:grid-cols-2">
                    {myReviews.slice(0, 4).map((r) => (
                      <div key={r.id} className="rounded-xl bg-ink-50 px-4 py-3">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[12.5px] font-bold text-ink-900">{r.patientName}</span>
                          <Stars value={r.rating} size={12} />
                        </div>
                        <p className="mt-1.5 text-[12px] leading-6 text-ink-600">{r.comment || 'بدون تعليق'}</p>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </Card>
          </div>
        )}
        {/* ---- REVIEWS ---- */}
        {tab === 'reviews' && (
          <div className="mt-5 grid gap-5 lg:grid-cols-[320px_1fr]">
            <Card className="h-fit">
              <SectionTitle title="ملخص التقييم" subtitle={`${myReviews.length} تقييم منشور`} icon={<Star size={18} />} />
              {myReviews.length === 0 ? (
                <p className="mt-4 text-[12.5px] text-ink-400">لا توجد تقييمات بعد. ستظهر هنا بعد أن يقيّمك المرضى.</p>
              ) : (
                <>
                  <div className="mt-4 text-center">
                    <p className="font-display text-5xl font-extrabold text-ink-950">{myRating.toFixed(1)}</p>
                    <div className="mt-2 flex justify-center">
                      <Stars value={myRating} size={20} />
                    </div>
                  </div>
                  <div className="mt-5 space-y-2">
                    {[5, 4, 3, 2, 1].map((n) => {
                      const c = myReviews.filter((r) => r.rating === n).length
                      return (
                        <div key={n} className="flex items-center gap-2 text-[12px]">
                          <span className="w-8 font-bold text-ink-600">{n} ★</span>
                          <div className="h-2 flex-1 overflow-hidden rounded-full bg-ink-100">
                            <div className="h-full rounded-full bg-amber-400" style={{ width: `${(c / myReviews.length) * 100}%` }} />
                          </div>
                          <span className="w-6 text-left text-ink-400">{c}</span>
                        </div>
                      )
                    })}
                  </div>
                </>
              )}
            </Card>

            <div className="space-y-3">
              {myReviews.length === 0 ? (
                <EmptyState icon={<Star size={24} />} title="لا توجد تقييمات بعد" description="تقييمات المرضى بعد الزيارة تظهر هنا." />
              ) : (
                myReviews.map((r) => (
                  <Card key={r.id}>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[13.5px] font-bold text-ink-900">{r.patientName}</span>
                      <Stars value={r.rating} size={14} />
                    </div>
                    <p className="mt-1 text-[11px] text-ink-400">{formatStamp(r.createdAt)}</p>
                    <p className="mt-2 text-[13px] leading-7 text-ink-700">{r.comment || 'بدون تعليق'}</p>
                    {r.reply && (
                      <p className="mt-3 rounded-xl bg-brand-50 px-4 py-3 text-[12.5px] leading-6 text-brand-800">
                        <span className="font-bold">رد الإدارة: </span>
                        {r.reply}
                      </p>
                    )}
                  </Card>
                ))
              )}
            </div>
          </div>
        )}
        {/* ---- ATTENDANCE (حضوري وغيابي) ---- */}
        {tab === 'attendance' && <MyAttendancePanel doctor={doctor} onDone={(msg, tone) => push(msg, tone)} />}

        {/* ---- SCHEDULE (أيام وساعات الدوام) ---- */}
        {tab === 'schedule' && (
          <SchedulePanel doctor={doctor} appointments={myAppointments} onDone={(msg, tone) => push(msg, tone)} />
        )}
        {/* ---- AVAILABILITY ---- */}
        {tab === 'availability' && (
          <AvailabilityPanel
            doctor={doctor}
            appointments={myAppointments}
            onDone={(msg) => push(msg)}
          />
        )}
      </main>

      <Footer />

      {/* ---- patient file modal ---- */}
      <PatientFileModal
        patient={openPatient}
        onClose={() => setOpenPatient(null)}
        appointments={openPatient ? db.appointments.filter((a) => a.patientId === openPatient.id && a.doctorId === doctor.id) : []}
        prescriptions={openPatient ? db.prescriptions.filter((p) => p.patientId === openPatient.id && p.doctorId === doctor.id) : []}
        doctors={db.doctors}
        onContact={(p, channel) =>
          logActivity(doctor.name, 'doctor', channel === 'whatsapp' ? 'تواصل واتساب مع مريض' : 'اتصال بمريض', `${channel === 'whatsapp' ? 'واتساب' : 'اتصال'} على ${p.name} — ${p.phone}`, 'medical')
        }
        onSaveNotes={(id, notes) => {
          updateAppointment(id, { notes })
          push('تم حفظ ملاحظات الكشف')
        }}
        onPrescribe={(p) => {
          setOpenPatient(null)
          setRxTarget(p)
          setRxAppointment(null)
          setRxForm({ diagnosis: '', advice: '', followUp: '' })
          setMeds([{ name: '', dosage: '', duration: '', notes: '' }])
        }}
      />

      {/* ---- prescription modal ---- */}
      <Modal
        open={!!rxTarget}
        onClose={() => setRxTarget(null)}
        title="إصدار وصفة طبية"
        subtitle={rxTarget ? `المريض: ${rxTarget.name}` : ''}
        size="md"
        footer={
          <>
            <Button variant="secondary" onClick={() => setRxTarget(null)}>
              إلغاء
            </Button>
            <Button onClick={issuePrescription}>
              <Pill size={16} />
              إصدار الوصفة
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <Field label="التشخيص" required>
            <Input
              value={rxForm.diagnosis}
              onChange={(e) => setRxForm({ ...rxForm, diagnosis: e.target.value })}
              placeholder="مثال: ارتفاع ضغط الدم الأساسي"
            />
          </Field>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[13px] font-semibold text-ink-700">الأدوية</span>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setMeds([...meds, { name: '', dosage: '', duration: '', notes: '' }])}
              >
                <Plus size={14} />
                إضافة دواء
              </Button>
            </div>
            <div className="space-y-3">
              {meds.map((m, i) => (
                <div key={i} className="rounded-2xl border border-ink-100 p-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] font-bold text-ink-500">دواء {i + 1}</span>
                    {meds.length > 1 && (
                      <button
                        onClick={() => setMeds(meds.filter((_, idx) => idx !== i))}
                        className="rounded-lg p-1.5 text-ink-400 transition hover:bg-rose-50 hover:text-rose-600"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                  <div className="mt-2 grid gap-3 sm:grid-cols-3">
                    <Input
                      placeholder="اسم الدواء"
                      value={m.name}
                      onChange={(e) =>
                        setMeds(meds.map((x, idx) => (idx === i ? { ...x, name: e.target.value } : x)))
                      }
                    />
                    <Input
                      placeholder="الجرعة"
                      value={m.dosage}
                      onChange={(e) =>
                        setMeds(meds.map((x, idx) => (idx === i ? { ...x, dosage: e.target.value } : x)))
                      }
                    />
                    <Input
                      placeholder="المدة"
                      value={m.duration}
                      onChange={(e) =>
                        setMeds(meds.map((x, idx) => (idx === i ? { ...x, duration: e.target.value } : x)))
                      }
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Field label="إرشادات للمريض">
            <Textarea
              value={rxForm.advice}
              onChange={(e) => setRxForm({ ...rxForm, advice: e.target.value })}
              placeholder="نصائح عند أخذ الدواء ونمط الحياة..."
            />
          </Field>

          <Field label="موعد المتابعة المقترح">
            <Input
              value={rxForm.followUp}
              onChange={(e) => setRxForm({ ...rxForm, followUp: e.target.value })}
              placeholder="مثال: بعد أسبوعين"
            />
          </Field>
        </div>
      </Modal>
    </div>
  )
}

/* ---------------- availability (ظرف / غير متاح) ---------------- */
const OFF_REASONS = ['ظرف طارئ', 'إجازة', 'ظرف صحي', 'مهمة خارج العيادة', 'أخرى']

function addDaysKey(n: number) {
  const d = new Date()
  d.setDate(d.getDate() + n)
  return toDateKey(d)
}

function AvailabilityPanel({
  doctor,
  appointments,
  onDone,
}: {
  doctor: Doctor
  appointments: Appointment[]
  onDone: (message: string) => void
}) {
  const today = toDateKey(new Date())
  const [reason, setReason] = useState(OFF_REASONS[0])
  const [note, setNote] = useState('')
  const [until, setUntil] = useState(today)
  const [cancelAffected, setCancelAffected] = useState(false)
  const current = doctor.unavailable

  const affected = appointments.filter(
    (a) =>
      a.date >= today &&
      (!until || a.date <= until) &&
      (a.status === 'scheduled' || a.status === 'confirmed'),
  )

  function announce() {
    const cancelled = setDoctorUnavailable(
      doctor.id,
      { reason, note: note.trim(), since: today, until },
      { cancelAffected },
    )
    // webhook «Not available» — الفشل مبيكسرش الإعلان
    void notify('doctor.unavailable', {
      doctorId: doctor.id,
      doctorName: doctor.name,
      doctorPhone: doctor.phone,
      reason,
      note: note.trim(),
      since: today,
      until,
      cancelled,
      affected: affected.map((a) => ({
        patientName: a.patientName,
        patientPhone: a.patientPhone,
        date: a.date,
        time: a.time,
      })),
    })
    onDone(
      cancelled
        ? `تم قفل مواعيدك وإلغاء ${cancelled} موعد`
        : 'تم قفل مواعيدك — هتظهر للمرضى إنك مش موجود',
    )
  }

  function comeBack() {
    setDoctorUnavailable(doctor.id, null)
    onDone('حمدلله على السلامة — اتفتحت مواعيدك للحجز')
  }

  if (current && isDoctorOffNow(doctor)) {
    return (
      <div className="mt-5 grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <Card className="!border-rose-200 !bg-rose-50/60">
          <div className="flex items-start gap-4">
            <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-rose-600 text-white">
              <CalendarX size={22} />
            </span>
            <div className="min-w-0 flex-1">
              <h3 className="font-display text-lg font-extrabold text-rose-900">مواعيدك مقفولة دلوقتي</h3>
              <p className="mt-1 text-[13px] leading-6 text-rose-800">
                السبب: <b>{current.reason}</b>
                {current.note ? ` — ${current.note}` : ''}
              </p>
              <p className="text-[12px] text-rose-700">
                من {formatFullDate(current.since)} {current.until ? `حتى ${formatFullDate(current.until)}` : 'ومفتوحة لحد ما ترجع'}
              </p>
              <p className="mt-3 text-[12.5px] text-ink-600">
                المرضى بيشوفوا «غير متاح حالياً» ومش هيقدروا يحجزوا معاك في الفترة دي.
              </p>
              <Button className="mt-4" onClick={comeBack}>
                <RotateCcw size={16} />
                رجعت — افتح المواعيد
              </Button>
            </div>
          </div>
        </Card>
        <Card>
          <SectionTitle title="مواعيد متأثرة" subtitle="مواعيد مجدولة داخل فترة عدم التواجد" icon={<CalendarDays size={18} />} />
          {affected.length === 0 ? (
            <p className="text-[12.5px] text-ink-500">مفيش مواعيد محجوزة في الفترة دي.</p>
          ) : (
            <ul className="space-y-2">
              {affected.slice(0, 8).map((a) => (
                <li key={a.id} className="flex items-center justify-between rounded-xl bg-ink-50 px-3.5 py-2.5 text-[12.5px]">
                  <span className="font-bold text-ink-800">{a.patientName}</span>
                  <span className="text-ink-500">
                    {formatFullDate(a.date)} — {formatTime(a.time)}
                  </span>
                </li>
              ))}
              {affected.length > 8 && <li className="text-[11.5px] text-ink-400">و {affected.length - 8} موعد آخر</li>}
            </ul>
          )}
        </Card>
      </div>
    )
  }

  return (
    <div className="mt-5 grid gap-5 lg:grid-cols-[1.3fr_1fr]">
      <Card>
        <SectionTitle
          title="عندي ظرف — مش موجود"
          subtitle="اضغط وهتتقفل مواعيدك ويظهر للمرضى إنك غير متاح"
          icon={<CalendarX size={18} />}
        />
        <div className="space-y-4">
          <div>
            <span className="mb-1.5 block text-[13px] font-semibold text-ink-700">السبب</span>
            <div className="flex flex-wrap gap-2">
              {OFF_REASONS.map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setReason(r)}
                  className={`rounded-xl border px-3.5 py-2 text-[12.5px] font-bold transition ${
                    reason === r
                      ? 'border-rose-500 bg-rose-600 text-white'
                      : 'border-ink-200 bg-white text-ink-600 hover:border-rose-300'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="mb-1.5 block text-[13px] font-semibold text-ink-700">لحد امتى؟</span>
            <div className="flex flex-wrap items-center gap-2">
              <Input type="date" min={today} value={until} onChange={(e) => setUntil(e.target.value)} className="max-w-[190px]" />
              {[
                ['النهارده بس', today],
                ['يومين', addDaysKey(1)],
                ['أسبوع', addDaysKey(6)],
                ['مفتوح', ''],
              ].map(([label, value]) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => setUntil(value)}
                  className={`rounded-lg px-3 py-2 text-[12px] font-bold transition ${
                    until === value ? 'bg-ink-900 text-white' : 'bg-ink-50 text-ink-600 hover:bg-ink-100'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            <span className="mt-1.5 block text-xs text-ink-400">سيبه فاضي (مفتوح) لو مش عارف — هتفتح المواعيد بنفسك لما ترجع</span>
          </div>

          <Field label="ملاحظة للإدارة (اختياري)">
            <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="أي تفاصيل تحب الإدارة تعرفها..." />
          </Field>

          <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-ink-100 p-3.5 text-[12.5px] text-ink-700">
            <input
              type="checkbox"
              checked={cancelAffected}
              onChange={(e) => setCancelAffected(e.target.checked)}
              className="mt-1 size-4 accent-rose-600"
            />
            <span>
              <b>إلغاء المواعيد المحجوزة في الفترة دي</b>
              <span className="block text-ink-500">
                {affected.length} موعد مجدول/مؤكد هيتلغي ويظهر للمريض كملغي.
              </span>
            </span>
          </label>

          <Button className="w-full !bg-rose-600 hover:!bg-rose-700" onClick={announce}>
            <CalendarX size={16} />
            إعلان عدم التواجد وقفل المواعيد
          </Button>
        </div>
      </Card>

      <Card>
        <SectionTitle title="إيه اللي هيحصل؟" subtitle="بعد الضغط على الزرار" icon={<AlertCircle size={18} />} />
        <ul className="space-y-3 text-[12.5px] leading-6 text-ink-600">
          <li>• مواعيدك تتقفل فوراً في صفحة الحجز، وكل الأوقات بتظهر غير متاحة.</li>
          <li>• اسمك بيظهر عند المرضى بعلامة «غير متاح حالياً».</li>
          <li>• الإدارة بتشوف الإعلان في سجل الأنشطة وفي صفحة الأطباء.</li>
          <li>• ترجع في أي وقت بضغطة «رجعت — افتح المواعيد».</li>
        </ul>
      </Card>
    </div>
  )
}

/* ---------------- schedule (مواعيد الدوام: أيام + ساعات) ---------------- */
const WEEK_DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']

function hourLabel(h: number) {
  const period = h >= 12 && h < 24 ? 'م' : 'ص'
  const h12 = h % 12 === 0 ? 12 : h % 12
  return `${h12}:00 ${period}`
}

function SchedulePanel({
  doctor,
  appointments,
  onDone,
}: {
  doctor: Doctor
  appointments: Appointment[]
  onDone: (message: string, tone?: 'success' | 'error') => void
}) {
  const [days, setDays] = useState<number[]>(doctor.days)
  const [startHour, setStartHour] = useState(doctor.startHour)
  const [endHour, setEndHour] = useState(doctor.endHour)
  const [saving, setSaving] = useState(false)
  const [sync, setSync] = useState<ScheduleSyncResult | null>(null)

  const dirty =
    startHour !== doctor.startHour ||
    endHour !== doctor.endHour ||
    days.length !== doctor.days.length ||
    days.some((d) => !doctor.days.includes(d))

  const today = toDateKey(new Date())
  const slotsPerDay = Math.max(0, (endHour - startHour) * 2 - 1)

  // مواعيد محجوزة جاية هتبقى برا الدوام الجديد (مبنلغيهاش — بس بنحذّر)
  const outside = appointments.filter((a) => {
    if (a.date < today || (a.status !== 'scheduled' && a.status !== 'confirmed')) return false
    const hour = Number(a.time.slice(0, 2))
    const day = new Date(`${a.date}T00:00:00`).getDay()
    return !days.includes(day) || hour < startHour || hour >= endHour
  })

  function toggle(i: number) {
    setDays((cur) => (cur.includes(i) ? cur.filter((x) => x !== i) : [...cur, i].sort()))
  }

  async function save() {
    if (days.length === 0) return onDone('اختار يوم دوام واحد على الأقل', 'error')
    if (endHour <= startHour) return onDone('ساعة النهاية لازم تكون بعد ساعة البداية', 'error')
    setSaving(true)
    const result = await setDoctorSchedule(doctor.id, { days, startHour, endHour })
    setSaving(false)
    setSync(result)
    if (result.ok) onDone('اتحفظت مواعيدك في قاعدة البيانات وظهرت للإدارة والحجز')
    else onDone('اتحفظت على الجهاز بس — تعذر الحفظ في قاعدة البيانات', 'error')
  }

  const syncNote =
    sync && !sync.ok
      ? sync.reason === 'no_supabase'
        ? 'قاعدة البيانات (Supabase) غير مفعّلة في الإعدادات.'
        : sync.reason === 'no_session'
          ? 'سجّل خروج وادخل تاني بنفس الإيميل والباسورد المسجلين في Supabase Auth عشان الحفظ يوصل لقاعدة البيانات.'
          : sync.reason === 'denied'
            ? 'مفيش صلاحية: تأكد إن حسابك في جدول profiles مربوط بـ doctor_id بتاعك.'
            : 'حصل خطأ أثناء الحفظ، جرّب تاني.'
      : null

  return (
    <div className="mt-5 grid gap-5 lg:grid-cols-[1.3fr_1fr]">
      <Card>
        <SectionTitle
          title="إدارة مواعيدي"
          subtitle="حدّد أيام وساعات دوامك — بتتحفظ في قاعدة البيانات وبتظهر للإدارة ولصفحة الحجز"
          icon={<CalendarCheck size={18} />}
        />
        <div className="space-y-5">
          <div>
            <span className="mb-2 block text-[13px] font-semibold text-ink-700">أيام الدوام</span>
            <div className="flex flex-wrap gap-2">
              {WEEK_DAYS.map((label, i) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => toggle(i)}
                  aria-pressed={days.includes(i)}
                  className={`rounded-xl px-4 py-2.5 text-[12.5px] font-bold transition ${
                    days.includes(i) ? 'bg-brand-600 text-white' : 'bg-ink-50 text-ink-500 hover:bg-ink-100'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="بداية الدوام">
              <Select value={String(startHour)} onChange={(e) => setStartHour(Number(e.target.value))}>
                {Array.from({ length: 17 }, (_, i) => i + 6).map((h) => (
                  <option key={h} value={h}>
                    {hourLabel(h)}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="نهاية الدوام">
              <Select value={String(endHour)} onChange={(e) => setEndHour(Number(e.target.value))}>
                {Array.from({ length: 17 }, (_, i) => i + 8).map((h) => (
                  <option key={h} value={h}>
                    {hourLabel(h)}
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          {outside.length > 0 && (
            <p className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-[12.5px] leading-6 text-amber-800">
              تنبيه: {outside.length} موعد محجوز هيبقى خارج دوامك الجديد. مش هيتلغي تلقائياً — راجعه من «المواعيد القادمة».
            </p>
          )}

          <div className="flex flex-wrap items-center gap-3">
            <Button onClick={save} disabled={!dirty || saving}>
              <Save size={16} />
              {saving ? 'جاري الحفظ...' : 'حفظ المواعيد'}
            </Button>
            {dirty && (
              <Button
                variant="ghost"
                onClick={() => {
                  setDays(doctor.days)
                  setStartHour(doctor.startHour)
                  setEndHour(doctor.endHour)
                }}
              >
                تراجع
              </Button>
            )}
          </div>

          {syncNote && (
            <p className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-[12.5px] leading-6 text-rose-800">{syncNote}</p>
          )}
          {sync?.ok && (
            <p className="flex items-center gap-2 text-[12.5px] font-semibold text-emerald-700">
              <CheckCircle2 size={15} />
              محفوظة في قاعدة البيانات
            </p>
          )}
        </div>
      </Card>

      <Card>
        <SectionTitle title="دوامك الحالي" subtitle="ده اللي بيشوفه المرضى والإدارة" icon={<Clock size={18} />} />
        <div className="flex flex-wrap gap-1.5">
          {doctor.days.length === 0 ? (
            <span className="text-[12.5px] text-ink-400">لم تحدد أيام دوام.</span>
          ) : (
            doctor.days.map((d) => (
              <Badge key={d} tone="brand">
                {WEEK_DAYS[d]}
              </Badge>
            ))
          )}
        </div>
        <p className="mt-4 text-[13px] font-bold text-ink-800">
          من {hourLabel(doctor.startHour)} إلى {hourLabel(doctor.endHour)}
        </p>
        <p className="mt-1 text-[12px] text-ink-500">
          {Math.max(0, (doctor.endHour - doctor.startHour) * 2 - 1)} موعد (نصف ساعة) في اليوم
          {dirty ? ` — بعد التعديل: ${slotsPerDay}` : ''}
        </p>
        <ul className="mt-5 space-y-2.5 text-[12.5px] leading-6 text-ink-600">
          <li>• التعديل بيتحفظ في قاعدة البيانات ويظهر للإدارة لحظياً في صفحة الأطباء.</li>
          <li>• المرضى بيحجزوا بس في الأيام والساعات دي.</li>
          <li>• للإجازة أو الظرف الطارئ استخدم تبويب «عندي ظرف / غير متاح».</li>
        </ul>
      </Card>
    </div>
  )
}

/* ---------------- حضوري وغيابي ---------------- */
function MyAttendancePanel({
  doctor,
  onDone,
}: {
  doctor: Doctor
  onDone: (message: string, tone?: 'success' | 'error') => void
}) {
  const db = useDB()
  const data: AttendanceData = useMemo(
    () => ({ records: db.attendance, leaves: db.leaves, appointments: db.appointments }),
    [db.attendance, db.leaves, db.appointments],
  )
  const now = new Date()
  const today = toDateKey(now)
  const from = toDateKey(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 29))
  const s = useMemo(() => summarize(doctor, data, from, today), [doctor, data, from, today])
  const row = todayRow(doctor, data)
  const grade = gradeOf(s.rate)
  const myLeaves = db.leaves.filter((l) => l.doctorId === doctor.id)

  function act(fn: () => { ok: true } | { ok: false; error: string }, okMsg: string) {
    const r = fn()
    onDone(r.ok ? okMsg : r.error, r.ok ? 'success' : 'error')
  }

  return (
    <div className="mt-5 grid gap-5 lg:grid-cols-[1.2fr_1fr]">
      <div className="space-y-5">
        <Card>
          <SectionTitle title="حضور النهارده" subtitle={formatFullDate(today)} icon={<UserCheck size={18} />} />
          {!row ? (
            <p className="rounded-xl bg-ink-50 px-4 py-3 text-[13px] text-ink-600">النهارده مش يوم دوامك — مفيش حاجة تتسجل.</p>
          ) : (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone={statusTone[row.status]}>{statusLabel[row.status]}</Badge>
                {row.checkIn && <span className="text-[12.5px] text-ink-600">حضور: <b dir="ltr">{row.checkIn}</b></span>}
                {row.checkOut && <span className="text-[12.5px] text-ink-600">انصراف: <b dir="ltr">{row.checkOut}</b></span>}
              </div>
              <div className="flex flex-wrap gap-2.5">
                <Button disabled={!!row.checkIn || row.status === 'leave'} onClick={() => act(() => checkInDoctor(doctor.id), 'تم تسجيل حضورك')}>
                  <LogIn size={16} />
                  تسجيل حضور
                </Button>
                <Button
                  variant="secondary"
                  disabled={!row.checkIn || !!row.checkOut}
                  onClick={() => act(() => checkOutDoctor(doctor.id), 'تم تسجيل انصرافك')}
                >
                  <LogOut size={16} />
                  تسجيل انصراف
                </Button>
              </div>
              <p className="text-[12px] leading-6 text-ink-500">
                لو سجلت حضورك بعد {doctor.startHour}:15 هيتحسب «متأخر». لو عندك ظرف استخدم تبويب «عندي ظرف / غير متاح» وهيتحسب ظرف مش غياب.
              </p>
            </div>
          )}
        </Card>

        <Card className="!p-0 overflow-hidden">
          <div className="px-5 pt-5 sm:px-6 sm:pt-6">
            <SectionTitle title="سجلي — آخر 30 يوم" icon={<ClipboardList size={18} />} />
          </div>
          {s.rows.length === 0 ? (
            <p className="px-6 pb-6 text-[12.5px] text-ink-500">لسه مفيش أيام محسوبة.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[420px] text-right text-[12.5px]">
                <thead className="bg-ink-50 text-[11.5px] font-bold text-ink-500">
                  <tr>
                    <th className="px-5 py-2.5">اليوم</th>
                    <th className="px-3 py-2.5">الحالة</th>
                    <th className="px-3 py-2.5">حضور</th>
                    <th className="px-3 py-2.5">انصراف</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink-50">
                  {[...s.rows].reverse().slice(0, 20).map((r) => (
                    <tr key={r.date}>
                      <td className="px-5 py-2.5 font-semibold text-ink-800">{formatFullDate(r.date)}</td>
                      <td className="px-3 py-2.5">
                        <Badge tone={statusTone[r.status]}>{statusLabel[r.status]}</Badge>
                      </td>
                      <td className="px-3 py-2.5 text-ink-600" dir="ltr">{r.checkIn || '—'}</td>
                      <td className="px-3 py-2.5 text-ink-600" dir="ltr">{r.checkOut || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      <Card>
        <SectionTitle title="ملخصي" subtitle="الإدارة بتشوف نفس الأرقام دي" icon={<TrendingUp size={18} />} />
        <div className="grid grid-cols-2 gap-3">
          {[
            { l: 'حضر', v: s.present, c: 'text-emerald-700' },
            { l: 'متأخر', v: s.late, c: 'text-amber-600' },
            { l: 'غياب', v: s.absent, c: 'text-rose-600' },
            { l: 'ظرف (مرات)', v: s.leaveEvents, c: 'text-sky-700' },
          ].map((k) => (
            <div key={k.l} className="rounded-xl bg-ink-50 px-3 py-3 text-center">
              <p className={`font-display text-2xl font-extrabold ${k.c}`}>{k.v}</p>
              <p className="text-[11px] text-ink-500">{k.l}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 flex items-center justify-between rounded-xl bg-brand-50 px-4 py-3">
          <span className="text-[12.5px] font-semibold text-brand-700">نسبة الحضور</span>
          <span className="flex items-center gap-2">
            <span className="font-display text-lg font-extrabold text-brand-700">{s.rate === null ? '—' : `${s.rate}%`}</span>
            <Badge tone={grade.tone}>{grade.label}</Badge>
          </span>
        </div>
        {myLeaves.length > 0 && (
          <div className="mt-5">
            <h4 className="mb-2 text-[12.5px] font-bold text-ink-700">آخر ظروفي</h4>
            <ul className="space-y-1.5 text-[12px] text-ink-600">
              {myLeaves.slice(0, 5).map((l) => (
                <li key={l.id} className="flex items-center justify-between rounded-lg bg-ink-50 px-3 py-2">
                  <span className="font-semibold">{l.reason}</span>
                  <span className="text-ink-400">{formatFullDate(l.since)}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </Card>
    </div>
  )
}

function HeartPulseIcon() {
  return <Activity size={12} />
}

/* ---------------- helpers ---------------- */
function findVisitPrescription(a: Appointment, list: Prescription[]) {
  return (
    list.find((rx) => rx.appointmentId === a.id) ||
    list.find(
      (rx) =>
        !rx.appointmentId &&
        rx.patientId === a.patientId &&
        rx.doctorId === a.doctorId &&
        toDateKey(new Date(rx.issuedAt)) === a.date,
    )
  )
}

/* ---------------- patient file ---------------- */
function PatientFileModal({
  patient,
  onClose,
  appointments,
  prescriptions,
  doctors,
  onPrescribe,
  onContact,
  onSaveNotes,
}: {
  patient: Patient | null
  onClose: () => void
  appointments: Appointment[]
  prescriptions: Prescription[]
  doctors: { id: string; name: string }[]
  onPrescribe: (p: Patient) => void
  onContact: (p: Patient, channel: 'whatsapp' | 'call') => void
  onSaveNotes: (appointmentId: string, notes: string) => void
}) {
  const settings = useSettings()
  const fullDb = useDB()
  const [visitId, setVisitId] = useState<string | null>(null)

  const sorted = useMemo(
    () => [...appointments].sort((a, b) => (a.date + a.time < b.date + b.time ? 1 : -1)),
    [appointments],
  )
  const visit = sorted.find((a) => a.id === visitId) || null
  const visitRx = visit ? findVisitPrescription(visit, prescriptions) : undefined
  const doctorOf = (id: string) => doctors.find((d) => d.id === id)?.name ?? '—'

  const lastTouch = sorted[0]
    ? formatFullDate(sorted[0].date)
    : patient
      ? formatStamp(patient.createdAt)
      : ''

  function close() {
    setVisitId(null)
    onClose()
  }

  const greeting = patient
    ? `مرحباً ${patient.name}، معك ${settings.name}.${
        sorted[0] ? ` بخصوص موعدك يوم ${formatFullDate(sorted[0].date)} الساعة ${formatTime(sorted[0].time)}.` : ''
      }`
    : ''

  return (
    <>
      <Modal
        open={!!patient}
        onClose={close}
        title={patient ? `ملف المريض: ${patient.name}` : ''}
        subtitle={patient ? `آخر زيارة: ${lastTouch}` : ''}
        size="xl"
        footer={
          <>
            <Button variant="secondary" onClick={close}>
              إغلاق
            </Button>
            {patient && (
              <Button
                variant="secondary"
                onClick={() =>
                  printPatientFile({
                    settings,
                    patient,
                    doctors: fullDb.doctors,
                    appointments,
                    prescriptions,
                  })
                }
              >
                <Printer size={16} />
                طباعة الملف
              </Button>
            )}
            {patient && (
              <Button onClick={() => onPrescribe(patient)}>
                <Pill size={16} />
                إصدار وصفة
              </Button>
            )}
          </>
        }
      >
        {patient && (
          <div className="grid gap-5 lg:grid-cols-[1fr_1.4fr]">
            {/* personal + medical data */}
            <div className="space-y-4">
              <div className="flex items-center gap-4 rounded-2xl bg-ink-50 p-4">
                <Avatar name={patient.name} size={56} />
                <div>
                  <p className="text-[15px] font-extrabold text-ink-900">{patient.name}</p>
                  <p className="text-[12px] text-ink-500" dir="ltr">
                    {patient.phone}
                  </p>
                </div>
              </div>

              <div className="rounded-2xl border border-ink-100 p-4">
                <h4 className="mb-2 flex items-center gap-2 text-[12.5px] font-extrabold text-ink-800">
                  <User size={14} className="text-brand-600" />
                  البيانات الشخصية
                </h4>
                <div className="space-y-1.5 text-[12.5px]">
                  {[
                    ['البريد الإلكتروني', patient.email || '—'],
                    ['رقم الهوية', patient.nationalId || '—'],
                    ['تاريخ الميلاد', patient.birthDate || '—'],
                    ['العمر', patient.birthDate ? `${ageFrom(patient.birthDate)} سنة` : '—'],
                    ['الجنس', genderLabel(patient.gender)],
                    ['العنوان', patient.address || '—'],
                    ['شركة التأمين', patient.insurance || '—'],
                    [
                      'جهة الطوارئ',
                      patient.emergency.name
                        ? `${patient.emergency.name} (${patient.emergency.relation}) — ${patient.emergency.phone}`
                        : '—',
                    ],
                  ].map(([l, v]) => (
                    <div key={l} className="flex items-start justify-between gap-3 border-b border-ink-50 py-1.5 last:border-0">
                      <span className="text-ink-500">{l}</span>
                      <span className="text-left font-bold text-ink-800">{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-ink-100 p-4">
                <h4 className="mb-3 flex items-center gap-2 text-[12.5px] font-extrabold text-ink-800">
                  <Activity size={14} className="text-brand-600" />
                  البيانات الطبية
                </h4>
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between rounded-xl bg-ink-50 px-3.5 py-2.5">
                    <span className="text-[12px] text-ink-500">فصيلة الدم</span>
                    <span className="text-[12.5px] font-bold text-ink-900">{patient.bloodType}</span>
                  </div>
                  <div className="flex items-center justify-between rounded-xl bg-rose-50 px-3.5 py-2.5">
                    <span className="text-[12px] text-rose-600">الحساسية</span>
                    <span className="text-[12.5px] font-bold text-rose-700">{patient.allergies}</span>
                  </div>
                  <div className="flex items-center justify-between rounded-xl bg-amber-50 px-3.5 py-2.5">
                    <span className="text-[12px] text-amber-700">الأمراض المزمنة</span>
                    <span className="text-[12.5px] font-bold text-amber-800">{patient.chronic}</span>
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border border-ink-100 p-4">
                <h4 className="mb-2 flex items-center gap-2 text-[12.5px] font-extrabold text-ink-800">
                  <MessageCircle size={14} className="text-brand-600" />
                  تواصل مع المريض
                </h4>
                <p className="mb-3 text-[11.5px] text-ink-500" dir="ltr">
                  {patient.phone}
                </p>
                <div className="flex gap-2">
                  <a
                    href={waLink(patient.phone, greeting)}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => onContact(patient, 'whatsapp')}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-[#25D366] px-3 py-2.5 text-[12px] font-bold text-ink-950 transition hover:bg-[#1eb958]"
                  >
                    <MessageCircle size={14} />
                    واتساب
                  </a>
                  <a
                    href={telHref(patient.phone)}
                    onClick={() => onContact(patient, 'call')}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-ink-200 px-3 py-2.5 text-[12px] font-bold text-ink-700 transition hover:border-brand-300 hover:text-brand-700"
                  >
                    <Phone size={14} />
                    اتصال
                  </a>
                </div>
              </div>
            </div>

            {/* history */}
            <div className="space-y-4">
              <div className="rounded-2xl border border-ink-100 p-4">
                <h4 className="mb-1 flex items-center gap-2 text-[12.5px] font-extrabold text-ink-800">
                  <History size={14} className="text-brand-600" />
                  سجل الكشوفات ({sorted.length})
                </h4>
                <p className="mb-3 text-[11px] text-ink-400">اضغط على أي كشف لعرض التشخيص والعلاج وما تم فيه.</p>
                {sorted.length === 0 ? (
                  <p className="text-[12px] text-ink-400">لا توجد مواعيد مسجلة.</p>
                ) : (
                  <div className="space-y-2.5">
                    {sorted.map((a) => {
                      const meta = statusMeta[a.status]
                      const rx = findVisitPrescription(a, prescriptions)
                      return (
                        <button
                          key={a.id}
                          type="button"
                          onClick={() => setVisitId(a.id)}
                          className="block w-full rounded-xl border border-ink-100 p-3 text-right transition hover:border-brand-300 hover:bg-brand-50/40 focus-visible:outline-2 focus-visible:outline-brand-500"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <p className="text-[12.5px] font-bold text-ink-900">
                              {formatFullDate(a.date)} — {formatTime(a.time)}
                            </p>
                            <Badge tone={meta.tone}>{meta.label}</Badge>
                          </div>
                          <p className="mt-1 text-[11.5px] text-ink-500">
                            {typeMeta[a.type]} — {a.reason}
                          </p>
                          {rx && (
                            <p className="mt-1.5 flex items-center gap-1.5 text-[11.5px] font-bold text-violet-700">
                              <Pill size={12} />
                              التشخيص: {rx.diagnosis}
                            </p>
                          )}
                          <p className="mt-1 flex items-center justify-between text-[10.5px] text-ink-400">
                            <span>الطبيب المعالج: {doctorOf(a.doctorId)}</span>
                            <span className="flex items-center gap-0.5 font-bold text-brand-700">
                              عرض التفاصيل
                              <ChevronLeft size={12} />
                            </span>
                          </p>
                        </button>
                      )
                    })}
                  </div>
                )}
              </div>

              <div className="rounded-2xl border border-ink-100 p-4">
                <h4 className="mb-3 flex items-center gap-2 text-[12.5px] font-extrabold text-ink-800">
                  <Pill size={14} className="text-brand-600" />
                  الروشتات الطبية ({prescriptions.length})
                </h4>
                {prescriptions.length === 0 ? (
                  <p className="text-[12px] text-ink-400">لا توجد وصفات مسجلة.</p>
                ) : (
                  <div className="space-y-2.5">
                    {prescriptions.map((p) => (
                      <div key={p.id} className="rounded-xl bg-violet-50/70 p-3">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-[12.5px] font-bold text-ink-900">{p.diagnosis}</p>
                          <span className="text-[10.5px] text-ink-400">{formatStamp(p.issuedAt)}</span>
                        </div>
                        <ul className="mt-2 space-y-1">
                          {p.items.map((m, i) => (
                            <li key={i} className="flex items-center justify-between text-[11.5px] text-ink-600">
                              <span className="font-semibold">{m.name}</span>
                              <span>
                                {m.dosage} — {m.duration}
                              </span>
                            </li>
                          ))}
                        </ul>
                        {p.advice && <p className="mt-2 text-[11px] leading-5 text-ink-500">{p.advice}</p>}
                        {p.followUp && (
                          <p className="mt-1.5 text-[11px] font-bold text-amber-700">المتابعة: {p.followUp}</p>
                        )}
                        <p className="mt-1.5 text-[10.5px] text-ink-400">د. {doctorOf(p.doctorId).replace(/^د\.\s*/, '')}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </Modal>

      <VisitDetailModal
        key={visit?.id ?? 'none'}
        appointment={visit}
        patient={patient}
        prescription={visitRx}
        doctorName={visit ? doctorOf(visit.doctorId) : ''}
        onClose={() => setVisitId(null)}
        onSaveNotes={onSaveNotes}
        onPrintRx={() =>
          visitRx &&
          patient &&
          printPrescription({
            settings,
            rx: visitRx,
            patient,
            doctors: fullDb.doctors,
            specialties: fullDb.specialties,
            appointments,
          })
        }
        onPrintInvoice={() =>
          visit &&
          printInvoice({
            settings,
            appointment: visit,
            patient: patient ?? undefined,
            doctors: fullDb.doctors,
            specialties: fullDb.specialties,
            appointments,
            prescriptions,
          })
        }
      />
    </>
  )
}

/* ---------------- single visit (كشف) ---------------- */
function VisitDetailModal({
  appointment,
  patient,
  prescription,
  doctorName,
  onClose,
  onSaveNotes,
  onPrintRx,
  onPrintInvoice,
}: {
  appointment: Appointment | null
  patient: Patient | null
  prescription?: Prescription
  doctorName: string
  onClose: () => void
  onSaveNotes: (appointmentId: string, notes: string) => void
  onPrintRx: () => void
  onPrintInvoice: () => void
}) {
  const [notes, setNotes] = useState(appointment?.notes ?? '')
  const dirty = !!appointment && notes !== appointment.notes
  const meta = appointment ? statusMeta[appointment.status] : null

  return (
    <Modal
      open={!!appointment}
      onClose={onClose}
      title={appointment ? `كشف ${formatFullDate(appointment.date)}` : ''}
      subtitle={appointment && patient ? `${patient.name} — ${formatTime(appointment.time)}` : ''}
      size="md"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            رجوع للملف
          </Button>
          {prescription && (
            <Button variant="secondary" onClick={onPrintRx}>
              <Printer size={16} />
              طباعة الوصفة
            </Button>
          )}
          {appointment && (
            <Button variant="secondary" onClick={onPrintInvoice}>
              <Receipt size={16} />
              الفاتورة
            </Button>
          )}
          {appointment && (
            <Button disabled={!dirty} onClick={() => onSaveNotes(appointment.id, notes.trim())}>
              <Save size={16} />
              حفظ الملاحظات
            </Button>
          )}
        </>
      }
    >
      {appointment && meta && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone={meta.tone}>{meta.label}</Badge>
            <Badge tone="slate">{typeMeta[appointment.type]}</Badge>
            <Badge tone={appointment.paid ? 'green' : 'amber'}>{appointment.paid ? 'مدفوع' : 'غير مدفوع'}</Badge>
            <span className="text-[11.5px] text-ink-400">الطبيب: {doctorName}</span>
          </div>

          <div className="rounded-2xl border border-ink-100 p-4">
            <h4 className="mb-1.5 flex items-center gap-2 text-[12.5px] font-extrabold text-ink-800">
              <ClipboardList size={14} className="text-brand-600" />
              سبب الزيارة / الشكوى
            </h4>
            <p className="text-[13px] leading-6 text-ink-700">{appointment.reason || '—'}</p>
          </div>

          <div className="rounded-2xl border border-ink-100 p-4">
            <h4 className="mb-1.5 flex items-center gap-2 text-[12.5px] font-extrabold text-ink-800">
              <Stethoscope size={14} className="text-brand-600" />
              التشخيص
            </h4>
            {prescription ? (
              <p className="text-[13px] font-bold leading-6 text-ink-900">{prescription.diagnosis}</p>
            ) : (
              <p className="text-[12.5px] text-ink-400">
                {appointment.status === 'completed'
                  ? 'تم الكشف دون وصفة مسجلة.'
                  : 'لم يتم تسجيل تشخيص لهذا الكشف بعد.'}
              </p>
            )}
          </div>

          {prescription && (
            <div className="rounded-2xl bg-violet-50/70 p-4">
              <h4 className="mb-2 flex items-center gap-2 text-[12.5px] font-extrabold text-ink-800">
                <Pill size={14} className="text-violet-600" />
                العلاج — وصفة {prescription.code}
              </h4>
              <ul className="space-y-1.5">
                {prescription.items.map((m) => (
                  <li key={m.id} className="flex items-center justify-between gap-3 text-[12.5px] text-ink-700">
                    <span className="font-bold">{m.name}</span>
                    <span className="text-ink-500">
                      {m.dosage} — {m.duration}
                    </span>
                  </li>
                ))}
              </ul>
              {prescription.advice && (
                <p className="mt-3 border-t border-violet-100 pt-3 text-[12px] leading-6 text-ink-600">
                  <span className="font-bold text-ink-800">الإرشادات: </span>
                  {prescription.advice}
                </p>
              )}
              {prescription.followUp && (
                <p className="mt-1.5 text-[12px] font-bold text-amber-700">المتابعة: {prescription.followUp}</p>
              )}
            </div>
          )}

          <Field label="ملاحظات الطبيب على الكشف">
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="ما الذي حدث في الكشف؟ ملاحظات، فحوصات مطلوبة، حالة المريض..."
            />
          </Field>
        </div>
      )}
    </Modal>
  )
}
