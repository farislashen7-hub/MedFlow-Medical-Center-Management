import type {
  Activity,
  Appointment,
  DBState,
  CenterSettings,
  Doctor,
  DoctorAttendance,
  DoctorLeave,
  Offer,
  Review,
  Patient,
  Prescription,
  Specialty,
  WhatsAppThread,
} from './types'
import { addDays, toDateKey } from './format'

/* ---------- deterministic pseudo random ---------- */
function mulberry32(seed: number) {
  let a = seed
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const rand = mulberry32(20260906)
const pick = <T,>(arr: T[]) => arr[Math.floor(rand() * arr.length)]
const between = (min: number, max: number) => min + Math.floor(rand() * (max - min + 1))

const NOW = new Date()

/* ---------- offers / reviews demo data ---------- */
const reviewComments = [
  'دكتور محترم جداً وشرح الحالة بالتفصيل، والمواعيد منظمة.',
  'خدمة ممتازة وتعامل راقٍ من الاستقبال حتى نهاية الكشف.',
  'الانتظار كان قصيراً والطبيب اهتم بكل أسئلتي.',
  'تجربة جيدة، أتمنى توفر مواعيد أكثر في عطلة الأسبوع.',
  'الحجز عبر الموقع سهل جداً وتأكيد واتساب وصلني فوراً.',
  'علاج فعّال وروشتة واضحة، أنصح به.',
]

export function buildExtras(
  patients: { id: string; name: string }[],
  _doctors: Doctor[],
  appointments: Appointment[],
): { offers: Offer[]; reviews: Review[] } {
  const until = toDateKey(addDays(new Date(), 21))
  const offers: Offer[] = [
    {
      id: 'off_1',
      title: 'كشف متابعة مجاني',
      details: 'احجز أول كشف واحصل على زيارة متابعة خلال 14 يوماً بدون رسوم إضافية.',
      price: 0,
      oldPrice: 250,
      validUntil: until,
      image: '',
      theme: 'brand',
      message: '',
      active: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'off_2',
      title: 'باقة الفحص الشامل',
      details: 'تحاليل أساسية + كشف باطنة + تخطيط قلب بسعر موحد.',
      price: 399,
      oldPrice: 650,
      validUntil: until,
      image: '',
      theme: 'amber',
      message: '',
      active: true,
      createdAt: new Date().toISOString(),
    },
  ]
  const done = appointments.filter((a) => a.status === 'completed').slice(0, 6)
  const reviews: Review[] = done.map((a, i) => ({
    id: `rev_${i + 1}`,
    patientId: a.patientId,
    patientName: patients.find((p) => p.id === a.patientId)?.name ?? a.patientName,
    doctorId: a.doctorId,
    appointmentId: a.id,
    rating: [5, 5, 4, 5, 4, 5][i % 6],
    comment: reviewComments[i % reviewComments.length],
    status: 'published',
    reply: i === 1 ? 'شكراً لثقتكم، نسعد بخدمتكم دائماً.' : '',
    createdAt: new Date(Date.now() - (i + 1) * 86400000 * 3).toISOString(),
  }))
  return { offers, reviews }
}

/* ---------- center settings ---------- */
export const defaultSettings: CenterSettings = {
  name: 'مركز medflow الطبي',
  tagline: 'SMART CLINIC',
  about:
    'منصة ذكية لإدارة العيادات وحجز المواعيد ومتابعة المرضى عبر واتساب، مصممة لتقديم تجربة رعاية صحية سلسة.',
  logo: '/images/logo.png',
  phone: '0500000000',
  whatsapp: '',
  email: 'support@medflow.sa',
  website: '',
  city: 'الرياض',
  address: 'طريق الملك فهد، حي العليا - الدور الثاني',
  mapUrl: '',
  workDays: 'السبت — الخميس',
  workHours: '8:00 ص — 10:00 م',
  currency: 'ر.س',
  countryCode: '966',
  licenseNo: '',
  taxNo: '',
  instagram: '',
  facebook: '',
  x: '',
  managerName: '',
  managerEmail: '',
  managerPhone: '',
}

/* ---------- specialties ---------- */
const specialties: Specialty[] = [
  {
    id: 'sp_cardio',
    name: 'طب القلب',
    nameEn: 'Cardiology',
    icon: 'HeartPulse',
    description: 'تشخيص وعلاج أمراض القلب والأوعية الدموية مع متابعة جهاز القلب.',
    color: '#E11D48',
  },
  {
    id: 'sp_peds',
    name: 'طب الأطفال',
    nameEn: 'Pediatrics',
    icon: 'Baby',
    description: 'صحة الأطفال والمراقبات الدورية ومتابعة النمو والتطعيمات.',
    color: '#0EA5E9',
  },
  {
    id: 'sp_derm',
    name: 'طب الجلدية',
    nameEn: 'Dermatology',
    icon: 'Sparkles',
    description: 'علاج حب الشباب والأكزيما والتهابات الجلد وإجراءات التجميل الطبية.',
    color: '#8B5CF6',
  },
  {
    id: 'sp_ortho',
    name: 'جراحة العظام',
    nameEn: 'Orthopedics',
    icon: 'Bone',
    description: 'إصابات العظام والمفاصل والعمود الفقري وعمليات جراحة العظام.',
    color: '#F59E0B',
  },
  {
    id: 'sp_obgyn',
    name: 'النسائية والتوليد',
    nameEn: 'Obstetrics & Gynecology',
    icon: 'HeartHandshake',
    description: 'متابعة الحمل والولادة وعلاج أمراض النساء والعقم.',
    color: '#EC4899',
  },
  {
    id: 'sp_internal',
    name: 'الطب الباطني',
    nameEn: 'Internal Medicine',
    icon: 'Stethoscope',
    description: 'تشخيص الأمراض المزمنة والغدد الصماء وجهاز الهضم والسكري.',
    color: '#10B981',
  },
  {
    id: 'sp_dental',
    name: 'طب الأسنان',
    nameEn: 'Dentistry',
    icon: 'Smile',
    description: 'العناية بالأسنان والتركيبات والتبييض وعلاج عصب Tooth.',
    color: '#06B6D4',
  },
  {
    id: 'sp_neuro',
    name: 'طب الأعصاب',
    nameEn: 'Neurology',
    icon: 'Brain',
    description: 'الصداع النصفي والاضطرابات العصبية والعمود الفقري.',
    color: '#6366F1',
  },
]

/* ---------- doctors ---------- */
const doctors: Doctor[] = [
  {
    id: 'doc_1',
    name: 'د. سارة الحربي',
    title: 'استشارية قلب',
    phone: '0501112233',
    password: '123456',
    email: 'sara@medflow.sa',
    specialtyId: 'sp_cardio',
    years: 12,
    rating: 4.9,
    reviews: 214,
    location: 'الرياض - حي الملقا',
    clinic: 'مركز النخبة الطبي - الدور الثالث',
    bio: 'استشارية أمراض القلب الباطنية، خبرة واسعة في قسطرة الشرايين وعمليات صمامات القلب. حاصلة على زمالة الكلية الملكية لأمراض القلب.',
    image: '/images/doc-1.jpg',
    fee: 350,
    days: [0, 1, 2, 4, 6],
    startHour: 9,
    endHour: 17,
    active: true,
  },
  {
    id: 'doc_2',
    name: 'د. خالد المطيري',
    title: 'أخصائي قلب',
    phone: '0504445566',
    password: '123456',
    email: 'khaled@medflow.sa',
    specialtyId: 'sp_cardio',
    years: 9,
    rating: 4.7,
    reviews: 132,
    location: 'جدة - حي الروضة',
    clinic: 'مستشفى الحياة التخصصي',
    bio: 'أخصائي أمراض القلب والضغط، يركز على تشخيص ارتفاع ضغط الدم ومتابعة المرضى بعد عمليات القسطرة.',
    image: '/images/doc-2.jpg',
    fee: 250,
    days: [1, 3, 5],
    startHour: 16,
    endHour: 22,
    active: true,
  },
  {
    id: 'doc_3',
    name: 'د. منى العتيبي',
    title: 'استشارية طب أطفال',
    phone: '0507778899',
    password: '123456',
    email: 'mona@medflow.sa',
    specialtyId: 'sp_peds',
    years: 15,
    rating: 4.9,
    reviews: 331,
    location: 'الرياض - حي النرجس',
    clinic: 'مركز الأمومة والطفولة الطبي',
    bio: 'استشارية طب الأطفال حديثي الولادة، خبرة في متابعة النمو والتطعيمات وعلاج حساسية صدر الأطفال.',
    image: '/images/doc-3.jpg',
    fee: 300,
    days: [0, 2, 3, 5],
    startHour: 10,
    endHour: 18,
    active: true,
  },
  {
    id: 'doc_4',
    name: 'د. يوسف الزهراني',
    title: 'أخصائي أطفال',
    phone: '0512223344',
    password: '123456',
    email: 'yousef@medflow.sa',
    specialtyId: 'sp_peds',
    years: 7,
    rating: 4.6,
    reviews: 98,
    location: 'الدمام - حي الفيصلية',
    clinic: 'عيادات الشفاء للأطفال',
    bio: 'أخصائي طب الأطفال والصدر، متخصص في علاج الربو والحساسية ومتابعة حديثي الولادة.',
    image: '/images/doc-4.jpg',
    fee: 200,
    days: [1, 2, 4, 6],
    startHour: 17,
    endHour: 22,
    active: true,
  },
  {
    id: 'doc_5',
    name: 'د. ليلى القحطاني',
    title: 'استشارية جلدية',
    phone: '0523334455',
    password: '123456',
    email: 'layla@medflow.sa',
    specialtyId: 'sp_derm',
    years: 10,
    rating: 4.8,
    reviews: 176,
    location: 'جدة - حي السلامة',
    clinic: 'مركز البشرة والجمال الطبي',
    bio: 'استشارية الأمراض الجلدية والتجميل، متخصصة في علاج حب الشباب والبهاق والتهابات الجلد.',
    image: '/images/doc-5.jpg',
    fee: 320,
    days: [0, 1, 3, 4],
    startHour: 12,
    endHour: 20,
    active: true,
  },
  {
    id: 'doc_6',
    name: 'د. أحمد بن سالم',
    title: 'استشاري جراحة عظام',
    phone: '0534445566',
    password: '123456',
    email: 'ahmed@medflow.sa',
    specialtyId: 'sp_ortho',
    years: 18,
    rating: 4.9,
    reviews: 289,
    location: 'الرياض - حي العليا',
    clinic: 'مركز العظام والعمود الفقري',
    bio: 'استشاري جراحة العظام والمفاصل، خبرة عميقة في عمليات استبدال المفاصل وعلاج إصابات الملاعب.',
    image: '/images/doc-6.jpg',
    fee: 400,
    days: [0, 1, 2, 3, 5],
    startHour: 8,
    endHour: 16,
    active: true,
  },
  {
    id: 'doc_7',
    name: 'د. هدى الشمري',
    title: 'استشارية نساء وتوليد',
    phone: '0545556677',
    password: '123456',
    email: 'huda@medflow.sa',
    specialtyId: 'sp_obgyn',
    years: 13,
    rating: 4.7,
    reviews: 203,
    location: 'الرياض - حي حطين',
    clinic: 'مركز الأمان للولادة',
    bio: 'استشارية أمراض النساء والتوليد، متخصصة في متابعة الحمل عالي الخطورة وعلاج تكيس المبايض.',
    image: '/images/doc-7.jpg',
    fee: 350,
    days: [1, 2, 4, 6],
    startHour: 14,
    endHour: 21,
    active: true,
  },
  {
    id: 'doc_8',
    name: 'د. عمر باوزير',
    title: 'استشاري طب باطني',
    phone: '0556667788',
    password: '123456',
    email: 'omar@medflow.sa',
    specialtyId: 'sp_internal',
    years: 11,
    rating: 4.6,
    reviews: 141,
    location: 'الخبر - حي العقربية',
    clinic: 'مركز الغدد والسكر التخصصي',
    bio: 'استشاري الطب الباطني والغدد الصماء، متخصص في متابعة السكري من النوع الثاني والغدة الدرقية.',
    image: '/images/doc-8.jpg',
    fee: 280,
    days: [0, 3, 4, 6],
    startHour: 9,
    endHour: 15,
    active: true,
  },
  {
    id: 'doc_9',
    name: 'د. ريم الشمري',
    title: 'أخصائية أسنان',
    phone: '0567778899',
    password: '123456',
    email: 'reem@medflow.sa',
    specialtyId: 'sp_dental',
    years: 6,
    rating: 4.8,
    reviews: 118,
    location: 'الرياض - حي الياسمين',
    clinic: 'عيادة ابتسامة دنتال',
    bio: 'أخصائية علاج أسنان تجميلي وتبييض وتركيبات، تقدم خدمة مريحة وخالية من الألم للأسرة.',
    image: '/images/doc-8.jpg',
    fee: 180,
    days: [0, 1, 2, 4, 5],
    startHour: 13,
    endHour: 21,
    active: true,
  },
]

/* ---------- patients ---------- */
const patients: Patient[] = [
  {
    id: 'pat_1',
    name: 'محمد عبدالله الفهد',
    phone: '0551234567',
    password: '123456',
    email: 'm.alfaheed@example.com',
    nationalId: '1045887213',
    birthDate: '1985-04-12',
    gender: 'male',
    bloodType: 'O+',
    allergies: 'حساسية من البنسلين',
    chronic: 'ارتفاع ضغط الدم، ارتفاع الكوليسترول',
    insurance: 'بوبا العربية للتأمين',
    address: 'الرياض - حي الياسمين - شارع أنس بن مالك',
    emergency: { name: 'عبدالرحمن الفهد', relation: 'الأب', phone: '0559876543' },
    createdAt: '2025-11-02T09:20:00.000Z',
  },
  {
    id: 'pat_2',
    name: 'فاطمة أحمد الزهراني',
    phone: '0509876543',
    password: '123456',
    email: 'f.alzahrani@example.com',
    nationalId: '1022334455',
    birthDate: '1994-09-30',
    gender: 'female',
    bloodType: 'A+',
    allergies: 'لا يوجد',
    chronic: 'لا يوجد',
    insurance: 'التعاونية',
    address: 'جدة - حي الروضة - شارع الأمير سلطان',
    emergency: { name: 'أحمد الزهراني', relation: 'الزوج', phone: '0501122334' },
    createdAt: '2025-12-14T13:05:00.000Z',
  },
  {
    id: 'pat_3',
    name: 'عبدالله سالم القحطاني',
    phone: '0533445566',
    password: '123456',
    email: 'a.alqahtani@example.com',
    nationalId: '1099887766',
    birthDate: '2018-02-22',
    gender: 'male',
    bloodType: 'B-',
    allergies: 'حساسية من المكسرات',
    chronic: 'ربو خفيف',
    insurance: 'ميدغلف',
    address: 'الدمام - حي الشاطئ',
    emergency: { name: 'سالم القحطاني', relation: 'الأب', phone: '0539998877' },
    createdAt: '2026-01-08T10:40:00.000Z',
  },
  {
    id: 'pat_4',
    name: 'نورة سعد الدوسري',
    phone: '0566778899',
    password: '123456',
    email: 'n.dosari@example.com',
    nationalId: '1077665544',
    birthDate: '1991-06-05',
    gender: 'female',
    bloodType: 'AB+',
    allergies: 'لا يوجد',
    chronic: 'فقر دم',
    insurance: 'لا يوجد',
    address: 'الرياض - حي القيروان',
    emergency: { name: 'سعد الدوسري', relation: 'الأب', phone: '0562223344' },
    createdAt: '2026-02-19T08:15:00.000Z',
  },
  {
    id: 'pat_5',
    name: 'طارق فهد المطيري',
    phone: '0541122334',
    password: '123456',
    email: 't.almutairi@example.com',
    nationalId: '1055443322',
    birthDate: '1978-11-18',
    gender: 'male',
    bloodType: 'O-',
    allergies: 'لا يوجد',
    chronic: 'السكري من النوع الثاني',
    insurance: 'بوبا العربية للتأمين',
    address: 'الخبر - حي العقربية',
    emergency: { name: 'هند المطيري', relation: 'الزوجة', phone: '0549988776' },
    createdAt: '2026-03-03T11:30:00.000Z',
  },
  {
    id: 'pat_6',
    name: 'ريم عمر الخالدي',
    phone: '0599887766',
    password: '123456',
    email: 'r.alkhalidi@example.com',
    nationalId: '1066554433',
    birthDate: '1999-08-25',
    gender: 'female',
    bloodType: 'A-',
    allergies: 'لا يوجد',
    chronic: 'لا يوجد',
    insurance: 'التعاونية',
    address: 'جدة - حي الحمراء',
    emergency: { name: 'عمر الخالدي', relation: 'الأب', phone: '0591112233' },
    createdAt: '2026-04-21T16:45:00.000Z',
  },
]

/* ---------- appointments across 6 months ---------- */
const reasons = [
  'ألم في الصدر مع ضيق تنفس متقطع',
  'متابعة دورية لقياس ضغط الدم',
  'طفح جلدي مزمن في الذراعين',
  'ألم في الركبة اليمنى عند الصعود',
  'متابعة الحمل - فحص روتيني',
  'ارتفاع Sugar في الدم مع تعب عام',
  'تسوس في الأسنان الأامية',
  'صداع نصفي متكرر مع حساسية للضوء',
  'متابعة نتائج التحاليل السابقة',
  'فحص دوري وتحديث التقرير الطبي',
]

const slots = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00']

const appointments: Appointment[] = []
const prescriptions: Prescription[] = []

let apptCounter = 1000
let rxCounter = 500

const takenSlots = new Set<string>()

for (let monthOffset = 5; monthOffset >= 0; monthOffset--) {
  const monthDate = new Date(NOW.getFullYear(), NOW.getMonth() - monthOffset, 1)
  const daysInMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0).getDate()
  const maxDay = monthOffset === 0 ? Math.min(NOW.getDate(), daysInMonth) : daysInMonth
  const count = between(24, 38)

  for (let i = 0; i < count; i++) {
    const doctor = pick(doctors)
    const patient = pick(patients)

    const candidates: number[] = []
    for (let d = 1; d <= maxDay; d++) {
      const dt = new Date(monthDate.getFullYear(), monthDate.getMonth(), d)
      if (doctor.days.includes(dt.getDay())) candidates.push(d)
    }
    if (candidates.length === 0) continue
    const day = pick(candidates)
    const date = new Date(monthDate.getFullYear(), monthDate.getMonth(), day)
    const dateKey = toDateKey(date)

    const doctorSlots = slots.filter((s) => {
      const h = Number(s.slice(0, 2))
      return h >= doctor.startHour && h < doctor.endHour
    })
    let time = ''
    for (let attempt = 0; attempt < 14; attempt++) {
      const candidate = pick(doctorSlots)
      const key = `${doctor.id}|${dateKey}|${candidate}`
      if (!takenSlots.has(key)) {
        time = candidate
        takenSlots.add(key)
        break
      }
    }
    if (!time) continue
    const isPast = date.getTime() < NOW.getTime()
    let status: Appointment['status']
    if (isPast) {
      const r = rand()
      status = r < 0.72 ? 'completed' : r < 0.85 ? 'cancelled' : r < 0.95 ? 'no-show' : 'completed'
    } else {
      status = rand() < 0.75 ? 'scheduled' : 'confirmed'
    }
    const type: Appointment['type'] = rand() < 0.6 ? 'new' : rand() < 0.8 ? 'followup' : 'urgent'
    const id = `apt_${apptCounter++}`
    const createdAt = new Date(date.getTime() - between(1, 12) * 86400000).toISOString()
    appointments.push({
      id,
      patientId: patient.id,
      patientName: patient.name,
      patientPhone: patient.phone,
      doctorId: doctor.id,
      specialtyId: doctor.specialtyId,
      date: dateKey,
      time,
      duration: 30,
      status,
      type,
      reason: pick(reasons),
      notes: '',
      fee: doctor.fee,
      paid: status === 'completed' ? rand() < 0.85 : false,
      createdAt,
    })

    if (status === 'completed' && rand() < 0.72) {
      prescriptions.push({
        id: `rx_${rxCounter++}`,
        code: `RX-${90000 + appointments.length}`,
        appointmentId: id,
        patientId: patient.id,
        doctorId: doctor.id,
        diagnosis: pick([
          'ارتفاع ضغط الدم الأساسي',
          'التهاب الجهاز التنفسي العلوي',
          'الأكزيما التأcontactية',
          'التهاب وتر الركبة',
          'الحمل الطبيعي',
          'ارتفاع سكر الدم - النوع الثاني',
          'تسوس سطحي',
          'الصداع النصفي',
          'فقر الدم بعوز الحديد',
        ]),
        items: [
          {
            id: `med_${rxCounter}_1`,
            name: pick(['أوميغا 3', 'لوسارتان 50 ملغ', 'بانادول 500 ملغ', 'فنتولين بخاخ', 'سالبوتامول بخاخ', 'أوميبرازول 20 ملغ', 'ميتفورمين 850 ملغ']),
            dosage: pick(['قرص مرة يومياً', 'قرصان يومياً', 'جرعة واحدة مساءً', 'بخاخ عند اللزوم']),
            duration: pick(['5 أيام', '7 أيام', '14 يوم', 'شهر', '3 أشهر']),
            notes: '',
          },
          {
            id: `med_${rxCounter}_2`,
            name: pick(['فيتامين د 50000', 'أوميغا 3', 'مكمل الكالسيوم', 'فيتامين ب 12']),
            dosage: 'قرص يومياً بعد الفطور',
            duration: 'شهر',
            notes: '',
          },
        ],
        advice: 'شرب كمية كافية من الماء والمحافظة على النشاط البدني المعتدل وتجنب بذل المجهود البدني العنيف.',
        followUp: pick(['بعد أسبوعين', 'بعد شهر', 'عند ظهور الأعراض مجدداً']),
        issuedAt: new Date(date.getTime() + 60 * 60000).toISOString(),
      })
    }
  }
}

/* future appointments for patients (scheduled / upcoming) */
const upcomingSeed: Array<[string, string, string, string, Appointment['type']]> = [
  ['pat_1', 'doc_1', 'sp_cardio', 'متابعة ضغط الدم بعد تعديل الجرعة', 'followup'],
  ['pat_1', 'doc_6', 'sp_ortho', 'ألم في الركبة اليمنى', 'new'],
  ['pat_2', 'doc_5', 'sp_derm', 'متابعة علاج حب الشباب', 'followup'],
  ['pat_3', 'doc_3', 'sp_peds', 'متابعة النمو والتطعيمات', 'followup'],
  ['pat_4', 'doc_7', 'sp_obgyn', 'متابعة سنوية', 'new'],
  ['pat_5', 'doc_8', 'sp_internal', 'متابعة السكر - تحليل A1C', 'followup'],
  ['pat_6', 'doc_9', 'sp_dental', 'تنظيف وتلميع الأسنان', 'new'],
]

for (const [patientId, doctorId, specialtyId, reason, type] of upcomingSeed) {
  const doctor = doctors.find((d) => d.id === doctorId)!
  const patient = patients.find((p) => p.id === patientId)!
  const date = addDays(NOW, between(1, 12))
  if (!doctor.days.includes(date.getDay())) {
    do {
      date.setDate(date.getDate() + 1)
    } while (!doctor.days.includes(date.getDay()))
  }
  appointments.push({
    id: `apt_${apptCounter++}`,
    patientId,
    patientName: patient.name,
    patientPhone: patient.phone,
    doctorId,
    specialtyId,
    date: toDateKey(date),
    time: pick(slots.filter((s) => Number(s.slice(0, 2)) >= doctor.startHour && Number(s.slice(0, 2)) <= doctor.endHour)),
    duration: 30,
    status: 'scheduled',
    type,
    reason,
    notes: '',
    fee: doctor.fee,
    paid: false,
    createdAt: new Date().toISOString(),
  })
}

/* ---------- activity log ---------- */
const activities: Activity[] = []
const activityTemplates: Array<[Activity['category'], string, string]> = [
  ['booking', 'حجز موعد جديد', 'تم تأكيد الحجز باسم'],
  ['login', 'تسجيل دخول', 'دخل إلى لوحة'],
  ['medical', 'إصدار وصفة طبية', 'وصفة رقم'],
  ['patient', 'تحديث بيانات الملف', 'تم تحديث بيانات'],
  ['admin', 'تحديث إعدادات', 'تم تحديث إعدادات النظام'],
]

for (let i = 0; i < 46; i++) {
  const [category, action, detail] = pick(activityTemplates)
  const actorType = pick(['admin', 'doctor', 'patient'] as const)
  const actorName =
    actorType === 'admin'
      ? 'م. ريم السالم'
      : actorType === 'doctor'
        ? pick(doctors).name
        : pick(patients).name
  const at = new Date(NOW.getTime() - between(0, 72) * 3600000 - between(0, 59) * 60000).toISOString()
  activities.push({
    id: `act_${i}`,
    actor: actorName,
    actorRole: actorType,
    action,
    detail: `${detail} ${pick(patients).name}`,
    category,
    at,
  })
}
activities.sort((a, b) => +new Date(b.at) - +new Date(a.at))

/* ---------- whatsapp threads ---------- */
// مفيش محادثات تجريبية: المحادثات الحقيقية بتتسجل من عروض واتساب والمحادثات الفعلية.
const threads: WhatsAppThread[] = []

/**
 * تاريخ حضور/غياب/ظروف تجريبي لآخر 75 يوم (PRNG مستقل عشان مايغيرش باقي الداتا).
 * كل طبيب له «طبع» مختلف (التزام عالي/متوسط/ضعيف) عشان التحليل يبان فيه فرق حقيقي.
 */
const OFF_REASONS_SEED = ['ظرف طارئ', 'إجازة', 'ظرف صحي', 'مهمة خارج العيادة']

export function buildAttendanceSeed(docs: Doctor[]): { attendance: DoctorAttendance[]; leaves: DoctorLeave[] } {
  const r = mulberry32(777001)
  const attendance: DoctorAttendance[] = []
  const leaves: DoctorLeave[] = []
  const hhmm = (min: number) => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`
  const DAYS = 75

  docs.forEach((d, idx) => {
    // طبع الطبيب: احتمال الغياب / التأخير
    const pAbsent = [0.02, 0.04, 0.09, 0.03, 0.14, 0.05, 0.02, 0.07, 0.04][idx % 9]
    const pLate = [0.04, 0.1, 0.12, 0.05, 0.2, 0.08, 0.03, 0.15, 0.06][idx % 9]

    // فترات ظرف (1–3 أيام) موزعة على الفترة
    const leaveDays = new Set<string>()
    const episodes = Math.floor(r() * 4) // 0..3
    for (let e = 0; e < episodes; e++) {
      const startOffset = 5 + Math.floor(r() * (DAYS - 12))
      const len = 1 + Math.floor(r() * 3)
      const since = toDateKey(addDays(NOW, -startOffset))
      const until = toDateKey(addDays(NOW, -(startOffset - len + 1)))
      const reason = OFF_REASONS_SEED[Math.floor(r() * OFF_REASONS_SEED.length)]
      leaves.push({
        id: `lv_${d.id}_${e}`,
        doctorId: d.id,
        reason,
        note: '',
        since,
        until,
        createdAt: new Date(`${since}T07:30:00`).toISOString(),
        endedAt: new Date(`${until}T23:00:00`).toISOString(),
      })
      for (let k = 0; k < len; k++) leaveDays.add(toDateKey(addDays(NOW, -(startOffset - k))))
    }

    for (let back = DAYS; back >= 1; back--) {
      const day = addDays(NOW, -back)
      const key = toDateKey(day)
      if (!d.days.includes(day.getDay()) || leaveDays.has(key)) continue
      const roll = r()
      const base = {
        id: `${d.id}_${key}`,
        doctorId: d.id,
        date: key,
        checkOut: hhmm(d.endHour * 60 + Math.floor(r() * 25) - 5),
        note: '',
      }
      if (roll < pAbsent) {
        attendance.push({ ...base, status: 'absent', checkIn: '', checkOut: '', note: 'لم يحضر دون إخطار' })
      } else if (roll < pAbsent + pLate) {
        attendance.push({ ...base, status: 'late', checkIn: hhmm(d.startHour * 60 + 20 + Math.floor(r() * 35)) })
      } else {
        attendance.push({ ...base, status: 'present', checkIn: hhmm(d.startHour * 60 - 10 + Math.floor(r() * 22)) })
      }
    }
  })
  return { attendance, leaves }
}

function newDateSafe(hoursAgo: number) {
  return new Date(NOW.getTime() - hoursAgo * 3600000).toISOString()
}

export function buildSeed(): DBState {
  return {
    settings: { ...defaultSettings },
    ...buildExtras(patients, doctors, appointments),
    specialties,
    doctors,
    patients,
    appointments: appointments.sort((a, b) => (a.date + a.time < b.date + b.time ? 1 : -1)),
    prescriptions,
    activities,
    threads,
    media: {},
    ...buildAttendanceSeed(doctors),
    admins: [
      {
        id: 'adm_1',
        name: 'م. ريم السالم',
        email: 'admin@medflow.sa',
        password: 'admin123',
        phone: '0500000000',
        role: 'admin',
      },
    ],
  }
}
