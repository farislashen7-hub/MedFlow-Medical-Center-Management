import type { Doctor, Appointment } from './types'
import { fromDateKey, toDateKey } from './format'

export interface Slot {
  time: string
  available: boolean
  label: string
}

function fmt(h: number, m: number) {
  const period = h >= 12 ? 'م' : 'ص'
  const hour12 = h % 12 === 0 ? 12 : h % 12
  return `${hour12}:${m < 10 ? '0' + m : m} ${period}`
}

/** الطبيب غير متاح في اليوم ده؟ (إعلان عدم تواجد ساري) */
export function isDoctorOffOn(doctor: Doctor, dateKey: string): boolean {
  const u = doctor.unavailable
  if (!u) return false
  if (dateKey < u.since) return false
  return !u.until || dateKey <= u.until
}

/** الطبيب معلن عدم تواجده دلوقتي؟ (النهارده ضمن الفترة) */
export function isDoctorOffNow(doctor: Doctor, now = new Date()): boolean {
  return isDoctorOffOn(doctor, toDateKey(now))
}

export function generateSlots(
  doctor: Doctor,
  dateKey: string,
  appointments: Appointment[],
  now = new Date(),
): Slot[] {
  const date = fromDateKey(dateKey)
  const isToday = toDateKey(now) === dateKey
  const slots: Slot[] = []
  const off = isDoctorOffOn(doctor, dateKey)

  for (let h = doctor.startHour; h < doctor.endHour; h++) {
    for (const m of [0, 30]) {
      if (h === doctor.endHour - 1 && m === 30) continue
      const time = `${h < 10 ? '0' + h : h}:${m < 10 ? '0' + m : m}`
      const slotDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), h, m)
      const past = slotDate.getTime() < now.getTime()
      const taken = appointments.some(
        (a) =>
          a.doctorId === doctor.id &&
          a.date === dateKey &&
          a.time === time &&
          a.status !== 'cancelled',
      )
      slots.push({
        time,
        available: !taken && !past && !off,
        label: fmt(h, m),
      })
    }
  }
  return slots
}

export function workingDaysInRange(doctor: Doctor, days = 14, now = new Date()) {
  const result: { key: string; weekday: string; day: number; month: string; count: number }[] = []
  for (let i = 1; i <= days; i++) {
    const d = new Date(now)
    d.setDate(d.getDate() + i)
    const key = toDateKey(d)
    result.push({
      key,
      weekday: ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'][d.getDay()],
      day: d.getDate(),
      month: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'][d.getMonth()],
      count: doctor.days.includes(d.getDay()) && !isDoctorOffOn(doctor, key) ? 1 : 0,
    })
  }
  return result
}
