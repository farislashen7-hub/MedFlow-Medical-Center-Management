/**
 * الشكاوى (public.complaints): بتوصل من واتساب عن طريق n8n -> /api/complaints، وبتظهر هنا لحظياً (Supabase Realtime).
 * القراءة بجلسة Supabase بس (الإدارة تشوف الكل، الدكتور اللي عليه) — RLS في migration_12.
 */
import { useEffect, useSyncExternalStore } from 'react'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from './supabase'

export type ComplaintStatus = 'new' | 'in_review' | 'resolved' | 'rejected'
export type ComplaintCategory = 'doctor' | 'staff' | 'waiting' | 'billing' | 'facility' | 'booking' | 'other'
export type ComplaintPriority = 'low' | 'normal' | 'high'

export interface Complaint {
  id: string
  patientName: string
  patientPhone: string
  doctorId: string | null
  appointmentId: string | null
  category: ComplaintCategory
  subject: string
  message: string
  priority: ComplaintPriority
  status: ComplaintStatus
  adminResponse: string
  source: 'whatsapp' | 'web' | 'manual'
  createdAt: string
  resolvedAt: string | null
}

interface Row {
  id: string
  patient_name: string
  patient_phone: string
  doctor_id: string | null
  appointment_id: string | null
  category: ComplaintCategory
  subject: string
  message: string
  priority: ComplaintPriority
  status: ComplaintStatus
  admin_response: string | null
  source: Complaint['source'] | null
  created_at: string
  resolved_at: string | null
}

const fromRow = (r: Row): Complaint => ({
  id: r.id,
  patientName: r.patient_name,
  patientPhone: r.patient_phone,
  doctorId: r.doctor_id,
  appointmentId: r.appointment_id,
  category: r.category,
  subject: r.subject,
  message: r.message,
  priority: r.priority,
  status: r.status,
  adminResponse: r.admin_response ?? '',
  source: r.source ?? 'whatsapp',
  createdAt: r.created_at,
  resolvedAt: r.resolved_at,
})

interface Snapshot {
  items: Complaint[]
  /** في جلسة Supabase (من غيرها RLS بتخفي الشكاوى) */
  signedIn: boolean
  loaded: boolean
  error: string | null
}

let snap: Snapshot = { items: [], signedIn: false, loaded: false, error: null }
const listeners = new Set<() => void>()
const newListeners = new Set<(c: Complaint) => void>()
const emit = () => listeners.forEach((l) => l())
const set = (patch: Partial<Snapshot>) => {
  snap = { ...snap, ...patch }
  emit()
}
const sortDesc = (a: Complaint, b: Complaint) => +new Date(b.createdAt) - +new Date(a.createdAt)

function upsert(c: Complaint) {
  const rest = snap.items.filter((x) => x.id !== c.id)
  set({ items: [c, ...rest].sort(sortDesc) })
}

export function useComplaints(): Snapshot {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb)
      return () => listeners.delete(cb)
    },
    () => snap,
    () => snap,
  )
}

/** تنبيه لحظي لما شكوى جديدة توصل (بعد التحميل الأولي بس) */
export function onNewComplaint(cb: (c: Complaint) => void) {
  newListeners.add(cb)
  return () => {
    newListeners.delete(cb)
  }
}

export async function refreshComplaints() {
  if (!supabase) return
  const { data, error } = await supabase.from('complaints').select('*').order('created_at', { ascending: false }).limit(500)
  if (error) return set({ error: error.message, loaded: true })
  set({ items: ((data as Row[]) ?? []).map(fromRow), loaded: true, error: null })
}

export async function updateComplaint(
  id: string,
  patch: Partial<Pick<Complaint, 'status' | 'priority' | 'adminResponse'>>,
): Promise<{ ok: boolean; error?: string }> {
  if (!supabase) return { ok: false, error: 'Supabase غير متفعّل' }
  const row: Record<string, unknown> = {}
  if (patch.status) row.status = patch.status
  if (patch.priority) row.priority = patch.priority
  if (patch.adminResponse !== undefined) row.admin_response = patch.adminResponse.trim() || null
  const { data, error } = await supabase.from('complaints').update(row).eq('id', id).select('*').maybeSingle()
  if (error) return { ok: false, error: error.message }
  if (!data) return { ok: false, error: 'مفيش صلاحية تعديل (سجّل دخول بحساب إدارة Supabase)' }
  upsert(fromRow(data as Row))
  return { ok: true }
}

/** في AuthProvider: جلسة Supabase => نجيب الشكاوى ونشترك Realtime (INSERT/UPDATE/DELETE) */
export function useRemoteComplaints() {
  useEffect(() => {
    const sb = supabase
    if (!sb) return
    let channel: RealtimeChannel | null = null
    let uid: string | null = null

    const stop = () => {
      if (channel) sb.removeChannel(channel)
      channel = null
      uid = null
    }

    const start = async (userId: string) => {
      if (uid === userId && channel) return
      stop()
      uid = userId
      set({ signedIn: true })
      await refreshComplaints()
      channel = sb
        .channel('complaints-realtime')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'complaints' }, (payload) => {
          if (payload.eventType === 'DELETE') {
            const id = (payload.old as { id?: string }).id
            if (id) set({ items: snap.items.filter((x) => x.id !== id) })
            return
          }
          const c = fromRow(payload.new as Row)
          const isNew = payload.eventType === 'INSERT' && !snap.items.some((x) => x.id === c.id)
          upsert(c)
          if (isNew) newListeners.forEach((l) => l(c))
        })
        .subscribe()
    }

    const { data: sub } = sb.auth.onAuthStateChange((event, session) => {
      if (session && (event === 'INITIAL_SESSION' || event === 'SIGNED_IN')) {
        setTimeout(() => void start(session.user.id), 0)
      } else if (event === 'SIGNED_OUT') {
        stop()
        set({ items: [], signedIn: false, loaded: false, error: null })
      }
    })
    return () => {
      sub.subscription.unsubscribe()
      stop()
    }
  }, [])
}
