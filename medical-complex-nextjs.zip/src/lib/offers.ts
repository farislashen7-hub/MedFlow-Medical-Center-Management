import type { CenterSettings, Offer } from './types'
import { formatFullDate, money, toDateKey } from './format'

export type OfferStatus = 'active' | 'paused' | 'expired'

export function offerStatus(o: Pick<Offer, 'active' | 'validUntil'>): OfferStatus {
  if (!o.active) return 'paused'
  if (o.validUntil && o.validUntil < toDateKey(new Date())) return 'expired'
  return 'active'
}

export const offerStatusMeta: Record<OfferStatus, { label: string; tone: 'green' | 'amber' | 'slate' }> = {
  active: { label: 'شغال', tone: 'green' },
  paused: { label: 'متوقف', tone: 'amber' },
  expired: { label: 'منتهي', tone: 'slate' },
}

type OfferDraft = Pick<Offer, 'title' | 'details' | 'price' | 'oldPrice' | 'validUntil'>

/** رسالة واتساب تلقائية من بيانات العرض — تدعم *غامق* و ~مشطوب~ */
export function offerMessage(o: OfferDraft, center: Pick<CenterSettings, 'name'>) {
  const lines = [`🔥 *${o.title || 'عرض جديد'}* 🔥`]
  if (o.details) lines.push('', o.details)
  const price = o.price > 0 ? money(o.price) : 'مجاناً'
  lines.push('', `💰 السعر: *${price}*${o.oldPrice ? ` ~${money(o.oldPrice)}~` : ''}`)
  if (o.validUntil) lines.push(`⏳ ساري حتى ${formatFullDate(o.validUntil)}`)
  const origin = typeof window !== 'undefined' ? window.location.origin : ''
  lines.push('', `📅 احجز الآن: ${origin}/book`, '', `— ${center.name}`)
  return lines.join('\n')
}

/** يحوّل تنسيق واتساب إلى عناصر للمعاينة */
export function renderWhatsAppText(text: string) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/\*(.+?)\*/g, '<strong>$1</strong>')
    .replace(/~(.+?)~/g, '<s>$1</s>')
}
