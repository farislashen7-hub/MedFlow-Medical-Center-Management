/**
 * أرقام الجوال: مصر + دول الخليج (السعودية، الإمارات، الكويت، قطر، البحرين، عُمان).
 * نفس المنطق مستخدم داخل n8n (Code node: Validate Phone) — لو غيّرت هنا غيّر هناك.
 */
export type PhoneResult =
  | { ok: true; iso: string; e164: string; wa: string }
  | { ok: false; error: 'EMPTY' | 'INVALID_CHARS' | 'COUNTRY_NOT_SUPPORTED' | 'BAD_LENGTH_OR_PREFIX'; country?: string }

interface Rule {
  cc: string
  iso: string
  re: RegExp
  trunk?: boolean
}

/** الطول/البادئة للرقم الوطني (بدون كود الدولة وبدون صفر البداية) */
export const PHONE_RULES: Rule[] = [
  { cc: '20', iso: 'EG', re: /^1[0125]\d{8}$/, trunk: true },
  { cc: '966', iso: 'SA', re: /^5\d{8}$/, trunk: true },
  { cc: '971', iso: 'AE', re: /^5[024568]\d{7}$/, trunk: true },
  { cc: '965', iso: 'KW', re: /^[569]\d{7}$/ },
  { cc: '974', iso: 'QA', re: /^[3567]\d{7}$/ },
  { cc: '973', iso: 'BH', re: /^[36]\d{7}$/ },
  { cc: '968', iso: 'OM', re: /^[79]\d{7}$/ },
]

/** الرقم المحلي 05xxxxxxxx (من غير كود دولة) يتحسب على الدولة الخليجية دي */
let defaultGulfCc = '966'
export function setPhoneDefaultCc(cc: string) {
  const clean = cc.replace(/\D/g, '')
  defaultGulfCc = PHONE_RULES.some((r) => r.cc === clean && r.iso !== 'EG') ? clean : '966'
}

const toLatin = (s: string) =>
  s
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))

const build = (r: Rule, n: string): PhoneResult => ({ ok: true, iso: r.iso, e164: `+${r.cc}${n}`, wa: `${r.cc}${n}` })

export function parsePhone(raw: unknown): PhoneResult {
  const s = toLatin(String(raw ?? '')).trim().replace(/[\s\-().]/g, '')
  if (!s) return { ok: false, error: 'EMPTY' }
  if (!/^\+?\d+$/.test(s.replace(/^00/, '+'))) return { ok: false, error: 'INVALID_CHARS' }
  const intl = s.startsWith('+') || s.startsWith('00')
  const d = s.replace(/^(\+|00)/, '')

  if (intl) {
    const r = PHONE_RULES.find((x) => d.startsWith(x.cc))
    if (!r) return { ok: false, error: 'COUNTRY_NOT_SUPPORTED' }
    let n = d.slice(r.cc.length)
    if (r.trunk && n.startsWith('0')) n = n.slice(1)
    return r.re.test(n) ? build(r, n) : { ok: false, error: 'BAD_LENGTH_OR_PREFIX', country: r.iso }
  }
  if (d.startsWith('0')) {
    const n = d.slice(1)
    if (PHONE_RULES[0].re.test(n)) return build(PHONE_RULES[0], n)
    const g = PHONE_RULES.find((x) => x.cc === defaultGulfCc)!
    if (g.re.test(n)) return build(g, n)
    return { ok: false, error: 'BAD_LENGTH_OR_PREFIX' }
  }
  for (const r of PHONE_RULES) {
    if (d.startsWith(r.cc) && r.re.test(d.slice(r.cc.length))) return build(r, d.slice(r.cc.length))
  }
  if (PHONE_RULES[0].re.test(d)) return build(PHONE_RULES[0], d)
  return { ok: false, error: 'BAD_LENGTH_OR_PREFIX' }
}

/** صيغة موحدة للمقارنة (E.164 لو صالح، وإلا الرقم منظّف) */
export function phoneKey(raw: string) {
  const r = parsePhone(raw)
  return r.ok ? r.e164 : raw.replace(/[\s-]/g, '')
}

export const samePhone = (a: string, b: string) => phoneKey(a) === phoneKey(b)

export const PHONE_HINT = 'رقم غير صحيح — رقم مصري (01xxxxxxxxx) أو خليجي بكود الدولة (+966 / +971 / +965 / +974 / +973 / +968) بالطول الصحيح'
