import type { CenterSettings } from './types'
import { formatFullDate, formatStamp, formatTime, money } from './format'
import { centerFooter, centerHeader, esc, printDocument, statusLabel, typeLabel } from './print'
import { periodLabel } from './reports'
import type { Bar, Report } from './reports'

export type SectionKey = 'summary' | 'activity' | 'finance' | 'doctors' | 'patients' | 'clinical' | 'feedback' | 'comms' | 'list'

export const SECTIONS: { id: SectionKey; label: string }[] = [
  { id: 'summary', label: 'الملخص التنفيذي والملاحظات' },
  { id: 'activity', label: 'حركة المواعيد' },
  { id: 'finance', label: 'التقرير المالي' },
  { id: 'doctors', label: 'أداء الأطباء والتخصصات' },
  { id: 'patients', label: 'المرضى' },
  { id: 'clinical', label: 'الوصفات والتشخيصات' },
  { id: 'feedback', label: 'تقييمات المرضى' },
  { id: 'comms', label: 'واتساب والعروض' },
  { id: 'list', label: 'ملحق: كشف المواعيد التفصيلي' },
]

export const ALL_SECTIONS: SectionKey[] = SECTIONS.map((s) => s.id)

const REPORT_CSS = `
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
.kpis.c3{grid-template-columns:repeat(3,1fr)}
.kpi{border:1px solid var(--i1);border-radius:12px;padding:9px 12px;background:#fff}
.kpi .v{font-family:'Tajawal',sans-serif;font-weight:800;font-size:18px;color:var(--b9);line-height:1.3}
.kpi .l{font-size:10px;color:var(--i5)}
.kpi.hi{background:var(--b);border-color:var(--b)}.kpi.hi .v,.kpi.hi .l{color:#fff}
.kpi.warn .v{color:#be123c}.kpi.amber .v{color:#b45309}
.two{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.card{border:1px solid var(--i1);border-radius:12px;padding:10px 12px}
.card h3{font-size:11.5px;font-weight:800;color:var(--i9);margin-bottom:6px}
.hb{display:grid;grid-template-columns:96px 1fr 62px;gap:8px;align-items:center;margin:4px 0;font-size:10.5px}
.hb .lb{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hb .tr{height:8px;background:var(--i1);border-radius:99px;overflow:hidden}
.hb .fl{height:100%;border-radius:99px;background:var(--b)}
.hb .vv{text-align:left;font-weight:700;color:var(--i9)}
.vb{display:flex;align-items:flex-end;gap:3px;height:92px;border-bottom:1px solid var(--i2);padding:0 2px}
.vb i{flex:1;background:var(--b);border-radius:3px 3px 0 0;min-height:1px;display:block}
.vl{display:flex;gap:3px;margin-top:3px;padding:0 2px}
.vl span{flex:1;text-align:center;font-size:8px;color:var(--i5);overflow:hidden;white-space:nowrap}
.ins{list-style:none}
.ins li{padding:6px 10px 6px 8px;border-radius:8px;margin:4px 0;font-size:11px;display:flex;gap:8px;align-items:flex-start}
.ins li::before{content:'';flex:none;width:7px;height:7px;border-radius:50%;margin-top:7px}
.ins .good{background:#ecfdf5;color:#065f46}.ins .good::before{background:#10b981}
.ins .warn{background:#fff1f2;color:#9f1239}.ins .warn::before{background:#f43f5e}
.ins .info{background:var(--i0);color:var(--i7)}.ins .info::before{background:var(--b)}
.pb{break-before:page;page-break-before:always}
.meta-row{display:flex;flex-wrap:wrap;gap:6px 22px;font-size:10.5px;color:var(--i7);background:var(--i0);border-radius:10px;padding:8px 12px;margin-bottom:12px}
.meta-row b{color:var(--i9)}
.small td,.small th{font-size:10px;padding:5px 7px}
@page{@bottom-center{content:counter(page) ' / ' counter(pages);font-size:9px;color:#8496a0}}
`

const kpi = (label: string, value: string | number, cls = '') => `<div class="kpi ${cls}"><div class="v">${esc(value)}</div><div class="l">${esc(label)}</div></div>`

function hbars(items: Bar[], fmt: (n: number) => string = String, color = '#0f8271', empty = 'لا توجد بيانات في الفترة المحددة'): string {
  const list = items.filter((i) => i.value > 0)
  if (!list.length) return `<div style="font-size:10.5px;color:var(--i4)">${empty}</div>`
  const max = Math.max(...list.map((i) => i.value), 1)
  return list
    .map(
      (i) =>
        `<div class="hb"><span class="lb">${esc(i.label)}</span><span class="tr"><span class="fl" style="display:block;width:${Math.max(3, (i.value / max) * 100)}%;background:${i.color ?? color}"></span></span><span class="vv">${esc(fmt(i.value))}</span></div>`,
    )
    .join('')
}

function vbars(items: Bar[], color = '#0f8271'): string {
  if (!items.some((i) => i.value > 0)) return '<div style="font-size:10.5px;color:var(--i4)">لا توجد بيانات في الفترة المحددة</div>'
  const max = Math.max(...items.map((i) => i.value), 1)
  const step = items.length > 16 ? Math.ceil(items.length / 16) : 1
  return `<div class="vb">${items
    .map((i) => `<i title="${esc(i.label)}: ${i.value}" style="height:${(i.value / max) * 100}%;background:${color}"></i>`)
    .join('')}</div><div class="vl">${items.map((i, idx) => `<span>${idx % step === 0 ? esc(i.label) : ''}</span>`).join('')}</div>`
}

const pillFor = (s: string) => (s === 'completed' ? 'g' : s === 'cancelled' ? 'r' : s === 'no-show' ? 'a' : 's')

export function reportHtml(r: Report, settings: CenterSettings, sections: SectionKey[] = ALL_SECTIONS): string {
  const has = (k: SectionKey) => sections.includes(k)
  const t = r.totals
  const f = r.finance
  const parts: string[] = []

  parts.push(
    centerHeader(settings, 'تقرير إداري شامل', [
      ['الفترة', periodLabel(r.filter)],
      ['تاريخ الإصدار', formatStamp(r.generatedAt)],
    ]),
  )
  parts.push(
    `<div class="meta-row"><span>النطاق: <b>${esc(r.doctorName)}</b></span><span>عدد المواعيد: <b>${t.total}</b></span>${
      settings.managerName ? `<span>مُعدّ إلى: <b>${esc(settings.managerName)}</b></span>` : ''
    }</div>`,
  )

  if (has('summary')) {
    parts.push(`<h2 class="sec">الملخص التنفيذي</h2>
<div class="kpis">
  ${kpi('إجمالي المواعيد', t.total, 'hi')}
  ${kpi('كشوفات مكتملة', t.completed)}
  ${kpi('نسبة الإتمام', `${t.attendance}%`)}
  ${kpi('الإيرادات', money(f.revenue), 'hi')}
  ${kpi('ملغاة', `${t.cancelled} (${t.cancelRate}%)`, t.cancelRate >= 15 ? 'warn' : '')}
  ${kpi('لم يحضر', `${t.noShow} (${t.noShowRate}%)`, t.noShowRate >= 10 ? 'warn' : '')}
  ${kpi('مواعيد قادمة', t.upcoming)}
  ${kpi('متوسط المواعيد/يوم', t.perDay)}
</div>
<div class="two" style="margin-top:12px">
  <div class="card"><h3>توزيع حالات المواعيد</h3>${hbars(r.byStatus)}</div>
  <div class="card"><h3>نوع الكشف</h3>${hbars(r.byType)}</div>
</div>
<h2 class="sec">ملاحظات وتوصيات</h2>
${
  r.insights.length
    ? `<ul class="ins">${r.insights.map((i) => `<li class="${i.tone}">${esc(i.text)}</li>`).join('')}</ul>`
    : '<div class="box s">لا توجد ملاحظات خاصة في هذه الفترة.</div>'
}`)
  }

  if (has('activity')) {
    parts.push(`<h2 class="sec">حركة المواعيد</h2>
<div class="card"><h3>المواعيد حسب ${r.timeline.unit === 'day' ? 'اليوم' : 'الشهر'}</h3>${vbars(r.timeline.appointments)}</div>
<div class="two" style="margin-top:12px">
  <div class="card"><h3>حسب أيام الأسبوع</h3>${hbars(r.byWeekday, String, '#8b5cf6')}</div>
  <div class="card"><h3>ساعات الذروة</h3>${hbars(r.byHour, String, '#0ea5e9')}</div>
</div>`)
  }

  if (has('finance')) {
    parts.push(`<h2 class="sec">التقرير المالي</h2>
<div class="kpis">
  ${kpi('إجمالي الإيرادات', money(f.revenue), 'hi')}
  ${kpi('المحصّل فعلياً', money(f.collected))}
  ${kpi('غير محصّل', money(f.outstanding), f.outstanding > 0 ? 'amber' : '')}
  ${kpi('متوسط قيمة الكشف', money(f.avgFee))}
  ${kpi('إيرادات متوقعة (قادمة)', money(f.expected))}
  ${kpi('إيراد ضائع (إلغاء/غياب)', money(f.lost), f.lost > 0 ? 'warn' : '')}
</div>
<div class="card" style="margin-top:12px"><h3>الإيراد حسب ${r.timeline.unit === 'day' ? 'اليوم' : 'الشهر'}</h3>${vbars(r.timeline.revenue, '#10b981')}</div>
<div class="two" style="margin-top:12px">
  <div class="card"><h3>الإيراد حسب الطبيب</h3>${hbars(f.byDoctor, money, '#0f8271')}</div>
  <div class="card"><h3>الإيراد حسب التخصص</h3>${hbars(f.bySpecialty, money, '#8b5cf6')}</div>
</div>`)
  }

  if (has('doctors')) {
    parts.push(`<h2 class="sec">أداء الأطباء</h2>
<table class="small"><thead><tr><th>الطبيب</th><th>التخصص</th><th class="n">المواعيد</th><th class="n">مكتمل</th><th class="n">ملغي</th><th class="n">غياب</th><th class="n">الإتمام</th><th class="num">الإيراد</th><th class="n">التقييم</th><th class="n">وصفات</th></tr></thead><tbody>
${
  r.doctors.length
    ? r.doctors
        .map(
          (d) =>
            `<tr><td><b>${esc(d.doctor.name)}</b>${d.off ? ' <span class="pill r">غير متاح</span>' : ''}</td><td>${esc(d.specialty)}</td><td class="n">${d.total}</td><td class="n">${d.completed}</td><td class="n">${d.cancelled}</td><td class="n">${d.noShow}</td><td class="n">${d.rate}%</td><td class="num">${esc(money(d.revenue))}</td><td class="n">${d.rating.toFixed(1)}</td><td class="n">${d.prescriptions}</td></tr>`,
        )
        .join('')
    : '<tr><td colspan="10">لا توجد بيانات</td></tr>'
}
</tbody></table>
<h2 class="sec">أداء التخصصات</h2>
<table class="small"><thead><tr><th>التخصص</th><th class="n">المواعيد</th><th class="n">النسبة</th><th class="n">مكتمل</th><th class="num">الإيراد</th></tr></thead><tbody>
${
  r.specialties.length
    ? r.specialties
        .map((s) => `<tr><td><b>${esc(s.name)}</b></td><td class="n">${s.total}</td><td class="n">${s.share}%</td><td class="n">${s.completed}</td><td class="num">${esc(money(s.revenue))}</td></tr>`)
        .join('')
    : '<tr><td colspan="5">لا توجد بيانات</td></tr>'
}
</tbody></table>`)
  }

  if (has('patients')) {
    const p = r.patients
    parts.push(`<h2 class="sec">المرضى</h2>
<div class="kpis">
  ${kpi('إجمالي المسجلين', p.total, 'hi')}
  ${kpi('جدد في الفترة', p.newInRange)}
  ${kpi('نشطون في الفترة', p.active)}
  ${kpi('عائدون (أكثر من زيارة)', p.returning)}
</div>
<div class="two" style="margin-top:12px">
  <div class="card"><h3>الفئات العمرية (النشطون)</h3>${hbars(p.ageGroups, String, '#0ea5e9')}</div>
  <div class="card"><h3>الجنس وبيانات صحية</h3>${hbars(
    [
      { label: 'ذكور', value: p.male, color: '#0f8271' },
      { label: 'إناث', value: p.female, color: '#ec4899' },
      { label: 'لديهم حساسية', value: p.withAllergies, color: '#e11d48' },
      { label: 'أمراض مزمنة', value: p.withChronic, color: '#f59e0b' },
    ],
  )}</div>
</div>
<h2 class="sec">أكثر المرضى زيارة</h2>
<table class="small"><thead><tr><th class="n">#</th><th>المريض</th><th>الجوال</th><th class="n">الزيارات</th><th class="num">إجمالي المدفوع</th></tr></thead><tbody>
${
  p.top.length
    ? p.top
        .map((x, i) => `<tr><td class="n">${i + 1}</td><td><b>${esc(x.name)}</b></td><td><bdi dir="ltr">${esc(x.phone)}</bdi></td><td class="n">${x.visits}</td><td class="num">${esc(money(x.spent))}</td></tr>`)
        .join('')
    : '<tr><td colspan="5">لا توجد بيانات</td></tr>'
}
</tbody></table>`)
  }

  if (has('clinical')) {
    const c = r.clinical
    parts.push(`<h2 class="sec">الوصفات والتشخيصات</h2>
<div class="kpis c3">
  ${kpi('وصفات صادرة', c.count, 'hi')}
  ${kpi('متوسط الأدوية بالوصفة', c.avgMeds)}
  ${kpi('وصفات بها متابعة', c.withFollowUp)}
</div>
<div class="two" style="margin-top:12px">
  <div class="card"><h3>أكثر التشخيصات</h3>${hbars(c.topDiagnoses, String, '#8b5cf6')}</div>
  <div class="card"><h3>أكثر الأدوية وصفاً</h3>${hbars(c.topMeds, String, '#0f8271')}</div>
</div>`)
  }

  if (has('feedback')) {
    const fb = r.feedback
    parts.push(`<h2 class="sec">تقييمات المرضى</h2>
<div class="kpis c3">
  ${kpi('متوسط التقييم', fb.avg ? `${fb.avg} / 5` : '—', 'hi')}
  ${kpi('عدد التقييمات', fb.count)}
  ${kpi('تقييمات مخفية', fb.hidden)}
</div>
<div class="two" style="margin-top:12px">
  <div class="card"><h3>توزيع التقييمات</h3>${hbars(fb.distribution, String, '#f59e0b')}</div>
  <div class="card"><h3>أحدث الآراء</h3>${
    fb.recent.length
      ? fb.recent
          .map((x) => `<div style="margin:5px 0;font-size:10.5px"><b>${esc(x.patient)}</b> → ${esc(x.doctor)} <span class="pill a">${x.rating} ★</span><br><span style="color:var(--i5)">${esc(x.comment || '—')}</span></div>`)
          .join('')
      : '<div style="font-size:10.5px;color:var(--i4)">لا توجد تقييمات في الفترة</div>'
  }</div>
</div>`)
  }

  if (has('comms')) {
    const c = r.comms
    parts.push(`<h2 class="sec">واتساب والعروض</h2>
<div class="kpis">
  ${kpi('محادثات نشطة بالفترة', c.threads)}
  ${kpi('محادثات مفتوحة الآن', c.open)}
  ${kpi('بتدخل بشري', c.human)}
  ${kpi('رسائل غير مقروءة', c.unread, c.unread > 0 ? 'amber' : '')}
  ${kpi('رسائل المرضى', c.patientMsgs)}
  ${kpi('ردود الموظفين', c.agentMsgs)}
  ${kpi('ردود المساعد الآلي', c.botMsgs)}
  ${kpi('عروض مفعّلة', c.activeOffers)}
</div>`)
  }

  if (has('list')) {
    parts.push(`<div class="pb"></div>${centerHeader(settings, 'ملحق المواعيد', [['الفترة', periodLabel(r.filter)]])}
<h2 class="sec">كشف المواعيد التفصيلي (${r.appointments.length})</h2>
<table class="small"><thead><tr><th class="n">#</th><th>التاريخ</th><th>المريض</th><th>الطبيب</th><th>النوع</th><th>الحالة</th><th>الدفع</th><th class="num">المبلغ</th></tr></thead><tbody>
${
  r.appointments.length
    ? r.appointments
        .map((a, i) => {
          const docName = r.doctors.find((d) => d.doctor.id === a.doctorId)?.doctor.name ?? '—'
          return `<tr><td class="n">${i + 1}</td><td>${esc(formatFullDate(a.date))}<br><span style="color:var(--i5)">${esc(formatTime(a.time))}</span></td><td>${esc(a.patientName)}</td><td>${esc(docName)}</td><td>${esc(typeLabel[a.type])}</td><td><span class="pill ${pillFor(a.status)}">${esc(statusLabel[a.status])}</span></td><td>${a.status === 'cancelled' ? '—' : a.paid ? 'مدفوع' : 'غير مدفوع'}</td><td class="num">${esc(money(a.fee))}</td></tr>`
        })
        .join('')
    : '<tr><td colspan="8">لا توجد مواعيد</td></tr>'
}
</tbody>${
      r.appointments.length
        ? `<tfoot><tr><td colspan="7">إجمالي الإيرادات (المكتملة)</td><td class="num">${esc(money(f.revenue))}</td></tr></tfoot>`
        : ''
    }</table>`)
  }

  parts.push(
    `<div class="sign"><div>إعداد: الإدارة</div><div>اعتماد المدير${settings.managerName ? ` — ${esc(settings.managerName)}` : ''}</div></div>`,
  )
  parts.push(centerFooter(settings, 'تقرير سري — للاستخدام الداخلي للإدارة فقط'))
  return parts.join('\n')
}

export function printReport(r: Report, settings: CenterSettings, sections: SectionKey[] = ALL_SECTIONS) {
  printDocument(`تقرير ${settings.name} — ${periodLabel(r.filter)}`, reportHtml(r, settings, sections), REPORT_CSS)
}

export { REPORT_CSS }
