/**
 * Browser -> /api/n8n (Vercel Function) -> n8n webhook (src/lib/n8n.ts). Never throws: callers decide what to show.
 */
import { sendEvent } from './n8n'

export type NotifyEvent = 'prescription.issued' | 'doctor.unavailable' | 'report.send' | 'offer.broadcast' | 'review.submitted'

export interface NotifyResult {
  ok: boolean
  /** السيرفر/n8n مش مضبوط أو مش واصلله (مفيش /api محلياً، أو N8N_WEBHOOK_BASE فاضي) */
  skipped?: boolean
  status?: number
  error?: string
  reason?: string
}

export async function notify(event: NotifyEvent, payload: Record<string, unknown>): Promise<NotifyResult> {
  const r = await sendEvent(event, payload)
  return { ok: r.ok, skipped: r.skipped, status: r.status, error: r.error, reason: r.reason }
}
