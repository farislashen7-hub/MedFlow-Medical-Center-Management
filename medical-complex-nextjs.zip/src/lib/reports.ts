import type { Appointment, DBState, Doctor, Specialty } from './types'
import { AR_DAYS, AR_MONTHS, ageFrom, formatFullDate, fromDateKey, money, toDateKey } from './format'

/* ------------------------------------------------------------------ */
/*  filter + presets                                                   */
/* ------------------------------------------------------------------ */

export interface ReportFilter {
  from: string
  to: string
  doctorId: string
}

export type PresetId = 'month' | 'last30' | 'last90' | 'year' | 'all' | 'custom'

export const PRESETS: { id: PresetId; label: string }[] = [
  { id: 'month', label: 'الشهر الحالي' },
  { id: 'last30', label: 'آخر 30 يوم' },
  { id: 'last90', label: 'آخر 90 يوم' },
  { id: 'year', label: 'السنة الحالية' },
  { id: 'all', label: 'كل الفترات' },
  { id: 'custom', label: 'فترة مخصصة' },
]

export function presetRange(id: PresetId, db: DBState, now = new Date()): { from: string; to: string } {
  const today = toDateKey(now)
  const shift = (days: number) => {
    const d = new Date(now)
    d.setDate(d.getDate() - days)
    return toDateKey(d)
  }
  switch (id) {
    case 'month':
      return { from: toDateKey(new Date(now.getFullYear(), now.getMonth(), 1)), to: today }
    case 'last30':
      return { from: shift(29), to: today }
    case 'last90':
      return { from: shift(89), to: today }
    case 'year':
      return { from: `${now.getFullYear()}-01-01`, to: today }
    case 'all': {
      const dates = db.appointments.map((a) => a.date).sort()
      return { from: dates[0] ?? today, to: dates[dates.length - 1] > today ? dates[dates.length - 1] : today }
    }
    default:
      return { from: shift(29), to: today }
  }
}

/* ------------------------------------------------------------------ */
/*  report shape                                                       */
/* ------------------------------------------------------------------ */

export interface Bar {
  label: string
  value: number
  color?: string
}

export interface DoctorRow {
  doctor: Doctor
  specialty: string
  total: number
  completed: number
  cancelled: number
  noShow: number
  rate: number
  revenue: number
  prescriptions: number
  rating: number
  off: boolean
}

export interface SpecialtyRow {
  name: string
  total: number
  completed: number
  revenue: number
  share: number
  color: string
}

export interface Insight {
  tone: 'good' | 'warn' | 'info'
  text: string
}

export interface Report {
  filter: ReportFilter
  doctorName: string
  generatedAt: string
  appointments: Appointment[]
  totals: {
    total: number
    completed: number
    cancelled: number
    noShow: number
    scheduled: number
    upcoming: number
    attendance: number
    cancelRate: number
    noShowRate: number
    perDay: number
  }
  byStatus: Bar[]
  byType: Bar[]
  byWeekday: Bar[]
  byHour: Bar[]
  timeline: { appointments: Bar[]; revenue: Bar[]; unit: 'day' | 'month' }
  finance: {
    revenue: number
    collected: number
    outstanding: number
    expected: number
    lost: number
    avgFee: number
    byDoctor: Bar[]
    bySpecialty: Bar[]
  }
  doctors: DoctorRow[]
  specialties: SpecialtyRow[]
  patients: {
    total: number
    newInRange: number
    active: number
    returning: number
    male: number
    female: number
    ageGroups: Bar[]
    withAllergies: number
    withChronic: number
    top: { name: string; phone: string; visits: number; spent: number }[]
  }
  clinical: {
    count: number
    avgMeds: number
    withFollowUp: number
    topDiagnoses: Bar[]
    topMeds: Bar[]
  }
  feedback: {
    count: number
    avg: number
    distribution: Bar[]
    hidden: number
    recent: { patient: string; doctor: string; rating: number; comment: string }[]
  }
  comms: {
    threads: number
    open: number
    human: number
    unread: number
    patientMsgs: number
    agentMsgs: number
    botMsgs: number
    activeOffers: number
  }
  insights: Insight[]
}

/* ------------------------------------------------------------------ */
/*  builder                                                            */
/* ------------------------------------------------------------------ */

const PALETTE = ['#0f8271', '#0ea5e9', '#8b5cf6', '#f59e0b', '#e11d48', '#10b981', '#ec4899', '#06b6d4']
const pct = (a: number, b: number) => (b ? Math.round((a / b) * 100) : 0)
const dayOf = (iso: string) => toDateKey(new Date(iso))

function countBy<T>(list: T[], key: (x: T) => string): Map<string, number> {
  const map = new Map<string, number>()
  list.forEach((x) => {
    const k = key(x).trim()
    if (k) map.set(k, (map.get(k) ?? 0) + 1)
  })
  return map
}

function top(map: Map<string, number>, n: number): Bar[] {
  return [...map.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([label, value]) => ({ label, value }))
}

function buildBuckets(from: string, to: string): { key: string; label: string; unit: 'day' | 'month' }[] {
  const start = fromDateKey(from)
  const end = fromDateKey(to)
  const days = Math.round((+end - +start) / 86_400_000) + 1
  const out: { key: string; label: string; unit: 'day' | 'month' }[] = []
  if (days <= 45) {
    for (let i = 0; i < days; i++) {
      const d = new Date(start)
      d.setDate(d.getDate() + i)
      out.push({ key: toDateKey(d), label: `${d.getDate()}`, unit: 'day' })
    }
    return out
  }
  const cur = new Date(start.getFullYear(), start.getMonth(), 1)
  const multiYear = end.getFullYear() !== start.getFullYear()
  while (cur <= end) {
    const key = `${cur.getFullYear()}-${String(cur.getMonth() + 1).padStart(2, '0')}`
    out.push({
      key,
      label: multiYear ? `${AR_MONTHS[cur.getMonth()].slice(0, 3)} ${String(cur.getFullYear()).slice(2)}` : AR_MONTHS[cur.getMonth()],
      unit: 'month',
    })
    cur.setMonth(cur.getMonth() + 1)
  }
  return out.slice(-24)
}

export function buildReport(db: DBState, filter: ReportFilter, now = new Date()): Report {
  const today = toDateKey(now)
  const inRange = (day: string) => day >= filter.from && day <= filter.to
  const docOk = (id: string) => !filter.doctorId || id === filter.doctorId
  const doctor = db.doctors.find((d) => d.id === filter.doctorId)

  const appts = db.appointments
    .filter((a) => inRange(a.date) && docOk(a.doctorId))
    .sort((a, b) => (`${a.date} ${a.time}` < `${b.date} ${b.time}` ? -1 : 1))

  const count = (s: Appointment['status']) => appts.filter((a) => a.status === s).length
  const completed = count('completed')
  const cancelled = count('cancelled')
  const noShow = count('no-show')
  const scheduled = count('scheduled') + count('confirmed')
  const total = appts.length
  const spanDays = Math.max(1, Math.round((+fromDateKey(filter.to) - +fromDateKey(filter.from)) / 86_400_000) + 1)

  const byStatus: Bar[] = [
    { label: 'مكتمل', value: completed, color: '#10b981' },
    { label: 'مجدول', value: count('scheduled'), color: '#38bdf8' },
    { label: 'مؤكد', value: count('confirmed'), color: '#0f8271' },
    { label: 'ملغي', value: cancelled, color: '#f43f5e' },
    { label: 'لم يحضر', value: noShow, color: '#f59e0b' },
  ]
  const byType: Bar[] = [
    { label: 'كشف جديد', value: appts.filter((a) => a.type === 'new').length, color: '#0f8271' },
    { label: 'متابعة', value: appts.filter((a) => a.type === 'followup').length, color: '#8b5cf6' },
    { label: 'عاجل', value: appts.filter((a) => a.type === 'urgent').length, color: '#e11d48' },
  ]
  const byWeekday: Bar[] = AR_DAYS.map((label, i) => ({
    label,
    value: appts.filter((a) => fromDateKey(a.date).getDay() === i).length,
  }))
  const hours = new Map<number, number>()
  appts.forEach((a) => {
    const h = Number(a.time.split(':')[0])
    hours.set(h, (hours.get(h) ?? 0) + 1)
  })
  const byHour: Bar[] = [...hours.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([h, value]) => ({ label: `${h % 12 === 0 ? 12 : h % 12}${h >= 12 ? 'م' : 'ص'}`, value }))

  /* timeline */
  const buckets = buildBuckets(filter.from, filter.to)
  const unit = buckets[0]?.unit ?? 'day'
  const keyOf = (date: string) => (unit === 'day' ? date : date.slice(0, 7))
  const timeline = {
    unit,
    appointments: buckets.map((b) => ({ label: b.label, value: appts.filter((a) => keyOf(a.date) === b.key).length })),
    revenue: buckets.map((b) => ({
      label: b.label,
      value: appts.filter((a) => keyOf(a.date) === b.key && a.status === 'completed').reduce((s, a) => s + a.fee, 0),
    })),
  }

  /* finance */
  const sumFee = (list: Appointment[]) => list.reduce((s, a) => s + a.fee, 0)
  const doneList = appts.filter((a) => a.status === 'completed')
  const revenue = sumFee(doneList)
  const finance = {
    revenue,
    collected: sumFee(appts.filter((a) => a.paid && a.status !== 'cancelled')),
    outstanding: sumFee(doneList.filter((a) => !a.paid)),
    expected: sumFee(appts.filter((a) => (a.status === 'scheduled' || a.status === 'confirmed') && a.date >= today)),
    lost: sumFee(appts.filter((a) => a.status === 'cancelled' || a.status === 'no-show')),
    avgFee: doneList.length ? Math.round(revenue / doneList.length) : 0,
    byDoctor: [] as Bar[],
    bySpecialty: [] as Bar[],
  }

  /* doctors */
  const doctors: DoctorRow[] = db.doctors
    .filter((d) => docOk(d.id))
    .map((d) => {
      const list = appts.filter((a) => a.doctorId === d.id)
      const done = list.filter((a) => a.status === 'completed')
      return {
        doctor: d,
        specialty: db.specialties.find((s) => s.id === d.specialtyId)?.name ?? '—',
        total: list.length,
        completed: done.length,
        cancelled: list.filter((a) => a.status === 'cancelled').length,
        noShow: list.filter((a) => a.status === 'no-show').length,
        rate: pct(done.length, list.length),
        revenue: sumFee(done),
        prescriptions: db.prescriptions.filter((r) => r.doctorId === d.id && inRange(dayOf(r.issuedAt))).length,
        rating: d.rating,
        off: !!d.unavailable && today >= d.unavailable.since && (!d.unavailable.until || today <= d.unavailable.until),
      }
    })
    .sort((a, b) => b.revenue - a.revenue || b.total - a.total)
  finance.byDoctor = doctors.filter((d) => d.revenue > 0).map((d) => ({ label: d.doctor.name, value: d.revenue }))

  /* specialties */
  const specialties: SpecialtyRow[] = db.specialties
    .map((sp: Specialty, i) => {
      const list = appts.filter((a) => a.specialtyId === sp.id)
      const done = list.filter((a) => a.status === 'completed')
      return {
        name: sp.name,
        total: list.length,
        completed: done.length,
        revenue: sumFee(done),
        share: pct(list.length, total),
        color: PALETTE[i % PALETTE.length],
      }
    })
    .filter((s) => s.total > 0)
    .sort((a, b) => b.total - a.total)
  finance.bySpecialty = specialties.filter((s) => s.revenue > 0).map((s) => ({ label: s.name, value: s.revenue, color: s.color }))

  /* patients */
  const activeIds = new Set(appts.map((a) => a.patientId))
  const activePatients = db.patients.filter((p) => activeIds.has(p.id))
  const visitsBy = new Map<string, { name: string; phone: string; visits: number; spent: number }>()
  appts.forEach((a) => {
    const row = visitsBy.get(a.patientId) ?? { name: a.patientName, phone: a.patientPhone, visits: 0, spent: 0 }
    if (a.status !== 'cancelled') row.visits++
    if (a.status === 'completed') row.spent += a.fee
    visitsBy.set(a.patientId, row)
  })
  const groups = [
    { label: 'أقل من 12', test: (n: number) => n < 12 },
    { label: '12 – 17', test: (n: number) => n >= 12 && n <= 17 },
    { label: '18 – 35', test: (n: number) => n >= 18 && n <= 35 },
    { label: '36 – 50', test: (n: number) => n >= 36 && n <= 50 },
    { label: '51 – 65', test: (n: number) => n >= 51 && n <= 65 },
    { label: 'فوق 65', test: (n: number) => n > 65 },
  ]
  const ages = activePatients.map((p) => ageFrom(p.birthDate)).filter((n): n is number => typeof n === 'number')
  const patients = {
    total: db.patients.length,
    newInRange: db.patients.filter((p) => inRange(dayOf(p.createdAt))).length,
    active: activePatients.length,
    returning: [...visitsBy.values()].filter((v) => v.visits > 1).length,
    male: activePatients.filter((p) => p.gender === 'male').length,
    female: activePatients.filter((p) => p.gender === 'female').length,
    ageGroups: groups.map((g) => ({ label: g.label, value: ages.filter(g.test).length })),
    withAllergies: activePatients.filter((p) => p.allergies && p.allergies !== 'لا يوجد').length,
    withChronic: activePatients.filter((p) => p.chronic && p.chronic !== 'لا يوجد').length,
    top: [...visitsBy.values()].sort((a, b) => b.visits - a.visits || b.spent - a.spent).slice(0, 8),
  }

  /* clinical */
  const rxList = db.prescriptions.filter((r) => inRange(dayOf(r.issuedAt)) && docOk(r.doctorId))
  const medItems = rxList.flatMap((r) => r.items)
  const clinical = {
    count: rxList.length,
    avgMeds: rxList.length ? Math.round((medItems.length / rxList.length) * 10) / 10 : 0,
    withFollowUp: rxList.filter((r) => r.followUp).length,
    topDiagnoses: top(countBy(rxList, (r) => r.diagnosis), 8),
    topMeds: top(countBy(medItems, (m) => m.name), 8),
  }

  /* feedback */
  const reviews = db.reviews.filter((r) => inRange(dayOf(r.createdAt)) && docOk(r.doctorId))
  const shown = reviews.filter((r) => r.status === 'published')
  const feedback = {
    count: reviews.length,
    avg: shown.length ? Math.round((shown.reduce((s, r) => s + r.rating, 0) / shown.length) * 10) / 10 : 0,
    distribution: [5, 4, 3, 2, 1].map((n) => ({ label: `${n} ★`, value: shown.filter((r) => r.rating === n).length })),
    hidden: reviews.length - shown.length,
    recent: [...shown]
      .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
      .slice(0, 5)
      .map((r) => ({
        patient: r.patientName,
        doctor: db.doctors.find((d) => d.id === r.doctorId)?.name ?? '—',
        rating: r.rating,
        comment: r.comment,
      })),
  }

  /* comms */
  const msgs = db.threads.flatMap((t) => t.messages).filter((m) => inRange(dayOf(m.at)))
  const comms = {
    threads: db.threads.filter((t) => inRange(dayOf(t.lastAt))).length,
    open: db.threads.filter((t) => t.status === 'open').length,
    human: db.threads.filter((t) => t.humanAgent).length,
    unread: db.threads.reduce((s, t) => s + t.unread, 0),
    patientMsgs: msgs.filter((m) => m.from === 'patient').length,
    agentMsgs: msgs.filter((m) => m.from === 'agent').length,
    botMsgs: msgs.filter((m) => m.from === 'bot').length,
    activeOffers: db.offers.filter((o) => o.active).length,
  }

  /* insights */
  const insights: Insight[] = []
  const peakDay = [...byWeekday].sort((a, b) => b.value - a.value)[0]
  if (peakDay && peakDay.value > 0) insights.push({ tone: 'info', text: `أكثر أيام الأسبوع ازدحاماً: ${peakDay.label} (${peakDay.value} موعد).` })
  const peakHour = [...byHour].sort((a, b) => b.value - a.value)[0]
  if (peakHour && peakHour.value > 0) insights.push({ tone: 'info', text: `ساعة الذروة: ${peakHour.label} بعدد ${peakHour.value} موعد.` })
  if (doctors[0] && doctors[0].revenue > 0) insights.push({ tone: 'good', text: `الأعلى إيراداً: ${doctors[0].doctor.name} بإجمالي ${money(doctors[0].revenue)}.` })
  if (specialties[0]) insights.push({ tone: 'info', text: `التخصص الأكثر طلباً: ${specialties[0].name} (${specialties[0].share}% من المواعيد).` })
  const att = pct(completed, total)
  if (total && att >= 75) insights.push({ tone: 'good', text: `نسبة إتمام الكشوفات مرتفعة (${att}%).` })
  if (total && pct(noShow, total) >= 10) insights.push({ tone: 'warn', text: `نسبة عدم الحضور ${pct(noShow, total)}% — يُنصح بتفعيل التذكير عبر واتساب قبل الموعد.` })
  if (total && pct(cancelled, total) >= 15) insights.push({ tone: 'warn', text: `نسبة الإلغاء ${pct(cancelled, total)}% — يلزم مراجعة أسباب الإلغاء.` })
  if (finance.outstanding > 0) insights.push({ tone: 'warn', text: `مبالغ كشوفات مكتملة غير محصّلة: ${money(finance.outstanding)}.` })
  if (finance.lost > 0) insights.push({ tone: 'info', text: `قيمة المواعيد الملغاة/الغائبة (إيراد ضائع): ${money(finance.lost)}.` })
  const lowRated = doctors.filter((d) => d.rating > 0 && d.rating < 4)
  if (lowRated.length) insights.push({ tone: 'warn', text: `أطباء تقييمهم أقل من 4: ${lowRated.map((d) => d.doctor.name).join('، ')}.` })
  const offNow = doctors.filter((d) => d.off)
  if (offNow.length) insights.push({ tone: 'info', text: `أطباء معلنون عدم التواجد حالياً: ${offNow.map((d) => d.doctor.name).join('، ')}.` })
  if (finance.expected > 0) insights.push({ tone: 'good', text: `إيرادات متوقعة من المواعيد القادمة: ${money(finance.expected)}.` })

  return {
    filter,
    doctorName: doctor?.name ?? 'كل الأطباء',
    generatedAt: now.toISOString(),
    appointments: appts,
    totals: {
      total,
      completed,
      cancelled,
      noShow,
      scheduled,
      upcoming: appts.filter((a) => a.date >= today && (a.status === 'scheduled' || a.status === 'confirmed')).length,
      attendance: att,
      cancelRate: pct(cancelled, total),
      noShowRate: pct(noShow, total),
      perDay: Math.round((total / spanDays) * 10) / 10,
    },
    byStatus,
    byType,
    byWeekday,
    byHour,
    timeline,
    finance,
    doctors,
    specialties,
    patients,
    clinical,
    feedback,
    comms,
    insights,
  }
}

export function periodLabel(f: ReportFilter): string {
  return `${formatFullDate(f.from)} — ${formatFullDate(f.to)}`
}

/** ملخص نصي مختصر للإرسال بالإيميل/الواتساب */
export function reportSummaryText(r: Report, centerName: string): string {
  const lines = [
    `📊 تقرير ${centerName}`,
    `الفترة: ${periodLabel(r.filter)}`,
    `الطبيب: ${r.doctorName}`,
    '',
    `• إجمالي المواعيد: ${r.totals.total} (مكتمل ${r.totals.completed} • ملغي ${r.totals.cancelled} • لم يحضر ${r.totals.noShow})`,
    `• نسبة الإتمام: ${r.totals.attendance}%`,
    `• الإيرادات: ${money(r.finance.revenue)} (محصّل ${money(r.finance.collected)} • غير محصّل ${money(r.finance.outstanding)})`,
    `• متوسط الكشف: ${money(r.finance.avgFee)}`,
    `• المرضى: ${r.patients.active} نشط • ${r.patients.newInRange} جديد`,
    `• الوصفات الصادرة: ${r.clinical.count}`,
    `• متوسط التقييم: ${r.feedback.avg || '—'} (${r.feedback.count} تقييم)`,
  ]
  if (r.doctors[0]?.revenue) lines.push(`• الأعلى إيراداً: ${r.doctors[0].doctor.name} — ${money(r.doctors[0].revenue)}`)
  const warns = r.insights.filter((i) => i.tone === 'warn')
  if (warns.length) lines.push('', '⚠️ ملاحظات تحتاج انتباه:', ...warns.map((w) => `- ${w.text}`))
  lines.push('', 'التقرير المفصل (PDF) مرفق.')
  return lines.join('\n')
}
