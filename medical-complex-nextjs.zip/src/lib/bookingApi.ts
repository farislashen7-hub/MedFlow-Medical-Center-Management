/**
 * الحجز: المتصفح -> Supabase مباشرة (publishable key + سياسة RLS "public can book")
 * ثم -> n8n webhook (appointment.created). فشل n8n مبيكسرش الحجز.
 */
import { supabase } from './supabase'
import { parsePhone } from './phone'
import { sendEvent } from './n8n'

export interface BookingPayload {
  appointmentId: string
  patientName: string
  patientPhone: string
  doctorId: string
  specialtyId: string
  doctorName: string
  specialtyName: string
  date: string
  time: string
  type: string
  reason: string
}

export type BookingResult =
  | { ok: true; skipped?: boolean }
  | { ok: false; reason: 'invalid_phone' | 'slot_taken' | 'rate_limited' }

const TYPES = ['new', 'followup', 'urgent']

export async function submitBooking(p: BookingPayload): Promise<BookingResult> {
  const phone = parsePhone(p.patientPhone)
  if (!phone.ok) return { ok: false, reason: 'invalid_phone' }

  const row = {
    id: p.appointmentId,
    patient_name: p.patientName.trim().replace(/\s+/g, ' ').slice(0, 120),
    patient_phone: phone.e164,
    phone_country: phone.iso,
    doctor_id: p.doctorId,
    specialty_id: p.specialtyId,
    date: p.date,
    time: p.time,
    type: TYPES.includes(p.type) ? p.type : 'new',
    reason: p.reason.trim().slice(0, 1000),
    status: 'confirmed',
    source: 'web',
  }

  // بدون .select(): الزائر مالوش صلاحية قراءة
  // فشل/غياب Supabase مبيمنعش إشعار n8n (الحجز بيكمل محلياً والواتساب يتبعت). الوحيد اللي بيوقف: الميعاد متحجز.
  let skipped = !supabase
  if (supabase) {
    const { error } = await supabase.from('appointments').insert(row)
    if (error) {
      if (error.code === '23505') {
        if (/doctor_slot/i.test(`${error.message} ${error.details ?? ''}`)) return { ok: false, reason: 'slot_taken' }
        return { ok: true } // نفس id اتبعت قبل كده
      }
      console.warn('[booking] supabase', error.code, error.message)
      skipped = true
    }
  }

  // حجز المتابعة بيروح لـ webhook الـ Rebooking، والباقي لـ booking
  void sendEvent(row.type === 'followup' ? 'appointment.rebooked' : 'appointment.created', {
    id: row.id,
    name: row.patient_name,
    phone: phone.e164,
    phone_wa: phone.wa,
    country: phone.iso,
    doctor_id: p.doctorId,
    doctor_name: p.doctorName,
    specialty_id: p.specialtyId,
    specialty_name: p.specialtyName,
    date: p.date,
    time: p.time,
    type: row.type,
    reason: row.reason,
    status: 'confirmed',
  })
  return skipped ? { ok: true, skipped: true } : { ok: true }
}
