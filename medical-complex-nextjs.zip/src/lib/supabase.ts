import { createClient } from '@supabase/supabase-js'

/** عميل Supabase للمتصفح: publishable key فقط (محمي بالـ RLS). الـ service role مكانه n8n بس. */
const url = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim()
const key = (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined)?.trim()

export const supabase = url && key ? createClient(url, key) : null
