import type { Appointment, CenterSettings, Doctor, Patient, Prescription, Specialty } from './types'
import { ageFrom, formatFullDate, formatStamp, formatTime, genderLabel, money, toDateKey } from './format'

/* ------------------------------------------------------------------ */
/*  helpers                                                            */
/* ------------------------------------------------------------------ */

export function esc(v: unknown): string {
  return String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

export const DEFAULT_LOGO = '/images/logo.png'

/** مسار مطلق للشعار — الـ iframe بتاع الطباعة مبيفهمش المسارات النسبية */
export function logoSrc(s: CenterSettings): string {
  const src = s.logo || DEFAULT_LOGO
  if (/^(data:|https?:)/.test(src)) return src
  return new URL(src, window.location.origin).href
}

export const statusLabel: Record<Appointment['status'], string> = {
  scheduled: 'مجدول',
  confirmed: 'مؤكد',
  completed: 'مكتمل',
  cancelled: 'ملغي',
  'no-show': 'لم يحضر',
}

export const typeLabel: Record<Appointment['type'], string> = {
  new: 'كشف جديد',
  followup: 'متابعة',
  urgent: 'كشف عاجل',
}

/** أول موعد قادم للمريض بعد وقت معين (مجدول/مؤكد فقط) — بيظهر كـ «ميعاد الحجز القادم» */
export function findNextAppointment(
  appointments: Appointment[],
  patientId: string,
  after: { date: string; time?: string },
  excludeId?: string,
): Appointment | undefined {
  const ref = `${after.date} ${after.time ?? '00:00'}`
  return appointments
    .filter(
      (a) =>
        a.patientId === patientId &&
        a.id !== excludeId &&
        (a.status === 'scheduled' || a.status === 'confirmed') &&
        `${a.date} ${a.time}` > ref,
    )
    .sort((a, b) => (`${a.date} ${a.time}` < `${b.date} ${b.time}` ? -1 : 1))[0]
}

/* ------------------------------------------------------------------ */
/*  shared print styles + shell                                        */
/* ------------------------------------------------------------------ */

export const PRINT_CSS = `
:root{--b:#0f8271;--b9:#0e453f;--b5:#1aa38c;--b1:#d3f5ea;--b0:#eefbf7;--i9:#172227;--i7:#3d4a51;--i5:#62757f;--i4:#8496a0;--i2:#d4dcdf;--i1:#eaeeef;--i0:#f6f8f9}
*{box-sizing:border-box;margin:0;padding:0}
html,body{-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{font-family:'IBM Plex Sans Arabic','Tajawal',Tahoma,Arial,sans-serif;color:var(--i9);font-size:12px;line-height:1.7;direction:rtl;background:#fff}
@page{size:A4;margin:11mm 11mm 14mm}
h1,h2,h3,.disp{font-family:'Tajawal','IBM Plex Sans Arabic',Tahoma,sans-serif}
.hd{display:flex;justify-content:space-between;align-items:center;gap:16px;padding-bottom:12px;border-bottom:3px solid var(--b)}
.brand{display:flex;align-items:center;gap:12px}
.brand img{width:54px;height:54px;border-radius:14px;object-fit:cover;display:block}
.brand h1{font-size:21px;font-weight:800;line-height:1.25;color:var(--i9)}
.brand small{display:block;font-size:9.5px;letter-spacing:.22em;color:var(--b);font-weight:600;margin-top:1px}
.doc{text-align:left}
.doc .t{display:inline-block;background:var(--b);color:#fff;font-family:'Tajawal',sans-serif;font-weight:800;font-size:14px;padding:5px 18px;border-radius:999px}
.doc .m{margin-top:6px;font-size:10.5px;color:var(--i5);line-height:1.6}
.doc .m b{color:var(--i9);font-weight:700}
.contact{display:flex;flex-wrap:wrap;gap:4px 18px;margin:9px 0 14px;padding:8px 12px;background:var(--b0);border-radius:10px;font-size:10.5px;color:var(--i7)}
.contact span{display:inline-flex;align-items:center;gap:5px}
.contact svg{width:12px;height:12px;stroke:var(--b);fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none}
h2.sec{font-size:12.5px;font-weight:800;color:var(--b9);margin:15px 0 7px;display:flex;align-items:center;gap:7px}
h2.sec::before{content:'';width:4px;height:14px;border-radius:2px;background:var(--b)}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.grid.c2{grid-template-columns:repeat(2,1fr)}
.grid.c4{grid-template-columns:repeat(4,1fr)}
.cell{border:1px solid var(--i1);border-radius:10px;padding:7px 10px;background:#fff}
.cell label{display:block;font-size:9.5px;color:var(--i4)}
.cell b{font-size:12px;font-weight:700}
.cell.warn{background:#fff1f2;border-color:#fecdd3}.cell.warn b{color:#be123c}
.cell.amber{background:#fffbeb;border-color:#fde68a}.cell.amber b{color:#92400e}
table{width:100%;border-collapse:collapse}
th{background:var(--b9);color:#fff;font-family:'Tajawal',sans-serif;font-weight:700;font-size:10.5px;padding:7px 9px;text-align:right}
th:first-child{border-radius:0 8px 0 0}th:last-child{border-radius:8px 0 0 0}
td{padding:7px 9px;border-bottom:1px solid var(--i1);font-size:11.5px;vertical-align:top}
tbody tr:nth-child(even) td{background:var(--i0)}
td.n,th.n{text-align:center;width:30px}
td.num,th.num{text-align:left;white-space:nowrap}
tfoot td{font-weight:800;background:var(--b0)!important;border-bottom:0}
.box{border-radius:10px;padding:9px 12px;margin-top:8px;font-size:11.5px;line-height:1.8}
.box.g{background:var(--b0);color:var(--b9)}
.box.a{background:#fffbeb;color:#92400e;border:1px solid #fde68a}
.box.s{background:var(--i0);color:var(--i7)}
.next{display:flex;justify-content:space-between;align-items:center;gap:12px;border:1.5px dashed var(--b);border-radius:12px;padding:10px 14px;background:var(--b0);margin-top:10px}
.next .l{font-size:10px;color:var(--b9);font-weight:700}
.next .v{font-family:'Tajawal',sans-serif;font-weight:800;font-size:14px;color:var(--b9)}
.next .s{font-size:10.5px;color:var(--i5)}
.sign{display:flex;justify-content:space-between;margin-top:30px;gap:36px}
.sign div{flex:1;border-top:1px solid var(--i2);padding-top:5px;text-align:center;font-size:10px;color:var(--i5)}
.ft{margin-top:18px;padding-top:8px;border-top:1px solid var(--i1);text-align:center;font-size:9.5px;color:var(--i4);line-height:1.8}
.stamp{display:inline-block;border:2px solid;border-radius:8px;padding:2px 14px;font-family:'Tajawal',sans-serif;font-weight:800;font-size:15px;transform:rotate(-4deg)}
.stamp.paid{color:#059669;border-color:#059669}.stamp.unpaid{color:#d97706;border-color:#d97706}.stamp.void{color:#be123c;border-color:#be123c}
.totals{margin-top:10px;margin-right:auto;width:62%;border:1px solid var(--i1);border-radius:12px;overflow:hidden}
.totals div{display:flex;justify-content:space-between;padding:7px 12px;font-size:11.5px;border-bottom:1px solid var(--i1)}
.totals div:last-child{border-bottom:0;background:var(--b);color:#fff;font-family:'Tajawal',sans-serif;font-weight:800;font-size:14px}
.pill{display:inline-block;border-radius:999px;padding:1px 9px;font-size:10px;font-weight:700;background:var(--i1);color:var(--i7)}
.pill.g{background:#d1fae5;color:#065f46}.pill.r{background:#ffe4e6;color:#9f1239}.pill.a{background:#fef3c7;color:#92400e}.pill.s{background:#e0f2fe;color:#075985}
tr,.cell,.box,.next,.totals,.kpi{break-inside:avoid;page-break-inside:avoid}
h2.sec{break-after:avoid}
`

const ICON = {
  pin: '<svg viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/></svg>',
  phone:
    '<svg viewBox="0 0 24 24"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg>',
  mail: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>',
  id: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 10h4M7 14h6"/></svg>',
}

export function contactStrip(s: CenterSettings): string {
  const place = [s.city, s.address].filter(Boolean).join(' — ')
  const items = [
    place && `<span>${ICON.pin}${esc(place)}</span>`,
    s.phone && `<span>${ICON.phone}<bdi dir="ltr">${esc(s.phone)}</bdi></span>`,
    s.email && `<span>${ICON.mail}<bdi dir="ltr">${esc(s.email)}</bdi></span>`,
    s.licenseNo && `<span>${ICON.id}ترخيص رقم <bdi dir="ltr">${esc(s.licenseNo)}</bdi></span>`,
    s.taxNo && `<span>${ICON.id}الرقم الضريبي <bdi dir="ltr">${esc(s.taxNo)}</bdi></span>`,
  ].filter(Boolean)
  return items.length ? `<div class="contact">${items.join('')}</div>` : ''
}

/** هيدر موحد: شعار + اسم المركز + بيانات (العنوان/التليفون/الإيميل) + عنوان المستند */
export function centerHeader(s: CenterSettings, title: string, meta: [string, string][] = []): string {
  return `
<div class="hd">
  <div class="brand">
    <img src="${esc(logoSrc(s))}" alt="">
    <div><h1>${esc(s.name)}</h1>${s.tagline ? `<small>${esc(s.tagline)}</small>` : ''}</div>
  </div>
  <div class="doc">
    <span class="t">${esc(title)}</span>
    <div class="m">${meta.map(([k, v]) => `${esc(k)}: <b>${esc(v)}</b>`).join('<br>')}</div>
  </div>
</div>
${contactStrip(s)}`
}

export function centerFooter(s: CenterSettings, note: string): string {
  const place = [s.city, s.address].filter(Boolean).join(' — ')
  return `<div class="ft">${esc(note)}<br>${esc(s.name)}${place ? ` • ${esc(place)}` : ''}${
    s.phone ? ` • <bdi dir="ltr">${esc(s.phone)}</bdi>` : ''
  }${s.email ? ` • <bdi dir="ltr">${esc(s.email)}</bdi>` : ''}</div>`
}

export function nextAppointmentBox(next: Appointment | undefined, doctors: Doctor[], followUp?: string): string {
  if (!next && !followUp) return ''
  if (!next) {
    return `<div class="next"><div><div class="l">موعد المتابعة المقترح</div><div class="v">${esc(followUp)}</div></div><div class="s">لم يتم حجز موعد بعد — تواصل معنا للحجز</div></div>`
  }
  const doc = doctors.find((d) => d.id === next.doctorId)
  return `<div class="next">
  <div><div class="l">ميعاد الحجز القادم</div><div class="v">${esc(formatFullDate(next.date))} — ${esc(formatTime(next.time))}</div></div>
  <div class="s">${doc ? esc(doc.name) : ''}${followUp ? `<br>${esc(followUp)}` : ''}${next.reason ? `<br>${esc(next.reason)}` : ''}</div>
</div>`
}

/* ------------------------------------------------------------------ */
/*  print through hidden iframe (no popup blockers, keeps RTL + A4)    */
/* ------------------------------------------------------------------ */

export function buildDocument(title: string, body: string, extraCss = ''): string {
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${esc(title)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Tajawal:wght@500;700;800&display=swap">
<style>${PRINT_CSS}${extraCss}</style></head><body>${body}</body></html>`
}

export function printDocument(title: string, body: string, extraCss = ''): void {
  const iframe = document.createElement('iframe')
  iframe.setAttribute('aria-hidden', 'true')
  iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden'
  document.body.appendChild(iframe)
  const win = iframe.contentWindow
  const doc = iframe.contentDocument
  if (!win || !doc) {
    iframe.remove()
    return
  }
  doc.open()
  doc.write(buildDocument(title, body, extraCss))
  doc.close()

  const cleanup = () => window.setTimeout(() => iframe.remove(), 500)
  const run = async () => {
    const imgs = Array.from(doc.images).map(
      (img) =>
        new Promise<void>((resolve) => {
          if (img.complete) return resolve()
          img.onload = () => resolve()
          img.onerror = () => resolve()
        }),
    )
    const fonts: Promise<unknown> = doc.fonts?.ready ?? Promise.resolve()
    await Promise.race([Promise.all([fonts, ...imgs]), new Promise((r) => window.setTimeout(r, 3500))])
    win.addEventListener('afterprint', cleanup)
    win.focus()
    win.print()
    window.setTimeout(() => iframe.remove(), 120_000)
  }
  void run()
}

/* ------------------------------------------------------------------ */
/*  prescription                                                       */
/* ------------------------------------------------------------------ */

export interface PrescriptionPrintInput {
  settings: CenterSettings
  rx: Prescription
  patient: Patient
  doctors: Doctor[]
  specialties: Specialty[]
  appointments: Appointment[]
}

export function prescriptionHtml(i: PrescriptionPrintInput): string {
  const { settings: s, rx, patient: p } = i
  const doctor = i.doctors.find((d) => d.id === rx.doctorId)
  const specialty = i.specialties.find((x) => x.id === doctor?.specialtyId)
  const appt = i.appointments.find((a) => a.id === rx.appointmentId)
  const next = findNextAppointment(
    i.appointments,
    p.id,
    appt ? { date: appt.date, time: appt.time } : { date: toDateKey(new Date(rx.issuedAt)) },
    appt?.id,
  )
  const hasAllergy = p.allergies && p.allergies !== 'لا يوجد'
  const hasChronic = p.chronic && p.chronic !== 'لا يوجد'

  return `${centerHeader(s, 'وصفة طبية', [
    ['رقم الوصفة', rx.code],
    ['التاريخ', formatStamp(rx.issuedAt)],
  ])}

<h2 class="sec">بيانات المريض</h2>
<div class="grid">
  <div class="cell"><label>اسم المريض</label><b>${esc(p.name)}</b></div>
  <div class="cell"><label>العمر / الجنس</label><b>${esc(ageFrom(p.birthDate))}${p.birthDate ? ' سنة' : ''} — ${esc(genderLabel(p.gender))}</b></div>
  <div class="cell"><label>رقم الجوال</label><b><bdi dir="ltr">${esc(p.phone)}</bdi></b></div>
  <div class="cell"><label>فصيلة الدم</label><b>${esc(p.bloodType || '—')}</b></div>
  <div class="cell ${hasAllergy ? 'warn' : ''}"><label>الحساسية</label><b>${esc(p.allergies || 'لا يوجد')}</b></div>
  <div class="cell ${hasChronic ? 'amber' : ''}"><label>الأمراض المزمنة</label><b>${esc(p.chronic || 'لا يوجد')}</b></div>
</div>

<h2 class="sec">الطبيب المعالج</h2>
<div class="grid c2">
  <div class="cell"><label>الطبيب</label><b>${esc(doctor?.name ?? '—')}</b></div>
  <div class="cell"><label>التخصص</label><b>${esc([doctor?.title, specialty?.name].filter(Boolean).join(' — ') || '—')}</b></div>
</div>

<h2 class="sec">التشخيص</h2>
<div class="box g" style="margin-top:0;font-weight:700;font-size:13px">${esc(rx.diagnosis)}</div>

<h2 class="sec">الأدوية الموصوفة</h2>
<table>
  <thead><tr><th class="n">#</th><th>الدواء</th><th>الجرعة</th><th>المدة</th><th>ملاحظات</th></tr></thead>
  <tbody>
    ${rx.items
      .map(
        (m, idx) =>
          `<tr><td class="n"><b>${idx + 1}</b></td><td><b>${esc(m.name)}</b></td><td>${esc(m.dosage || '—')}</td><td>${esc(m.duration || '—')}</td><td>${esc(m.notes || '—')}</td></tr>`,
      )
      .join('')}
  </tbody>
</table>

${rx.advice ? `<div class="box g"><b>إرشادات الطبيب: </b>${esc(rx.advice)}</div>` : ''}
${nextAppointmentBox(next, i.doctors, rx.followUp)}

<div class="sign"><div>توقيع الطبيب${doctor ? ` — ${esc(doctor.name)}` : ''}</div><div>ختم المركز</div></div>
${centerFooter(s, 'وصفة صادرة إلكترونياً — صالحة بدون ختم مادي عند التحقق من رقم الوصفة')}`
}

export function printPrescription(i: PrescriptionPrintInput) {
  printDocument(`وصفة ${i.rx.code} — ${i.patient.name}`, prescriptionHtml(i))
}

/* ------------------------------------------------------------------ */
/*  invoice                                                            */
/* ------------------------------------------------------------------ */

export interface InvoicePrintInput {
  settings: CenterSettings
  appointment: Appointment
  patient?: Patient
  doctors: Doctor[]
  specialties: Specialty[]
  appointments: Appointment[]
  prescriptions: Prescription[]
}

export function invoiceNumber(a: Appointment) {
  return `INV-${a.id.replace(/[^a-z0-9]/gi, '').slice(-6).toUpperCase()}`
}

export function invoiceHtml(i: InvoicePrintInput): string {
  const { settings: s, appointment: a } = i
  const doctor = i.doctors.find((d) => d.id === a.doctorId)
  const specialty = i.specialties.find((x) => x.id === a.specialtyId)
  const rx = i.prescriptions.find((r) => r.appointmentId === a.id)
  const next = findNextAppointment(i.appointments, a.patientId, { date: a.date, time: a.time }, a.id)
  const cancelled = a.status === 'cancelled'
  const stamp = cancelled
    ? '<span class="stamp void">ملغاة</span>'
    : a.paid
      ? '<span class="stamp paid">مدفوعة</span>'
      : '<span class="stamp unpaid">غير مدفوعة</span>'

  return `${centerHeader(s, 'فاتورة', [
    ['رقم الفاتورة', invoiceNumber(a)],
    ['تاريخ الإصدار', formatStamp(new Date().toISOString())],
  ])}

<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px">
  <div style="flex:1">
    <h2 class="sec" style="margin-top:2px">بيانات العميل</h2>
    <div class="grid c2">
      <div class="cell"><label>اسم المريض</label><b>${esc(a.patientName)}</b></div>
      <div class="cell"><label>رقم الجوال</label><b><bdi dir="ltr">${esc(a.patientPhone)}</bdi></b></div>
      ${i.patient?.insurance && i.patient.insurance !== 'لا يوجد' ? `<div class="cell"><label>التأمين</label><b>${esc(i.patient.insurance)}</b></div>` : ''}
      ${i.patient?.nationalId ? `<div class="cell"><label>رقم الهوية</label><b><bdi dir="ltr">${esc(i.patient.nationalId)}</bdi></b></div>` : ''}
    </div>
  </div>
  <div style="padding-top:18px">${stamp}</div>
</div>

<h2 class="sec">تفاصيل الخدمة</h2>
<table>
  <thead><tr><th>البند</th><th>الطبيب / التخصص</th><th>موعد الكشف</th><th>الحالة</th><th class="num">المبلغ</th></tr></thead>
  <tbody>
    <tr>
      <td><b>${esc(typeLabel[a.type])}</b>${a.reason ? `<br><span style="color:var(--i5);font-size:10.5px">${esc(a.reason)}</span>` : ''}</td>
      <td>${esc(doctor?.name ?? '—')}<br><span style="color:var(--i5);font-size:10.5px">${esc(specialty?.name ?? '')}</span></td>
      <td>${esc(formatFullDate(a.date))}<br><span style="color:var(--i5);font-size:10.5px">${esc(formatTime(a.time))}</span></td>
      <td><span class="pill ${a.status === 'completed' ? 'g' : cancelled ? 'r' : a.status === 'no-show' ? 'a' : 's'}">${esc(statusLabel[a.status])}</span></td>
      <td class="num"><b>${esc(money(a.fee))}</b></td>
    </tr>
    ${rx ? `<tr><td colspan="4" style="color:var(--i5)">وصفة طبية مرفقة ${esc(rx.code)} — ${esc(rx.diagnosis)}</td><td class="num">مشمولة</td></tr>` : ''}
  </tbody>
</table>

<div class="totals">
  <div><span>الإجمالي الفرعي</span><span>${esc(money(a.fee))}</span></div>
  <div><span>حالة السداد</span><span>${cancelled ? 'ملغاة' : a.paid ? 'تم السداد' : 'مستحقة الدفع'}</span></div>
  <div><span>${a.paid && !cancelled ? 'المبلغ المدفوع' : 'المبلغ المستحق'}</span><span>${esc(money(cancelled ? 0 : a.fee))}</span></div>
</div>

${nextAppointmentBox(next, i.doctors, rx?.followUp)}
${a.notes ? `<div class="box s"><b>ملاحظات: </b>${esc(a.notes)}</div>` : ''}
${centerFooter(s, 'شكراً لثقتكم — هذه الفاتورة صادرة إلكترونياً')}`
}

export function printInvoice(i: InvoicePrintInput) {
  printDocument(`فاتورة ${invoiceNumber(i.appointment)} — ${i.appointment.patientName}`, invoiceHtml(i))
}

/* ------------------------------------------------------------------ */
/*  patient file ("وصف المريض")                                        */
/* ------------------------------------------------------------------ */

export interface PatientFilePrintInput {
  settings: CenterSettings
  patient: Patient
  doctors: Doctor[]
  appointments: Appointment[]
  prescriptions: Prescription[]
}

export function patientFileHtml(i: PatientFilePrintInput): string {
  const { settings: s, patient: p } = i
  const sorted = [...i.appointments].sort((a, b) => (`${a.date} ${a.time}` < `${b.date} ${b.time}` ? 1 : -1))
  const next = findNextAppointment(i.appointments, p.id, { date: toDateKey(new Date()), time: '00:00' })
  const doc = (id: string) => i.doctors.find((d) => d.id === id)?.name ?? '—'
  const hasAllergy = p.allergies && p.allergies !== 'لا يوجد'
  const hasChronic = p.chronic && p.chronic !== 'لا يوجد'

  return `${centerHeader(s, 'ملف مريض', [
    ['تاريخ الطباعة', formatStamp(new Date().toISOString())],
    ['عدد الزيارات', String(sorted.length)],
  ])}

<h2 class="sec">البيانات الشخصية</h2>
<div class="grid">
  <div class="cell"><label>الاسم</label><b>${esc(p.name)}</b></div>
  <div class="cell"><label>العمر / الجنس</label><b>${esc(ageFrom(p.birthDate))}${p.birthDate ? ' سنة' : ''} — ${esc(genderLabel(p.gender))}</b></div>
  <div class="cell"><label>رقم الجوال</label><b><bdi dir="ltr">${esc(p.phone)}</bdi></b></div>
  <div class="cell"><label>رقم الهوية</label><b><bdi dir="ltr">${esc(p.nationalId || '—')}</bdi></b></div>
  <div class="cell"><label>شركة التأمين</label><b>${esc(p.insurance || '—')}</b></div>
  <div class="cell"><label>العنوان</label><b>${esc(p.address || '—')}</b></div>
</div>
${
  p.emergency?.name
    ? `<div class="box s"><b>جهة الطوارئ: </b>${esc(p.emergency.name)} (${esc(p.emergency.relation)}) — <bdi dir="ltr">${esc(p.emergency.phone)}</bdi></div>`
    : ''
}

<h2 class="sec">البيانات الطبية</h2>
<div class="grid">
  <div class="cell"><label>فصيلة الدم</label><b>${esc(p.bloodType || '—')}</b></div>
  <div class="cell ${hasAllergy ? 'warn' : ''}"><label>الحساسية</label><b>${esc(p.allergies || 'لا يوجد')}</b></div>
  <div class="cell ${hasChronic ? 'amber' : ''}"><label>الأمراض المزمنة</label><b>${esc(p.chronic || 'لا يوجد')}</b></div>
</div>

<h2 class="sec">سجل الكشوفات</h2>
${
  sorted.length === 0
    ? '<div class="box s">لا توجد مواعيد مسجلة.</div>'
    : `<table><thead><tr><th>التاريخ</th><th>الطبيب</th><th>النوع</th><th>السبب / التشخيص</th><th>الحالة</th></tr></thead><tbody>${sorted
        .map((a) => {
          const rx = i.prescriptions.find((r) => r.appointmentId === a.id)
          return `<tr><td>${esc(formatFullDate(a.date))}<br><span style="color:var(--i5);font-size:10px">${esc(formatTime(a.time))}</span></td><td>${esc(doc(a.doctorId))}</td><td>${esc(typeLabel[a.type])}</td><td>${esc(a.reason)}${rx ? `<br><b style="color:var(--b9)">التشخيص: ${esc(rx.diagnosis)}</b>` : ''}${a.notes ? `<br><span style="color:var(--i5);font-size:10.5px">ملاحظات: ${esc(a.notes)}</span>` : ''}</td><td><span class="pill ${a.status === 'completed' ? 'g' : a.status === 'cancelled' ? 'r' : a.status === 'no-show' ? 'a' : 's'}">${esc(statusLabel[a.status])}</span></td></tr>`
        })
        .join('')}</tbody></table>`
}

<h2 class="sec">الوصفات الطبية</h2>
${
  i.prescriptions.length === 0
    ? '<div class="box s">لا توجد وصفات مسجلة.</div>'
    : i.prescriptions
        .map(
          (r) => `<div class="box g" style="margin-top:6px">
<b>${esc(r.code)} — ${esc(r.diagnosis)}</b> <span style="color:var(--i5);font-size:10.5px">(${esc(formatStamp(r.issuedAt))} — ${esc(doc(r.doctorId))})</span><br>
${r.items.map((m) => `${esc(m.name)}${m.dosage ? ` — ${esc(m.dosage)}` : ''}${m.duration ? ` — ${esc(m.duration)}` : ''}`).join(' • ')}
${r.advice ? `<br><b>إرشادات:</b> ${esc(r.advice)}` : ''}</div>`,
        )
        .join('')
}

${nextAppointmentBox(next, i.doctors)}
${centerFooter(s, 'ملف سري — للاستخدام الطبي فقط')}`
}

export function printPatientFile(i: PatientFilePrintInput) {
  printDocument(`ملف المريض — ${i.patient.name}`, patientFileHtml(i))
}
