import { useEffect } from 'react'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from './supabase'
import {
  applyRemoteAppointment,
  applyRemoteAttendance,
  applyRemoteLeave,
  applyRemoteSchedule,
  removeRemoteAppointment,
  removeRemoteAttendance,
} from './db'
import type { RemoteAppointment, RemoteAttendance, RemoteLeave, RemoteSchedule } from './db'

/** دخول الدكتور/الإدارة على Supabase Auth (signInWithPassword). فشله مبيمنعش الدخول المحلي. */
export async function signInSupabase(email: string, password: string) {
  if (!supabase) return
  const { error } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password })
  if (error) console.warn('[supabase auth]', error.message)
}

export interface StaffProfile {
  userId: string
  email: string
  role: 'admin' | 'doctor'
  doctorId: string | null
}

/** دخول الطاقم من Supabase Auth + قراءة الدور من profiles. null = بيانات غلط أو مفيش profile. */
export async function signInStaffSupabase(email: string, password: string): Promise<StaffProfile | null> {
  if (!supabase) {
    console.warn('[staff login] Supabase مش متفعّل: VITE_SUPABASE_URL / VITE_SUPABASE_PUBLISHABLE_KEY ناقصين')
    return null
  }
  const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password })
  if (error || !data.user) {
    console.warn('[staff login] Supabase Auth رفض الدخول:', error?.message)
    return null
  }
  const { data: profile, error: profErr } = await supabase
    .from('profiles')
    .select('role, doctor_id')
    .eq('id', data.user.id)
    .maybeSingle()
  if (!profile || (profile.role !== 'admin' && profile.role !== 'doctor')) {
    console.warn('[staff login] اتسجل دخول بس مفيش صف في profiles لليوزر ده', profErr?.message ?? '')
    await supabase.auth.signOut()
    return null
  }
  return {
    userId: data.user.id,
    email: data.user.email ?? email.trim().toLowerCase(),
    role: profile.role,
    doctorId: (profile.doctor_id as string | null) ?? null,
  }
}

export async function signOutSupabase() {
  if (supabase) await supabase.auth.signOut()
}

/**
 * لما فيه جلسة Supabase: يجيب المواعيد (RLS بتحدد المسموح) ويشترك Realtime
 * ويدمجها في قاعدة الواجهة الحالية فالداشبورد تتحدّث لحظياً.
 */
export function useRemoteAppointments() {
  useEffect(() => {
    const sb = supabase
    if (!sb) return
    let channel: RealtimeChannel | null = null
    let uid: string | null = null

    const stop = () => {
      if (channel) sb.removeChannel(channel)
      channel = null
      uid = null
    }

    const start = async (userId: string) => {
      if (uid === userId && channel) return
      stop()
      uid = userId
      const { data } = await sb.from('appointments').select('*').order('created_at', { ascending: false })
      ;(data as RemoteAppointment[] | null)?.forEach((r) => applyRemoteAppointment(r))
      channel = sb
        .channel('appointments-realtime')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'appointments' }, (payload) => {
          if (payload.eventType === 'DELETE') removeRemoteAppointment((payload.old as { id: string }).id)
          else applyRemoteAppointment(payload.new as RemoteAppointment, true)
        })
        .subscribe()
    }

    const { data: sub } = sb.auth.onAuthStateChange((event, session) => {
      if (session && (event === 'INITIAL_SESSION' || event === 'SIGNED_IN')) {
        // لا تنتظر Supabase داخل الـ callback نفسه
        setTimeout(() => void start(session.user.id), 0)
      } else if (event === 'SIGNED_OUT') {
        stop()
      }
    })
    return () => {
      sub.subscription.unsubscribe()
      stop()
    }
  }, [])
}

/**
 * جداول الدوام (doctor_schedules): قراءتها عامة (الحجز محتاجها) فبنجيبها لكل الزوار
 * ونشترك Realtime — أي تعديل من الطبيب بيظهر فوراً في لوحة الإدارة وصفحة الحجز.
 */
export function useRemoteSchedules() {
  useEffect(() => {
    const sb = supabase
    if (!sb) return
    let alive = true
    void sb
      .from('doctor_schedules')
      .select('*')
      .then(({ data, error }) => {
        if (!alive) return
        if (error) console.warn('[schedules]', error.message)
        ;(data as RemoteSchedule[] | null)?.forEach((r) => applyRemoteSchedule(r))
      })
    const channel = sb
      .channel('doctor-schedules-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'doctor_schedules' }, (payload) => {
        if (payload.eventType !== 'DELETE') applyRemoteSchedule(payload.new as RemoteSchedule)
      })
      .subscribe()
    return () => {
      alive = false
      sb.removeChannel(channel)
    }
  }, [])
}

/**
 * حضور الأطباء + سجل الظروف (doctor_attendance / doctor_leaves): بتتقرأ بجلسة Supabase بس
 * (الطبيب يشوف بتاعه، الإدارة تشوف الكل — RLS). بنجيبها ونشترك Realtime فلوحة الإدارة تتحدّث لحظياً.
 */
export function useRemoteAttendance() {
  useEffect(() => {
    const sb = supabase
    if (!sb) return
    let channel: RealtimeChannel | null = null
    let uid: string | null = null

    const stop = () => {
      if (channel) sb.removeChannel(channel)
      channel = null
      uid = null
    }

    const start = async (userId: string) => {
      if (uid === userId && channel) return
      stop()
      uid = userId
      const [att, lv] = await Promise.all([
        sb.from('doctor_attendance').select('*'),
        sb.from('doctor_leaves').select('*'),
      ])
      if (att.error) console.warn('[attendance]', att.error.message)
      if (lv.error) console.warn('[leaves]', lv.error.message)
      ;(att.data as RemoteAttendance[] | null)?.forEach((r) => applyRemoteAttendance(r))
      ;(lv.data as RemoteLeave[] | null)?.forEach((r) => applyRemoteLeave(r))
      channel = sb
        .channel('attendance-realtime')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'doctor_attendance' }, (payload) => {
          if (payload.eventType === 'DELETE') removeRemoteAttendance((payload.old as { id: string }).id)
          else applyRemoteAttendance(payload.new as RemoteAttendance)
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'doctor_leaves' }, (payload) => {
          if (payload.eventType !== 'DELETE') applyRemoteLeave(payload.new as RemoteLeave)
        })
        .subscribe()
    }

    const { data: sub } = sb.auth.onAuthStateChange((event, session) => {
      if (session && (event === 'INITIAL_SESSION' || event === 'SIGNED_IN')) {
        setTimeout(() => void start(session.user.id), 0)
      } else if (event === 'SIGNED_OUT') {
        stop()
      }
    })
    return () => {
      sub.subscription.unsubscribe()
      stop()
    }
  }, [])
}
