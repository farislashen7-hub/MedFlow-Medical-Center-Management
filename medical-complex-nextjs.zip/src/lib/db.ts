import { useSyncExternalStore } from 'react'
import type {
  Activity,
  Admin,
  ActivityCategory,
  Appointment,
  AppointmentStatus,
  CenterSettings,
  Offer,
  Review,
  DBState,
  Doctor,
  AttendanceStatus as AttStatus,
  DoctorAttendance,
  DoctorLeave,
  DoctorUnavailable,
  Medication,
  Patient,
  Prescription,
  Role,
  Session,
  WhatsAppMessage,
  WhatsAppThread,
} from './types'
import { buildAttendanceSeed, buildExtras, buildSeed, defaultSettings } from './seed'
import { applyCenterFormat, normalizePhone, toDateKey, toWhatsAppNumber, uid } from './format'
import { isLate, nowHHmm, recordId } from './attendance'
import { samePhone } from './phone'
import { supabase } from './supabase'
import { sendEvent } from './n8n'
import { cancelBookingRemote } from './cancelApi'

const DB_KEY = 'medflow.db.v1'
const SESSION_KEY = 'medflow.session.v1'

/** رقم واتساب التجريبي القديم (0500000000) كان بيحجب رقم العيادة الحقيقي — نعتبره فاضي عشان الأزرار تستخدم رقم الهاتف */
function normalizeSettings(s: CenterSettings): CenterSettings {
  return s.whatsapp === '0500000000' ? { ...s, whatsapp: '' } : s
}

function load(): DBState {
  if (typeof window === 'undefined') return buildSeed()
  try {
    const raw = window.localStorage.getItem(DB_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as DBState
      if (parsed && parsed.appointments && parsed.doctors) {
        // ترقية البيانات القديمة: إضافة بيانات المركز الافتراضية إن لم تكن موجودة
        const extras = buildExtras(parsed.patients || [], parsed.doctors, parsed.appointments)
        const att = !parsed.attendance || !parsed.leaves ? buildAttendanceSeed(parsed.doctors) : null
        // الحملات القديمة اتشالت — نتجاهل أي بيانات محفوظة منها
        const { broadcasts: _legacyBroadcasts, ...rest } = parsed as DBState & { broadcasts?: unknown }
        void _legacyBroadcasts
        // محادثات واتساب التجريبية القديمة (wa_1) ونشاطها المولّد (act_N) اتشالوا — نمسحهم من أي بيانات محفوظة
        return {
          ...rest,
          threads: (parsed.threads ?? []).filter((t) => t.id !== 'wa_1'),
          activities: (parsed.activities ?? []).filter((a) => !(a.category === 'whatsapp' && /^act_\d+$/.test(a.id))),
          settings: normalizeSettings({ ...defaultSettings, ...(parsed.settings || {}) }),
          offers: parsed.offers ?? extras.offers,
          reviews: parsed.reviews ?? extras.reviews,
          media: parsed.media ?? {},
          attendance: parsed.attendance ?? att?.attendance ?? [],
          leaves: parsed.leaves ?? att?.leaves ?? [],
        }
      }
    }
  } catch {
    /* ignore corrupted storage */
  }
  const seeded = buildSeed()
  try {
    window.localStorage.setItem(DB_KEY, JSON.stringify(seeded))
  } catch {
    /* storage may be unavailable */
  }
  return seeded
}

let state: DBState = load()
applyCenterFormat(state.settings)
const listeners = new Set<() => void>()

function emit() {
  listeners.forEach((l) => l())
}

function subscribe(cb: () => void) {
  listeners.add(cb)
  return () => {
    listeners.delete(cb)
  }
}

export function getDB() {
  return state
}

export function useDB(): DBState {
  return useSyncExternalStore(subscribe, getDB, getDB)
}

function persist() {
  try {
    window.localStorage.setItem(DB_KEY, JSON.stringify(state))
  } catch {
    /* ignore */
  }
  emit()
}

export function resetDB() {
  const keep = state.settings
  state = { ...buildSeed(), settings: keep }
  persist()
}

/* ---------------- center settings ---------------- */

export function useSettings(): CenterSettings {
  return useDB().settings
}

export function getSettings() {
  return state.settings
}

export function updateSettings(patch: Partial<CenterSettings>) {
  state = withActivity(
    { ...state, settings: { ...state.settings, ...patch } },
    'الإدارة',
    'admin',
    'تحديث بيانات المركز',
    'تم تعديل بيانات المركز (الاسم، التواصل، العنوان، ساعات العمل...)',
    'admin',
  )
  applyCenterFormat(state.settings)
  persist()
}

function withActivity(
  base: DBState,
  actor: string,
  actorRole: Role,
  action: string,
  detail: string,
  category: ActivityCategory,
): DBState {
  const entry: Activity = {
    id: uid('act'),
    actor,
    actorRole,
    action,
    detail,
    category,
    at: new Date().toISOString(),
  }
  return { ...base, activities: [entry, ...base.activities] }
}

export interface Actor {
  name: string
  role: Role
}

export function logActivity(
  actor: string,
  actorRole: Role,
  action: string,
  detail: string,
  category: ActivityCategory,
) {
  const entry: Activity = {
    id: uid('act'),
    actor,
    actorRole,
    action,
    detail,
    category,
    at: new Date().toISOString(),
  }
  state = { ...state, activities: [entry, ...state.activities] }
  persist()
}

/* ---------------- patients ---------------- */

export function findPatientByPhone(phone: string) {
  return state.patients.find((p) => samePhone(p.phone, phone))
}

export function findPatientByNationalId(nid: string) {
  const k = nid.trim().toLowerCase()
  return k ? state.patients.find((p) => p.nationalId.trim().toLowerCase() === k) : undefined
}

export function createPatient(input: {
  name: string
  phone: string
  password: string
  email?: string
  nationalId?: string
  birthDate?: string
  gender?: 'male' | 'female'
  bloodType?: string
  allergies?: string
  chronic?: string
  insurance?: string
  address?: string
  emergency?: { name: string; relation: string; phone: string }
}): Patient {
  const patient: Patient = {
    id: uid('pat'),
    name: input.name.trim(),
    phone: normalizePhone(input.phone),
    password: input.password,
    email: input.email || '',
    nationalId: input.nationalId || '',
    birthDate: input.birthDate || '',
    gender: input.gender || 'male',
    bloodType: input.bloodType || 'غير محدد',
    allergies: input.allergies || 'لا يوجد',
    chronic: input.chronic || 'لا يوجد',
    insurance: input.insurance || 'لا يوجد',
    address: input.address || '',
    emergency: input.emergency ?? { name: '', relation: '', phone: '' },
    createdAt: new Date().toISOString(),
  }
  state = { ...state, patients: [patient, ...state.patients] }
  persist()
  return patient
}

export function updatePatient(id: string, patch: Partial<Patient>) {
  state = {
    ...state,
    patients: state.patients.map((p) => (p.id === id ? { ...p, ...patch } : p)),
  }
  persist()
}

/* ---------------- admins (Supabase) ---------------- */

/** أدمن دخل من Supabase Auth: نسجّله محلياً (من غير باسورد صالح) عشان الجلسة تفضل صالحة */
export function upsertSupabaseAdmin(input: { userId: string; email: string; name?: string }): Admin {
  const id = `sb_${input.userId}`
  const existing = state.admins.find((a) => a.id === id)
  if (existing) return existing
  const admin: Admin = {
    id,
    name: input.name || input.email.split('@')[0],
    email: input.email,
    password: uid('nopw') + uid('nopw'),
    phone: '',
    role: 'admin',
  }
  state = { ...state, admins: [...state.admins, admin] }
  persist()
  return admin
}

/* ---------------- doctors ---------------- */

export function createDoctor(input: Partial<Doctor> & { name: string; specialtyId: string }) {
  const doctor: Doctor = {
    id: uid('doc'),
    name: input.name,
    title: input.title || 'استشاري',
    phone: input.phone || '',
    password: input.password || '123456',
    email: input.email || '',
    specialtyId: input.specialtyId,
    years: input.years ?? 5,
    rating: 5,
    reviews: 0,
    location: input.location || state.settings.city,
    clinic: input.clinic || state.settings.name,
    bio: input.bio || '',
    image: input.image || '/images/doc-2.jpg',
    fee: input.fee ?? 250,
    days: input.days ?? [0, 1, 2, 3, 4],
    startHour: input.startHour ?? 9,
    endHour: input.endHour ?? 17,
    active: input.active ?? true,
  }
  state = withActivity(
    { ...state, doctors: [doctor, ...state.doctors] },
    'الإدارة',
    'admin',
    'إضافة طبيب',
    `تمت إضافة ${doctor.name} إلى العيادة`,
    'admin',
  )
  persist()
  void pushRemoteSchedule(doctor.id, doctor)
  return doctor
}

export function updateDoctor(id: string, patch: Partial<Doctor>) {
  const doctor = state.doctors.find((d) => d.id === id)
  state = withActivity(
    {
      ...state,
      doctors: state.doctors.map((d) => (d.id === id ? { ...d, ...patch } : d)),
    },
    'الإدارة',
    'admin',
    'تعديل بيانات طبيب',
    `تم تحديث بيانات ${doctor?.name ?? 'طبيب'}`,
    'admin',
  )
  persist()
  // لو الإدارة عدّلت أيام/ساعات الدوام نحفظها في قاعدة البيانات برضو
  if (patch.days !== undefined || patch.startHour !== undefined || patch.endHour !== undefined) {
    const next = state.doctors.find((d) => d.id === id)
    if (next) void pushRemoteSchedule(id, next)
  }
}

/* ---------------- doctor schedule (مواعيد الطبيب: أيام + ساعات الدوام) ---------------- */

export interface DoctorSchedule {
  days: number[]
  startHour: number
  endHour: number
}

export interface RemoteSchedule {
  doctor_id: string
  days: number[]
  start_hour: number
  end_hour: number
}

export type ScheduleSyncResult =
  | { ok: true }
  | { ok: false; reason: 'no_supabase' | 'no_session' | 'denied' | 'error' }

/** يحفظ جدول الطبيب في Supabase (جدول doctor_schedules). RLS: الطبيب صاحب الجدول أو الإدارة بس. */
async function pushRemoteSchedule(doctorId: string, sch: DoctorSchedule): Promise<ScheduleSyncResult> {
  if (!supabase) return { ok: false, reason: 'no_supabase' }
  try {
    const { data } = await supabase.auth.getSession()
    if (!data.session) return { ok: false, reason: 'no_session' }
    const { error } = await supabase.from('doctor_schedules').upsert(
      { doctor_id: doctorId, days: sch.days, start_hour: sch.startHour, end_hour: sch.endHour },
      { onConflict: 'doctor_id' },
    )
    if (error) {
      console.warn('[schedule] supabase', error.code, error.message)
      return { ok: false, reason: error.code === '42501' ? 'denied' : 'error' }
    }
    return { ok: true }
  } catch (err) {
    console.warn('[schedule] push failed', err)
    return { ok: false, reason: 'error' }
  }
}

/** الطبيب بيحدّد أيام وساعات دوامه — بتتحفظ محلياً وفي قاعدة البيانات وبتظهر للإدارة والحجز. */
export function setDoctorSchedule(id: string, input: DoctorSchedule): Promise<ScheduleSyncResult> {
  const doctor = state.doctors.find((d) => d.id === id)
  if (!doctor) return Promise.resolve({ ok: false, reason: 'error' })
  const days = [...new Set(input.days.filter((d) => Number.isInteger(d) && d >= 0 && d <= 6))].sort()
  const schedule: DoctorSchedule = { days, startHour: input.startHour, endHour: input.endHour }
  state = withActivity(
    { ...state, doctors: state.doctors.map((d) => (d.id === id ? { ...d, ...schedule } : d)) },
    doctor.name,
    'doctor',
    'تعديل مواعيد الدوام',
    `${doctor.name} حدّد دوامه: ${days.length} أيام من ${schedule.startHour}:00 إلى ${schedule.endHour}:00`,
    'booking',
  )
  persist()
  return pushRemoteSchedule(id, schedule)
}

/** دمج جدول جاي من Supabase (الجلب الأولي + Realtime). بيحدّث نفس الطبيب بس ومبيعملش حلقة لو مفيش تغيير. */
export function applyRemoteSchedule(r: RemoteSchedule) {
  const doctor = state.doctors.find((d) => d.id === r.doctor_id)
  if (!doctor) return
  const days = [...r.days].sort()
  const same =
    doctor.startHour === r.start_hour &&
    doctor.endHour === r.end_hour &&
    doctor.days.length === days.length &&
    doctor.days.every((d, i) => d === days[i])
  if (same) return
  state = {
    ...state,
    doctors: state.doctors.map((d) =>
      d.id === r.doctor_id ? { ...d, days, startHour: r.start_hour, endHour: r.end_hour } : d,
    ),
  }
  persist()
}

/** إعلان عدم تواجد الطبيب (ظرف طارئ/إجازة) — بيقفل مواعيده في الحجز. null = رجوع للعمل */
export function setDoctorUnavailable(
  id: string,
  value: DoctorUnavailable | null,
  options: { cancelAffected?: boolean } = {},
): number {
  const doctor = state.doctors.find((d) => d.id === id)
  if (!doctor) return 0
  let cancelled = 0
  let appointments = state.appointments
  if (value && options.cancelAffected) {
    appointments = state.appointments.map((a) => {
      const inRange =
        a.doctorId === id &&
        a.date >= value.since &&
        (!value.until || a.date <= value.until) &&
        (a.status === 'scheduled' || a.status === 'confirmed')
      if (!inRange) return a
      cancelled++
      return { ...a, status: 'cancelled' as const, notes: a.notes ? `${a.notes} — ألغي: ${value.reason}` : `ألغي: ${value.reason}` }
    })
  }
  // سجل الظروف: كل إعلان = صف. الإعلان الجديد بيقفل أي ظرف لسه ساري، والرجوع بيقفل الساري.
  const nowIso = new Date().toISOString()
  const closed: DoctorLeave[] = []
  let leaves = state.leaves.map((l) => {
    if (l.doctorId === id && !l.endedAt) {
      const next = { ...l, endedAt: nowIso }
      closed.push(next)
      return next
    }
    return l
  })
  let created: DoctorLeave | null = null
  if (value) {
    created = {
      id: uid('lv'),
      doctorId: id,
      reason: value.reason,
      note: value.note,
      since: value.since,
      until: value.until,
      createdAt: nowIso,
      endedAt: '',
    }
    leaves = [created, ...leaves]
  }
  state = withActivity(
    {
      ...state,
      appointments,
      leaves,
      doctors: state.doctors.map((d) => (d.id === id ? { ...d, unavailable: value } : d)),
    },
    doctor.name,
    'doctor',
    value ? 'إعلان عدم التواجد' : 'العودة للعمل',
    value
      ? `${doctor.name} غير متاح (${value.reason})${value.until ? ` حتى ${value.until}` : ''}${cancelled ? ` — إلغاء ${cancelled} موعد` : ''}`
      : `${doctor.name} عاد وفُتحت مواعيده للحجز`,
    'booking',
  )
  persist()
  closed.forEach((l) => void pushRemoteLeave(l))
  if (created) void pushRemoteLeave(created)
  return cancelled
}

/* ---------------- حضور وغياب الأطباء + سجل الظروف ---------------- */

export interface RemoteAttendance {
  id: string
  doctor_id: string
  date: string
  status: string
  check_in: string
  check_out: string
  note: string
}

export interface RemoteLeave {
  id: string
  doctor_id: string
  reason: string
  note: string
  since: string
  until: string
  created_at: string
  ended_at: string | null
}

const ATT_STATUSES: AttStatus[] = ['present', 'late', 'absent', 'leave']

/** يكتب في Supabase لو فيه جلسة (الطبيب صاحب السجل أو الإدارة). فشله مبيكسرش حاجة محلياً. */
async function upsertRemote(table: string, row: Record<string, unknown>) {
  if (!supabase) return
  try {
    const { data } = await supabase.auth.getSession()
    if (!data.session) return
    const { error } = await supabase.from(table).upsert(row, { onConflict: 'id' })
    if (error) console.warn(`[${table}]`, error.code, error.message)
  } catch (err) {
    console.warn(`[${table}] push failed`, err)
  }
}

async function pushRemoteAttendance(r: DoctorAttendance) {
  await upsertRemote('doctor_attendance', {
    id: r.id,
    doctor_id: r.doctorId,
    date: r.date,
    status: r.status,
    check_in: r.checkIn,
    check_out: r.checkOut,
    note: r.note,
  })
}

async function pushRemoteLeave(l: DoctorLeave) {
  await upsertRemote('doctor_leaves', {
    id: l.id,
    doctor_id: l.doctorId,
    reason: l.reason,
    note: l.note,
    since: l.since,
    until: l.until,
    created_at: l.createdAt,
    ended_at: l.endedAt || null,
  })
}

function putAttendance(rec: DoctorAttendance, actor: string, role: Role, action: string, detail: string) {
  const exists = state.attendance.some((a) => a.id === rec.id)
  state = withActivity(
    {
      ...state,
      attendance: exists ? state.attendance.map((a) => (a.id === rec.id ? rec : a)) : [rec, ...state.attendance],
    },
    actor,
    role,
    action,
    detail,
    'admin',
  )
  persist()
  void pushRemoteAttendance(rec)
}

export type CheckResult = { ok: true } | { ok: false; error: string }

/** الطبيب بيسجل حضوره النهارده. اتأخر عن بداية الدوام + السماح => «متأخر». */
export function checkInDoctor(id: string): CheckResult {
  const doctor = state.doctors.find((d) => d.id === id)
  if (!doctor) return { ok: false, error: 'الطبيب غير موجود.' }
  const date = toDateKey(new Date())
  const existing = state.attendance.find((a) => a.id === recordId(id, date))
  if (existing?.checkIn) return { ok: false, error: 'سجلت حضورك النهارده بالفعل.' }
  if (doctor.unavailable && state.leaves.some((l) => l.doctorId === id && !l.endedAt && l.since <= date && (!l.until || l.until >= date))) {
    return { ok: false, error: 'أنت معلن عدم التواجد — اضغط «رجعت» الأول من تبويب الظرف.' }
  }
  const time = nowHHmm()
  const status: AttStatus = isLate(doctor, time) ? 'late' : 'present'
  putAttendance(
    { id: recordId(id, date), doctorId: id, date, status, checkIn: time, checkOut: '', note: existing?.note ?? '' },
    doctor.name,
    'doctor',
    'تسجيل حضور',
    `${doctor.name} سجّل حضوره الساعة ${time}${status === 'late' ? ' (متأخر)' : ''}`,
  )
  return { ok: true }
}

export function checkOutDoctor(id: string): CheckResult {
  const doctor = state.doctors.find((d) => d.id === id)
  if (!doctor) return { ok: false, error: 'الطبيب غير موجود.' }
  const date = toDateKey(new Date())
  const rec = state.attendance.find((a) => a.id === recordId(id, date))
  if (!rec?.checkIn) return { ok: false, error: 'سجّل حضورك الأول.' }
  if (rec.checkOut) return { ok: false, error: 'سجلت انصرافك النهارده بالفعل.' }
  const time = nowHHmm()
  putAttendance({ ...rec, checkOut: time }, doctor.name, 'doctor', 'تسجيل انصراف', `${doctor.name} سجّل انصرافه الساعة ${time}`)
  return { ok: true }
}

/** الإدارة بتعدّل/بتسجل حالة يوم لطبيب (حضر/متأخر/غائب/ظرف) */
export function setAttendanceRecord(
  doctorId: string,
  date: string,
  patch: { status: AttStatus; checkIn?: string; checkOut?: string; note?: string },
) {
  const doctor = state.doctors.find((d) => d.id === doctorId)
  if (!doctor || !ATT_STATUSES.includes(patch.status)) return
  const existing = state.attendance.find((a) => a.id === recordId(doctorId, date))
  const worked = patch.status === 'present' || patch.status === 'late'
  const rec: DoctorAttendance = {
    id: recordId(doctorId, date),
    doctorId,
    date,
    status: patch.status,
    checkIn: worked ? patch.checkIn ?? existing?.checkIn ?? '' : '',
    checkOut: worked ? patch.checkOut ?? existing?.checkOut ?? '' : '',
    note: patch.note ?? existing?.note ?? '',
  }
  putAttendance(rec, 'الإدارة', 'admin', 'تعديل حضور طبيب', `${doctor.name} — ${date}: ${patch.status}`)
}

/** يمسح السجل الصريح (اليوم يرجع محسوب تلقائياً) */
export function clearAttendanceRecord(doctorId: string, date: string) {
  const id = recordId(doctorId, date)
  if (!state.attendance.some((a) => a.id === id)) return
  state = { ...state, attendance: state.attendance.filter((a) => a.id !== id) }
  persist()
  if (!supabase) return
  void (async () => {
    try {
      const { data } = await supabase.auth.getSession()
      if (data.session) await supabase.from('doctor_attendance').delete().eq('id', id)
    } catch {
      /* ignore */
    }
  })()
}

export function applyRemoteAttendance(r: RemoteAttendance) {
  if (!ATT_STATUSES.includes(r.status as AttStatus)) return
  const rec: DoctorAttendance = {
    id: r.id,
    doctorId: r.doctor_id,
    date: r.date,
    status: r.status as AttStatus,
    checkIn: (r.check_in ?? '').slice(0, 5),
    checkOut: (r.check_out ?? '').slice(0, 5),
    note: r.note ?? '',
  }
  const cur = state.attendance.find((a) => a.id === rec.id)
  if (cur && JSON.stringify(cur) === JSON.stringify(rec)) return
  state = {
    ...state,
    attendance: cur ? state.attendance.map((a) => (a.id === rec.id ? rec : a)) : [rec, ...state.attendance],
  }
  persist()
}

export function removeRemoteAttendance(id: string) {
  if (!state.attendance.some((a) => a.id === id)) return
  state = { ...state, attendance: state.attendance.filter((a) => a.id !== id) }
  persist()
}

export function applyRemoteLeave(r: RemoteLeave) {
  const leave: DoctorLeave = {
    id: r.id,
    doctorId: r.doctor_id,
    reason: r.reason,
    note: r.note ?? '',
    since: r.since,
    until: r.until ?? '',
    createdAt: r.created_at,
    endedAt: r.ended_at ?? '',
  }
  const cur = state.leaves.find((l) => l.id === leave.id)
  if (cur && JSON.stringify(cur) === JSON.stringify(leave)) return
  state = { ...state, leaves: cur ? state.leaves.map((l) => (l.id === leave.id ? leave : l)) : [leave, ...state.leaves] }
  persist()
}

export function removeDoctor(id: string) {
  const doctor = state.doctors.find((d) => d.id === id)
  state = withActivity(
    { ...state, doctors: state.doctors.filter((d) => d.id !== id) },
    'الإدارة',
    'admin',
    'حذف طبيب',
    `تم حذف ${doctor?.name ?? 'طبيب'} من العيادة`,
    'admin',
  )
  persist()
}

/* ---------------- appointments ---------------- */

export function createAppointment(
  input: {
    id?: string
    patientId: string
    patientName: string
    patientPhone: string
    doctorId: string
    specialtyId: string
    date: string
    time: string
    type: Appointment['type']
    reason: string
    notes?: string
  },
  actor?: Actor,
): Appointment {
  const doctor = state.doctors.find((d) => d.id === input.doctorId)
  const appointment: Appointment = {
    id: input.id || uid('apt'),
    patientId: input.patientId,
    patientName: input.patientName,
    patientPhone: input.patientPhone,
    doctorId: input.doctorId,
    specialtyId: input.specialtyId,
    date: input.date,
    time: input.time,
    duration: 30,
    status: 'scheduled',
    type: input.type,
    reason: input.reason,
    notes: input.notes || '',
    fee: doctor?.fee ?? 0,
    paid: false,
    createdAt: new Date().toISOString(),
  }
  state = withActivity(
    { ...state, appointments: [appointment, ...state.appointments] },
    actor?.name ?? input.patientName,
    actor?.role ?? 'patient',
    'حجز موعد جديد',
    `${input.patientName} مع ${doctor?.name ?? 'الطبيب'} — ${input.date} الساعة ${input.time}`,
    'booking',
  )
  persist()
  return appointment
}

/** إشعار n8n بإلغاء موعد (N8N_PATH_cancelbooking). فشله مبيكسرش حاجة. */
function notifyCancelled(appt: Appointment, cancelledBy: 'patient' | 'staff' = 'staff') {
  const doctor = state.doctors.find((d) => d.id === appt.doctorId)
  void sendEvent('appointment.cancelled', {
    id: appt.id,
    name: appt.patientName,
    phone: appt.patientPhone,
    phone_wa: toWhatsAppNumber(appt.patientPhone),
    doctor_id: appt.doctorId,
    doctor_name: doctor?.name ?? '',
    specialty_id: appt.specialtyId,
    date: appt.date,
    time: appt.time,
    status: 'cancelled',
    cancelled_by: cancelledBy,
  })
}

export type PatientCancelResult = { ok: true } | { ok: false; error: string }

/**
 * إلغاء المريض لموعده: السيرفر يحدّث Supabase (يفتح الميعاد للدكتور) ويبعت واتساب التأكيد.
 * لو السيرفر مش متاح / الحجز مش في Supabase: الإلغاء يتم محلياً ويتبعت الإشعار من المتصفح (احتياطي).
 */
export async function cancelAppointmentByPatient(id: string, patientId: string): Promise<PatientCancelResult> {
  const appt = state.appointments.find((a) => a.id === id)
  if (!appt || appt.patientId !== patientId) return { ok: false, error: 'الموعد غير موجود.' }
  if (appt.status === 'cancelled') return { ok: true }
  if (appt.status === 'completed' || appt.status === 'no-show') return { ok: false, error: 'لا يمكن إلغاء موعد منتهي.' }

  const doctor = state.doctors.find((d) => d.id === appt.doctorId)
  const specialty = state.specialties.find((x) => x.id === appt.specialtyId)
  const remote = await cancelBookingRemote({
    appointmentId: appt.id,
    patientPhone: appt.patientPhone,
    doctorName: doctor?.name ?? '',
    specialtyName: specialty?.name ?? '',
  })
  if (!remote.ok && 'error' in remote) {
    const msg: Record<string, string> = {
      NOT_CANCELLABLE: 'لا يمكن إلغاء هذا الموعد.',
      PAST_APPOINTMENT: 'موعد قديم، لا يمكن إلغاؤه.',
      FORBIDDEN: 'تعذر التحقق من الحجز.',
      RATE_LIMITED: 'محاولات كتيرة، حاول بعد شوية.',
    }
    return { ok: false, error: msg[remote.error] ?? 'تعذر إلغاء الموعد.' }
  }
  // السيرفر مبعتش إشعار (مش لاقي الحجز في Supabase أو مش متاح) => نبعت من هنا
  const serverNotified = remote.ok && remote.found
  if (!serverNotified) notifyCancelled(appt, 'patient')

  state = withActivity(
    { ...state, appointments: state.appointments.map((a) => (a.id === id ? { ...a, status: 'cancelled' } : a)) },
    appt.patientName,
    'patient',
    'إلغاء موعد',
    `ألغى ${appt.patientName} موعده مع ${doctor?.name ?? 'الطبيب'} — ${appt.date} الساعة ${appt.time}`,
    'booking',
  )
  persist()
  return { ok: true }
}

export function updateAppointment(id: string, patch: Partial<Appointment>) {
  const prev = state.appointments.find((a) => a.id === id)
  if (prev && patch.status === 'cancelled' && prev.status !== 'cancelled') notifyCancelled(prev)
  state = {
    ...state,
    appointments: state.appointments.map((a) => (a.id === id ? { ...a, ...patch } : a)),
  }
  persist()
}

const statusLabel: Record<AppointmentStatus, string> = {
  scheduled: 'مجدول',
  confirmed: 'مؤكد',
  completed: 'مكتمل',
  cancelled: 'ملغي',
  'no-show': 'لم يحضر',
}

export function setAppointmentStatus(id: string, status: AppointmentStatus, actor?: Actor) {
  const appt = state.appointments.find((a) => a.id === id)
  if (!appt) return
  if (status === 'cancelled' && appt.status !== 'cancelled') notifyCancelled(appt)
  const doctor = state.doctors.find((d) => d.id === appt.doctorId)
  state = withActivity(
    {
      ...state,
      appointments: state.appointments.map((a) =>
        a.id === id
          ? { ...a, status, paid: status === 'completed' ? a.paid || true : a.paid }
          : a,
      ),
    },
    actor?.name ?? doctor?.name ?? 'النظام',
    actor?.role ?? 'doctor',
    'تحديث حالة موعد',
    `موعد ${appt.patientName} مع ${doctor?.name ?? 'الطبيب'} أصبح ${statusLabel[status]}`,
    'booking',
  )
  persist()
  void pushRemoteStatus(id, status)
}

/* ---------------- Supabase sync (appointments) ---------------- */

export interface RemoteAppointment {
  id: string
  patient_name: string
  patient_phone: string
  doctor_id: string
  specialty_id: string
  date: string
  time: string
  type: string
  reason: string
  status: string
  created_at: string
}

const fromRemoteStatus = (s: string): AppointmentStatus =>
  s === 'no_show' ? 'no-show' : s === 'pending' ? 'scheduled' : (['confirmed', 'completed', 'cancelled'].includes(s) ? (s as AppointmentStatus) : 'scheduled')
const toRemoteStatus = (s: AppointmentStatus) => (s === 'no-show' ? 'no_show' : s === 'scheduled' ? 'pending' : s)

/** تحديث الحالة في Supabase (بيتنفذ بس لو فيه جلسة دكتور/إدارة؛ RLS بترفض غير كده بهدوء) */
async function pushRemoteStatus(id: string, status: AppointmentStatus) {
  if (!supabase) return
  try {
    await supabase.from('appointments').update({ status: toRemoteStatus(status) }).eq('id', id)
  } catch {
    /* ignore */
  }
}

/** دمج موعد جاي من Supabase. overwrite=false (الجلب الأولي) مبيغيّرش مواعيد موجودة محلياً. */
export function applyRemoteAppointment(r: RemoteAppointment, overwrite = false) {
  const status = fromRemoteStatus(r.status)
  const existing = state.appointments.find((a) => a.id === r.id)
  if (existing) {
    if (!overwrite || existing.status === status) return
    state = { ...state, appointments: state.appointments.map((a) => (a.id === r.id ? { ...a, status } : a)) }
    persist()
    return
  }
  const patient =
    findPatientByPhone(r.patient_phone) ??
    createPatient({ name: r.patient_name, phone: r.patient_phone, password: uid('pw') })
  const doctor = state.doctors.find((d) => d.id === r.doctor_id)
  const appointment: Appointment = {
    id: r.id,
    patientId: patient.id,
    patientName: r.patient_name,
    patientPhone: r.patient_phone,
    doctorId: r.doctor_id,
    specialtyId: r.specialty_id,
    date: r.date,
    time: r.time.slice(0, 5),
    duration: 30,
    status,
    type: (['new', 'followup', 'urgent'].includes(r.type) ? r.type : 'new') as Appointment['type'],
    reason: r.reason,
    notes: '',
    fee: doctor?.fee ?? 0,
    paid: status === 'completed',
    createdAt: r.created_at,
  }
  state = withActivity(
    { ...state, appointments: [appointment, ...state.appointments] },
    r.patient_name,
    'patient',
    'حجز موعد جديد',
    `${r.patient_name} مع ${doctor?.name ?? 'الطبيب'} — ${r.date} الساعة ${appointment.time}`,
    'booking',
  )
  persist()
}

export function removeRemoteAppointment(id: string) {
  if (!state.appointments.some((a) => a.id === id)) return
  state = { ...state, appointments: state.appointments.filter((a) => a.id !== id) }
  persist()
}

/* ---------------- prescriptions ---------------- */

export function createPrescription(
  input: {
    appointmentId?: string
    patientId: string
    doctorId: string
    diagnosis: string
    items: Omit<Medication, 'id'>[]
    advice: string
    followUp: string
  },
  actor?: Actor,
): Prescription {
  const prescription: Prescription = {
    id: uid('rx'),
    code: `RX-${Date.now().toString().slice(-5)}`,
    appointmentId: input.appointmentId || '',
    patientId: input.patientId,
    doctorId: input.doctorId,
    diagnosis: input.diagnosis,
    items: input.items.map((m) => ({ ...m, id: uid('med') })),
    advice: input.advice,
    followUp: input.followUp,
    issuedAt: new Date().toISOString(),
  }
  const doctor = state.doctors.find((d) => d.id === input.doctorId)
  const patient = state.patients.find((p) => p.id === input.patientId)
  state = withActivity(
    { ...state, prescriptions: [prescription, ...state.prescriptions] },
    actor?.name ?? doctor?.name ?? 'الطبيب',
    actor?.role ?? 'doctor',
    'إصدار وصفة طبية',
    `وصفة ${prescription.code} للمريض ${patient?.name ?? ''} — ${input.diagnosis}`,
    'medical',
  )
  persist()
  return prescription
}

/* ---------------- whatsapp ---------------- */

export function sendWhatsApp(threadId: string, text: string, from: WhatsAppMessage['from']) {
  const message: WhatsAppMessage = { id: uid('m'), from, text, at: new Date().toISOString() }
  const thread = state.threads.find((t) => t.id === threadId)
  state = withActivity(
    {
      ...state,
      threads: state.threads.map((t) =>
        t.id === threadId
          ? {
              ...t,
              messages: [...t.messages, message],
              lastAt: message.at,
              unread: from === 'patient' ? t.unread + 1 : 0,
            }
          : t,
      ),
    },
    from === 'patient' ? thread?.patientName ?? 'المريض' : 'الإدارة',
    from === 'patient' ? 'patient' : 'admin',
    from === 'patient' ? 'رسالة واتساب واردة' : 'الرد على محادثة واتساب',
    `${thread?.patientName ?? ''}: ${text.slice(0, 60)}`,
    'whatsapp',
  )
  persist()
}

/** يمسح كل محادثات واتساب من لوحة الإدارة (محلياً). مسح قاعدة بيانات واتساب نفسها بيتم من wipeRemoteChats. */
export function clearAllThreads(remoteWiped: boolean) {
  const count = state.threads.length
  state = withActivity(
    { ...state, threads: [] },
    'الإدارة',
    'admin',
    'مسح كل محادثات واتساب',
    `تم مسح ${count} محادثة${remoteWiped ? ' ومعاها بيانات واتساب في الداتابيز' : ''}`,
    'whatsapp',
  )
  persist()
}

export function setThreadAgent(threadId: string, agent: string | null) {
  state = {
    ...state,
    threads: state.threads.map((t) =>
      t.id === threadId
        ? {
            ...t,
            humanAgent: agent,
            status: agent ? 'open' : 'open',
            lastAt: new Date().toISOString(),
            messages: [
              ...t.messages,
              {
                id: uid('m'),
                from: 'bot' as const,
                text: agent
                  ? `تم تحويل المحادثة إلى "${agent}" لرد بشري على الاستفسار.`
                  : 'تم إنهاء التفاعل البشري وإعادة المحادثة إلى المساعد الآلي.',
                at: new Date().toISOString(),
              },
            ],
          }
        : t,
    ),
  }
  persist()
}

export function markThreadRead(threadId: string) {
  state = {
    ...state,
    threads: state.threads.map((t) => (t.id === threadId ? { ...t, unread: 0 } : t)),
  }
  persist()
}

export function toggleThreadStatus(threadId: string) {
  state = {
    ...state,
    threads: state.threads.map((t) =>
      t.id === threadId ? { ...t, status: t.status === 'closed' ? 'open' : 'closed' } : t,
    ),
  }
  persist()
}

/* ---------------- offers ---------------- */

export function createOffer(input: Omit<Offer, 'id' | 'createdAt'>): Offer {
  const offer: Offer = { ...input, id: uid('off'), createdAt: new Date().toISOString() }
  state = withActivity(
    { ...state, offers: [offer, ...state.offers] },
    'الإدارة',
    'admin',
    'إضافة عرض',
    `تمت إضافة العرض «${offer.title}»`,
    'admin',
  )
  persist()
  return offer
}

export function updateOffer(id: string, patch: Partial<Offer>) {
  state = {
    ...state,
    offers: state.offers.map((o) => (o.id === id ? { ...o, ...patch } : o)),
  }
  persist()
}

export function removeOffer(id: string) {
  const offer = state.offers.find((o) => o.id === id)
  state = withActivity(
    { ...state, offers: state.offers.filter((o) => o.id !== id) },
    'الإدارة',
    'admin',
    'حذف عرض',
    `تم حذف العرض «${offer?.title ?? ''}»`,
    'admin',
  )
  persist()
}

/* ---------------- offers sent over whatsapp ---------------- */

/** يسجّل إن العرض اتبعت لمريض (بعد نجاح الـ webhook) في محادثته + سجل النشاط */
export function logOfferSent(offerId: string, message: string, patient: { name: string; phone: string }) {
  const offer = state.offers.find((o) => o.id === offerId)
  if (!offer) return
  const at = new Date().toISOString()
  const imageId = offer.image ? `offer_${offer.id}` : undefined
  const msg: WhatsAppMessage = { id: uid('m'), from: 'agent', text: message, at, imageId }
  const key = toWhatsAppNumber(patient.phone)
  const existing = state.threads.find((t) => toWhatsAppNumber(t.patientPhone) === key)
  const threads: WhatsAppThread[] = existing
    ? state.threads.map((t) => (t.id === existing.id ? { ...t, messages: [...t.messages, msg], lastAt: at } : t))
    : [
        {
          id: uid('wa'),
          patientName: patient.name,
          patientPhone: patient.phone,
          subject: `عرض: ${offer.title}`,
          messages: [msg],
          humanAgent: null,
          status: 'open',
          unread: 0,
          lastAt: at,
        },
        ...state.threads,
      ]

  state = withActivity(
    {
      ...state,
      threads,
      media: imageId && !state.media[imageId] ? { ...state.media, [imageId]: offer.image } : state.media,
    },
    'الإدارة',
    'admin',
    'إرسال عرض على واتساب',
    `${patient.name}: ${offer.title}${imageId ? ' (مع صورة)' : ''}`,
    'whatsapp',
  )
  persist()
}

/* ---------------- reviews ---------------- */

export function createReview(input: {
  patientId: string
  patientName: string
  doctorId: string
  appointmentId: string
  rating: number
  comment: string
}): Review {
  const review: Review = {
    ...input,
    id: uid('rev'),
    status: 'published',
    reply: '',
    createdAt: new Date().toISOString(),
  }
  const doctor = state.doctors.find((d) => d.id === input.doctorId)
  state = withActivity(
    {
      ...state,
      reviews: [review, ...state.reviews],
      doctors: state.doctors.map((d) =>
        d.id === input.doctorId
          ? {
              ...d,
              rating: Math.round(((d.rating * d.reviews + input.rating) / (d.reviews + 1)) * 10) / 10,
              reviews: d.reviews + 1,
            }
          : d,
      ),
    },
    input.patientName,
    'patient',
    'تقييم زيارة',
    `${input.patientName} قيّم ${doctor?.name ?? 'الطبيب'} بـ ${input.rating}/5`,
    'patient',
  )
  persist()
  return review
}

export function updateReview(id: string, patch: Partial<Review>) {
  state = {
    ...state,
    reviews: state.reviews.map((r) => (r.id === id ? { ...r, ...patch } : r)),
  }
  persist()
}

/* ---------------- session ---------------- */

export function loadSession(): Session | null {
  try {
    const raw = window.localStorage.getItem(SESSION_KEY)
    return raw ? (JSON.parse(raw) as Session) : null
  } catch {
    return null
  }
}

export function saveSession(session: Session | null) {
  try {
    if (session) window.localStorage.setItem(SESSION_KEY, JSON.stringify(session))
    else window.localStorage.removeItem(SESSION_KEY)
  } catch {
    /* ignore */
  }
}
