import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import type { Role, Session } from './types'
import {
  createPatient,
  findPatientByNationalId,
  findPatientByPhone,
  getDB,
  loadSession,
  logActivity,
  saveSession,
  upsertSupabaseAdmin,
  useDB,
} from './db'
import { isValidPhone, normalizePhone } from './format'
import { PHONE_HINT, samePhone } from './phone'
import {
  signInStaffSupabase,
  signInSupabase,
  signOutSupabase,
  useRemoteAppointments,
  useRemoteAttendance,
  useRemoteSchedules,
} from './remoteAppointments'
import { useRemoteComplaints } from './complaints'
import { flushUnsyncedPatients, syncPatient } from './patientsApi'

export interface RegisterInput {
  name: string
  phone: string
  password: string
  email?: string
  nationalId?: string
  birthDate?: string
  gender?: 'male' | 'female'
  bloodType?: string
  allergies?: string
  chronic?: string
  insurance?: string
  address?: string
  emergency?: { name: string; relation: string; phone: string }
}

interface AuthValue {
  session: Session | null
  loading: boolean
  login: (role: Role, identifier: string, password: string) => { ok: boolean; error?: string }
  /** دخول الطاقم: Supabase Auth أولاً (admin/doctor من جدول profiles) وبعدها الحساب المحلي كاحتياطي */
  loginStaff: (role: 'doctor' | 'admin', identifier: string, password: string) => Promise<{ ok: boolean; error?: string }>
  /** login=false: يعمل الملف من غير ما يبدّل الجلسة الحالية (مثلاً الإدارة بتحجز لمريض جديد) */
  registerPatient: (input: RegisterInput, options?: { login?: boolean }) => { ok: boolean; error?: string }
  logout: () => void
}

const AuthContext = createContext<AuthValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const db = useDB()
  useRemoteAppointments()
  useRemoteComplaints()
  useRemoteSchedules()
  useRemoteAttendance()
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)

  // أي مريض سجّل ومتبعتش لـ Supabase (فشل قبل كده) يتعاد مرة عند فتح الموقع
  useEffect(() => {
    void flushUnsyncedPatients(getDB().patients)
  }, [])

  useEffect(() => {
    const stored = loadSession()
    if (stored) {
      const stillValid =
        (stored.role === 'patient' && db.patients.some((p) => p.id === stored.id)) ||
        (stored.role === 'doctor' && db.doctors.some((d) => d.id === stored.id)) ||
        (stored.role === 'admin' && db.admins.some((a) => a.id === stored.id))
      if (stillValid) setSession(stored)
      else saveSession(null)
    }
    setLoading(false)
  }, [db.patients, db.doctors, db.admins])

  const login = useCallback(
    (role: Role, identifier: string, password: string) => {
      const id = identifier.trim().toLowerCase()
      if (role === 'patient') {
        const patient = findPatientByPhone(identifier)
        if (!patient) return { ok: false, error: 'لا يوجد حساب مسجل بهذا الرقم، يمكنك إنشاء حساب جديد.' }
        if (patient.password !== password) return { ok: false, error: 'كلمة المرور غير صحيحة.' }
        const next: Session = { role: 'patient', id: patient.id, name: patient.name }
        saveSession(next)
        setSession(next)
        logActivity(patient.name, 'patient', 'تسجيل دخول', `دخل إلى بوابة المريض`, 'login')
        return { ok: true }
      }
      if (role === 'doctor') {
        const doctor = db.doctors.find(
          (d) => samePhone(d.phone, identifier) || d.email.toLowerCase() === id,
        )
        if (!doctor) return { ok: false, error: 'لا يوجد حساب طبيب بهذا الرقم أو البريد الإلكتروني.' }
        if (doctor.password !== password) return { ok: false, error: 'كلمة المرور غير صحيحة.' }
        const next: Session = { role: 'doctor', id: doctor.id, name: doctor.name }
        saveSession(next)
        setSession(next)
        void signInSupabase(doctor.email, password)
        logActivity(doctor.name, 'doctor', 'تسجيل دخول', `دخل إلى لوحة الطبيب`, 'login')
        return { ok: true }
      }
      const admin = db.admins.find((a) => a.email.toLowerCase() === id || samePhone(a.phone, identifier))
      if (!admin) return { ok: false, error: 'لا يوجد حساب إدارة بهذه البيانات.' }
      if (admin.password !== password) return { ok: false, error: 'كلمة المرور غير صحيحة.' }
      const next: Session = { role: 'admin', id: admin.id, name: admin.name }
      saveSession(next)
      setSession(next)
      void signInSupabase(admin.email, password)
      logActivity(admin.name, 'admin', 'تسجيل دخول', `دخل إلى لوحة الإدارة`, 'login')
      return { ok: true }
    },
    [db],
  )

  const loginStaff = useCallback(
    async (role: 'doctor' | 'admin', identifier: string, password: string) => {
      if (/^\S+@\S+\.\S+$/.test(identifier.trim())) {
        const prof = await signInStaffSupabase(identifier, password)
        if (prof && prof.role === role) {
          let next: Session | null = null
          if (role === 'admin') {
            const admin = upsertSupabaseAdmin({ userId: prof.userId, email: prof.email })
            next = { role: 'admin', id: admin.id, name: admin.name }
          } else {
            const doctor = getDB().doctors.find((d) => d.id === prof.doctorId)
            if (doctor) next = { role: 'doctor', id: doctor.id, name: doctor.name }
          }
          if (next) {
            saveSession(next)
            setSession(next)
            logActivity(next.name, role, 'تسجيل دخول', role === 'admin' ? 'دخل إلى لوحة الإدارة' : 'دخل إلى لوحة الطبيب', 'login')
            return { ok: true }
          }
        }
        if (prof) await signOutSupabase() // دور غلط أو طبيب مش موجود محلياً
      }
      return login(role, identifier, password)
    },
    [login],
  )

  const registerPatient = useCallback(
    (input: RegisterInput, options: { login?: boolean } = {}) => {
      if (!isValidPhone(input.phone)) return { ok: false, error: PHONE_HINT }
      const phone = normalizePhone(input.phone)
      if (findPatientByPhone(phone)) return { ok: false, error: 'هذا الرقم مسجل مسبقاً، يمكنك تسجيل الدخول مباشرة.' }
      if (input.password.length < 6) return { ok: false, error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل.' }
      if (input.nationalId && findPatientByNationalId(input.nationalId)) {
        return { ok: false, error: 'رقم الهوية مسجل مسبقاً، يمكنك تسجيل الدخول برقم جوالك.' }
      }
      const patient = createPatient({
        name: input.name,
        phone,
        password: input.password,
        email: input.email,
        nationalId: input.nationalId?.trim(),
        birthDate: input.birthDate,
        gender: input.gender,
        bloodType: input.bloodType,
        allergies: input.allergies?.trim() || undefined,
        chronic: input.chronic?.trim() || undefined,
        insurance: input.insurance?.trim() || undefined,
        address: input.address?.trim(),
        emergency: input.emergency,
      })
      void syncPatient(patient)
      if (options.login !== false) {
        const next: Session = { role: 'patient', id: patient.id, name: patient.name }
        saveSession(next)
        setSession(next)
      }
      logActivity(patient.name, 'patient', 'إنشاء حساب', 'سجل حساب جديد في بوابة المريض', 'patient')
      return { ok: true }
    },
    [],
  )

  const logout = useCallback(() => {
    if (session) {
      logActivity(session.name, session.role, 'تسجيل خروج', 'غادر من البوابة', 'login')
    }
    saveSession(null)
    setSession(null)
    void signOutSupabase()
  }, [session])

  const value = useMemo(
    () => ({ session, loading, login, loginStaff, registerPatient, logout }),
    [session, loading, login, loginStaff, registerPatient, logout],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
