import {
  Baby,
  Bone,
  Brain,
  HeartHandshake,
  HeartPulse,
  Smile,
  Sparkles,
  Stethoscope,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

export const specialtyIcons: Record<string, LucideIcon> = {
  HeartPulse,
  Baby,
  Sparkles,
  Bone,
  HeartHandshake,
  Stethoscope,
  Smile,
  Brain,
}

export function getSpecialtyIcon(name: string): LucideIcon {
  return specialtyIcons[name] || Stethoscope
}
