import { parsePhone, setPhoneDefaultCc } from './phone'

export const AR_DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']
export const AR_DAYS_SHORT = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت']
export const AR_MONTHS = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
]

export function pad(n: number) {
  return n < 10 ? `0${n}` : `${n}`
}

export function toDateKey(d: Date) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}

export function fromDateKey(key: string) {
  const [y, m, d] = key.split('-').map(Number)
  return new Date(y, (m || 1) - 1, d || 1)
}

export function addDays(d: Date, n: number) {
  const copy = new Date(d)
  copy.setDate(copy.getDate() + n)
  return copy
}

export function formatDate(dateKey: string) {
  const d = fromDateKey(dateKey)
  return `${AR_DAYS[d.getDay()]}، ${d.getDate()} ${AR_MONTHS[d.getMonth()]} ${d.getFullYear()}`
}

export function formatDateShort(dateKey: string) {
  const d = fromDateKey(dateKey)
  return `${d.getDate()} ${AR_MONTHS[d.getMonth()]}`
}

export function formatFullDate(dateKey: string) {
  const d = fromDateKey(dateKey)
  return `${AR_DAYS_SHORT[d.getDay()]} ${d.getDate()} ${AR_MONTHS[d.getMonth()]} ${d.getFullYear()}`
}

export function formatTime(time: string) {
  const [hStr, mStr] = time.split(':')
  const h = Number(hStr)
  const m = mStr || '00'
  const period = h >= 12 ? 'م' : 'ص'
  const hour12 = h % 12 === 0 ? 12 : h % 12
  return `${hour12}:${m} ${period}`
}

export function formatStamp(iso: string) {
  const d = new Date(iso)
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} — ${formatTime(`${pad(d.getHours())}:${pad(d.getMinutes())}`)}`
}

export function formatStampTime(iso: string) {
  const d = new Date(iso)
  return formatTime(`${pad(d.getHours())}:${pad(d.getMinutes())}`)
}

export function relativeTime(iso: string) {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.round(diff / 60000)
  if (mins < 1) return 'الآن'
  if (mins < 60) return `قبل ${mins} دقيقة`
  const hours = Math.round(mins / 60)
  if (hours < 24) return `قبل ${hours} ساعة`
  const days = Math.round(hours / 24)
  if (days < 30) return `قبل ${days} يوم`
  const months = Math.round(days / 30)
  return `قبل ${months} شهر`
}

let currencySymbol = 'ر.س'
let defaultCountryCode = '966'

/** تُستدعى من db.ts عند تحميل/تعديل بيانات المركز */
export function applyCenterFormat(opts: { currency?: string; countryCode?: string }) {
  if (opts.currency) currencySymbol = opts.currency
  if (opts.countryCode) {
    defaultCountryCode = opts.countryCode.replace(/\D/g, '') || '966'
    setPhoneDefaultCc(defaultCountryCode)
  }
}

export function money(n: number) {
  return `${n.toLocaleString('ar-SA')} ${currencySymbol}`
}

export function currency(n: number) {
  return money(n)
}

export function ageFrom(birthDate: string) {
  if (!birthDate) return '—'
  const b = new Date(birthDate)
  const now = new Date()
  let age = now.getFullYear() - b.getFullYear()
  const m = now.getMonth() - b.getMonth()
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age--
  return age
}

export function genderLabel(g: string) {
  return g === 'female' ? 'أنثى' : 'ذكر'
}

export function initials(name: string) {
  const parts = name.replace(/^د\.\s*/, '').trim().split(/\s+/)
  return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).replace(/undefined/g, '')
}

export function uid(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`
}

/** يرجع الرقم بصيغة E.164 (+20…/+966…) لو صالح، وإلا الرقم منظّف */
export function normalizePhone(phone: string) {
  const r = parsePhone(phone)
  return r.ok ? r.e164 : phone.replace(/[\s-]/g, '')
}

export function isValidPhone(phone: string) {
  return parsePhone(phone).ok
}

export function isValidPassword(pw: string) {
  return pw.length >= 6
}

export function downloadCsv(filename: string, rows: (string | number)[][]) {
  const csv = rows
    .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n')
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

/** رقم دولي لواتساب: 05xxxxxxxx -> 9665xxxxxxxx ، ويقبل الأرقام الدولية كما هي */
export function toWhatsAppNumber(phone: string) {
  const parsed = parsePhone(phone)
  if (parsed.ok) return parsed.wa
  const digits = phone.replace(/[^\d+]/g, '')
  if (digits.startsWith('+')) return digits.slice(1)
  if (digits.startsWith('00')) return digits.slice(2)
  if (digits.startsWith(defaultCountryCode)) return digits
  return `${defaultCountryCode}${digits.replace(/^0/, '')}`
}

export function waLink(phone: string, text?: string) {
  const base = `https://wa.me/${toWhatsAppNumber(phone)}`
  return text ? `${base}?text=${encodeURIComponent(text)}` : base
}

export function telHref(phone: string) {
  return `tel:+${toWhatsAppNumber(phone)}`
}
