/**
 * Browser -> /api/n8n (Vercel Function) -> n8n webhook (بالـ secret من السيرفر).
 * مفيش رابط n8n ولا secret في المتصفح، ومفيش CORS ولا مشكلة صفحة تحذير ngrok.
 * محلياً (npm run dev) مفيش /api: الإرسال بيتخطى بهدوء. للتجربة الكاملة: `vercel dev`.
 */
import { parsePhone } from './phone'

export interface N8nResult {
  ok: boolean
  /** السيرفر/n8n مش مضبوط أو مش واصلله */
  skipped?: boolean
  status?: number
  data?: unknown
  /** كود الخطأ من السيرفر (STAGE_FAILED, N8N_FAILED, ...) */
  error?: string
  reason?: string
}

/** يبعت { event, payload } لـ /api/n8n (مع timeout ومعالجة رد غير JSON) */
export async function triggerN8nWorkflow(
  event: string,
  payload: Record<string, unknown>,
  timeoutMs = 25_000,
): Promise<N8nResult> {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), timeoutMs)
  try {
    const res = await fetch('/api/n8n', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event, payload }),
      signal: ctrl.signal,
    })
    if (res.status === 404) return { ok: false, skipped: true, status: 404 } // dev: مفيش /api
    if (!res.ok) {
      const err = (await res.json().catch(() => null)) as { error?: string; reason?: string } | null
      console.warn('[n8n]', event, 'HTTP', res.status, err)
      return { ok: false, status: res.status, error: err?.error, reason: err?.reason }
    }
    const data = await res.json().catch(() => null)
    return { ok: true, status: res.status, data }
  } catch (err) {
    console.warn('[n8n] failed', event, err)
    return { ok: false, skipped: true }
  } finally {
    clearTimeout(timer)
  }
}

/* ---------- تجهيز الـ payload (نفس الشكل اللي كان بيطلعه api/notify.js) ---------- */
const clip = (v: unknown, max: number) => String(v ?? '').trim().replace(/\s+/g, ' ').slice(0, max)
const text = (v: unknown, max: number) => String(v ?? '').trim().slice(0, max)
const isDate = (s: string) => /^\d{4}-\d{2}-\d{2}$/.test(s)
const MAX_B64 = 8_000_000

function phoneOf(raw: unknown) {
  const p = parsePhone(clip(raw, 30))
  return p.ok
    ? { phone: p.e164, phone_wa: p.wa, country: p.iso as string | null }
    : { phone: clip(raw, 30), phone_wa: null as string | null, country: null as string | null }
}

function b64(v: unknown): string {
  const s = String(v ?? '')
  if (s.length > MAX_B64) throw new Error('FILE_TOO_LARGE')
  return s
}

type P = Record<string, any> // eslint-disable-line @typescript-eslint/no-explicit-any

const SHAPE: Record<string, (p: P) => Record<string, unknown>> = {
  'appointment.created': (p) => p,
  'appointment.rebooked': (p) => p,
  'appointment.cancelled': (p) => p,
  'review.submitted': (p) => ({
    review_id: clip(p.reviewId, 64),
    patient_name: clip(p.patientName, 120),
    doctor_name: clip(p.doctorName, 120),
    rating: (() => {
      const r = Number(p.rating)
      if (!Number.isInteger(r) || r < 1 || r > 5) throw new Error('BAD_RATING')
      return r
    })(),
    comment: text(p.comment, 1000),
    date: clip(p.date, 10),
  }),
  'prescription.issued': (p) => ({
    code: clip(p.code, 32),
    patient_name: clip(p.patientName, 120),
    ...phoneOf(p.patientPhone),
    doctor_name: clip(p.doctorName, 120),
    specialty_name: clip(p.specialtyName, 120),
    diagnosis: clip(p.diagnosis, 500),
    issued_at: clip(p.issuedAt, 40),
    image_base64: b64(p.image),
    mimetype: p.mimetype === 'image/png' ? 'image/png' : 'image/jpeg',
    filename: `${clip(p.code, 32).replace(/[^\w-]/g, '') || 'rx'}.jpg`,
  }),
  'doctor.unavailable': (p) => ({
    doctor_id: clip(p.doctorId, 64),
    doctor_name: clip(p.doctorName, 120),
    doctor_phone: clip(p.doctorPhone, 30),
    reason: clip(p.reason, 200),
    note: clip(p.note, 500),
    since: isDate(clip(p.since, 10)) ? clip(p.since, 10) : '',
    until: isDate(clip(p.until, 10)) ? clip(p.until, 10) : '',
    cancelled: Math.max(0, Math.min(10_000, Number(p.cancelled) || 0)),
    affected: (Array.isArray(p.affected) ? p.affected : []).slice(0, 200).map((a: P) => ({
      patient_name: clip(a?.patientName, 120),
      ...phoneOf(a?.patientPhone),
      date: isDate(clip(a?.date, 10)) ? clip(a.date, 10) : '',
      time: clip(a?.time, 8),
    })),
  }),
  'report.send': (p) => {
    const m = phoneOf(p.managerPhone)
    const email = clip(p.managerEmail, 200)
    return {
      center_name: clip(p.centerName, 120),
      period: clip(p.period, 120),
      manager_name: clip(p.managerName, 120),
      manager_email: /^\S+@\S+\.\S+$/.test(email) ? email : '',
      manager_phone: m.phone,
      manager_phone_wa: m.phone_wa,
      summary: text(p.summary, 6000),
      pdf_base64: b64(p.pdf),
      mimetype: 'application/pdf',
      filename: clip(p.filename, 100).replace(/[^\w.\-\u0600-\u06FF]/g, '-').replace(/(\.pdf)?$/i, '.pdf') || 'report.pdf',
    }
  },
  // عرض واحد -> webhook واحد، و n8n بيلف على المستلمين
  'offer.broadcast': (p) => {
    const seen = new Set<string>()
    const recipients = (Array.isArray(p.recipients) ? p.recipients : [])
      .slice(0, 500)
      .map((r: P) => ({ name: clip(r?.name, 120), number: String(r?.number ?? '').replace(/\D/g, '') }))
      .filter((r: { number: string }) => /^\d{8,15}$/.test(r.number) && !seen.has(r.number) && !!seen.add(r.number))
    if (recipients.length === 0) throw new Error('INVALID_PHONE')
    const image = b64(p.image)
    return {
      offer_title: clip(p.offerTitle, 200),
      text: text(p.text, 4000),
      image_base64: image || null,
      mimetype: image ? p.mimetype || 'image/jpeg' : null,
      recipients,
      count: recipients.length,
    }
  },
}

/** يبعت حدث لـ n8n (عبر السيرفر) بنفس الشكل { event, payload, ts } */
export async function sendEvent(event: string, payload: P): Promise<N8nResult> {
  const shape = SHAPE[event]
  if (!shape) return { ok: true, skipped: true }
  let shaped: Record<string, unknown>
  try {
    shaped = shape(payload)
  } catch (e) {
    console.warn('[n8n] bad payload', event, e)
    return { ok: false, status: 422, error: e instanceof Error ? e.message : 'BAD_PAYLOAD' }
  }
  return triggerN8nWorkflow(event, shaped)
}
