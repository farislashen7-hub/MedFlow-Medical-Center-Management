/**
 * إلغاء المريض لحجزه: Browser -> /api/cancel-booking (Vercel Function، service role) -> Supabase + n8n.
 * المريض مالوش صلاحية UPDATE على Supabase، فمينفعش يتعمل من المتصفح مباشرة.
 */
export type CancelRemote =
  | { ok: true; found: boolean; already?: boolean; notified?: boolean }
  | { ok: false; error: 'NOT_CANCELLABLE' | 'PAST_APPOINTMENT' | 'FORBIDDEN' | 'RATE_LIMITED' }
  | { ok: false; unavailable: true }

export async function cancelBookingRemote(p: {
  appointmentId: string
  patientPhone: string
  doctorName: string
  specialtyName: string
}): Promise<CancelRemote> {
  try {
    const res = await fetch('/api/cancel-booking', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(p),
    })
    const data = (await res.json().catch(() => ({}))) as {
      ok?: boolean
      found?: boolean
      already?: boolean
      notified?: boolean
      error?: string
    }
    if (res.ok && data.ok) return { ok: true, found: !!data.found, already: data.already, notified: data.notified }
    if (data.error === 'NOT_CANCELLABLE' || data.error === 'PAST_APPOINTMENT' || data.error === 'FORBIDDEN' || data.error === 'RATE_LIMITED') {
      return { ok: false, error: data.error }
    }
    return { ok: false, unavailable: true } // 404 (npm run dev) / 5xx / مفيش شبكة
  } catch {
    return { ok: false, unavailable: true }
  }
}
