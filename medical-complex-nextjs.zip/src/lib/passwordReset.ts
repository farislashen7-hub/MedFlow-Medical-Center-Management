/**
 * استعادة كلمة مرور المريض: Browser -> /api/password-reset -> (n8n -> واتساب).
 * الكود 6 أرقام بيتولّد ويتتحقق منه في السيرفر بس. الباسورد الجديد بيتحفظ محلياً (db.ts) زي التسجيل.
 */
export type ResetError =
  | 'INVALID_PHONE'
  | 'INVALID_CODE'
  | 'CODE_EXPIRED'
  | 'TOO_MANY_ATTEMPTS'
  | 'TOO_SOON'
  | 'RATE_LIMITED'
  | 'SERVICE_UNAVAILABLE'
  | 'SEND_FAILED'
  | 'NETWORK'

export interface ResetResult {
  ok: boolean
  error?: ResetError
  /** ثواني الانتظار قبل إعادة الإرسال (TOO_SOON) أو الكولداون بعد الإرسال */
  retryAfter?: number
  cooldown?: number
  remaining?: number
}

async function call(body: Record<string, unknown>): Promise<ResetResult> {
  try {
    const res = await fetch('/api/password-reset', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    // npm run dev: مفيش /api
    if (res.status === 404) return { ok: false, error: 'SERVICE_UNAVAILABLE' }
    const data = (await res.json().catch(() => ({}))) as {
      error?: ResetError
      retryAfter?: number
      cooldown?: number
      remaining?: number
    }
    if (res.ok) return { ok: true, cooldown: data.cooldown }
    return { ok: false, error: data.error ?? 'SEND_FAILED', retryAfter: data.retryAfter, remaining: data.remaining }
  } catch {
    return { ok: false, error: 'NETWORK' }
  }
}

export const requestResetCode = (phone: string) => call({ action: 'request', phone })
export const verifyResetCode = (phone: string, code: string) => call({ action: 'verify', phone, code })

export function resetErrorText(r: ResetResult): string {
  switch (r.error) {
    case 'INVALID_PHONE':
      return 'رقم الجوال غير صحيح.'
    case 'INVALID_CODE':
      return r.remaining != null ? `الكود غير صحيح. متبقي ${r.remaining} محاولات.` : 'الكود غير صحيح.'
    case 'CODE_EXPIRED':
      return 'الكود منتهي أو غير موجود. اطلب كود جديد.'
    case 'TOO_MANY_ATTEMPTS':
      return 'محاولات كتير غلط. اطلب كود جديد.'
    case 'TOO_SOON':
      return `استنى ${r.retryAfter ?? 60} ثانية قبل طلب كود جديد.`
    case 'RATE_LIMITED':
      return 'طلبات كتير. حاول بعد شوية.'
    case 'SERVICE_UNAVAILABLE':
      return 'خدمة الإرسال غير متاحة حالياً. حاول لاحقاً أو تواصل مع العيادة.'
    case 'NETWORK':
      return 'تعذر الاتصال. تأكد من الإنترنت وحاول تاني.'
    default:
      return 'تعذر إرسال الكود. حاول تاني.'
  }
}
