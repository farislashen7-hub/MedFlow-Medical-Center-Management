import { supabase } from './supabase'

/**
 * مسح كل محادثات واتساب من الداتابيز عن طريق /api/wipe-chats ► n8n (res-wipe-all).
 * للإدارة بس: السيرفر بيتأكد من جلسة Supabase (profiles.role = 'admin').
 */
export async function wipeRemoteChats(): Promise<{ ok: boolean; error?: string }> {
  if (!supabase) return { ok: false, error: 'Supabase مش متفعّل' }
  const { data } = await supabase.auth.getSession()
  const token = data.session?.access_token
  if (!token) return { ok: false, error: 'سجّل دخول الإدارة بحساب Supabase علشان تمسح بيانات واتساب' }
  try {
    const res = await fetch('/api/wipe-chats', { method: 'POST', headers: { Authorization: `Bearer ${token}` } })
    if (res.ok) return { ok: true }
    if (res.status === 404) return { ok: false, error: 'السيرفر مش متاح (npm run dev)' }
    const d = (await res.json().catch(() => ({}))) as { error?: string; reason?: string }
    const msg: Record<string, string> = {
      UNAUTHORIZED: 'انتهت الجلسة، سجّل دخول تاني',
      FORBIDDEN: 'الصلاحية للإدارة بس',
      RATE_LIMITED: 'محاولات كتير، حاول بعد شوية',
      SERVICE_UNAVAILABLE: 'N8N_WEBHOOK_BASE أو Supabase مش مضبوط في Vercel',
      NOT_CONFIGURED: 'مسار المسح في n8n مش مضبوط (N8N_PATH_WIPE_ALL)',
      N8N_FAILED: `n8n رجّع خطأ (${d.reason ?? 'unknown'}). تأكد إن workflow res-wipe-all Active وفيه Respond to Webhook`,
    }
    return { ok: false, error: msg[d.error ?? ''] ?? 'تعذر مسح بيانات واتساب' }
  } catch {
    return { ok: false, error: 'تعذر الاتصال بالسيرفر' }
  }
}
