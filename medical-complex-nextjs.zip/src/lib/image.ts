/**
 * Reads an image file and returns a downscaled JPEG data-URL.
 * Downscaling keeps the stored payload small enough for localStorage
 * while staying crisp for avatar-sized portraits.
 * If the browser cannot decode or draw the image, the original data-URL is
 * returned instead — an upload never silently fails.
 */
export function fileToDataUrl(file: File, maxSize = 480): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('الملف المختار ليس صورة'))
      return
    }

    let settled = false
    const finish = (out: string) => {
      if (settled) return
      settled = true
      clearTimeout(guard)
      resolve(out)
    }
    const fail = (err: Error) => {
      if (settled) return
      settled = true
      clearTimeout(guard)
      reject(err)
    }

    // hard safety net: never leave the caller hanging
    const guard = setTimeout(() => fail(new Error('استغرقت معالجة الصورة وقتاً طويلاً')), 15000)

    try {
      const reader = new FileReader()
      reader.onerror = () => fail(new Error('تعذر قراءة الملف'))
      reader.onload = () => {
        const dataUrl = String(reader.result)
        try {
          const img = new Image()
          const timer = setTimeout(() => finish(dataUrl), 2000)
          img.onload = () => {
            try {
              const scale = Math.min(1, maxSize / Math.max(img.width, img.height))
              const width = Math.max(1, Math.round(img.width * scale))
              const height = Math.max(1, Math.round(img.height * scale))
              const canvas = document.createElement('canvas')
              canvas.width = width
              canvas.height = height
              const ctx = canvas.getContext('2d')
              if (!ctx) {
                clearTimeout(timer)
                finish(dataUrl)
                return
              }
              ctx.drawImage(img, 0, 0, width, height)
              clearTimeout(timer)
              finish(canvas.toDataURL('image/jpeg', 0.82))
            } catch {
              clearTimeout(timer)
              finish(dataUrl)
            }
          }
          img.onerror = () => {
            clearTimeout(timer)
            finish(dataUrl)
          }
          img.src = dataUrl
        } catch {
          finish(dataUrl)
        }
      }
      reader.readAsDataURL(file)
    } catch (err) {
      fail(err instanceof Error ? err : new Error('تعذر قراءة الملف'))
    }
  })
}
