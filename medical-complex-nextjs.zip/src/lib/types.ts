export type Role = 'admin' | 'doctor' | 'patient'

export type Gender = 'male' | 'female'

export interface Specialty {
  id: string
  name: string
  nameEn: string
  icon: string
  description: string
  color: string
}

export interface Doctor {
  id: string
  name: string
  title: string
  phone: string
  password: string
  email: string
  specialtyId: string
  years: number
  rating: number
  reviews: number
  location: string
  clinic: string
  bio: string
  image: string
  fee: number
  days: number[]
  startHour: number
  endHour: number
  active: boolean
  /** yyyy-mm-dd — أول يوم بيتحسب منه الحضور والغياب (لو فاضي: أول سجل) */
  joinedAt?: string
  /** إعلان عدم التواجد (ظرف طارئ/إجازة): بيقفل مواعيد الطبيب لحد ما يرجع */
  unavailable?: DoctorUnavailable | null
}

export interface DoctorUnavailable {
  reason: string
  note: string
  /** yyyy-mm-dd — تاريخ بداية عدم التواجد */
  since: string
  /** yyyy-mm-dd — لو فاضي يبقى مفتوح لحد ما الطبيب يرجع بنفسه */
  until: string
}

export interface EmergencyContact {
  name: string
  relation: string
  phone: string
}

export interface Patient {
  id: string
  name: string
  phone: string
  password: string
  email: string
  nationalId: string
  birthDate: string
  gender: Gender
  bloodType: string
  allergies: string
  chronic: string
  insurance: string
  address: string
  emergency: EmergencyContact
  createdAt: string
}

export type AppointmentStatus = 'scheduled' | 'confirmed' | 'completed' | 'cancelled' | 'no-show'
export type AppointmentType = 'new' | 'followup' | 'urgent'

export interface Appointment {
  id: string
  patientId: string
  patientName: string
  patientPhone: string
  doctorId: string
  specialtyId: string
  date: string
  time: string
  duration: number
  status: AppointmentStatus
  type: AppointmentType
  reason: string
  notes: string
  fee: number
  paid: boolean
  createdAt: string
}

export interface Medication {
  id: string
  name: string
  dosage: string
  duration: string
  notes: string
}

export interface Prescription {
  id: string
  code: string
  appointmentId: string
  patientId: string
  doctorId: string
  diagnosis: string
  items: Medication[]
  advice: string
  followUp: string
  issuedAt: string
}

export type ActivityCategory = 'booking' | 'login' | 'medical' | 'whatsapp' | 'admin' | 'patient'

export interface Activity {
  id: string
  actor: string
  actorRole: Role
  action: string
  detail: string
  category: ActivityCategory
  at: string
}

export interface WhatsAppMessage {
  id: string
  from: 'patient' | 'agent' | 'bot'
  text: string
  at: string
  /** مفتاح الصورة في db.media (عروض الواتساب) */
  imageId?: string
}

export interface WhatsAppThread {
  id: string
  patientName: string
  patientPhone: string
  subject: string
  messages: WhatsAppMessage[]
  humanAgent: string | null
  status: 'open' | 'closed'
  unread: number
  lastAt: string
}

export interface Admin {
  id: string
  name: string
  email: string
  password: string
  phone: string
  role: 'admin'
}

export interface CenterSettings {
  name: string
  tagline: string
  about: string
  logo: string
  phone: string
  whatsapp: string
  email: string
  website: string
  city: string
  address: string
  mapUrl: string
  workDays: string
  workHours: string
  currency: string
  countryCode: string
  licenseNo: string
  taxNo: string
  instagram: string
  facebook: string
  x: string
  /** بيانات مدير المركز — بتستخدم لإرسال التقارير */
  managerName: string
  managerEmail: string
  managerPhone: string
}

export type OfferTheme = 'brand' | 'amber' | 'violet' | 'rose'

export interface Offer {
  id: string
  title: string
  details: string
  price: number
  oldPrice: number | null
  validUntil: string
  image: string
  theme: OfferTheme
  message: string
  active: boolean
  createdAt: string
}

export type ReviewStatus = 'published' | 'hidden'

export interface Review {
  id: string
  patientId: string
  patientName: string
  doctorId: string
  appointmentId: string
  rating: number
  comment: string
  status: ReviewStatus
  reply: string
  createdAt: string
}

export type AttendanceStatus = 'present' | 'late' | 'absent' | 'leave'

/** سجل حضور يوم واحد لطبيب (id = doctorId_date) */
export interface DoctorAttendance {
  id: string
  doctorId: string
  /** yyyy-mm-dd */
  date: string
  status: AttendanceStatus
  /** HH:mm — فاضي لو الإدارة سجّلت الحالة يدوياً */
  checkIn: string
  checkOut: string
  note: string
}

/** سجل «عندي ظرف» — كل إعلان عدم تواجد = صف (تاريخ كامل، مش بس الحالي) */
export interface DoctorLeave {
  id: string
  doctorId: string
  reason: string
  note: string
  since: string
  /** فاضي = مفتوح لحد ما يرجع */
  until: string
  createdAt: string
  /** ISO — وقت ما الطبيب رجع (فاضي لو لسه ساري) */
  endedAt: string
}

export interface DBState {
  settings: CenterSettings
  offers: Offer[]
  reviews: Review[]
  specialties: Specialty[]
  doctors: Doctor[]
  patients: Patient[]
  appointments: Appointment[]
  prescriptions: Prescription[]
  activities: Activity[]
  threads: WhatsAppThread[]
  /** صور الحملات: مفتاح -> data URL (بتتخزن مرة واحدة وتتشاف في كل المحادثات) */
  media: Record<string, string>
  admins: Admin[]
  attendance: DoctorAttendance[]
  leaves: DoctorLeave[]
}

export interface Session {
  role: Role
  id: string
  name: string
}
