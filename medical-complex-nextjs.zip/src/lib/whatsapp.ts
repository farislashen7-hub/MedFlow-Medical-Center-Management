import { toWhatsAppNumber, waLink } from './format'
import { notify } from './notify'

export type SendResult = 'api' | 'clipboard' | 'text-only' | 'skipped' | 'failed'

/** سبب آخر فشل في إرسال العرض (رسالة عربي واضحة للتوست) */
export function offerFailureHint(r: { status?: number; error?: string; reason?: string }): string {
  const { status, error, reason } = r
  if (error === 'STAGE_FAILED') return 'جداول العروض في Supabase مش جاهزة — نفّذ migration_04 وتأكد من SUPABASE_SERVICE_ROLE_KEY'
  if (status === 503) return 'N8N_WEBHOOK_BASE أو Supabase مش مضبوط في Vercel'
  if (status === 413 || error === 'FILE_TOO_LARGE' || error === 'PAYLOAD_TOO_LARGE') return 'صورة العرض كبيرة — صغّرها (أقل من 3MB)'
  if (status === 429) return 'طلبات كتير — استنى شوية وجرّب تاني'
  if (status === 422) return `بيانات العرض غير صالحة (${error ?? 'BAD_PAYLOAD'})`
  if (error === 'N8N_FAILED') {
    if (reason === 'http_401' || reason === 'http_403') return 'n8n رفض الطلب — N8N_WEBHOOK_SECRET مختلف عن credential الـ webhook'
    if (reason === 'http_404') return 'webhook cli-offer مش لاقيه — فعّل الـ workflow (Active) وراجع الـ path'
    if (reason === 'unreachable') return 'n8n مش واصلله — راجع ngrok وN8N_WEBHOOK_BASE'
    return `n8n رجّع خطأ (${reason ?? 'unknown'})`
  }
  return 'تعذر الإرسال عبر webhook العروض — جرّب تاني'
}

let lastOfferFailure: { status?: number; error?: string; reason?: string } = {}
export const getLastOfferFailure = () => lastOfferFailure

function dataUrlToBlob(dataUrl: string): Blob {
  const [head, b64] = dataUrl.split(',')
  const mime = /data:(.*?);base64/.exec(head)?.[1] || 'image/jpeg'
  const bin = atob(b64)
  const arr = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i)
  return new Blob([arr], { type: mime })
}

/** Clipboard only accepts image/png in most browsers -> redraw through a canvas. */
function toPngBlob(dataUrl: string): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => {
      const c = document.createElement('canvas')
      c.width = img.naturalWidth
      c.height = img.naturalHeight
      const ctx = c.getContext('2d')
      if (!ctx) return reject(new Error('canvas'))
      ctx.drawImage(img, 0, 0)
      c.toBlob((b) => (b ? resolve(b) : reject(new Error('blob'))), 'image/png')
    }
    img.onerror = () => reject(new Error('img'))
    img.src = dataUrl
  })
}

/**
 * Send ONE offer to MANY patients with ONE webhook call.
 * Browser -> /api/n8n gets recipients, saves them in Supabase (offer_recipients) and sends n8n `cli-offer`
 * only { campaign_id, offer_title, text, image_base64 } (NO phone numbers). n8n reads the numbers by
 * campaign_id and loops (Evolution sendMedia/sendText).                      => 'api'
 * /api not reachable (local dev): exactly one recipient -> wa.me fallback (+ image copied to clipboard);
 *   several recipients -> 'skipped' (no tab spam; use `vercel dev`).
 * Webhook reached but rejected/failed => 'failed' (nothing is marked sent).
 * NOTE: wa.me can never attach an image by itself; that is a WhatsApp limitation.
 */
export async function sendOfferWhatsApp(
  recipients: { name: string; phone: string }[],
  text: string,
  imageDataUrl?: string,
  offerTitle = '',
): Promise<SendResult> {
  const list = recipients.map((r) => ({ name: r.name, number: toWhatsAppNumber(r.phone) }))

  const r = await notify('offer.broadcast', {
    recipients: list,
    text,
    offerTitle,
    image: imageDataUrl ? imageDataUrl.split(',')[1] : null,
    mimetype: imageDataUrl ? /data:(.*?);base64/.exec(imageDataUrl)?.[1] || 'image/jpeg' : null,
  })
  if (r.ok) return 'api'
  if (!r.skipped) {
    lastOfferFailure = { status: r.status, error: r.error, reason: r.reason }
    return 'failed'
  }
  if (recipients.length !== 1) return 'skipped'

  let copied = false
  if (imageDataUrl && typeof ClipboardItem !== 'undefined' && navigator.clipboard?.write) {
    try {
      const png = await toPngBlob(imageDataUrl)
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': png })])
      copied = true
    } catch {
      copied = false
    }
  }
  window.open(waLink(recipients[0].phone, text), '_blank', 'noopener')
  return imageDataUrl && copied ? 'clipboard' : 'text-only'
}

export { dataUrlToBlob }
