/**
 * Minimal PDF writer: one full-page JPEG per page (no dependencies).
 * Used to turn HTML documents (invoice, report) into a real .pdf file.
 */
export interface PdfPageImage {
  jpeg: Uint8Array
  /** pixel size of the JPEG */
  wPx: number
  hPx: number
  /** placement on the page, in PDF points (origin = top-left) */
  x: number
  y: number
  w: number
  h: number
}

export const A4_W = 595.28
export const A4_H = 841.89

const enc = new TextEncoder()
const f = (n: number) => n.toFixed(2)

export function buildPdf(pages: PdfPageImage[], pageW = A4_W, pageH = A4_H): Uint8Array {
  const chunks: Uint8Array[] = []
  const offsets: number[] = []
  let size = 0
  const push = (c: Uint8Array | string) => {
    const b = typeof c === 'string' ? enc.encode(c) : c
    chunks.push(b)
    size += b.length
  }
  const obj = (id: number, body: () => void) => {
    offsets[id] = size
    push(`${id} 0 obj\n`)
    body()
    push('\nendobj\n')
  }

  push('%PDF-1.4\n')
  push(new Uint8Array([0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a]))

  // ids: 1 catalog, 2 pages, then per page: page, content, image
  const pageId = (i: number) => 3 + i * 3
  obj(1, () => push('<< /Type /Catalog /Pages 2 0 R >>'))
  obj(2, () =>
    push(`<< /Type /Pages /Count ${pages.length} /Kids [${pages.map((_, i) => `${pageId(i)} 0 R`).join(' ')}] >>`),
  )

  pages.forEach((p, i) => {
    const pid = pageId(i)
    const content = `q ${f(p.w)} 0 0 ${f(p.h)} ${f(p.x)} ${f(pageH - p.y - p.h)} cm /Im0 Do Q`
    obj(pid, () =>
      push(
        `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f(pageW)} ${f(pageH)}] /Resources << /XObject << /Im0 ${pid + 2} 0 R >> >> /Contents ${pid + 1} 0 R >>`,
      ),
    )
    obj(pid + 1, () => {
      push(`<< /Length ${content.length} >>\nstream\n${content}\nendstream`)
    })
    obj(pid + 2, () => {
      push(
        `<< /Type /XObject /Subtype /Image /Width ${p.wPx} /Height ${p.hPx} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.jpeg.length} >>\nstream\n`,
      )
      push(p.jpeg)
      push('\nendstream')
    })
  })

  const total = 3 + pages.length * 3
  const xref = size
  push(`xref\n0 ${total}\n0000000000 65535 f \n`)
  for (let id = 1; id < total; id++) push(`${String(offsets[id]).padStart(10, '0')} 00000 n \n`)
  push(`trailer\n<< /Size ${total} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`)

  const out = new Uint8Array(size)
  let pos = 0
  for (const c of chunks) {
    out.set(c, pos)
    pos += c.length
  }
  return out
}
