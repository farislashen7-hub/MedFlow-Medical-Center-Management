import { buildDocument } from './print'
import { A4_H, A4_W, buildPdf } from './pdf'
import type { PdfPageImage } from './pdf'

/** A4 @ 96dpi — document is laid out at this width, then rasterised. */
const PAGE_PX = 794
const MAX_CANVAS_H = 16000

const CAPTURE_CSS = `html,body{background:#fff}body{width:${PAGE_PX}px;padding:26px 30px;overflow:visible}`

async function mount(html: string, css = '') {
  const iframe = document.createElement('iframe')
  iframe.setAttribute('aria-hidden', 'true')
  iframe.style.cssText = `position:fixed;top:0;left:-${PAGE_PX + 200}px;width:${PAGE_PX}px;height:1200px;border:0;pointer-events:none`
  document.body.appendChild(iframe)
  const doc = iframe.contentDocument
  const win = iframe.contentWindow
  if (!doc || !win) {
    iframe.remove()
    throw new Error('capture: no iframe document')
  }
  doc.open()
  doc.write(buildDocument('capture', html, CAPTURE_CSS + css))
  doc.close()

  const imgs = Array.from(doc.images).map(
    (img) =>
      new Promise<void>((resolve) => {
        if (img.complete) return resolve()
        img.onload = () => resolve()
        img.onerror = () => resolve()
      }),
  )
  const fonts: Promise<unknown> = doc.fonts?.ready ?? Promise.resolve()
  await Promise.race([Promise.all([fonts, ...imgs]), new Promise((r) => window.setTimeout(r, 4000))])
  const height = Math.ceil(doc.body.scrollHeight)
  iframe.style.height = `${height}px`
  return { iframe, body: doc.body, height }
}

async function rasterise(html: string, css: string, maxScale: number): Promise<HTMLCanvasElement> {
  const [{ default: html2canvas }, m] = await Promise.all([import('html2canvas'), mount(html, css)])
  try {
    const scale = Math.max(1, Math.min(maxScale, MAX_CANVAS_H / m.height))
    return await html2canvas(m.body, {
      scale,
      useCORS: true,
      backgroundColor: '#ffffff',
      logging: false,
      width: PAGE_PX,
      height: m.height,
      windowWidth: PAGE_PX,
    })
  } finally {
    m.iframe.remove()
  }
}

/** Single-image render (prescription, etc.) -> JPEG data URL. */
export async function htmlToJpegDataUrl(html: string, css = '', quality = 0.92): Promise<string> {
  const canvas = await rasterise(html, css, 2)
  return canvas.toDataURL('image/jpeg', quality)
}

function dataUrlToBytes(dataUrl: string): Uint8Array {
  const bin = atob(dataUrl.split(',')[1] ?? '')
  const out = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i)
  return out
}

/** true when the pixel row is a single flat colour (no glyphs) -> safe place to cut a page */
function isFlatRow(ctx: CanvasRenderingContext2D, y: number, w: number): boolean {
  const d = ctx.getImageData(0, y, w, 1).data
  const r = d[0],
    g = d[1],
    b = d[2]
  for (let x = 4; x < d.length; x += 16) {
    if (Math.abs(d[x] - r) > 6 || Math.abs(d[x + 1] - g) > 6 || Math.abs(d[x + 2] - b) > 6) return false
  }
  return true
}

/** HTML -> multi-page A4 PDF (pages are cut on blank rows so text is never sliced). */
export async function htmlToPdfBlob(html: string, css = '', quality = 0.85): Promise<Blob> {
  const canvas = await rasterise(html, css, 1.6)
  const W = canvas.width
  const H = canvas.height
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('capture: no 2d context')

  const marginPt = 22
  const contentPt = A4_H - marginPt * 2
  const slicePx = Math.floor((contentPt / A4_W) * W)
  const pages: PdfPageImage[] = []

  let y = 0
  while (y < H) {
    let end = Math.min(H, y + slicePx)
    if (end < H) {
      const floor = end - Math.floor(slicePx * 0.22)
      for (let yy = end; yy > floor; yy--) {
        if (isFlatRow(ctx, yy, W)) {
          end = yy
          break
        }
      }
    }
    const h = end - y
    const page = document.createElement('canvas')
    page.width = W
    page.height = h
    const pctx = page.getContext('2d')
    if (!pctx) throw new Error('capture: no page context')
    pctx.fillStyle = '#fff'
    pctx.fillRect(0, 0, W, h)
    pctx.drawImage(canvas, 0, y, W, h, 0, 0, W, h)
    pages.push({
      jpeg: dataUrlToBytes(page.toDataURL('image/jpeg', quality)),
      wPx: W,
      hPx: h,
      x: 0,
      y: marginPt,
      w: A4_W,
      h: (h / W) * A4_W,
    })
    y = end
  }
  const bytes = buildPdf(pages)
  return new Blob([bytes as BlobPart], { type: 'application/pdf' })
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 10_000)
}

export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onerror = () => reject(new Error('read failed'))
    r.onload = () => resolve(String(r.result).split(',')[1] ?? '')
    r.readAsDataURL(blob)
  })
}

export function safeFilename(name: string): string {
  return name.replace(/[\\/:*?"<>|\s]+/g, '-').replace(/-+/g, '-').slice(0, 80)
}
