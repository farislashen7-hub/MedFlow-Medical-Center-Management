/**
 * تسجيل المريض: بيتحفظ محلياً (db.ts) وبعدين بيتبعت لـ Supabase (جدول patients، migration_05).
 * الباسورد مبيتبعتش. فشل Supabase مبيمنعش التسجيل المحلي، والمريض بيتحط في طابور ويتعاد.
 * المسار: /api/register-patient (service role) ثم احتياطي إدخال مباشر.
 * أعمدة الجدول: full_name, phone (unique), date_of_birth, gender, national_id, blood_type,
 * allergies, chronic_diseases, insurance, address, emergency_contact (نص), email. الـ id بيتولّد في الداتابيز (uuid).
 */
import { supabase } from './supabase'
import type { Patient } from './types'

const orNull = (v: string) => (v && v.trim() ? v.trim() : null)

const QUEUE_KEY = 'medflow.unsynced-patients.v1'
const readQueue = (): string[] => {
  try {
    return JSON.parse(window.localStorage.getItem(QUEUE_KEY) || '[]') as string[]
  } catch {
    return []
  }
}
const writeQueue = (ids: string[]) => {
  try {
    window.localStorage.setItem(QUEUE_KEY, JSON.stringify([...new Set(ids)]))
  } catch {
    /* ignore */
  }
}

/** يبعت المريض لـ Supabase. لو فشل يتحط في طابور ويتعاد تلقائياً عند فتح الموقع (flushUnsyncedPatients). */
export async function syncPatient(p: Patient): Promise<{ ok: boolean; error?: string }> {
  const r = await insertPatient(p)
  const q = readQueue().filter((id) => id !== p.id)
  if (!r.ok && r.error !== 'SUPABASE_NOT_CONFIGURED') {
    console.error('[patients] sync failed (هيتعاد تلقائياً):', r.error)
    q.push(p.id)
  }
  writeQueue(q)
  return r
}

export async function flushUnsyncedPatients(all: Patient[]) {
  for (const id of readQueue()) {
    const p = all.find((x) => x.id === id)
    if (p) await syncPatient(p)
    else writeQueue(readQueue().filter((x) => x !== id))
  }
}

/** الأول من السيرفر (service role: مش بيتأثر بـ RLS)، ولو مش متاح يجرّب إدخال مباشر من المتصفح. */
async function insertPatient(p: Patient): Promise<{ ok: boolean; error?: string }> {
  const e = p.emergency
  const emergency = [e?.name, e?.relation, e?.phone].filter(Boolean).join(' - ')

  try {
    const res = await fetch('/api/register-patient', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: p.name,
        phone: p.phone,
        email: p.email,
        birthDate: p.birthDate,
        gender: p.gender,
        nationalId: p.nationalId,
        bloodType: p.bloodType,
        allergies: p.allergies,
        chronic: p.chronic,
        insurance: p.insurance,
        address: p.address,
        emergency,
      }),
    })
    if (res.ok) return { ok: true }
    if (res.status !== 404 && res.status !== 503) {
      const d = (await res.json().catch(() => ({}))) as { error?: string; code?: string; detail?: string }
      // 422 = بيانات مرفوضة: مفيش فايدة من إعادة المحاولة بنفس الداتا
      return { ok: false, error: `${d.error ?? res.status}${d.code ? ` ${d.code}` : ''}${d.detail ? `: ${d.detail}` : ''}` }
    }
  } catch {
    /* مفيش /api (npm run dev) أو مفيش شبكة: نكمل بالإدخال المباشر */
  }
  return insertPatientDirect(p, emergency)
}

async function insertPatientDirect(p: Patient, emergency: string): Promise<{ ok: boolean; error?: string }> {
  if (!supabase) return { ok: false, error: 'SUPABASE_NOT_CONFIGURED' }

  // بدون .select(): الزائر مالوش صلاحية قراءة
  const { error } = await supabase.from('patients').insert({
    full_name: p.name,
    phone: p.phone,
    email: p.email || '',
    date_of_birth: /^\d{4}-\d{2}-\d{2}$/.test(p.birthDate) ? p.birthDate : null,
    gender: p.gender,
    national_id: orNull(p.nationalId),
    blood_type: orNull(p.bloodType),
    allergies: orNull(p.allergies),
    chronic_diseases: orNull(p.chronic),
    insurance: orNull(p.insurance),
    address: orNull(p.address),
    emergency_contact: orNull(emergency),
  })
  // 23505 = نفس الرقم اتسجل قبل كده في Supabase
  if (error && error.code !== '23505') {
    console.error('[patients] supabase', error.code, error.message)
    return { ok: false, error: `${error.code}: ${error.message}` }
  }
  return { ok: true }
}
