/**
 * حضور وغياب الأطباء — حسابات بحتة (من غير حالة).
 *
 * اليوم المحسوب = يوم من doctor.days (أو أي يوم له سجل). ترتيب الأولوية لكل يوم:
 *   1) سجل حضور موجود (الطبيب سجّل بنفسه أو الإدارة عدّلت)  -> نفس حالته
 *   2) الطبيب كان معلن «عندي ظرف» في اليوم ده (من سجل الظروف) -> «ظرف / إجازة» (مش غياب)
 *   3) عنده كشف مكتمل في اليوم ده من غير سجل                  -> «حضر» (محسوبة تلقائياً)
 *   4) النهارده                                               -> «لم يسجل بعد»
 *   5) يوم فات من غير أي حاجة                                  -> «غياب»
 */
import type { Appointment, AttendanceStatus, Doctor, DoctorAttendance, DoctorLeave } from './types'
import { addDays, fromDateKey, toDateKey } from './format'

/** دقايق السماح بعد بداية الدوام قبل ما يتحسب تأخير */
export const LATE_GRACE_MIN = 15

export type DayStatus = AttendanceStatus | 'pending'

export interface AttendanceData {
  records: DoctorAttendance[]
  leaves: DoctorLeave[]
  appointments: Appointment[]
}

export interface DayRow {
  date: string
  status: DayStatus
  checkIn: string
  checkOut: string
  note: string
  /** true لو الحالة متحسبة تلقائياً (مفيش سجل صريح) */
  derived: boolean
}

export const statusLabel: Record<DayStatus, string> = {
  present: 'حضر',
  late: 'متأخر',
  absent: 'غائب',
  leave: 'ظرف / إجازة',
  pending: 'لم يسجل بعد',
}

export const statusTone: Record<DayStatus, 'green' | 'amber' | 'rose' | 'sky' | 'slate'> = {
  present: 'green',
  late: 'amber',
  absent: 'rose',
  leave: 'sky',
  pending: 'slate',
}

export const recordId = (doctorId: string, date: string) => `${doctorId}_${date}`

const toMin = (hhmm: string) => {
  const [h, m] = hhmm.split(':').map(Number)
  return (h || 0) * 60 + (m || 0)
}

export const nowHHmm = (d = new Date()) =>
  `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`

/** الحضور بعد بداية الدوام بأكتر من فترة السماح؟ */
export function isLate(doctor: Doctor, checkIn: string) {
  return toMin(checkIn) > doctor.startHour * 60 + LATE_GRACE_MIN
}

/** آخر يوم فعلي للظرف (لو الطبيب رجع بدري بنقفل عند يوم الرجوع) */
function leaveEnd(l: DoctorLeave): string {
  const returned = l.endedAt ? toDateKey(new Date(l.endedAt)) : ''
  if (l.until && returned) return l.until < returned ? l.until : returned
  return l.until || returned
}

/** الطبيب في ظرف معلن في اليوم ده؟ (بيرجع السجل) */
export function leaveOn(leaves: DoctorLeave[], doctorId: string, dateKey: string): DoctorLeave | undefined {
  return leaves.find((l) => {
    if (l.doctorId !== doctorId || dateKey < l.since) return false
    const end = leaveEnd(l)
    return !end || dateKey <= end
  })
}

/** أول يوم بيتحسب منه الحضور */
export function trackingStart(doctor: Doctor, data: Pick<AttendanceData, 'records' | 'leaves'>): string {
  if (doctor.joinedAt) return doctor.joinedAt
  const dates = [
    ...data.records.filter((r) => r.doctorId === doctor.id).map((r) => r.date),
    ...data.leaves.filter((l) => l.doctorId === doctor.id).map((l) => l.since),
  ].sort()
  return dates[0] ?? toDateKey(new Date())
}

/** صفوف الأيام (المجدولة + أي يوم له سجل) بين from و to شامل */
export function dayRows(doctor: Doctor, data: AttendanceData, from: string, to: string, now = new Date()): DayRow[] {
  const today = toDateKey(now)
  const first = trackingStart(doctor, data)
  const start = from > first ? from : first
  const end = to < today ? to : today
  const byDate = new Map<string, DoctorAttendance>()
  data.records.forEach((r) => {
    if (r.doctorId === doctor.id) byDate.set(r.date, r)
  })
  const completedDays = new Set(
    data.appointments.filter((a) => a.doctorId === doctor.id && a.status === 'completed').map((a) => a.date),
  )

  const rows: DayRow[] = []
  for (let d = fromDateKey(start); toDateKey(d) <= end; d = addDays(d, 1)) {
    const key = toDateKey(d)
    const rec = byDate.get(key)
    if (rec) {
      rows.push({ date: key, status: rec.status, checkIn: rec.checkIn, checkOut: rec.checkOut, note: rec.note, derived: false })
      continue
    }
    if (!doctor.days.includes(d.getDay())) continue
    const leave = leaveOn(data.leaves, doctor.id, key)
    if (leave) {
      rows.push({ date: key, status: 'leave', checkIn: '', checkOut: '', note: leave.reason, derived: true })
    } else if (completedDays.has(key)) {
      rows.push({ date: key, status: 'present', checkIn: '', checkOut: '', note: 'محسوب من كشف مكتمل', derived: true })
    } else {
      rows.push({ date: key, status: key === today ? 'pending' : 'absent', checkIn: '', checkOut: '', note: '', derived: true })
    }
  }
  return rows
}

export interface AttendanceSummary {
  doctorId: string
  /** أيام الدوام المحسوبة (من غير «لم يسجل بعد») */
  counted: number
  present: number
  late: number
  absent: number
  /** أيام الظرف/الإجازة */
  leave: number
  pending: number
  /** عدد مرات «عندي ظرف» (عدد الإعلانات اللي بدأت في الفترة) */
  leaveEvents: number
  /** أسباب الظروف: السبب -> عدد المرات */
  leaveReasons: Record<string, number>
  /** نسبة الحضور = (حضر + متأخر) ÷ (حضر + متأخر + غائب) — الظرف مش بيتحسب غياب. null لو مفيش أيام */
  rate: number | null
  /** نسبة الالتزام بالمواعيد = حضر في الميعاد ÷ (حضر + متأخر) */
  punctuality: number | null
  avgCheckIn: string | null
  /** أطول سلسلة غياب متتالية (بالأيام المجدولة) */
  longestAbsentStreak: number
  lastAbsence: string | null
  absentByWeekday: number[]
  rows: DayRow[]
}

export function summarize(doctor: Doctor, data: AttendanceData, from: string, to: string, now = new Date()): AttendanceSummary {
  const rows = dayRows(doctor, data, from, to, now)
  const count = (s: DayStatus) => rows.filter((r) => r.status === s).length
  const present = count('present')
  const late = count('late')
  const absent = count('absent')
  const leave = count('leave')
  const pending = count('pending')
  const worked = present + late
  const denominator = worked + absent

  const checkIns = rows.filter((r) => r.checkIn && (r.status === 'present' || r.status === 'late')).map((r) => toMin(r.checkIn))
  const avg = checkIns.length ? Math.round(checkIns.reduce((s, m) => s + m, 0) / checkIns.length) : null

  let streak = 0
  let best = 0
  const absentByWeekday = [0, 0, 0, 0, 0, 0, 0]
  let lastAbsence: string | null = null
  rows.forEach((r) => {
    if (r.status === 'absent') {
      streak++
      best = Math.max(best, streak)
      absentByWeekday[fromDateKey(r.date).getDay()]++
      lastAbsence = r.date
    } else if (r.status !== 'pending') {
      streak = 0
    }
  })

  const periodLeaves = data.leaves.filter((l) => l.doctorId === doctor.id && l.since >= from && l.since <= to)
  const leaveReasons: Record<string, number> = {}
  periodLeaves.forEach((l) => {
    leaveReasons[l.reason] = (leaveReasons[l.reason] ?? 0) + 1
  })

  return {
    doctorId: doctor.id,
    counted: denominator + leave,
    present,
    late,
    absent,
    leave,
    pending,
    leaveEvents: periodLeaves.length,
    leaveReasons,
    rate: denominator ? Math.round((worked / denominator) * 100) : null,
    punctuality: worked ? Math.round((present / worked) * 100) : null,
    avgCheckIn: avg === null ? null : `${String(Math.floor(avg / 60)).padStart(2, '0')}:${String(avg % 60).padStart(2, '0')}`,
    longestAbsentStreak: best,
    lastAbsence,
    absentByWeekday,
    rows,
  }
}

/** تقييم نصي حسب نسبة الحضور */
export function gradeOf(rate: number | null): { label: string; tone: 'green' | 'brand' | 'amber' | 'rose' | 'slate' } {
  if (rate === null) return { label: 'لا بيانات', tone: 'slate' }
  if (rate >= 95) return { label: 'ممتاز', tone: 'green' }
  if (rate >= 85) return { label: 'جيد', tone: 'brand' }
  if (rate >= 70) return { label: 'يحتاج متابعة', tone: 'amber' }
  return { label: 'مقلق', tone: 'rose' }
}

/** نسب الحضور الأسبوعية (لرسم الاتجاه) لكل الأطباء مجمّعة */
export function weeklyTrend(
  doctors: Doctor[],
  data: AttendanceData,
  weeks: number,
  now = new Date(),
): { label: string; value: number }[] {
  const out: { label: string; value: number }[] = []
  for (let w = weeks - 1; w >= 0; w--) {
    const to = toDateKey(addDays(now, -w * 7))
    const from = toDateKey(addDays(now, -w * 7 - 6))
    let worked = 0
    let absent = 0
    doctors.forEach((d) => {
      const s = summarize(d, data, from, to, now)
      worked += s.present + s.late
      absent += s.absent
    })
    const total = worked + absent
    const d = fromDateKey(to)
    out.push({ label: `${d.getDate()}/${d.getMonth() + 1}`, value: total ? Math.round((worked / total) * 100) : 0 })
  }
  return out
}

/** حالة النهارده للطبيب: صف اليوم أو null لو مش يوم دوامه */
export function todayRow(doctor: Doctor, data: AttendanceData, now = new Date()): DayRow | null {
  const key = toDateKey(now)
  return dayRows(doctor, data, key, key, now)[0] ?? null
}
