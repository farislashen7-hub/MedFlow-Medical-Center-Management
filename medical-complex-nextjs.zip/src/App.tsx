import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import { AuthProvider } from './lib/auth'
import { ToastProvider } from './components/Toast'
import { BlockRole, Protected } from './components/Protected'
import Landing from './pages/Landing'
import Specialties from './pages/Specialties'
import Doctors from './pages/Doctors'
import Contact from './pages/Contact'
import Reviews from './pages/Reviews'
import Login from './pages/Login'
import ForgotPassword from './pages/ForgotPassword'
import StaffLogin from './pages/StaffLogin'
import Register from './pages/Register'
import Booking from './pages/Booking'
import PatientDashboard from './pages/PatientDashboard'
import DoctorDashboard from './pages/DoctorDashboard'
import AdminDashboard from './pages/AdminDashboard'

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/specialties" element={<Specialties />} />
            <Route path="/doctors" element={<Doctors />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/reviews" element={<Reviews />} />
            <Route path="/login" element={<Login />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/staff" element={<StaffLogin />} />
            <Route path="/register" element={<Register />} />
            <Route
              path="/book"
              element={
                <BlockRole role="doctor">
                  <Booking />
                </BlockRole>
              }
            />
            <Route
              path="/patient"
              element={
                <Protected role="patient">
                  <PatientDashboard />
                </Protected>
              }
            />
            <Route
              path="/doctor"
              element={
                <Protected role="doctor">
                  <DoctorDashboard />
                </Protected>
              }
            />
            <Route
              path="/admin"
              element={
                <Protected role="admin">
                  <AdminDashboard />
                </Protected>
              }
            />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  )
}
